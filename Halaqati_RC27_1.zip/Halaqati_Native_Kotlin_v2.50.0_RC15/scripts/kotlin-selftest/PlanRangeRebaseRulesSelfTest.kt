import com.mohammedsamir.halaqati.plans.PlanRangeRebaseRules
import com.mohammedsamir.halaqati.plans.PlanRangeRebaseRules.Status
import com.mohammedsamir.halaqati.plans.SmartPlanEngine
import com.mohammedsamir.halaqati.quran.QuranLocation
import java.time.LocalDate

private fun rec(date: String, ss: Int, sa: Int, es: Int, ea: Int, eval: String = "excellent", type: String = "new_hifz") =
    SmartPlanEngine.Recitation(
        id = "$date-$es-$ea", studentId = "s", activityType = type, date = LocalDate.parse(date),
        startSurah = ss, startAyah = sa, endSurah = es, endAyah = ea, evaluation = eval, createdAt = date,
    )

private fun check(ok: Boolean, msg: String) { if (!ok) { println("FAIL: $msg"); kotlin.system.exitProcess(1) } }

fun main() {
    val rev = "reverse_surahs_forward_ayahs"
    val fwd = "forward_surahs_forward_ayahs"
    val history = listOf(
        rec("2026-09-21", 24, 59, 24, 64),
        rec("2026-09-22", 23, 1, 23, 27),
        rec("2026-10-04", 23, 28, 23, 74),
        rec("2026-10-11", 22, 56, 22, 72),
        rec("2026-10-12", 22, 73, 22, 78, eval = "repeat"),
    )
    val start = LocalDate.parse("2026-10-01")
    // stale end: student at 22:72 beyond the carried range end 22:27 (reverse route)
    val stale = PlanRangeRebaseRules.diagnose(history, start, rev, QuranLocation(26, 184), QuranLocation(22, 27))
    check(stale.status == Status.STALE_END, "stale end detected")
    check(stale.expectedStart == QuranLocation(23, 28), "expected start is right after the last pre-month anchor, got ${stale.expectedStart}")
    check(stale.latestEnd == QuranLocation(22, 72), "failed (repeat) recitation must not move the anchor")
    // healthy: range end ahead of the student
    val ok = PlanRangeRebaseRules.diagnose(history, start, rev, QuranLocation(23, 28), QuranLocation(17, 50))
    check(ok.status == Status.OK, "healthy plan stays OK, got ${ok.status}")
    // start mismatch only
    val mismatch = PlanRangeRebaseRules.diagnose(history, start, rev, QuranLocation(26, 184), QuranLocation(17, 50))
    check(mismatch.status == Status.START_MISMATCH, "start mismatch flagged")
    // no end configured: never stale
    val open = PlanRangeRebaseRules.diagnose(history, start, rev, null, null)
    check(open.status == Status.OK, "open ended plan OK")
    // forward route
    val f = listOf(rec("2026-09-30", 2, 1, 2, 50), rec("2026-10-05", 2, 51, 2, 120))
    val fs = PlanRangeRebaseRules.diagnose(f, start, fwd, QuranLocation(2, 1), QuranLocation(2, 100))
    check(fs.status == Status.STALE_END && fs.expectedStart == QuranLocation(2, 51), "forward route stale end, got $fs")
    // no hifz at all
    val none = PlanRangeRebaseRules.diagnose(emptyList(), start, rev, QuranLocation(26, 184), QuranLocation(22, 27))
    check(none.status == Status.OK, "no recitations -> nothing to rebase")
    // start-of-surah wrap: anchor at last ayah moves to next surah along route
    val wrap = listOf(rec("2026-09-30", 23, 1, 23, 118))
    check(PlanRangeRebaseRules.expectedStart(wrap, start, rev) == QuranLocation(22, 1), "reverse wrap goes to previous surah")
    // month first recitation when nothing before the month
    val newbie = listOf(rec("2026-10-03", 30, 1, 30, 20))
    check(PlanRangeRebaseRules.expectedStart(newbie, start, rev) == QuranLocation(30, 1), "falls back to first recitation start")
    check(PlanRangeRebaseRules.emptyHifzDutyMessage(null, null, rev).contains("لا يوجد تسميع"), "message: no anchor")
    check(PlanRangeRebaseRules.emptyHifzDutyMessage(QuranLocation(22, 72), QuranLocation(22, 27), rev).contains("إعادة ضبط"), "message: stale end")
    check(PlanRangeRebaseRules.emptyHifzDutyMessage(QuranLocation(22, 72), QuranLocation(17, 1), rev).contains("هدف الخطة"), "message: generic")
    check(PlanRangeRebaseRules.normalizePages(376, 332) == (332 to 376), "descending pages are stored ascending")
    check(PlanRangeRebaseRules.normalizePages(332, 376) == (332 to 376), "ascending pages stay")
    check(PlanRangeRebaseRules.normalizePages(null, 376) == (null to 376), "null side untouched")
    println("PlanRangeRebaseRules self-tests passed")
}
