#!/usr/bin/env python3
"""RC26 static gate: plan range rebase, empty-duty message, home card wiring."""
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
base = 'app/src/main/java/com/mohammedsamir/halaqati/'
errors = []
def read(rel):
    p = root / rel
    if not p.exists():
        errors.append('missing ' + rel); return ''
    return p.read_text(encoding='utf-8', errors='ignore')
def need(c, m):
    if not c: errors.append(m)
rules = read(base + 'plans/PlanRangeRebaseRules.kt')
for t in ('STALE_END', 'START_MISMATCH', 'fun diagnose(', 'fun expectedStart(', 'emptyHifzDutyMessage'):
    need(t in rules, 'rules missing ' + t)
repo = read(base + 'data/HalaqatiRepository.kt')
for t in ('fun planRangeRebasePreviews(', 'fun applyPlanRangeRebase(', 'rc26_rebased_plans', '"hifz", "review", "sard"'):
    need(t in repo, 'repository missing ' + t)
need('PlanRangeRebaseDialog(' in read(base + 'ui/screens/CoreScreens.kt'), 'plans screen does not open the rebase dialog')
need('ضبط النطاق' in read(base + 'ui/screens/CoreScreens.kt'), 'rebase button label missing')
need('emptyHifzDutyMessage' in read(base + 'ui/screens/CoreScreens.kt'), 'empty duty message not wired')
dash = read(base + 'ui/screens/DashboardScreen.kt')
need('PlansNeedAttentionCard' in dash, 'home card not wired')
dlg = read(base + 'ui/screens/PlanRangeRebaseDialog.kt')
need('تطبيق' in dlg and 'لا يتغير شيء قبل' in dlg, 'dialog must preview before applying')
need('normalizePages' in rules and repo.count('normalizePages') >= 5, 'page range must be stored ascending in every plan write path')
need('a > b' in read(base + 'data/SyncErrorRules.kt'), 'outbox heal for descending page range missing')
need('PlanRangeRebaseRulesSelfTest' in read('scripts/run-kotlin-selftests.sh'), 'self-test not registered')
need(read('RELEASE_2_62_0_RC26_PLAN_RANGE_AR.md') != '', 'release note missing')
if errors:
    print('\n'.join('FAIL: ' + e for e in errors)); sys.exit(1)
print('RC26 plan range check passed')
