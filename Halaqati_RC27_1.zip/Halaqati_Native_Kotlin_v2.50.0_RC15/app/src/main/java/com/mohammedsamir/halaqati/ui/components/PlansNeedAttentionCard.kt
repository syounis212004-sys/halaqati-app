package com.mohammedsamir.halaqati.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.plans.PlanRangeRebaseRules
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** RC26 home card (admin/supervisor/teacher): students whose smart plan range no longer matches them. */
@Composable
fun PlansNeedAttentionCard(modifier: Modifier = Modifier, onOpenPlans: () -> Unit) {
    var names by remember { mutableStateOf<List<String>>(emptyList()) }
    LaunchedEffect(Unit) {
        runCatching {
            withContext(Dispatchers.IO) {
                if (!AppGraph.repo.online()) emptyList()
                else AppGraph.repo.planRangeRebasePreviews()
                    .filter { it.status == PlanRangeRebaseRules.Status.STALE_END }
                    .map { it.studentName }
            }
        }.onSuccess { names = it }
    }
    if (names.isEmpty()) return
    Surface(
        modifier = modifier.fillMaxWidth().clickable(onClick = onOpenPlans),
        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .6f),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("خطط تحتاج ضبط النطاق: ${names.size}", fontWeight = FontWeight.Bold)
            Text(
                names.take(5).joinToString("، ") + if (names.size > 5) " …" else "",
                style = MaterialTheme.typography.bodySmall,
            )
            Text("افتح الخطط ← «ضبط النطاق» ليظهر مقرر هؤلاء الطلاب.", style = MaterialTheme.typography.labelMedium)
        }
    }
}
