package com.mohammedsamir.halaqati.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.plans.OrgInsightRules
import com.mohammedsamir.halaqati.ui.theme.statusColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.time.LocalDate

/** Insight data is live: refetch at most every 5 minutes (repo.table would otherwise serve its cache forever). */
private object InsightFreshness {
    private val last = HashMap<String, Long>()
    @Synchronized fun dueFor(key: String): Boolean {
        val now = System.currentTimeMillis()
        val due = now - (last[key] ?: 0L) > 5 * 60_000L
        if (due) last[key] = now
        return due
    }
}

private fun JSONArray.objs() = (0 until length()).mapNotNull { optJSONObject(it) }

private fun openGuardianMessage(context: Context, phone: String?, message: String) {
    val clean = phone?.filter { it.isDigit() || it == '+' }.orEmpty()
    val intent = if (clean.isNotBlank()) {
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$clean")).putExtra("sms_body", message)
    } else {
        Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, message), "إرسال رسالة لولي الأمر")
    }
    runCatching { context.startActivity(intent) }
}

/** RC27 home card: students absent from 3+ consecutive sessions, with a ready guardian message. */
@Composable
fun AbsenceStreakCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var rows by remember { mutableStateOf<List<Triple<String, Int, String?>>>(emptyList()) } // name, streak, phone
    var halaqaOf by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        runCatching {
            withContext(Dispatchers.IO) {
                if (!AppGraph.repo.online()) return@withContext emptyList<Triple<String, Int, String?>>() to emptyMap<String, String>()
                val from = LocalDate.now().minusDays(60).toString()
                val arr = AppGraph.repo.table(
                    "attendance_records",
                    "select=student_id,status,sessions!inner(session_date,status)&sessions.session_date=gte.$from&limit=5000",
                    forceRefresh = InsightFreshness.dueFor("absence"),
                )
                val att = arr.objs().mapNotNull { o ->
                    val s = o.optJSONObject("sessions") ?: return@mapNotNull null
                    OrgInsightRules.Attendance(o.optString("student_id"), s.optString("session_date"), o.optString("status"), s.optString("status") == "cancelled")
                }
                val students = AppGraph.repo.students(forceRefresh = false).filter { it.status == "active" }.associateBy { it.id }
                val halaqas = AppGraph.repo.table("halaqas", "select=id,name&limit=200").objs().associate { it.optString("id") to it.optString("name") }
                val streaks = OrgInsightRules.absenceStreaks(att).filter { it.studentId in students }
                streaks.map { st -> Triple(students.getValue(st.studentId).fullName, st.count, students.getValue(st.studentId).guardianPhone) } to
                    streaks.associate { st -> students.getValue(st.studentId).fullName to (halaqas[students.getValue(st.studentId).halaqaId].orEmpty()) }
            }
        }.onSuccess { (r, h) -> rows = r; halaqaOf = h }
    }
    if (rows.isEmpty()) return
    val (bg, fg) = statusColors("warning")
    Surface(modifier = modifier.fillMaxWidth(), color = bg, contentColor = fg, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth().clickable { expanded = !expanded }, verticalAlignment = Alignment.CenterVertically) {
                Text("غياب متكرر: ${rows.size} طالب", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (expanded) "إخفاء" else "عرض", style = MaterialTheme.typography.labelMedium)
            }
            if (!expanded) {
                Text(rows.take(4).joinToString("، ") { it.first } + if (rows.size > 4) " …" else "", style = MaterialTheme.typography.bodySmall)
            } else {
                rows.take(15).forEach { (name, count, phone) ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(name, fontWeight = FontWeight.SemiBold)
                            Text("غاب $count جلسات متتالية", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { openGuardianMessage(context, phone, OrgInsightRules.guardianMessage(name, count, halaqaOf[name])) }) {
                            Text("رسالة للولي")
                        }
                    }
                }
            }
        }
    }
}

/** RC27 home card (admin/supervisor): this month's halaqas side by side. */
@Composable
fun HalaqaComparisonCard(modifier: Modifier = Modifier) {
    var stats by remember { mutableStateOf<List<OrgInsightRules.HalaqaStats>>(emptyList()) }
    var names by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var expanded by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        runCatching {
            withContext(Dispatchers.IO) {
                if (!AppGraph.repo.online()) return@withContext emptyList<OrgInsightRules.HalaqaStats>() to emptyMap<String, String>()
                val from = LocalDate.now().withDayOfMonth(1).toString()
                val fresh = InsightFreshness.dueFor("compare")
                val halaqas = AppGraph.repo.table("halaqas", "select=id,name,active&order=name.asc&limit=200").objs().filter { it.optBoolean("active", true) }
                if (halaqas.size < 2) return@withContext emptyList<OrgInsightRules.HalaqaStats>() to emptyMap<String, String>()
                val sessions = AppGraph.repo.table("sessions", "select=id,halaqa_id,session_date,status&session_date=gte.$from&limit=2000", forceRefresh = fresh).objs().map {
                    OrgInsightRules.HalaqaSession(it.optString("halaqa_id"), it.optString("session_date"), it.optString("status") == "cancelled")
                }
                val att = AppGraph.repo.table(
                    "attendance_records",
                    "select=status,sessions!inner(session_date,halaqa_id,status)&sessions.session_date=gte.$from&limit=5000",
                    forceRefresh = fresh,
                ).objs().mapNotNull { o ->
                    val s = o.optJSONObject("sessions") ?: return@mapNotNull null
                    if (s.optString("status") == "cancelled") null else OrgInsightRules.HalaqaAttendance(s.optString("halaqa_id"), o.optString("status"))
                }
                val rec = AppGraph.repo.table(
                    "recitation_entries",
                    "select=activity_type,pages_count,evaluation,sessions!inner(session_date,halaqa_id,status)&sessions.session_date=gte.$from&limit=5000",
                    forceRefresh = fresh,
                ).objs().mapNotNull { o ->
                    val s = o.optJSONObject("sessions") ?: return@mapNotNull null
                    if (s.optString("status") == "cancelled") null
                    else OrgInsightRules.HalaqaRecitation(s.optString("halaqa_id"), o.optString("activity_type"), o.optDouble("pages_count", 0.0), o.optString("evaluation"))
                }
                val students = AppGraph.repo.students(forceRefresh = false).filter { it.status == "active" }.groupBy { it.halaqaId.orEmpty() }.mapValues { it.value.size }
                OrgInsightRules.compare(halaqas.map { it.optString("id") }, students, sessions, att, rec) to
                    halaqas.associate { it.optString("id") to it.optString("name") }
            }
        }.onSuccess { (s, n) -> stats = s; names = n }
    }
    if (stats.isEmpty()) return
    Surface(modifier = modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth().clickable { expanded = !expanded }, verticalAlignment = Alignment.CenterVertically) {
                Text("مقارنة الحلقات هذا الشهر", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (expanded) "إخفاء" else "عرض", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
            if (expanded) {
                stats.forEach { s ->
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(names[s.halaqaId].orEmpty().ifBlank { "حلقة" }, fontWeight = FontWeight.SemiBold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                InsightStat("الحضور", s.attendancePercent?.let { "$it٪" } ?: "—", Modifier.weight(1f))
                                InsightStat("صفحات/طالب", "%.1f".format(s.pagesPerStudent), Modifier.weight(1f))
                                InsightStat("الجودة", s.qualityPercent?.let { "$it٪" } ?: "—", Modifier.weight(1f))
                                InsightStat("الجلسات", s.sessions.toString(), Modifier.weight(1f))
                            }
                            Text(
                                "حفظ ${"%.0f".format(s.hifzPages)} ص · مراجعة وتثبيت وسرد ${"%.0f".format(s.reviewPages)} ص · ${s.students} طالبًا",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InsightStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
