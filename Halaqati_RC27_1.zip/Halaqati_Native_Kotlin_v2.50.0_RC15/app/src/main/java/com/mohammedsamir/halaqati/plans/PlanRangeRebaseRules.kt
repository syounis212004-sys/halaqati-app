package com.mohammedsamir.halaqati.plans

import com.mohammedsamir.halaqati.quran.QuranLocation
import java.time.LocalDate

/**
 * RC26 pure rules: detect a monthly hifz plan whose stored Quran range no longer matches where the
 * student really is, and decide the corrected start. A plan rolled into a new month keeps last
 * month's absolute range; a student who passes that end (or started elsewhere) got no daily duty and
 * the engine stopped counting pages outside the old range.
 */
object PlanRangeRebaseRules {
    enum class Status { OK, STALE_END, START_MISMATCH, NO_ANCHOR }

    data class Diagnosis(
        val status: Status,
        val latestEnd: QuranLocation?,
        val expectedStart: QuranLocation?,
    )

    private fun isReverse(route: String) = route == "reverse_surahs_forward_ayahs"

    /**
     * smart_plans_check2 requires range_end_page >= range_start_page. A reverse-route range (An-Nas toward
     * Al-Baqarah) naturally starts on a higher page than it ends, so it was rejected with SQLSTATE 23514
     * and the edit stayed blocked in the Outbox. Always store the pair ascending.
     */
    fun normalizePages(start: Int?, end: Int?): Pair<Int?, Int?> =
        if (start != null && end != null && start > end) end to start else start to end

    /** Monotonic position along the route (bigger = further along). */
    fun position(location: QuranLocation, route: String): Long {
        val order = if (isReverse(route)) 200 - location.surah else location.surah
        return order * 1000L + location.ayah
    }

    private fun isPassing(evaluation: String?): Boolean =
        evaluation.orEmpty().lowercase() !in setOf("repeat", "weak", "إعادة", "ضعيف")

    private fun hifzEnds(recitations: List<SmartPlanEngine.Recitation>): List<SmartPlanEngine.Recitation> =
        recitations.filter {
            SmartPlanActivityRules.activityMatches("hifz", it.activityType) &&
                it.endSurah != null && it.endAyah != null && isPassing(it.evaluation)
        }

    private fun latest(list: List<SmartPlanEngine.Recitation>): SmartPlanEngine.Recitation? =
        list.maxWithOrNull(compareBy<SmartPlanEngine.Recitation> { it.date }.thenBy { it.createdAt })

    fun latestEnd(recitations: List<SmartPlanEngine.Recitation>): QuranLocation? =
        latest(hifzEnds(recitations))?.let { QuranLocation(it.endSurah!!, it.endAyah!!) }

    /** First location of the month: right after the last accepted hifz before the plan month began. */
    fun expectedStart(recitations: List<SmartPlanEngine.Recitation>, planStart: LocalDate, route: String): QuranLocation? {
        val ends = hifzEnds(recitations)
        latest(ends.filter { it.date < planStart })?.let { prev ->
            return SmartPlanActivityRules.nextLocation(QuranLocation(prev.endSurah!!, prev.endAyah!!), route)
        }
        val first = ends.filter { it.date >= planStart }
            .minWithOrNull(compareBy<SmartPlanEngine.Recitation> { it.date }.thenBy { it.createdAt })
        return first?.takeIf { it.startSurah != null && it.startAyah != null }
            ?.let { QuranLocation(it.startSurah!!, it.startAyah!!) }
    }

    fun diagnose(
        recitations: List<SmartPlanEngine.Recitation>,
        planStart: LocalDate,
        route: String,
        rangeStart: QuranLocation?,
        rangeEnd: QuranLocation?,
    ): Diagnosis {
        val latestEnd = latestEnd(recitations)
        val expected = expectedStart(recitations, planStart, route)
        if (rangeEnd != null && latestEnd != null && position(latestEnd, route) >= position(rangeEnd, route)) {
            return Diagnosis(if (expected == null) Status.NO_ANCHOR else Status.STALE_END, latestEnd, expected)
        }
        if (expected != null && rangeStart != null && expected != rangeStart) {
            return Diagnosis(Status.START_MISMATCH, latestEnd, expected)
        }
        return Diagnosis(Status.OK, latestEnd, expected)
    }

    /** Why the smart daily hifz duty is empty, in plain Arabic; never a bare "no amount required". */
    fun emptyHifzDutyMessage(latestEnd: QuranLocation?, rangeEnd: QuranLocation?, route: String): String = when {
        latestEnd == null -> "لا يوجد تسميع حفظ سابق لتحديد نقطة البداية. سجّل أول تسميع للطالب ليظهر المقرر."
        rangeEnd != null && position(latestEnd, route) >= position(rangeEnd, route) ->
            "تجاوز الطالب نهاية نطاق خطته القديم. اضغط «إعادة ضبط نطاق الشهر» في شاشة الخطط ليظهر مقرره."
        else -> "لم يُحسب مقدار الحفظ لهذا اليوم. راجع هدف الخطة وأيام الدوام."
    }
}
