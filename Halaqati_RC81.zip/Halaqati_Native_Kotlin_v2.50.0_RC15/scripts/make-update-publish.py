from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.28',
    'versionCode':28928,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "الرئيسية: بطاقة واحدة تجمع التحية والآية مع بطاقة اليوم",
        "أرقام «حاضر اليوم / بانتظارك / أتمّ التسميع» تُحسب من الواقع: كل من سمّع اليوم وكل من سُجّل حضوره، لا المجدولين فقط",
        "بطاقة إدارة الجمعيات: عنوان وسطر مختصر («جمعية واحدة · حلقتان») دون سطر الأسهم",
        "الهيكل الإداري: إزالة مسؤول الجمعية والمشرفين والمحفّظين من الجمعية، وفصل الحلقات عنها، مع تأكيد قبل التنفيذ ودون حذف أي حساب أو بيانات",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
