@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import com.mohammedsamir.halaqati.R
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens
import com.mohammedsamir.halaqati.ui.auth.NativeGoogleSignIn
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
    error: String? = null,
    onLogin: (String, String) -> Unit,
    onRegister: (String, String, String, String, String) -> Unit,
    onGoogleIdToken: (String, String) -> Unit,
    onGoogleOAuthUrl: () -> String,
    onResetPassword: (String, (String) -> Unit) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    var requestedRole by remember { mutableStateOf("guardian") }
    var resetDialog by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    var googleBusy by remember { mutableStateOf(false) }
    var brandVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { brandVisible = true }

    Surface(color = MaterialTheme.colorScheme.background) {
        Box(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 20.dp, vertical = 28.dp),
            contentAlignment = Alignment.Center,
        ) {
            Card(
                Modifier.widthIn(max = 520.dp).fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 22.dp, vertical = 22.dp),
                ) {
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            AnimatedVisibility(
                                visible = brandVisible,
                                enter = fadeIn(tween(260)) + scaleIn(tween(320), initialScale = .88f),
                            ) {
                                Surface(color = Color.White.copy(alpha = .10f), shape = RoundedCornerShape(22.dp)) {
                                    Image(
                                        painter = painterResource(R.drawable.launcher_legacy),
                                        contentDescription = "شعار حلقاتي",
                                        modifier = Modifier.padding(7.dp).size(66.dp).clip(RoundedCornerShape(18.dp)),
                                    )
                                }
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("حلقاتي", style = MaterialTheme.typography.headlineLarge, color = Color.White, fontWeight = FontWeight.ExtraBold)
                                Text("إدارة ومتابعة حلقات القرآن الكريم", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = .88f), maxLines = 1)
                            }
                        }
                        Surface(color = Color.White.copy(alpha = .09f), shape = RoundedCornerShape(16.dp)) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Image(
                                    painter = painterResource(R.drawable.brand_eastern_khan_younis),
                                    contentDescription = "الشرقية خانيونس",
                                    modifier = Modifier.size(46.dp).clip(CircleShape),
                                )
                                Column(Modifier.weight(1f)) {
                                    Text("مركز إبراهيم خليل الرحمن", color = Color.White, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text("الشرقية — خانيونس", color = Color.White.copy(alpha = .82f), style = MaterialTheme.typography.labelMedium, maxLines = 1)
                                }
                            }
                        }
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("صُنع بأيدٍ شرقية", color = Color.White.copy(alpha = .92f), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                            Text("Designed by : Dr. Mohammed Samir Abu Younis", color = Color.White.copy(alpha = .72f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                    }
                }
                Column(
                    Modifier.padding(horizontal = 24.dp, vertical = 22.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        if (register) "إنشاء حساب" else "أهلًا بك في حلقاتي",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        if (register) "أدخل بياناتك وسيظهر طلبك لمسؤول الحلقة للاعتماد." else "رحلة القرآن، أقرب إليك. استخدم حسابك للوصول إلى الحلقة.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    error?.let { StateNotice(it, kind = "error") }
                    info?.let {
                        StateNotice(
                            it,
                            kind = when {
                                it.startsWith("تعذر") -> "error"
                                it.startsWith("تم إلغاء") -> "warning"
                                else -> "success"
                            },
                        )
                    }

                    if (register) {
                        Text(
                            "إنشاء الحساب لا يمنح الصلاحية مباشرة؛ ينتظر اعتماد المسؤول.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("الاسم الكامل") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(15.dp),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("رقم الجوال") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(15.dp),
                            singleLine = true,
                        )
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            listOf(
                                "guardian" to "ولي أمر",
                                "teacher" to "محفّظ الحلقة",
                                "supervisor" to "مشرف الحلقات",
                            ).forEach { (value, label) ->
                                ProFilterChip(
                                    selected = requestedRole == value,
                                    onClick = { requestedRole = value },
                                    label = label,
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("البريد الإلكتروني") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("كلمة المرور") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(15.dp),
                        singleLine = true,
                    )

                    Button(
                        onClick = {
                            if (register) onRegister(email.trim(), password, name.trim(), phone.trim(), requestedRole)
                            else onLogin(email.trim(), password)
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.ActionHeight),
                        shape = RoundedCornerShape(16.dp),
                        enabled = email.isNotBlank() && password.length >= 6 && (!register || name.trim().length >= 3),
                    ) { Text(if (register) "إرسال طلب إنشاء الحساب" else "دخول") }

                    if (!register) {
                        OutlinedButton(
                            onClick = {
                                if (googleBusy) return@OutlinedButton
                                googleBusy = true
                                info = null
                                scope.launch {
                                    runCatching { NativeGoogleSignIn.launch(context) }
                                        .onSuccess { result -> onGoogleIdToken(result.idToken, result.rawNonce) }
                                        .onFailure { e ->
                                            googleBusy = false
                                            if (NativeGoogleSignIn.shouldFallbackToOAuth(e)) {
                                                runCatching {
                                                    NativeGoogleSignIn.launchOAuthFallback(context, onGoogleOAuthUrl())
                                                }.onSuccess {
                                                    info = "اختر حساب Google من النافذة الآمنة لإكمال الدخول."
                                                }.onFailure { fallbackError ->
                                                    info = "تعذر فتح تسجيل Google: ${fallbackError.message ?: "خطأ"}"
                                                }
                                            } else {
                                                info = when {
                                                    e.message?.contains("canceled", ignoreCase = true) == true -> "تم إلغاء اختيار حساب Google."
                                                    else -> "تعذر تسجيل الدخول بحساب Google: ${e.message ?: "خطأ"}"
                                                }
                                            }
                                        }
                                }
                            },
                            enabled = !googleBusy,
                            modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.ActionHeight),
                            shape = RoundedCornerShape(16.dp),
                        ) {
                            if (googleBusy) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("جارٍ فتح حسابات Google…")
                            } else {
                                Text("G", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.width(8.dp))
                                Text("الدخول بحساب Google")
                            }
                        }
                        TextButton(onClick = { resetDialog = true }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                            Text("نسيت كلمة المرور؟")
                        }
                    }

                    TextButton(onClick = { register = !register }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text(if (register) "لدي حساب بالفعل" else "إنشاء حساب جديد")
                    }
                }
            }
        }
    }

    if (resetDialog) {
        var resetEmail by remember(resetDialog) { mutableStateOf(email) }
        AlertDialog(
            onDismissRequest = { resetDialog = false },
            title = { Text("استرجاع كلمة المرور") },
            text = {
                OutlinedTextField(
                    value = resetEmail,
                    onValueChange = { resetEmail = it },
                    label = { Text("البريد الإلكتروني") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                Button(
                    enabled = resetEmail.contains('@'),
                    onClick = {
                        onResetPassword(resetEmail) { result -> info = result }
                        resetDialog = false
                    },
                ) { Text("إرسال الرابط") }
            },
            dismissButton = { TextButton(onClick = { resetDialog = false }) { Text("إلغاء") } },
        )
    }
}

@Composable
fun PendingApprovalScreen(profile: Profile, onRefresh: () -> Unit, onLogout: () -> Unit) {
    val rejected = profile.approvalStatus == "rejected"
    val blocked = profile.approvalStatus == "approved" && !profile.active
    val roleLabel = when (profile.requestedRole.takeIf { it != UserRole.UNKNOWN } ?: profile.role) {
        UserRole.GUARDIAN -> "ولي أمر"
        UserRole.TEACHER -> "محفّظ الحلقة"
        UserRole.SUPERVISOR -> "مشرف الحلقات"
        UserRole.ADMIN -> "مدير"
        else -> "مستخدم"
    }

    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Card(shape = RoundedCornerShape(26.dp)) {
            Column(
                Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    when {
                        rejected -> "لم تتم الموافقة على الحساب"
                        blocked -> "الحساب موقوف"
                        else -> "الحساب قيد اعتماد المسؤول"
                    },
                    style = MaterialTheme.typography.headlineSmall,
                )
                Text(profile.fullName)
                Text("نوع الحساب المطلوب: $roleLabel")
                Text(
                    when {
                        rejected -> profile.rejectionReason.ifBlank { "راجع مسؤول النظام لمعرفة سبب رفض الطلب." }
                        blocked -> "تم إيقاف الحساب من إدارة النظام. تواصل مع مسؤول الحلقات."
                        else -> "تم التحقق من بيانات الدخول، لكن الوصول إلى بيانات الحلقة لن يفتح حتى يعتمد المسؤول الحساب."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                )
                Button(onClick = onRefresh) { Text("تحديث حالة الاعتماد") }
                TextButton(onClick = onLogout) { Text("تسجيل الخروج") }
            }
        }
    }
}

@Composable
fun PasswordRecoveryScreen(
    email: String,
    onSubmit: (String, (String?) -> Unit) -> Unit,
    onCancel: () -> Unit,
) {
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val valid = password.length >= 6 && password == confirm

    Surface {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Card(Modifier.widthIn(max = 520.dp)) {
                Column(
                    Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("تعيين كلمة مرور جديدة", style = MaterialTheme.typography.headlineSmall)
                    if (email.isNotBlank()) {
                        Text(email, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        "اكتب كلمة المرور الجديدة مرتين. بعد نجاح التغيير سيتم إنهاء جلسة الاسترجاع ويمكنك تسجيل الدخول بالكلمة الجديدة.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    error?.let { StateNotice(it, kind = "error") }
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; error = null },
                        label = { Text("كلمة المرور الجديدة") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = confirm,
                        onValueChange = { confirm = it; error = null },
                        label = { Text("تأكيد كلمة المرور") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        isError = confirm.isNotBlank() && password != confirm,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (confirm.isNotBlank() && password != confirm) {
                        Text(
                            "كلمتا المرور غير متطابقتين.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                    Button(
                        onClick = {
                            busy = true
                            error = null
                            onSubmit(password) { message ->
                                busy = false
                                error = message
                            }
                        },
                        enabled = valid && !busy,
                        modifier = Modifier.fillMaxWidth().heightIn(min = HalaqatiUiTokens.TouchTarget),
                    ) {
                        if (busy) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary,
                            )
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(if (busy) "جارٍ الحفظ…" else "حفظ كلمة المرور")
                    }
                    TextButton(
                        onClick = onCancel,
                        enabled = !busy,
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                    ) { Text("إلغاء والعودة لتسجيل الدخول") }
                }
            }
        }
    }
}
