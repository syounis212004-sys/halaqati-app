package com.mohammedsamir.halaqati.ui.guardian

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mohammedsamir.halaqati.ui.components.AppTopBar
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens
import java.util.Locale

/** RC17.1 guardian home: explicit Hifz/Sard plan sections, RTL-first hierarchy and cache-first refresh. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuardianHomeScreen(
    navigate: (String) -> Unit,
    vm: GuardianHomeViewModel = viewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.start() }
    val overview = state.overview

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = "اطمئن على رحلته", kicker = "ولي الأمر · متابعة الأبناء")
        PullToRefreshBox(
            isRefreshing = state.refreshing && overview != null,
            onRefresh = { vm.refresh() },
            modifier = Modifier.weight(1f).fillMaxWidth(),
        ) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = HalaqatiUiTokens.ScreenHorizontal,
                    end = HalaqatiUiTokens.ScreenHorizontal,
                    top = 4.dp,
                    bottom = 24.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                if (state.children.size > 1) {
                    item(key = "switcher", contentType = "switcher") {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(state.children, key = { it.id }) { child ->
                                ProFilterChip(
                                    selected = child.id == state.selectedId,
                                    onClick = { vm.select(child.id) },
                                    label = child.name.substringBefore(' '),
                                )
                            }
                        }
                    }
                }
                if (state.stale && overview != null) {
                    item(key = "stale", contentType = "notice") {
                        StateNotice("تعرض آخر بيانات محفوظة${overview.updatedAt?.let { " · " + shortTime(it) } ?: ""}", kind = "warning")
                    }
                }
                state.message?.let { msg -> item(key = "msg", contentType = "notice") { StateNotice(msg, kind = "error") } }
                when {
                    overview == null && (state.loadingFirst || state.refreshing) ->
                        item(key = "loading", contentType = "loading") { LoadingSkeleton(rows = 3) }
                    overview == null && state.children.isEmpty() && !state.loadingFirst ->
                        item(key = "empty", contentType = "empty") { EmptyState("لا توجد ملفات طلاب مرتبطة بهذا الحساب") }
                    overview != null -> {
                        item(key = "today", contentType = "today") { TodayCard(overview) }
                        if (overview.planTitle != null) item(key = "plan", contentType = "plan") { PlanCard(overview) }
                        item(key = "metrics", contentType = "metrics") { MetricsStrip(overview) }
                        if (overview.latest.isNotEmpty()) {
                            item(key = "latest-title", contentType = "title") {
                                Text("آخر التسميعات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                            items(overview.latest, key = { "${it.date}:${it.activityLabel}:${it.range}" }, contentType = { "recitation" }) { line ->
                                RecitationRow(line)
                            }
                        }
                        item(key = "shortcuts", contentType = "shortcuts") {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { navigate("guardian_profile") }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("ملف الابن") }
                                OutlinedButton(onClick = { navigate("guardian_achievements") }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("الإنجاز") }
                                OutlinedButton(onClick = { navigate("guardian_competition") }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("المنافسة") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TodayCard(o: GuardianOverview) {
    val attendance = when (o.todayAttendance) {
        "present" -> "حضر اليوم"
        "late" -> "حضر اليوم (متأخر)"
        "absent" -> "غائب اليوم"
        "excused" -> "غائب بعذر اليوم"
        null -> when {
            o.todaySessionExists == false -> "لا توجد جلسة مسجلة اليوم"
            o.todaySessionStarted == false -> "جلسة اليوم لم تبدأ بعد"
            else -> "لم يُسجَّل الحضور بعد"
        }
        else -> "الحضور: ${o.todayAttendance}"
    }
    Card(
        Modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(HalaqatiUiTokens.RadiusHero),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
        ),
    ) {
        Column(Modifier.padding(horizontal = 22.dp, vertical = 20.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(
                listOf(o.trackLabel, o.subtitle).filter { it.isNotBlank() }.joinToString(" · "),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .78f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(o.childName, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                if (o.todayRecited) "$attendance · أتمّ ${if (o.tathbit) "التثبيت" else "التسميع"}" else attendance,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            if (o.todayRecited) {
                o.todayRange?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .9f)) }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .11f),
                ) {
                    Text(
                        "${if (o.tathbit) "تثبيت" else "تسميع"} اليوم: ${num(o.todayPages)} صفحة",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        style = MaterialTheme.typography.labelMedium,
                    )
                }
            } else {
                Text(
                    if (o.tathbit) "لم يُسجَّل تثبيت اليوم بعد" else "لم يُسجَّل تسميع اليوم بعد",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .78f),
                )
            }
        }
    }
}

@Composable
private fun PlanCard(o: GuardianOverview) {
    Card(
        Modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(HalaqatiUiTokens.RadiusCard),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(o.planTitle.orEmpty(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        if (o.planActivities.size > 1) "الحفظ والسرد محسوبان كلٌّ على حدة" else "التقدم بحسب هدف هذا الشهر",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (o.planComplete) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
            }
            if (o.planActivities.isEmpty()) {
                Text("لا توجد تفاصيل تقدم متاحة للخطة", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                o.planActivities.forEach { activity -> PlanActivityRow(activity) }
            }
        }
    }
}

@Composable
private fun PlanActivityRow(activity: GuardianPlanActivity) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .62f),
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(activity.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(
                    if (activity.hasTarget) "${num(activity.done)} / ${num(activity.target)} ص" else "${num(activity.done)} ص",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            if (activity.hasTarget) {
                LinearProgressIndicator(
                    progress = { (activity.percent / 100.0).toFloat() },
                    modifier = Modifier.fillMaxWidth().height(7.dp),
                    trackColor = MaterialTheme.colorScheme.outlineVariant,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${num(activity.percent)}٪", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.weight(1f))
                    when {
                        activity.surplus > 0.0001 -> {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(4.dp))
                            Text("+${num(activity.surplus)} ص فوق الهدف", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                        activity.complete -> Text("مكتمل", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        else -> Text("المتبقي ${num(activity.remaining)} ص", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                Text("إنجاز مسجل · لم يحدد للخطة هدف سرد مستقل على هذا الخادم", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun MetricsStrip(o: GuardianOverview) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Metric(o.monthMainLabel, "${num(o.monthMain)} ص", Modifier.weight(1f))
        Metric("الحضور", "${o.monthPresent}/${o.monthSessions}", Modifier.weight(1f))
        Metric("الجودة", o.quality?.let { "${num(it)}٪" } ?: "—", Modifier.weight(1f))
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(HalaqatiUiTokens.RadiusMetric), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(vertical = 14.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
private fun RecitationRow(line: GuardianRecitationLine) {
    Surface(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${line.activityLabel} · ${line.date}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                Text("${num(line.pages)} ص${line.quality?.let { " · ${num(it)}٪" } ?: ""}", style = MaterialTheme.typography.labelMedium)
            }
            Text(line.range, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun num(v: Double): String {
    val r = kotlin.math.round(v * 100) / 100
    return if (kotlin.math.abs(r - r.toLong()) < 1e-6) r.toLong().toString() else String.format(Locale.US, "%.2f", r).trimEnd('0').trimEnd('.')
}

private fun shortTime(iso: String): String = runCatching {
    java.time.OffsetDateTime.parse(iso).atZoneSameInstant(java.time.ZoneId.systemDefault())
        .format(java.time.format.DateTimeFormatter.ofPattern("d/M HH:mm", Locale.US))
}.getOrDefault("")
