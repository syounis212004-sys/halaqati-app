package com.mohammedsamir.halaqati.documents

import android.content.Context
import com.mohammedsamir.halaqati.BuildConfig
import com.mohammedsamir.halaqati.R
import com.mohammedsamir.halaqati.model.Student
import com.mohammedsamir.halaqati.quran.QuranMetadata
import com.mohammedsamir.halaqati.ui.screens.NativeReportStyle
import com.mohammedsamir.halaqati.ui.screens.ReportOrientation
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Locale

object ReportDocumentType {
    const val HALAQA = "halaqa"
    const val LEADERS = "leaders"
    const val POINTS = "points"
    const val ATTENDANCE = "attendance"
    const val RECITATIONS = "recitations"
    const val STUDENTS = "students"

    val all = listOf(HALAQA, LEADERS, POINTS, ATTENDANCE, RECITATIONS, STUDENTS)
    fun title(type: String): String = when (type) {
        LEADERS -> "لائحة الأوائل"
        POINTS -> "نقاط الطلاب"
        ATTENDANCE -> "حضور الحلقة"
        RECITATIONS -> "سجل التسميعات"
        STUDENTS -> "تقرير لكل طالب"
        else -> "التقرير الشامل للحلقة"
    }
}

/** RC13 report renderer: v2.44 report semantics, one HTML source for preview + vector PDF. */
object ReportHtmlRenderer {
    internal fun build(
        context: Context,
        reportType: String,
        summaryRows: List<JSONObject>,
        detailRows: List<JSONObject>,
        notesRows: List<JSONObject>,
        students: List<Student>,
        style: NativeReportStyle,
        from: String,
        to: String,
        track: String,
        halaqaLabel: String,
        teacherName: String = "",
    ): String {
        require(reportType in ReportDocumentType.all) { "نوع التقرير غير معروف" }
        val baseCss = context.assets.open("documents/report.css").bufferedReader().use { it.readText() }
        val centerLogo = if (style.logoMode in setOf("both", "center")) DocumentImageEncoder.resourceJpeg(context, R.drawable.center_logo, 260, 82) else null
        val halaqaLogo = if (style.logoMode in setOf("both", "halaqa")) DocumentImageEncoder.resourceJpeg(context, R.drawable.halaqa_logo, 260, 82) else null
        val primary = longToHex(style.primaryColor)
        val text = longToHex(style.textColor)
        val orientation = if (style.orientation == ReportOrientation.PORTRAIT) "portrait" else "landscape"
        val screenWidth = if (style.orientation == ReportOrientation.PORTRAIT) 792 else 1120
        val tracks = if (track == "all") listOf("general_hifz", "tathbit") else listOf(track)
        val studentById = students.associateBy { it.id }
        val sections = buildString {
            for (t in tracks) {
                val sr = summaryRows.filter { it.optString("track_code") == t || track != "all" }
                val dr = detailRows.filter { rowTrack(it) == t || track != "all" }
                val nr = notesRows.filter { rowTrack(it) == t || track != "all" }
                when (reportType) {
                    ReportDocumentType.LEADERS -> append(leadersSection(sr, style, t, halaqaLabel, from, to, teacherName, centerLogo, halaqaLogo))
                    ReportDocumentType.POINTS -> append(pointsSection(sr, style, t, halaqaLabel, from, to, teacherName, centerLogo, halaqaLogo))
                    ReportDocumentType.ATTENDANCE -> append(attendanceSection(sr, style, t, halaqaLabel, from, to, teacherName, centerLogo, halaqaLogo))
                    ReportDocumentType.RECITATIONS -> append(recitationsSection(dr, style, t, halaqaLabel, from, to, teacherName, centerLogo, halaqaLogo))
                    ReportDocumentType.STUDENTS -> append(studentSections(sr, dr, nr, studentById, style, t, halaqaLabel, from, to, teacherName, centerLogo, halaqaLogo))
                    else -> append(halaqaSection(sr, style, t, halaqaLabel, from, to, teacherName, centerLogo, halaqaLogo))
                }
            }
        }
        val customCss = """
          :root{--report-primary:$primary;--report-text:$text;--report-gold:#C89D4A;--report-scale:${String.format(Locale.US, "%.3f", style.fontScale.coerceIn(.75f,1.55f))}}
          .pro-table th{background:$primary!important;color:#fff!important}.pro-head-title h1,.pro-kpi b,.pro-meta b{color:$primary}
          @page{size:A4 $orientation;margin:0!important}
          @media screen{.pro-report-page{width:${screenWidth}px}}
          body{font-family:'${cssString(style.fontFamily)}','Cairo',Tahoma,Arial,sans-serif!important}
        """.trimIndent()
        return """
          <!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
          <meta name="viewport" content="width=$screenWidth,initial-scale=1,maximum-scale=1,user-scalable=no">
          <style>$baseCss\n$customCss</style></head><body><div class="pro-report">$sections</div>
          <script>${reportFitScript()}</script></body></html>
        """.trimIndent()
    }

    private fun header(
        typeTitle: String,
        sub: String,
        track: String,
        halaqaLabel: String,
        from: String,
        to: String,
        teacherName: String,
        centerLogo: String?,
        halaqaLogo: String?,
        style: NativeReportStyle,
    ): String {
        val left = logoHtml(halaqaLogo, "ح")
        val right = logoHtml(centerLogo, "۞")
        val customTitle = style.title.trim().takeIf { it.isNotBlank() && it != "تقرير حلقتي" } ?: typeTitle
        val teacher = if (style.includeTeacher && teacherName.isNotBlank()) "<div class=\"teacher\">إعداد: ${h(teacherName)}</div>" else ""
        return """
          <div class="pro-head">$left<div class="pro-head-title"><h1>${h(customTitle)}</h1>${headerSubtitle(customTitle, typeTitle, sub)}$teacher</div>$right</div>
          <div class="pro-meta"><span><b>الحلقة:</b> ${h(halaqaLabel)}</span><span><b>المسار:</b> ${h(trackLabel(track))}</span><span><b>الفترة:</b> ${h("$from — $to")}</span><span><b>تاريخ الإصدار:</b> ${LocalDate.now()}</span></div>
        """.trimIndent()
    }

    private fun footer(style: NativeReportStyle): String {
        val left = style.footer.ifBlank { "حلقتي · النظام الرسمي لإدارة ومتابعة حلقات القرآن الكريم" }
        return "<div class=\"pro-footer\"><span>${h(left)}</span><span>الإصدار ${h(BuildConfig.VERSION_NAME)}</span></div>"
    }

    private fun kpis(rows: List<JSONObject>, track: String = "all"): String = """
      <div class="pro-kpis">
        <div class="pro-kpi"><b>${rows.size}</b><span>طلاب</span></div>
        ${if (track == "tathbit") "<div class=\"pro-kpi\"><b>${fmt(rows.sumOf { it.optDouble("tathbit_pages",0.0) })}</b><span>تثبيت</span></div><div class=\"pro-kpi\"><b>${fmt(rows.sumOf { it.optDouble("points",0.0) })}</b><span>نقاط</span></div><div class=\"pro-kpi\"><b>${fmt(rows.sumOf { it.optDouble("tathbit_pages",0.0) } / rows.size.coerceAtLeast(1))}</b><span>متوسط التثبيت</span></div>"
          else "<div class=\"pro-kpi\"><b>${fmt(rows.sumOf { it.optDouble("hifz_pages",0.0) })}</b><span>حفظ</span></div><div class=\"pro-kpi\"><b>${fmt(rows.sumOf { it.optDouble("review_pages",0.0) })}</b><span>مراجعة</span></div><div class=\"pro-kpi\"><b>${fmt(rows.sumOf { it.optDouble("sard_pages",0.0) })}</b><span>سرد</span></div>"}
        <div class="pro-kpi"><b>${rows.sumOf { it.optInt("present",0)+it.optInt("late",0) }}</b><span>حضور</span></div>
        <div class="pro-kpi"><b>${rows.sumOf { it.optInt("absent",0)+it.optInt("excused",0) }}</b><span>غياب</span></div>
      </div>
    """.trimIndent()

    private data class Col(val key: String, val label: String, val cls: String = "", val value: (JSONObject, Int)->String)

    private fun relevant(cols: List<Col>, track: String): List<Col> = cols.filterNot { c ->
        when (track) {
            "tathbit" -> c.key in setOf("hifz", "review", "sard", "track")
            "general_hifz" -> c.key in setOf("tathbit", "track")
            else -> false
        }
    }

    private fun table(rows: List<JSONObject>, cols: List<Col>): String {
        if (cols.isEmpty()) return "<div class=\"report-empty-pro\">اختر عمودًا واحدًا على الأقل.</div>"
        val head = cols.joinToString("") { "<th>${h(it.label)}</th>" }
        val body = rows.mapIndexed { index, row ->
            "<tr>" + cols.joinToString("") { c -> "<td class=\"${c.cls}\">${h(c.value(row,index))}</td>" } + "</tr>"
        }.joinToString("")
        return "<div class=\"pro-table-wrap\"><table class=\"pro-table\"><thead><tr>$head</tr></thead><tbody>$body</tbody></table></div>"
    }

    private fun halaqaSection(rows: List<JSONObject>, style: NativeReportStyle, track: String, halaqa: String, from: String, to: String, teacher: String, centerLogo: String?, halaqaLogo: String?): String {
        val candidates = listOf(
            Col("rank","#","compact num") { _,i -> (i+1).toString() },
            Col("student","الطالب","name") { r,_ -> txt(r,"student_name","طالب") },
            Col("category","الفئة") { r,_ -> txt(r,"category_name") },
            Col("track","المسار") { _,_ -> trackLabel(track) },
            Col("hifz","الحفظ","num") { r,_ -> fmt(r.optDouble("hifz_pages",0.0)) },
            Col("tathbit","التثبيت","num") { r,_ -> fmt(r.optDouble("tathbit_pages",0.0)) },
            Col("review","المراجعة","num") { r,_ -> fmt(r.optDouble("review_pages",0.0)) },
            Col("sard","السرد","num") { r,_ -> fmt(r.optDouble("sard_pages",0.0)) },
            Col("points","النقاط","num") { r,_ -> fmt(r.optDouble("points",0.0)) },
            Col("attendance","الحضور","num") { r,_ -> (r.optInt("present",0)+r.optInt("late",0)).toString() },
            Col("absence","الغياب","num") { r,_ -> (r.optInt("absent",0)+r.optInt("excused",0)).toString() },
            Col("mistakes","الأخطاء","num") { r,_ -> r.optInt("mistakes",0).toString() },
        )
        val cols = relevant(candidates.filter { it.key in style.visibleColumns }, track)
        return section(
            header(ReportDocumentType.title(ReportDocumentType.HALAQA),"",track,halaqa,from,to,teacher,centerLogo,halaqaLogo,style) +
                kpis(rows, track) + table(rows, cols) +
                (if (rows.isEmpty()) empty("لا توجد بيانات في الفترة المحددة.") else "") + footer(style),
        )
    }

    private fun leadersSection(rows0: List<JSONObject>, style: NativeReportStyle, track: String, halaqa: String, from: String, to: String, teacher: String, centerLogo: String?, halaqaLogo: String?): String {
        val rows = rows0.sortedWith(compareByDescending<JSONObject>{it.optDouble("points",0.0)}.thenByDescending{it.optDouble("total_pages",0.0)})
        val top = rows.take(3)
        val podium = if (top.isEmpty()) "" else {
            val order = listOfNotNull(top.getOrNull(1), top.getOrNull(0), top.getOrNull(2))
            "<div class=\"podium\">" + order.mapIndexed { i,r ->
                val actual = when { i==0 && top.size>1 -> 2; i==1 -> 1; else -> 3 }
                val cls = when(actual){1->"first";2->"second";else->"third"}
                val name = txt(r,"student_name","طالب")
                "<div class=\"podium-person $cls\"><div class=\"podium-avatar\">${h(name.take(1))}</div><div class=\"podium-step\"><div class=\"podium-rank\">$actual</div><div class=\"podium-name\">${h(name)}</div><div class=\"podium-score\">${fmt(r.optDouble("points",0.0))} نقطة · ${fmt(r.optDouble("total_pages",0.0))} ص</div></div></div>"
            }.joinToString("") + "</div>"
        }
        val cols = listOf(
            Col("rank","الترتيب","compact num") { _,i -> (i+1).toString() },
            Col("student","الطالب","name") { r,_ -> txt(r,"student_name","طالب") },
            Col("points","النقاط","num") { r,_ -> fmt(r.optDouble("points",0.0)) },
            Col("pages","الصفحات","num") { r,_ -> fmt(r.optDouble("total_pages",0.0)) },
            Col("mistakes","الأخطاء","num") { r,_ -> r.optInt("mistakes",0).toString() },
            Col("attendance","الحضور","num") { r,_ -> (r.optInt("present",0)+r.optInt("late",0)).toString() },
        )
        val visible = cols.filter { it.key in style.visibleColumns }
        return section(
            header(ReportDocumentType.title(ReportDocumentType.LEADERS),"",track,halaqa,from,to,teacher,centerLogo,halaqaLogo,style) +
                podium + table(rows, visible) + (if (rows.isEmpty()) empty("لا توجد بيانات لهذا المسار.") else "") + footer(style),
        )
    }

    private fun pointsSection(rows: List<JSONObject>, style: NativeReportStyle, track: String, halaqa: String, from: String, to: String, teacher: String, centerLogo: String?, halaqaLogo: String?): String {
        val cols = listOf(
            Col("student","الطالب","name") { r,_ -> txt(r,"student_name","طالب") },
            Col("hifz","حفظ","num") { r,_ -> fmt(r.optDouble("hifz_pages",0.0)) },
            Col("tathbit","تثبيت","num") { r,_ -> fmt(r.optDouble("tathbit_pages",0.0)) },
            Col("review","مراجعة","num") { r,_ -> fmt(r.optDouble("review_pages",0.0)) },
            Col("sard","سرد","num") { r,_ -> fmt(r.optDouble("sard_pages",0.0)) },
            Col("mistakes","أخطاء","num") { r,_ -> r.optInt("mistakes",0).toString() },
            Col("prompts","نقرات","num") { r,_ -> r.optInt("prompts",0).toString() },
            Col("points","المجموع","num") { r,_ -> fmt(r.optDouble("points",0.0)) },
        )
        val visible = relevant(cols.filter { it.key in style.visibleColumns }, track)
        return section(
            header(ReportDocumentType.title(ReportDocumentType.POINTS),"",track,halaqa,from,to,teacher,centerLogo,halaqaLogo,style) +
                kpis(rows, track) + table(rows, visible) + (if(rows.isEmpty()) empty("لا توجد بيانات لهذا المسار.") else "") + footer(style),
        )
    }

    private fun attendanceSection(rows: List<JSONObject>, style: NativeReportStyle, track: String, halaqa: String, from: String, to: String, teacher: String, centerLogo: String?, halaqaLogo: String?): String {
        val cols = listOf(
            Col("student","الطالب","name") { r,_ -> txt(r,"student_name","طالب") },
            Col("present","حاضر","num") { r,_ -> r.optInt("present",0).toString() },
            Col("absent","غائب","num") { r,_ -> r.optInt("absent",0).toString() },
            Col("excused","بعذر","num") { r,_ -> r.optInt("excused",0).toString() },
            Col("late","متأخر","num") { r,_ -> r.optInt("late",0).toString() },
            Col("sessions","إجمالي التسجيلات","num") { r,_ -> r.optInt("sessions",0).toString() },
        )
        val visible = cols.filter { it.key in style.visibleColumns }
        return section(
            header(ReportDocumentType.title(ReportDocumentType.ATTENDANCE),"",track,halaqa,from,to,teacher,centerLogo,halaqaLogo,style) +
                kpis(rows, track) + table(rows, visible) + (if(rows.isEmpty()) empty("لا توجد بيانات حضور لهذا المسار.") else "") + footer(style),
        )
    }

    private fun recitationsSection(rows0: List<JSONObject>, style: NativeReportStyle, track: String, halaqa: String, from: String, to: String, teacher: String, centerLogo: String?, halaqaLogo: String?): String {
        val rows = rows0.sortedBy { it.optJSONObject("sessions")?.optString("session_date").orEmpty() }
        val cols = listOf(
            Col("date","التاريخ","compact") { r,_ -> r.optJSONObject("sessions")?.optString("session_date").orEmpty().ifBlank{"—"} },
            Col("student","الطالب","name") { r,_ -> r.optJSONObject("students")?.let { txt(it,"full_name","طالب") } ?: "طالب" },
            Col("activity","النوع") { r,_ -> activityAr(r.optString("activity_type")) },
            Col("range","النطاق","text-cell") { r,_ -> recitationRange(r) },
            Col("pages","صفحات","num") { r,_ -> fmt(r.optDouble("pages_count",0.0)) },
            Col("mistakes","أخطاء","num") { r,_ -> r.optInt("mistakes",0).toString() },
            Col("prompts","نقرات","num") { r,_ -> r.optInt("prompts",0).toString() },
            Col("evaluation","تقييم") { r,_ -> evaluationAr(r.optString("evaluation")) },
            Col("points","نقاط","num") { r,_ -> fmt(r.optDouble("points",0.0)) },
        )
        val visible = cols.filter { c -> style.visibleColumns.contains(c.key) }
        return section(
            header(ReportDocumentType.title(ReportDocumentType.RECITATIONS),"",track,halaqa,from,to,teacher,centerLogo,halaqaLogo,style) +
                table(rows, visible) + (if(rows.isEmpty()) empty("لا توجد تسميعات لهذا المسار.") else "") + footer(style),
        )
    }

    private fun studentSections(
        rows: List<JSONObject>, details: List<JSONObject>, notes: List<JSONObject>, students: Map<String,Student>, style: NativeReportStyle,
        track: String, halaqa: String, from: String, to: String, teacher: String, centerLogo: String?, halaqaLogo: String?,
    ): String {
        if (rows.isEmpty()) return section(header(ReportDocumentType.title(ReportDocumentType.STUDENTS),"",track,halaqa,from,to,teacher,centerLogo,halaqaLogo,style) + empty("لا توجد بيانات لهذا المسار.") + footer(style))
        return rows.mapIndexed { index, r ->
            val id=r.optString("student_id"); val st=students[id]; val name=txt(r,"student_name","طالب")
            val photoData = if (style.includePhotos) DocumentImageEncoder.dataUrl(st?.photoPath, 320, transparent = false) else null
            val photo = if (style.includePhotos) {
                if (photoData != null) "<div class=\"student-report-photo\"><img src=\"${hAttr(photoData)}\" alt=\"\"></div>"
                else "<div class=\"student-report-photo\">${h(name.take(1))}</div>"
            } else ""
            val birth = if(style.includeBirthDate) "<div>الميلاد<b>${h(st?.dateOfBirth ?: "—")}</b></div>" else ""
            val info="""<div class="student-report-card">$photo<div><h2 style="margin:0;color:var(--report-primary)">${h(name)}</h2><div class="student-info-grid"><div>المسار<b>${h(trackLabel(track))}</b></div><div>الفئة<b>${h(txt(r,"category_name"))}</b></div>$birth${if (track == "tathbit") "<div>التثبيت<b>${fmt(r.optDouble("tathbit_pages",0.0))} ص</b></div><div>النقاط<b>${fmt(r.optDouble("points",0.0))}</b></div><div>الحضور<b>${r.optInt("present",0)+r.optInt("late",0)}</b></div>" else "<div>الحفظ<b>${fmt(r.optDouble("hifz_pages",0.0))} ص</b></div><div>المراجعة<b>${fmt(r.optDouble("review_pages",0.0))} ص</b></div><div>السرد<b>${fmt(r.optDouble("sard_pages",0.0))} ص</b></div>"}</div></div></div>"""
            val recs=details.filter{it.optString("student_id")==id}
            val recCols=listOf(
                Col("date","التاريخ","compact"){x,_->x.optJSONObject("sessions")?.optString("session_date").orEmpty().ifBlank{"—"}},
                Col("activity","النوع"){x,_->activityAr(x.optString("activity_type"))},
                Col("range","النطاق","text-cell"){x,_->recitationRange(x)},
                Col("pages","صفحات","num"){x,_->fmt(x.optDouble("pages_count",0.0))},
                Col("mistakes","أخطاء","num"){x,_->x.optInt("mistakes",0).toString()},
                Col("points","نقاط","num"){x,_->fmt(x.optDouble("points",0.0))},
            )
            val ns=notes.filter{it.optString("student_id")==id}
            val notesHtml=if(ns.isEmpty())"" else "<div class=\"pro-section-title\">تعليقات ومتابعة</div>"+table(ns,listOf(
                Col("date","التاريخ","compact"){x,_->x.optJSONObject("sessions")?.optString("session_date").orEmpty().ifBlank{"—"}},
                Col("behavior","السلوك"){x,_->behaviorAr(x.optString("behavior"))},
                Col("homework","الواجب","text-cell"){x,_->txt(x,"homework")},
                Col("teacher_comment","تعليق المحفّظ","text-cell"){x,_->txt(x,"teacher_comment")},
            ))
            val visibleRecCols = recCols.filter { it.key in style.visibleColumns }
            section(header("تقرير الطالب ${index+1}/${rows.size}",name,track,halaqa,from,to,teacher,centerLogo,halaqaLogo,style)+info+"<div class=\"pro-section-title\">التسميعات</div>"+table(recs,visibleRecCols)+notesHtml+footer(style))
        }.joinToString("")
    }

    private fun section(content: String) = "<section class=\"pro-report-page\">$content</section>"
    private fun empty(text:String)="<div class=\"report-empty-pro\">${h(text)}</div>"
    private fun logoHtml(src:String?,fallback:String)= if(src!=null) "<div class=\"pro-head-logo\"><img src=\"${hAttr(src)}\" alt=\"\"></div>" else "<div class=\"pro-head-logo\">${h(fallback)}</div>"

    private fun rowTrack(row: JSONObject): String = row.optJSONObject("students")?.optString("track_code").orEmpty()
    private fun trackLabel(v:String)=when(v){"general_hifz"->"الحفظ العام";"tathbit"->"التثبيت";else->"جميع المسارات"}
    private fun activityAr(v:String)=mapOf("new_hifz" to "حفظ","review_near" to "مراجعة قريبة","review_far" to "مراجعة بعيدة","sard" to "سرد","tilawah" to "تلاوة","test" to "اختبار","tathbit" to "تثبيت")[v]?:v.ifBlank{"—"}
    private fun evaluationAr(v:String)=mapOf("excellent" to "ممتاز","very_good" to "جيد جدًا","good" to "جيد","repeat" to "إعادة","not_rated" to "غير مقيم")[v]?:v.ifBlank{"—"}
    private fun behaviorAr(v:String)=mapOf("excellent" to "ممتاز","good" to "جيد","normal" to "طبيعي","needs_attention" to "يحتاج متابعة","warning" to "تنبيه")[v]?:v.ifBlank{"—"}

    /** Human range = exact stored Surah/Ayah. Pages are only a fallback when no ayah data exists. */
    private fun recitationRange(r:JSONObject):String {
        val ss=nullableInt(r,"start_surah"); val sa=nullableInt(r,"start_ayah"); val es=nullableInt(r,"end_surah"); val ea=nullableInt(r,"end_ayah")
        if(ss!=null&&sa!=null){
            val endS=es?:ss; val endA=ea?:sa
            return when {
                endS==ss && endA==sa -> "سورة ${surahName(ss)}: $sa"
                endS==ss -> "سورة ${surahName(ss)}: $sa → $endA"
                else -> "${surahName(ss)} $sa → ${surahName(endS)} $endA"
            }
        }
        val surahs=r.optJSONArray("selected_surahs") ?: r.optJSONObject("selection_data")?.optJSONArray("selected_surahs")
        if(surahs!=null&&surahs.length()>0)return (0 until surahs.length()).joinToString("، "){surahName(surahs.optInt(it))}
        val juz=r.optJSONObject("selection_data")?.optJSONArray("selected_juz")
        if(juz!=null&&juz.length()>0)return "الأجزاء "+(0 until juz.length()).joinToString("، "){juz.optInt(it).toString()}
        val sp=nullableInt(r,"start_page"); val ep=nullableInt(r,"end_page")
        if(sp!=null||ep!=null){ val x=sp?:ep!!; val y=ep?:x; return if(x==y)"صفحة $x" else "صفحات $x–$y" }
        return "—"
    }
    private fun headerSubtitle(title:String, typeTitle:String, sub:String):String {
        val parts = listOfNotNull(typeTitle.takeIf { it.isNotBlank() && it != title }, sub.takeIf { it.isNotBlank() && it != title })
        return if (parts.isEmpty()) "" else "<p>${h(parts.joinToString(" · "))}</p>"
    }
    /** Null-safe text: JSON null / "null" / blank → fallback; collapses broken whitespace in names. */
    private fun txt(o:JSONObject, key:String, fallback:String="—"):String {
        if (!o.has(key) || o.isNull(key)) return fallback
        val v = o.optString(key).replace('\u00A0',' ').replace(Regex("\\s+")," ").trim()
        return if (v.isBlank() || v.equals("null", true)) fallback else v
    }
    private fun surahName(n:Int):String= runCatching { QuranMetadata.surahName(n) }.getOrDefault("سورة $n")
    private fun nullableInt(o:JSONObject,key:String):Int?=if(!o.has(key)||o.isNull(key))null else o.optInt(key).takeIf{it>0}
    private fun fmt(v:Double):String=if(kotlin.math.abs(v-kotlin.math.round(v))<.0001)kotlin.math.round(v).toInt().toString() else String.format(Locale.US,"%.2f",v).trimEnd('0').trimEnd('.')
    private fun longToHex(v:Long)=String.format(Locale.US,"#%06X",v and 0xFFFFFF)
    private fun h(v:String)=v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;")
    private fun hAttr(v:String)=h(v)
    private fun cssString(v:String)=v.replace("\\","\\\\").replace("'","\\'").replace("\n"," ").replace("\r"," ")

    private fun reportFitScript():String="""
      (function(){
        window.__HALAQATI_READY__=false;window.__HALAQATI_LAYOUT_OK__=true;
        function kind(label){if(/^(#|م|الترتيب|صفحات|أخطاء|نقرات|نقاط|حاضر|غائب|بعذر|متأخر|الحفظ|التثبيت|المراجعة|السرد|الحضور|الغياب|المجموع)$/i.test(label))return'compact';if(/الطالب/.test(label))return'name';if(/النطاق|تعليق|الواجب|ملاحظة/.test(label))return'flex';return'auto'}
        function fitTable(t){var hs=[...(t.tHead?.rows?.[0]?.cells||[])];if(!hs.length)return;var ks=hs.map(x=>kind((x.textContent||'').trim()));var ws=ks.map((k,i)=>{var max=(hs[i].textContent||'').length;[...t.tBodies].forEach(tb=>[...tb.rows].slice(0,80).forEach(r=>{var c=r.cells[i];if(c)max=Math.max(max,(c.textContent||'').trim().length)}));return k==='name'?Math.max(18,Math.min(28,18+max*.25)):k==='flex'?Math.max(14,Math.min(24,11+max*.24)):k==='compact'?Math.max(5,Math.min(8,4+max*.22)):Math.max(7,Math.min(14,6+max*.2))});var sum=ws.reduce((a,b)=>a+b,0)||1;var cg=document.createElement('colgroup');ws.forEach(w=>{var c=document.createElement('col');c.style.width=(w*100/sum).toFixed(2)+'%';cg.appendChild(c)});var old=t.querySelector('colgroup[data-auto]');if(old)old.remove();cg.dataset.auto='1';t.insertBefore(cg,t.firstChild);[...t.querySelectorAll('.name')].forEach(c=>{var s=parseFloat(getComputedStyle(c).fontSize)||9.5,g=0;while(c.scrollWidth>c.clientWidth+1&&s>7.1&&g++<14){s-=.25;c.style.fontSize=s+'px'}})}
        function run(){document.querySelectorAll('.pro-table').forEach(fitTable);document.querySelectorAll('.pro-report-page').forEach(p=>{if(p.scrollWidth>p.clientWidth+3)window.__HALAQATI_LAYOUT_OK__=false});document.documentElement.dataset.layoutOk=window.__HALAQATI_LAYOUT_OK__?'1':'0';window.__HALAQATI_READY__=true;}
        var done=()=>requestAnimationFrame(()=>requestAnimationFrame(run));if(document.fonts&&document.fonts.ready)document.fonts.ready.then(done).catch(done);else done();
      })();
    """.trimIndent()
}
