package com.mohammedsamir.halaqati.navigation

import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.ui.navigation.RoleNavigationPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RoleNavigationPolicyTest {
    @Test
    fun guardianBottomBarMatchesRc17RoleExperience() {
        assertEquals(
            listOf("home", "guardian_profile", "guardian_achievements", "more"),
            RoleNavigationPolicy.bottom(UserRole.GUARDIAN).map { it.route },
        )
    }

    @Test
    fun staffBottomBarMatchesGoldenMaster() {
        assertEquals(
            listOf("home", "sessions", "students", "plans", "more"),
            RoleNavigationPolicy.bottom(UserRole.TEACHER).map { it.route },
        )
    }

    @Test
    fun guardianCompetitionAndAchievementsStayDistinct() {
        val routes = RoleNavigationPolicy.destinations(UserRole.GUARDIAN).map { it.route }
        assertTrue("guardian_competition" in routes)
        assertTrue("guardian_achievements" in routes)
        assertFalse("users" in routes)
    }

    @Test
    fun guardianReportsAndPlansRemainAccessibleOutsideBottomBar() {
        val allowed = RoleNavigationPolicy.destinations(UserRole.GUARDIAN).map { it.route }.toSet()
        val bottom = RoleNavigationPolicy.bottom(UserRole.GUARDIAN).map { it.route }.toSet()
        val more = RoleNavigationPolicy.moreSections(UserRole.GUARDIAN)
            .flatMap { it.items }
            .map { it.route }
            .toSet()
        val drawer = RoleNavigationPolicy.drawerItems(UserRole.GUARDIAN)
            .map { it.destination.route }
            .toSet()

        assertTrue("plans" in allowed)
        assertTrue("reports" in allowed)
        assertFalse("plans" in bottom)
        assertFalse("reports" in bottom)
        assertTrue("plans" in drawer)
        assertTrue("reports" in drawer)
        assertTrue("reports" in more)
    }
}
