from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.54.0',
    'versionCode':25400,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    'notes':[
        'إصلاح خصوصية ولي الأمر: لا تظهر إلا أسماء الأبناء المرتبطين بالحساب، مع حماية إضافية في Supabase.',
        'إعادة ترتيب صفحة خطط الأبناء لإظهار الخطة والمقرر بسرعة وتقليل المساحة المهدرة أعلى الشاشة.',
        'إضافة أرشيف شهري ثابت لكل طالب للحفظ والسرد والتثبيت مع إمكانية الرجوع للشهور السابقة.',
        'إضافة دورة شهرية للخطط: إنهاء الشهر السابق وتجهيز خطة الشهر الجديد مع نسخ مراحل الحفظ والسرد.',
        'إطلاق نظام شارات حقيقي مبني على بيانات الخطة والتسميع والحضور والجودة مع دليل وتاريخ لكل شارة.',
        'إضافة سجل تدقيق إداري لعمليات تعديل الحلقات والخطط والفئات والإعلانات.'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
