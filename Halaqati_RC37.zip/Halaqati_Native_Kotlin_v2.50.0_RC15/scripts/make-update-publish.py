from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.73.0',
    'versionCode':27300,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        'نظام النطاق في كل التطبيق: الحفظ والسرد يُحسبان من أول آية إلى آخر آية وصل إليها الطالب (بدون تكرار) في التقارير والترتيب ومقارنة الحلقات وبطاقة الطالب ومراحل الخطة، وليس مجموع صفحات التسميعات.',
        'السرد يُحسب كنطاق واحد من أول آية سمّعها الطالب إلى آخر آية وصل إليها عبر كل الأيام، وإعادة نفس الآيات في يوم آخر لا تُضاف (نفس نظام الحفظ).',
        'دقة الحساب: السرد يُحسب الآن بالصفحات المسمَّعة فعلًا (كان يقيس صفحات برقم الصفحة فيُنقص السرد الذي يمر بسور عدة)، وتسجيلات فارغة قديمة لم تعد تخفض متوسط الجودة في الطالب والحلقات والتنبيهات.',
        'إصلاح السرد غير المحسوب: الطالب الذي سمّع سردًا في مرحلة السرد وليس له سرد سابق بنطاق كان يظهر 0 من 25 ص ومتأخرًا، لأن النظام كان يقيس السرد على نطاق حفظ الشهر. الآن يُحسب ما سمّعه فعلًا في مرحلة السرد.',
        'التنقل والواجهة: كل القوائم تحفظ موضعها عند الدخول لصفحة والرجوع منها، والتبديل بين التبويبات صار تلاشيًا هادئًا بدل الانزلاق الجانبي، والنص الثانوي في الوضع المظلم أفتح وأوضح.',
        'منصب المراقب: يرى الحلقات والطلاب وكمية تسميعهم في فترة تختارها، ويرفع طلب مكافأة أو تكريم أو متابعة لمدير النظام الذي يوافق أو يرفض ويصل الرد للمراقب. يحتاج تشغيل ملف SQL الجديد.',
        'الوضع المظلم: العناوين والأرقام بيضاء بدل الألوان. والرجوع من الجلسة أو ملف الطالب يعيد القائمة إلى موضعها ولا يرجع لأول جلسة، وتبقى مرشحات الطلاب كما هي.',
        'المزامنة: تظهر الآن رسالة واضحة إذا بقي أي تسجيل ولم يصل الخادم أكثر من 3 دقائق، والتطبيق يعيد المحاولة تلقائيًا كل 15 دقيقة، ولا يتوقف الإرسال بسبب عملية واحدة عالقة. وتقرير المشكلة يتضمن حالة المزامنة.'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
