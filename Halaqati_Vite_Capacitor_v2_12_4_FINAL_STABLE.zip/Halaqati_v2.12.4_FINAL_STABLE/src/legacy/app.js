const SUPABASE_URL='https://xlxzwucqdtggkfwwqibk.supabase.co';
const SUPABASE_KEY='sb_publishable_VZGYTedRpXfJdswijXoxig_F0Hva8ks';
const db=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
const OFFICIAL_APP_URL='https://xlxzwucqdtggkfwwqibk.supabase.co/functions/v1/halaqati-reset/';
const GOOGLE_REDIRECT_URL='https://xlxzwucqdtggkfwwqibk.supabase.co/functions/v1/halaqati-app/';
const APP_DEEP_LINK='com.mohammedsamir.halaqati://auth/callback';
const APP_VERSION_NAME='2.12.4';
const APP_VERSION_CODE=21204;
const UPDATE_MANIFEST_URL='https://syounis212004-sys.github.io/halaqati-web/version.json';
let halaqatiUpdateState={checking:false,error:'',info:null,currentVersionName:APP_VERSION_NAME,currentVersionCode:APP_VERSION_CODE,progress:0,message:''};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const today=()=>new Date().toISOString().slice(0,10); const monthStart=()=>new Date(new Date().getFullYear(),new Date().getMonth(),1).toISOString().slice(0,10);
const monthEnd=(ym)=>{let [y,m]=ym.split('-').map(Number);return new Date(y,m,0).toISOString().slice(0,10)};
let state={demo:false,user:null,profile:null,page:'home',halaqas:[],students:[],sessions:[],announcements:[],forum:[],comments:[],goals:[],monthly:[],leaderDaily:[],leaderMonthly:[],dailySummary:[],users:[],categories:[],halaqaTeachers:[],guardianAccounts:[],guardianDirectory:[],guardianRanksMonth:{},guardianRanksDay:{},guardianCompetition:{},competitionTrack:'hifz',competitionPeriod:'month',photoUrls:{},settings:null,communityTab:'announcements',announcementFilter:'all',rankTrack:'hifz',rankPeriod:'month',reportTab:'monthly',importRows:[],importHeaders:[],studentSearch:'',studentHalaqa:'all',studentCategory:'all',studentTrack:'all',studentStatus:'active',studentSort:'alpha',selectionMode:false,selectedStudents:new Set(),sessionView:null,sessionSearch:'',sessionSort:'alpha',sessionRoster:{attendance:[],notes:[],recitations:[]},offlineRosterCache:{},reportExistingRecIds:[],offline:false,syncing:false,pendingSync:0,networkVerified:false,lastNetworkCheck:0,fastStarted:false};
const roleAr={admin:'مسؤول النظام والحلقات',supervisor:'مشرف الحلقات',teacher:'محفّظ الحلقة',guardian:'ولي الأمر',student:'طالب (قديم)'};
const studentTrackAr={general_hifz:'مسار الحفظ العام',sard:'مسار السرد',tathbit:'مسار التثبيت'};
const requestRoleAr={supervisor:'مشرف الحلقات',teacher:'محفّظ الحلقة',guardian:'ولي أمر',admin:'مسؤول النظام والحلقات'};
const sesAr={tasmee:'تسميع',sard:'سرد',review:'مراجعة',test:'اختبار',tajweed:'تجويد',lesson:'درس',other:'أخرى'};
const attAr={present:'حاضر',absent:'غائب',excused:'بعذر',late:'متأخر'};
const actAr={new_hifz:'حفظ جديد',review_near:'مراجعة قريبة',review_far:'مراجعة بعيدة',sard:'سرد',tilawah:'تلاوة',test:'اختبار'};
const evalAr={excellent:'ممتاز',very_good:'جيد جداً',good:'جيد',repeat:'يحتاج إعادة',not_rated:'غير مقيّم'};
const behAr={excellent:'ممتاز',good:'جيد',normal:'طبيعي',needs_attention:'يحتاج متابعة',warning:'إنذار'};
const categoryAr={daily:'يومي',monthly:'شهري',general:'عام',schedule:'موعد',achievement:'إنجاز',urgent:'عاجل'};
const trackAr={hifz:'الحفظ',review:'المراجعة',sard:'السرد'};
const surahs=['الفاتحة','البقرة','آل عمران','النساء','المائدة','الأنعام','الأعراف','الأنفال','التوبة','يونس','هود','يوسف','الرعد','إبراهيم','الحجر','النحل','الإسراء','الكهف','مريم','طه','الأنبياء','الحج','المؤمنون','النور','الفرقان','الشعراء','النمل','القصص','العنكبوت','الروم','لقمان','السجدة','الأحزاب','سبأ','فاطر','يس','الصافات','ص','الزمر','غافر','فصلت','الشورى','الزخرف','الدخان','الجاثية','الأحقاف','محمد','الفتح','الحجرات','ق','الذاريات','الطور','النجم','القمر','الرحمن','الواقعة','الحديد','المجادلة','الحشر','الممتحنة','الصف','الجمعة','المنافقون','التغابن','الطلاق','التحريم','الملك','القلم','الحاقة','المعارج','نوح','الجن','المزمل','المدثر','القيامة','الإنسان','المرسلات','النبأ','النازعات','عبس','التكوير','الانفطار','المطففين','الانشقاق','البروج','الطارق','الأعلى','الغاشية','الفجر','البلد','الشمس','الليل','الضحى','الشرح','التين','العلق','القدر','البينة','الزلزلة','العاديات','القارعة','التكاثر','العصر','الهمزة','الفيل','قريش','الماعون','الكوثر','الكافرون','النصر','المسد','الإخلاص','الفلق','الناس'];
const ayahCounts=[7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6];
const juzStarts=[[1,1],[2,142],[2,253],[3,93],[4,24],[4,148],[5,82],[6,111],[7,88],[8,41],[9,93],[11,6],[12,53],[15,1],[17,1],[18,75],[21,1],[23,1],[25,21],[27,56],[29,46],[33,31],[36,28],[39,32],[41,47],[46,1],[51,31],[58,1],[67,1],[78,1]];
const ayahPrefix=(()=>{let a=[0];for(let i=0;i<ayahCounts.length;i++)a.push(a[i]+ayahCounts[i]);return a})();
const globalAyah=(s,a)=>ayahPrefix[s-1]+a;
const fmt=n=>Number(n||0).toLocaleString('ar-EG',{maximumFractionDigits:2});
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const scoringDefaults={mistakePenalty:1,promptPenalty:.5,pointPenaltyWeight:.25,excellentMax:.5,veryGoodMax:1,goodMax:2};
function toast(m){let t=$('#toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400)}
function hideAuthForms(){['loginForm','signupForm','forgotPasswordForm','recoveryPasswordForm','pendingPanel'].forEach(id=>$('#'+id)?.classList.add('hidden'))}
function toggleSignup(v){hideAuthForms();$(v?'#signupForm':'#loginForm').classList.remove('hidden')}
function showForgotPassword(v=true){hideAuthForms();if(v){$('#forgotEmail').value=$('#loginEmail')?.value.trim()||'';$('#forgotPasswordForm').classList.remove('hidden')}else $('#loginForm').classList.remove('hidden')}
function showPasswordRecovery(){hideAuthForms();$('#recoveryPasswordForm').classList.remove('hidden')}
function toggleDrawer(v){$('#drawer').classList.toggle('open',v);$('#backdrop').classList.toggle('open',v)}
function isOwner(){return state.profile?.role==='admin'}
function isSupervisor(){return state.profile?.role==='supervisor'}
function roleCanManage(){return ['admin','supervisor','teacher'].includes(state.profile?.role)}
function roleCanAdmin(){return ['admin','supervisor'].includes(state.profile?.role)}
function canManageStudents(){return ['admin','supervisor','teacher'].includes(state.profile?.role)}
function canManageUsers(){return isOwner()}
function iconFor(p){return {home:'⌂',halaqas:'▦',community:'◉',sessions:'▣',students:'👥',plans:'◇',reports:'▤',quran:'۞',ranking:'★',competition:'♛',supervision:'◎',users:'♙',data:'⇄',settings:'⚙',profile:'◌'}[p]||'•'}
function navItems(){let r=state.profile?.role;let common=[['home','الرئيسية'],['community','الإعلانات ومنتدى الحلقة']];if(r==='admin')return [['home','الرئيسية'],['halaqas','إدارة الحلقات والفئات'],['community','الإعلانات ومنتدى الحلقة'],['sessions','الجلسات اليومية'],['students','الطلاب'],['plans','الخطط الشهرية'],['reports','التقارير'],['quran','حاسبة القرآن'],['ranking','الترتيب والإحصائيات'],['data','الاستيراد والتصدير'],['supervision','متابعة المحفّظ'],['users','الحسابات والصلاحيات'],['settings','الإعدادات']];if(r==='supervisor')return [...common,['halaqas','الحلقات والفئات'],['sessions','الجلسات اليومية'],['students','الطلاب'],['plans','الخطط الشهرية'],['reports','التقارير'],['quran','حاسبة القرآن'],['ranking','الترتيب والإحصائيات'],['data','الاستيراد والتصدير'],['supervision','متابعة المحفّظ'],['settings','الإعدادات']];if(r==='teacher')return [...common,['halaqas','حلقتي والفئات'],['sessions','الجلسات اليومية'],['students','طلابي'],['plans','خطط الطلاب'],['reports','التقارير'],['quran','حاسبة القرآن'],['ranking','الترتيب والإحصائيات'],['data','تصدير البيانات'],['settings','الإعدادات']];if(r==='guardian')return [...common,['plans','خطة أبنائي'],['reports','تقارير أبنائي'],['competition','إحصائيات ومنافسة'],['ranking','الإنجازات'],['profile','ملف الطالب'],['settings','الإعدادات']];return common;}
function buildNav(){let n=$('#nav');n.innerHTML=navItems().map(([p,l])=>`<button class="${state.page===p?'active':''}" onclick="go('${p}')"><span class="ico">${iconFor(p)}</span>${l}</button>`).join('')}
function go(p){if(p!=='sessions')state.sessionView=null;state.page=p;toggleDrawer(false);render()}
function setFab(){let f=$('#fab');f.classList.add('hidden');if(state.page==='halaqas'&&isOwner()){f.classList.remove('hidden');f.dataset.action='halaqa'}if(state.page==='sessions'&&roleCanManage()){f.classList.remove('hidden');f.dataset.action='session'}if(state.page==='students'&&canManageStudents()){f.classList.remove('hidden');f.dataset.action='student'}if(state.page==='community'&&roleCanManage()){f.classList.remove('hidden');f.dataset.action=state.communityTab==='forum'?'forum':'announcement'}if(state.page==='plans'&&roleCanManage()){f.classList.remove('hidden');f.dataset.action='plan'}}
function fabAction(){let a=$('#fab').dataset.action;if(a==='halaqa')openHalaqa();if(a==='session')openSession();if(a==='student')openStudent();if(a==='announcement')openAnnouncement();if(a==='forum')openForum();if(a==='plan')openPlan()}
function stat(l,v){return `<div class="stat"><span>${l}</span><b>${v}</b></div>`}
function evalClass(e){return e==='excellent'?'blue':e==='very_good'?'good':e==='good'?'warn':'red'}
function evalDot(e){return 'eval-'+(e||'repeat')}
function visibleStudents(){return state.students}
function avatarHtml(s,cls='avatar'){let u=state.photoUrls[s.id];return u?`<div class="${cls}"><img src="${u}" alt=""></div>`:`<div class="${cls}">${(s.full_name||'ط')[0]}</div>`}

function cacheKey(){return state.user?.id?`halaqati_v18_cache_${state.user.id}`:null}
function queueKey(){return state.user?.id?`halaqati_v18_queue_${state.user.id}`:null}
function sessionMapKey(){return state.user?.id?`halaqati_v18_session_map_${state.user.id}`:null}
function cloneJson(v){return JSON.parse(JSON.stringify(v))}
function readOfflineQueue(){let k=queueKey();if(!k)return [];try{return JSON.parse(localStorage.getItem(k)||'[]')}catch(e){return []}}
function writeOfflineQueue(q){let k=queueKey();if(k)localStorage.setItem(k,JSON.stringify(q));state.pendingSync=q.length;updateSyncBadge()}
function readSessionMap(){let k=sessionMapKey();if(!k)return {};try{return JSON.parse(localStorage.getItem(k)||'{}')}catch(e){return {}}}
function writeSessionMap(m){let k=sessionMapKey();if(k)localStorage.setItem(k,JSON.stringify(m))}
const OFFLINE_AUTH_KEY='halaqati_v24_last_auth';
function saveOfflineAuth(u){if(!u?.id)return;try{localStorage.setItem(OFFLINE_AUTH_KEY,JSON.stringify({id:u.id,email:u.email||'',lastVerifiedAt:Date.now()}))}catch(e){}}
function readOfflineAuth(){try{let x=JSON.parse(localStorage.getItem(OFFLINE_AUTH_KEY)||'null');if(!x?.id)return null;let age=Date.now()-Number(x.lastVerifiedAt||0);if(age>45*24*60*60*1000)return null;return {id:x.id,email:x.email||''}}catch(e){return null}}
function clearOfflineAuth(){try{localStorage.removeItem(OFFLINE_AUTH_KEY)}catch(e){}}
function sleep(ms){return new Promise(r=>setTimeout(r,ms))}
async function withTimeout(promise,ms,label='timeout'){let t;try{return await Promise.race([promise,new Promise((_,rej)=>{t=setTimeout(()=>rej(new Error(label)),ms)})])}finally{clearTimeout(t)}}
async function internetReachable(force=false){
  if(!navigator.onLine){state.networkVerified=false;state.offline=true;return false}
  if(!force&&state.lastNetworkCheck&&Date.now()-state.lastNetworkCheck<5000)return !!state.networkVerified;
  state.lastNetworkCheck=Date.now();
  try{
    const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),1400);
    let r=await fetch(SUPABASE_URL+'/auth/v1/health',{method:'GET',cache:'no-store',headers:{apikey:SUPABASE_KEY,Authorization:'Bearer '+SUPABASE_KEY},signal:ctl.signal});
    clearTimeout(timer);state.networkVerified=!!r.ok;state.offline=!state.networkVerified;return state.networkVerified
  }catch(e){state.networkVerified=false;state.offline=true;return false}
}
function isNetworkError(e){let m=String(e?.message||e||'').toLowerCase();return !navigator.onLine||!state.networkVerified||m.includes('failed to fetch')||m.includes('network')||m.includes('load failed')||m.includes('timeout')||m.includes('abort')||m.includes('fetch')}
function cacheSnapshot(){let k=cacheKey();if(!k||!state.profile)return;let snap={savedAt:new Date().toISOString(),profile:state.profile,halaqas:state.halaqas,students:state.students,sessions:state.sessions,announcements:state.announcements,goals:state.goals,monthly:state.monthly,leaderDaily:state.leaderDaily,leaderMonthly:state.leaderMonthly,dailySummary:state.dailySummary,forum:state.forum,comments:state.comments,categories:state.categories,halaqaTeachers:state.halaqaTeachers,guardianAccounts:state.guardianAccounts,guardianDirectory:state.guardianDirectory,guardianRanksMonth:state.guardianRanksMonth,guardianRanksDay:state.guardianRanksDay,guardianCompetition:state.guardianCompetition,competitionTrack:state.competitionTrack,competitionPeriod:state.competitionPeriod,settings:state.settings,offlineRosterCache:state.offlineRosterCache};try{localStorage.setItem(k,JSON.stringify(snap))}catch(e){}}
function restoreSnapshot(){let k=cacheKey();if(!k)return false;try{let x=JSON.parse(localStorage.getItem(k)||'null');if(!x||!x.profile)return false;state.profile=x.profile;for(let p of ['halaqas','students','sessions','announcements','goals','monthly','leaderDaily','leaderMonthly','dailySummary','forum','comments','categories','halaqaTeachers','guardianAccounts','guardianDirectory'])state[p]=x[p]||[];state.guardianRanksMonth=x.guardianRanksMonth||{};state.guardianRanksDay=x.guardianRanksDay||{};state.guardianCompetition=x.guardianCompetition||{};state.competitionTrack=x.competitionTrack||'hifz';state.competitionPeriod=x.competitionPeriod||'month';state.settings=x.settings||null;state.offlineRosterCache=x.offlineRosterCache||{};state.users=[];state.offline=true;return true}catch(e){return false}}
function updateSyncBadge(){let b=$('#syncBadge');if(!b)return;let q=readOfflineQueue();state.pendingSync=q.length;b.className='sync-badge';if(state.syncing){b.classList.add('syncing');b.textContent=`مزامنة ${q.length||''}`.trim();return}if(!state.networkVerified||state.offline){b.classList.add('offline');b.textContent=q.length?`بدون نت · ${q.length} محفوظ`:'جاهز دون إنترنت';return}if(q.length){b.classList.add('pending');b.textContent=`بانتظار المزامنة ${q.length}`;return}b.textContent='متصل · متزامن'}
function enqueueOffline(op){let q=readOfflineQueue();if(op.key){let i=q.findIndex(x=>x.key===op.key);if(i>=0)q[i]=op;else q.push(op)}else q.push(op);writeOfflineQueue(q);state.offline=true;cacheSnapshot();return op}
function resolveSessionId(id,map=readSessionMap()){return map[id]||id}
function rememberRoster(id){state.offlineRosterCache[id]=cloneJson(state.sessionRoster);cacheSnapshot()}
function offlineNotice(){return (!state.networkVerified||state.offline||state.pendingSync)?`<div class="offline-notice"><b>${state.networkVerified?'بيانات محلية بانتظار المزامنة':'وضع العمل دون إنترنت'}</b><br>${state.pendingSync?`${state.pendingSync} عملية محفوظة بأمان على هذا الجهاز. ستُرفع تلقائياً عند عودة الاتصال.`:'الجلسات والحضور والسلوك والتسميع متاحة من النسخة المحلية.'}</div>`:''}
function localAttendanceSave(sid,seId,status,extra={}){let ex=rosterAttendance(sid),data={id:ex?.id||`offline-att-${Date.now()}-${sid}`,session_id:seId,student_id:sid,status,recorded_by:state.user.id,recorded_at:new Date().toISOString(),...extra,_offline:true};if(ex)Object.assign(ex,data);else state.sessionRoster.attendance.push(data);enqueueOffline({type:'attendance',key:`att:${seId}:${sid}`,payload:{session_id:seId,student_id:sid,status,recorded_by:state.user.id,...extra}});rememberRoster(seId);return data}
function localBehaviorSave(sid,seId,behavior){let ex=rosterNote(sid),data={id:ex?.id||`offline-note-${Date.now()}-${sid}`,session_id:seId,student_id:sid,behavior,behavior_score:behaviorScoreFor(behavior),created_by:state.user.id,parent_visible:true,_offline:true};if(ex)Object.assign(ex,data);else state.sessionRoster.notes.push(data);enqueueOffline({type:'behavior',key:`beh:${seId}:${sid}`,payload:{session_id:seId,student_id:sid,behavior,behavior_score:data.behavior_score,created_by:state.user.id,parent_visible:true}});rememberRoster(seId);return data}
function decorateRecForOffline(d){let pages=Number(d.pages_count||0),units=Number(d.mistakes||0)+Number(d.prompts||0)*.5,pp=pages>0?units/pages:null,ev=pp==null?'not_rated':pp<=.5?'excellent':pp<=1?'very_good':pp<=2?'good':'repeat';return {...d,penalty_units:units,penalty_per_page:pp,evaluation:ev,points:Math.max(0,pages-units*.25)}}
function saveReportOffline(payload){let sid=payload.studentId,seId=payload.sessionId;let at={id:`offline-att-${Date.now()}-${sid}`,...payload.attendance,_offline:true},nt={id:`offline-note-${Date.now()}-${sid}`,...payload.note,_offline:true};let oldA=rosterAttendance(sid),oldN=rosterNote(sid);if(oldA)Object.assign(oldA,at);else state.sessionRoster.attendance.push(at);if(oldN)Object.assign(oldN,nt);else state.sessionRoster.notes.push(nt);state.sessionRoster.recitations=state.sessionRoster.recitations.filter(x=>x.student_id!==sid);payload.rows.forEach((rr,i)=>state.sessionRoster.recitations.push({id:rr.dbId||`offline-rec-${Date.now()}-${i}`,...decorateRecForOffline(rr.data),_offline:true}));enqueueOffline({type:'report',key:`report:${seId}:${sid}`,payload});rememberRoster(seId);toast('تم حفظ التقرير على الجهاز وسيُرفع تلقائياً عند عودة الإنترنت')}
async function syncReportPayload(p,map){let seId=resolveSessionId(p.sessionId,map),attendance={...p.attendance,session_id:seId},note={...p.note,session_id:seId};let a=await db.from('attendance_records').upsert(attendance,{onConflict:'session_id,student_id'});if(a.error)throw a.error;let n=await db.from('student_daily_notes').upsert(note,{onConflict:'session_id,student_id'});if(n.error)throw n.error;let kept=[];for(let rr of p.rows){let d={...rr.data,session_id:seId};if(rr.dbId&&!String(rr.dbId).startsWith('offline-')){let r=await db.from('recitation_entries').update(d).eq('id',rr.dbId);if(r.error)throw r.error;kept.push(rr.dbId)}else{let r=await db.from('recitation_entries').insert(d).select('id').single();if(r.error)throw r.error;if(r.data?.id)kept.push(r.data.id)}}let removed=(p.existingRecIds||[]).filter(id=>!String(id).startsWith('offline-')&&!kept.includes(id));if(removed.length){let r=await db.from('recitation_entries').delete().in('id',removed);if(r.error)throw r.error}}
async function syncOfflineQueue(){if(state.syncing||!state.user)return updateSyncBadge();if(!(await internetReachable(true)))return updateSyncBadge();let q=readOfflineQueue();if(!q.length){state.offline=false;updateSyncBadge();return}state.syncing=true;updateSyncBadge();let map=readSessionMap(),remaining=[];for(let i=0;i<q.length;i++){let op=q[i];try{if(op.type==='session'){let obj={...op.obj};delete obj.id;delete obj._offline;let r=await db.from('sessions').insert(obj).select().single();if(r.error)throw r.error;map[op.localId]=r.data.id;writeSessionMap(map);let local=state.sessions.find(x=>x.id===op.localId);if(local)Object.assign(local,r.data);if(state.sessionView===op.localId)state.sessionView=r.data.id;if(state.offlineRosterCache[op.localId]){state.offlineRosterCache[r.data.id]=state.offlineRosterCache[op.localId];delete state.offlineRosterCache[op.localId]}}else if(op.type==='attendance'){let p={...op.payload,session_id:resolveSessionId(op.payload.session_id,map)};let r=await db.from('attendance_records').upsert(p,{onConflict:'session_id,student_id'});if(r.error)throw r.error}else if(op.type==='behavior'){let p={...op.payload,session_id:resolveSessionId(op.payload.session_id,map)};let r=await db.from('student_daily_notes').upsert(p,{onConflict:'session_id,student_id'});if(r.error)throw r.error}else if(op.type==='report'){await syncReportPayload(op.payload,map)}}catch(e){remaining.push(op,...q.slice(i+1));if(isNetworkError(e))break;console.error('offline sync',e);toast('تعذر مزامنة بعض البيانات: '+(e.message||e));break}}writeOfflineQueue(remaining);state.syncing=false;if(!remaining.length){state.offline=false;state.offlineRosterCache={};let mk=sessionMapKey();if(mk)localStorage.removeItem(mk);toast('تمت مزامنة البيانات المحفوظة بنجاح');await loadAll(true);if(state.sessionView)await loadSessionRosterData(state.sessionView);render()}cacheSnapshot();updateSyncBadge()}
function monthlyPointsForStudent(id){return state.leaderMonthly.filter(x=>x.student_id===id).reduce((a,x)=>a+Number(x.points||0),0)}
function sortStudentsList(rows,mode='alpha'){rows=[...rows];let dateVal=(x,k)=>x[k]?new Date(x[k]+'T00:00:00').getTime():null;return rows.sort((a,b)=>{if(mode==='points')return monthlyPointsForStudent(b.id)-monthlyPointsForStudent(a.id)||a.full_name.localeCompare(b.full_name,'ar');if(mode==='oldest'){let A=dateVal(a,'date_of_birth'),B=dateVal(b,'date_of_birth');return A==null?1:B==null?-1:A-B}if(mode==='youngest'){let A=dateVal(a,'date_of_birth'),B=dateVal(b,'date_of_birth');return A==null?1:B==null?-1:B-A}if(mode==='joined_old'){let A=dateVal(a,'enrollment_date'),B=dateVal(b,'enrollment_date');return A==null?1:B==null?-1:A-B}if(mode==='joined_new'){let A=dateVal(a,'enrollment_date'),B=dateVal(b,'enrollment_date');return A==null?1:B==null?-1:B-A}return a.full_name.localeCompare(b.full_name,'ar')})}
function rankRowFor(studentId,track,period='month'){let src=period==='day'?state.guardianRanksDay:state.guardianRanksMonth;return (src[studentId]||[]).find(x=>x.track===track)||null}




let googleSignInBusy=false;
let nativeAuthListenerReady=false;

function isNativeHalaqati(){
  return !!(window.Capacitor && typeof window.Capacitor.isNativePlatform==='function' && window.Capacitor.isNativePlatform());
}

function authParamsFromUrl(url){
  try{
    const u=new URL(url);
    const q=new URLSearchParams(u.search||'');
    const h=new URLSearchParams((u.hash||'').replace(/^#/,''));
    const get=k=>h.get(k)||q.get(k);
    return {
      access_token:get('access_token'),
      refresh_token:get('refresh_token'),
      code:get('code'),
      error:get('error'),
      error_code:get('error_code'),
      error_description:get('error_description')
    };
  }catch(e){return {}}
}

async function finishNativeGoogleLogin(url){
  if(!url || !url.startsWith(APP_DEEP_LINK))return false;
  const p=authParamsFromUrl(url);

  try{ await window.Capacitor?.Plugins?.Browser?.close?.(); }catch(e){}

  if(p.error || p.error_code){
    googleSignInBusy=false;
    toast('تعذر تسجيل الدخول باستخدام Google: '+decodeURIComponent(p.error_description||p.error||p.error_code||'خطأ غير معروف'));
    return true;
  }

  try{
    let session=null;

    // Supabase implicit OAuth flow (most common for this app)
    if(p.access_token && p.refresh_token){
      const {data,error}=await db.auth.setSession({
        access_token:p.access_token,
        refresh_token:p.refresh_token
      });
      if(error)throw error;
      session=data?.session;
    }
    // Support PKCE too if Supabase returns an authorization code.
    else if(p.code && db.auth.exchangeCodeForSession){
      const {data,error}=await db.auth.exchangeCodeForSession(p.code);
      if(error)throw error;
      session=data?.session;
    }

    if(!session){
      const {data}=await db.auth.getSession();
      session=data?.session||null;
    }

    if(!session?.user)throw new Error('لم يتم إنشاء جلسة تسجيل الدخول');

    googleSignInBusy=false;
    history.replaceState?.(null,'',location.pathname||'/');
    await boot(session.user);
    toast('تم تسجيل الدخول باستخدام Google');
  }catch(err){
    googleSignInBusy=false;
    toast('اكتمل اختيار حساب Google لكن تعذر فتح الجلسة: '+(err?.message||err));
  }
  return true;
}

async function setupNativeAuthDeepLink(){
  if(!isNativeHalaqati() || nativeAuthListenerReady)return;
  const AppPlugin=window.Capacitor?.Plugins?.App;
  if(!AppPlugin)return;

  nativeAuthListenerReady=true;

  try{
    await AppPlugin.addListener('appUrlOpen', async ({url})=>{
      await finishNativeGoogleLogin(url);
    });
  }catch(e){}

  // Handles the case where Android launched the app from the OAuth callback
  // before the JavaScript listener had finished loading.
  try{
    const launch=await AppPlugin.getLaunchUrl();
    if(launch?.url)await finishNativeGoogleLogin(launch.url);
  }catch(e){}
}

async function loginWithGoogle(){
  if(googleSignInBusy)return;
  if(!navigator.onLine)return toast('تسجيل الدخول بحساب Google يحتاج اتصالاً بالإنترنت');

  googleSignInBusy=true;

  try{
    if(isNativeHalaqati()){
      await setupNativeAuthDeepLink();

      const {data,error}=await db.auth.signInWithOAuth({
        provider:'google',
        options:{
          redirectTo:APP_DEEP_LINK,
          skipBrowserRedirect:true,
          queryParams:{prompt:'select_account'}
        }
      });

      if(error)throw error;
      if(!data?.url)throw new Error('لم يتم إنشاء رابط تسجيل الدخول');

      const BrowserPlugin=window.Capacitor?.Plugins?.Browser;
      if(BrowserPlugin?.open){
        await BrowserPlugin.open({
          url:data.url,
          presentationStyle:'popover'
        });
      }else{
        // Fallback if Browser plugin is unavailable.
        location.href=data.url;
      }
      return;
    }

    // Browser/HTML preview fallback.
    const webRedirect=(location.protocol==='http:'||location.protocol==='https:')
      ? (location.origin+location.pathname)
      : GOOGLE_REDIRECT_URL;

    const {error}=await db.auth.signInWithOAuth({
      provider:'google',
      options:{
        redirectTo:webRedirect,
        queryParams:{prompt:'select_account'}
      }
    });
    if(error)throw error;

  }catch(err){
    googleSignInBusy=false;
    const msg=String(err?.message||err);
    if(msg.toLowerCase().includes('provider') && msg.toLowerCase().includes('enabled')){
      return toast('Google Provider غير مفعّل في Supabase');
    }
    toast('تعذر تسجيل الدخول باستخدام Google: '+msg);
  }
}

// Register the deep-link handler as soon as the Capacitor bridge is available.
setTimeout(()=>setupNativeAuthDeepLink(),0);

async function login(){let {data,error}=await db.auth.signInWithPassword({email:$('#loginEmail').value.trim(),password:$('#loginPassword').value});if(error)return toast('تعذر تسجيل الدخول: '+error.message);await boot(data.user)}
$('#loginForm').addEventListener('submit',e=>{e.preventDefault();login()});
$('#signupForm').addEventListener('submit',async e=>{e.preventDefault();let requested=$('#signupRole').value;let {data,error}=await db.auth.signUp({email:$('#signupEmail').value.trim(),password:$('#signupPassword').value,options:{data:{full_name:$('#signupName').value.trim(),phone:$('#signupPhone').value.trim(),requested_role:requested}}});if(error)return toast(error.message);if(data.session){await boot(data.user)}else{toggleSignup(false);$('#loginEmail').value=$('#signupEmail').value.trim();toast('تم إرسال طلب الحساب. أكد البريد الإلكتروني إن طُلب، ثم انتظر اعتماد المسؤول.')}});
$('#forgotPasswordForm').addEventListener('submit',async e=>{e.preventDefault();let email=$('#forgotEmail').value.trim();if(!email)return toast('اكتب البريد الإلكتروني');let btn=e.submitter;if(btn){btn.disabled=true;btn.textContent='جاري الإرسال...'}let {error}=await db.auth.resetPasswordForEmail(email,{redirectTo:OFFICIAL_APP_URL});if(btn){btn.disabled=false;btn.textContent='إرسال رابط الاسترجاع'}if(error)return toast('تعذر إرسال رابط الاسترجاع: '+error.message);toast('تم إرسال رابط استرجاع كلمة المرور. افحص البريد الوارد والرسائل غير المرغوب فيها.');showForgotPassword(false);$('#loginEmail').value=email});
$('#recoveryPasswordForm').addEventListener('submit',async e=>{e.preventDefault();let p1=$('#recoveryPassword').value,p2=$('#recoveryPassword2').value;if(p1.length<6)return toast('كلمة المرور يجب أن تكون 6 أحرف على الأقل');if(p1!==p2)return toast('كلمتا المرور غير متطابقتين');let {data:{session}}=await db.auth.getSession();if(!session)return toast('رابط الاسترجاع غير صالح أو انتهت صلاحيته. اطلب رابطاً جديداً.');let {error}=await db.auth.updateUser({password:p1});if(error)return toast('تعذر تغيير كلمة المرور: '+error.message);toast('تم تغيير كلمة المرور بنجاح. يمكنك تسجيل الدخول بالكلمة الجديدة.');await db.auth.signOut();history.replaceState(null,'',location.pathname);$('#recoveryPassword').value='';$('#recoveryPassword2').value='';toggleSignup(false)});
function showAccessStatus(p){hideAuthForms();$('#pendingPanel').classList.remove('hidden');let rejected=p.approval_status==='rejected',blocked=p.approval_status==='approved'&&!p.active;$('#pendingIcon').textContent=rejected?'!':blocked?'×':'⌛';$('#pendingTitle').textContent=rejected?'لم تتم الموافقة على الحساب':blocked?'الحساب موقوف':'الحساب قيد اعتماد المسؤول';$('#pendingText').textContent=rejected?(p.rejection_reason||'راجع مسؤول النظام لمعرفة سبب رفض الطلب.'):blocked?'تم إيقاف الحساب من إدارة النظام. تواصل مع مسؤول الحلقات.':'تم التحقق من بيانات الدخول، لكن الوصول إلى بيانات الحلقة لن يفتح حتى يحدد مسؤول النظام الصلاحية ويعتمد الحساب.';$('#pendingRole').textContent=requestRoleAr[p.requested_role]||requestRoleAr[p.role]||'ولي أمر'}
async function checkApproval(){let {data:{user}}=await db.auth.getUser();if(!user)return location.reload();await boot(user)}
async function refreshFromServer({renderAfter=true}={}){
  if(!state.user||!(await internetReachable(true)))return false;
  try{
    let res=await withTimeout(db.from('profiles').select('*').eq('id',state.user.id).single(),3500,'profile timeout');
    if(res.error)throw res.error;
    if(!res.data)throw new Error('profile missing');
    state.profile=res.data;
    saveOfflineAuth(state.user);
    if(state.profile.approval_status!=='approved'||!state.profile.active){showAccessStatus(state.profile);return false}
    await loadAll(true);
    cacheSnapshot();
    if(renderAfter&&$('#app')&&!$('#app').classList.contains('hidden'))render();
    if(readOfflineQueue().length)setTimeout(syncOfflineQueue,100);
    return true
  }catch(e){state.networkVerified=false;state.offline=true;updateSyncBadge();return false}
}
async function boot(user=null){
  state.demo=false;
  let u=user;
  if(!u){try{let r=await withTimeout(db.auth.getSession(),650,'session timeout');u=r?.data?.session?.user||null}catch(e){u=null}}
  if(!u&&!navigator.onLine)u=readOfflineAuth();
  if(!u)return;
  state.user=u;saveOfflineAuth(u);

  // Local-first: restore and paint immediately. No network request is allowed to block the UI.
  let cached=restoreSnapshot();
  if(cached&&state.profile){
    if(state.profile.approval_status!=='approved'||!state.profile.active){showAccessStatus(state.profile);return}
    state.fastStarted=true;
    $('#pendingPanel').classList.add('hidden');
    showApp();
    updateSyncBadge();
    setTimeout(()=>refreshFromServer({renderAfter:true}),60);
    return
  }

  // First ever launch on this device still needs one successful online load.
  if(!(await internetReachable(true)))return toast('لا توجد نسخة محلية بعد. افتح التطبيق مرة واحدة مع الإنترنت لتحميل بيانات حسابك.');
  let res;
  try{res=await withTimeout(db.from('profiles').select('*').eq('id',u.id).single(),4000,'profile timeout')}catch(e){return toast('تعذر تحميل الحساب حالياً')}
  if(res?.error||!res?.data)return toast('تعذر تحميل الحساب');
  state.profile=res.data;
  if(state.profile.approval_status!=='approved'||!state.profile.active){showAccessStatus(state.profile);return}
  $('#pendingPanel').classList.add('hidden');
  await loadAll(true);showApp();cacheSnapshot();setTimeout(syncOfflineQueue,250)
}
async function logout(){try{await db.auth.signOut()}catch(e){}clearOfflineAuth();location.reload()}
function showApp(){$('#auth').classList.add('hidden');$('#app').classList.remove('hidden');$('#roleLabel').textContent=roleAr[state.profile.role]||state.profile.role;$('#userName').textContent=state.profile.full_name;$('#drawerUser').textContent=`${state.profile.full_name} · ${roleAr[state.profile.role]}`;$('#userAvatar').textContent=(state.profile.full_name||'ح')[0];updateSyncBadge();render()}
async function loadRoleExtras(){state.guardianAccounts=[];state.guardianDirectory=[];state.guardianRanksMonth={};state.guardianRanksDay={};state.guardianCompetition={};if(!state.networkVerified)return;if(roleCanManage()){let g=await db.rpc('list_guardian_accounts');if(!g.error)state.guardianAccounts=g.data||[]}if(state.profile?.role==='guardian'){let d=await db.rpc('guardian_student_directory');if(!d.error)state.guardianDirectory=d.data||[];for(let st of activeStudents()){let [m,day]=await Promise.all([db.rpc('student_rank_snapshot',{p_student_id:st.id,p_period:'month'}),db.rpc('student_rank_snapshot',{p_student_id:st.id,p_period:'day'})]);state.guardianRanksMonth[st.id]=m.data||[];state.guardianRanksDay[st.id]=day.data||[]}}}
async function loadAll(forceNetwork=false){
  let online=forceNetwork?true:await internetReachable();
  if(!online){if(restoreSnapshot()){state.pendingSync=readOfflineQueue().length;applySavedTheme();updateSyncBadge();return}state.offline=true;updateSyncBadge();return}
  state.networkVerified=true;state.offline=false;
  let queries=[db.from('halaqas').select('*').order('created_at'),db.from('students').select('*').order('full_name'),db.from('sessions').select('*').order('session_date',{ascending:false}).limit(120),db.from('announcements').select('*').order('pinned',{ascending:false}).order('publish_at',{ascending:false}).limit(80),db.from('student_goals').select('*').gte('period_end',monthStart()).limit(200),db.from('monthly_student_stats').select('*').gte('month_start',monthStart()),db.from('leaderboard_daily').select('*').eq('period_date',today()),db.from('leaderboard_monthly').select('*').gte('month_start',monthStart()),db.from('daily_student_summary').select('*').eq('session_date',today()).limit(200),db.from('forum_posts').select('*').order('pinned',{ascending:false}).order('created_at',{ascending:false}).limit(80),db.from('forum_comments').select('*').order('created_at').limit(500),db.from('app_settings').select('*').eq('id',1).single(),db.from('student_categories').select('*').order('min_age',{ascending:true,nullsFirst:false}).order('name'),db.from('halaqa_teachers').select('*')];if(roleCanAdmin())queries.push(db.from('profiles').select('id,full_name,email,phone,role,requested_role,approval_status,active,approved_at,rejection_reason,created_at').order('created_at',{ascending:false}));
  let r;
  try{r=await withTimeout(Promise.all(queries),6500,'load timeout')}catch(e){state.networkVerified=false;state.offline=true;if(restoreSnapshot()){updateSyncBadge();return}throw e}
  let critical=r.slice(0,3).find(x=>x.error&&isNetworkError(x.error));if(critical&&restoreSnapshot()){state.networkVerified=false;state.offline=true;state.pendingSync=readOfflineQueue().length;updateSyncBadge();return}
  [state.halaqas,state.students,state.sessions,state.announcements,state.goals,state.monthly,state.leaderDaily,state.leaderMonthly,state.dailySummary,state.forum,state.comments]=r.slice(0,11).map(x=>x.data||[]);state.settings=r[11]?.data||null;state.categories=r[12]?.data||[];state.halaqaTeachers=r[13]?.data||[];state.users=roleCanAdmin()?(r[14]?.data||[]):[];await loadRoleExtras();applySavedTheme();await loadPhotoUrls();state.pendingSync=readOfflineQueue().length;cacheSnapshot();updateSyncBadge()
}
async function loadPhotoUrls(){state.photoUrls={};if(state.demo||!state.networkVerified)return;await Promise.all(state.students.filter(s=>s.photo_path).map(async s=>{let {data}=await db.storage.from('student-photos').createSignedUrl(s.photo_path,3600);if(data?.signedUrl)state.photoUrls[s.id]=data.signedUrl}))}

function guardianDirectoryHtml(){if(!state.guardianDirectory.length)return '';let groups={};state.guardianDirectory.forEach(x=>{let k=x.halaqa_name||'الحلقة';(groups[k]||(groups[k]=[])).push(x.full_name)});return `<div class="section-head"><h3>أسماء طلاب الحلقة</h3></div><div class="privacy-note">يمكنك رؤية أسماء طلاب الحلقة فقط. الملفات الشخصية والهوية والجوال وتاريخ الميلاد والتقارير الخاصة بالطلاب الآخرين محجوبة بالكامل.</div>${Object.entries(groups).map(([h,names])=>`<div class="card directory-group"><h4>${esc(h)}</h4><div class="name-directory">${names.map(n=>`<span class="name-only">${esc(n)}</span>`).join('')}</div></div>`).join('')}`}
function guardianRankTiles(st,period='month'){return `<div class="guardian-rank-grid">${['hifz','review','sard'].map(t=>{let x=rankRowFor(st.id,t,period);return `<div class="guardian-rank"><span>${trackAr[t]}</span><b>${x?`${x.rank_no}/${x.total_students}`:'—'}</b><span>${x?`${fmt(x.points)} نقطة · ${fmt(x.pages)} ص`:'لا توجد نتيجة'}</span></div>`}).join('')}</div>`}
function guardianHomePage(){if(!state.students.length)return `${offlineNotice()}<div class="hero"><h2>أهلاً ${esc(state.profile.full_name)}</h2><p>حساب ولي الأمر جاهز، لكن لم يُربط أي طالب بحسابك بعد.</p></div><div class="notice" style="margin-top:14px">يتم الربط الآن باختيار حساب ولي الأمر مباشرة من ملف الطالب بواسطة مسؤول/مشرف/محفّظ الحلقة.</div>`;let cards=activeStudents().map(st=>{let m=state.monthly.find(x=>x.student_id===st.id)||{},d=state.dailySummary.find(x=>x.student_id===st.id);return `<div class="card guardian-child-card"><div class="row">${avatarHtml(st)}<div class="grow"><b>${esc(st.full_name)}</b><div class="muted">${esc(studentTrackAr[st.track_code]||'بدون مسار')} · ${esc(categoryName(st))}</div></div><button class="mini" onclick="studentProfile('${st.id}')">ملف ابني</button></div><div class="grid stats" style="margin-top:10px">${stat('حفظ الشهر',fmt(m.hifz_pages)+' ص')}${stat('مراجعة',fmt(m.review_pages)+' ص')}${stat('سرد',fmt(m.sard_pages)+' ص')}${stat('غياب',m.absent_days||0)}</div>${guardianRankTiles(st,'month')}<div class="today-line">${d?`اليوم: ${attAr[d.attendance_status]||'لم يسجل'} · حفظ ${fmt(d.hifz_pages)} ص · مراجعة ${fmt(d.review_pages)} ص · سرد ${fmt(d.sard_pages)} ص${d.behavior?` · السلوك ${behAr[d.behavior]||d.behavior}`:''}`:'لا توجد بيانات جلسة اليوم بعد.'}</div></div>`}).join('');return `${offlineNotice()}<div class="hero"><h2>أهلاً ${esc(state.profile.full_name)}</h2><p>هذه الصفحة تعرض بيانات أبنائك فقط: الإنجاز والحضور والخطة والترتيب داخل الحلقة.</p></div>${cards}<div class="actions"><button class="btn btn-soft" onclick="go('reports')">تقارير أبنائي</button><button class="btn btn-soft" onclick="go('competition')">إحصائيات ومنافسة</button><button class="btn btn-soft" onclick="go('ranking')">ترتيب أبنائي</button></div>${guardianDirectoryHtml()}<div class="section-head"><h3>آخر الإعلانات</h3><button class="mini" onclick="go('community')">عرض الكل</button></div>${announcementCards(state.announcements.slice(0,3))}`}
function homePage(){if(state.profile.role==='guardian')return guardianHomePage();let m=state.monthly,h=m.reduce((a,x)=>a+Number(x.hifz_pages||0),0),r=m.reduce((a,x)=>a+Number(x.review_pages||0),0),sa=m.reduce((a,x)=>a+Number(x.sard_pages||0),0),present=m.reduce((a,x)=>a+Number(x.present_days||0),0),abs=m.reduce((a,x)=>a+Number(x.absent_days||0),0);
let setup=isOwner()&&!state.halaqas.length?`<div class="notice" style="margin-bottom:12px"><b>ابدأ إعداد النظام:</b> لا توجد حلقة بعد. <button class="mini" onclick="go('halaqas')">إنشاء أول حلقة</button></div>`:'';return `${setup}<div class="hero"><h2>السلام عليكم، ${esc(state.profile.full_name)}</h2><p>${isOwner()?'إدارة الحلقات والصلاحيات والمتابعة العامة للنظام.':isSupervisor()?'متابعة الحلقة والمحفظين والطلاب والتقارير.':'تسجيل التسميع والحضور ومتابعة طلاب الحلقة.'}</p></div><div class="grid stats">${stat('الطلاب',activeStudents().length)}${stat('حفظ الشهر',fmt(h)+' ص')}${stat('مراجعة الشهر',fmt(r)+' ص')}${stat('سرد الشهر',fmt(sa)+' ص')}</div><div class="grid stats">${stat('الحضور',present)}${stat('الغياب',abs)}${stat('جلسات الشهر',state.sessions.filter(s=>s.session_date>=monthStart()).length)}${stat('الإعلانات',state.announcements.length)}</div><div class="section-head"><h3>إعلانات مهمة</h3><button class="mini" onclick="go('community')">عرض الكل</button></div>${announcementCards(state.announcements.filter(a=>a.pinned).slice(0,2))}<div class="section-head"><h3>جلسة اليوم</h3><button class="mini" onclick="go('sessions')">الجلسات</button></div>${sessionCards(state.sessions.filter(s=>s.session_date===today()).slice(0,2))}`}
function sessionCards(rows=state.sessions){if(!rows.length)return '<div class="empty">لا توجد جلسات.</div>';return rows.map(s=>`<div class="card row"><div class="avatar">${s.session_type==='sard'?'س':'ت'}</div><div class="grow"><b>${s.title||sesAr[s.session_type]}</b><div class="muted">${s.session_date} · ${sesAr[s.session_type]} · ${s.status==='open'?'مفتوحة':s.status==='cancelled'?'ملغاة':'مسجلة'} ${s._offline?'· محفوظ محلياً':''}</div></div>${roleCanManage()&&s.status!=='cancelled'?`<button class="mini" onclick="openSessionRoster('${s.id}')">فتح</button><button class="mini red" onclick="cancelSession('${s.id}')">إلغاء</button>`:''}</div>`).join('')}
function sessionsPage(){if(state.sessionView)return sessionRosterPage(state.sessionView);return `${offlineNotice()}<div class="section-head"><h3>الجلسات اليومية</h3>${roleCanManage()?'<button class="btn btn-primary" onclick="openSession()">+ جلسة</button>':''}</div><div class="tabs"><button class="tab active">الكل</button><button class="tab">تسميع</button><button class="tab">سرد</button><button class="tab">مراجعة</button><button class="tab">اختبارات</button></div>${sessionCards()}`}
async function cancelSession(id){if(!roleCanManage())return;if(!confirm('إلغاء هذه الجلسة؟ ستبقى محفوظة في السجل ولن تُحذف البيانات السابقة.'))return;let {error}=await db.from('sessions').update({status:'cancelled'}).eq('id',id);if(error)return toast(error.message);let s=state.sessions.find(x=>x.id===id);if(s)s.status='cancelled';toast('تم إلغاء الجلسة');render()}
function normalizeNameJs(v){return String(v||'').trim().toLowerCase().replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ؤ/g,'و').replace(/ئ/g,'ي').replace(/ة/g,'ه').replace(/[ـًٌٍَُِّْٰ]/g,'').replace(/[\s\-_–—:：/\\.،,()\[\]{}]+/g,' ').trim()}
function activeStudents(){return state.students.filter(s=>s.status!=='withdrawn')}
function categoryName(st){return state.categories.find(c=>c.id===st.category_id)?.name||'بدون فئة'}
function ageYears(d){if(!d)return null;let b=new Date(d+'T00:00:00'),n=new Date(),a=n.getFullYear()-b.getFullYear(),m=n.getMonth()-b.getMonth();if(m<0||(m===0&&n.getDate()<b.getDate()))a--;return a>=0?a:null}
function duplicateMap(){let m=new Map;activeStudents().forEach(s=>{let k=s.halaqa_id+'|'+normalizeNameJs(s.full_name);if(!m.has(k))m.set(k,[]);m.get(k).push(s)});return m}
function isDuplicateStudent(st){return (duplicateMap().get(st.halaqa_id+'|'+normalizeNameJs(st.full_name))||[]).length>1}
function filteredStudents(){let rows=state.students.filter(s=>state.studentStatus==='removed'?s.status==='withdrawn':s.status!=='withdrawn');if(state.studentHalaqa!=='all')rows=rows.filter(s=>s.halaqa_id===state.studentHalaqa);let q=normalizeNameJs(state.studentSearch);if(q)rows=rows.filter(s=>normalizeNameJs(s.full_name).includes(q)||String(s.national_id||'').includes(state.studentSearch)||String(s.phone||'').includes(state.studentSearch));if(state.studentCategory!=='all')rows=rows.filter(s=>(state.studentCategory==='none'?!s.category_id:s.category_id===state.studentCategory));if(state.studentTrack!=='all')rows=rows.filter(s=>(state.studentTrack==='none'?!s.track_code:s.track_code===state.studentTrack));return sortStudentsList(rows,state.studentSort)}
function setStudentFilter(k,v){state[k]=v;render()}
function toggleSelectionMode(){state.selectionMode=!state.selectionMode;if(!state.selectionMode)state.selectedStudents.clear();render()}
function toggleStudentSelection(id,on){if(on)state.selectedStudents.add(id);else state.selectedStudents.delete(id);let c=document.querySelector(`[data-stcard="${id}"]`);if(c)c.classList.toggle('selected',on);let n=$('#selectedCount');if(n)n.textContent=state.selectedStudents.size}
function selectAllFiltered(){state.selectionMode=true;filteredStudents().forEach(s=>state.selectedStudents.add(s.id));render()}
function selectDuplicateCopies(){state.selectionMode=true;state.selectedStudents.clear();for(let rows of duplicateMap().values()){if(rows.length>1){rows.sort((a,b)=>new Date(a.created_at)-new Date(b.created_at));rows.slice(1).forEach(s=>state.selectedStudents.add(s.id))}}toast(`تم تحديد ${state.selectedStudents.size} نسخة مكررة. راجعها قبل الإزالة.`);render()}
function studentCards(rows=null,selectable=false){rows=rows||activeStudents();if(!rows.length)return '<div class="empty">لا يوجد طلاب في هذا العرض.</div>';return rows.map(st=>{let m=state.monthly.find(x=>x.student_id===st.id)||{},g=state.goals.find(x=>x.student_id===st.id),pct=g&&g.target_hifz_pages?Math.min(100,Math.round(Number(m.hifz_pages||0)/Number(g.target_hifz_pages)*100)):0,age=ageYears(st.date_of_birth),dup=isDuplicateStudent(st),removed=st.status==='withdrawn',selected=state.selectedStudents.has(st.id);return `<div class="card student-card ${selected?'selected':''} ${removed?'removed-card':''}" data-stcard="${st.id}"><div class="row">${selectable&&state.selectionMode?`<input class="select-box" type="checkbox" ${selected?'checked':''} onchange="toggleStudentSelection('${st.id}',this.checked)">`:''}${avatarHtml(st)}<div class="grow"><b>${esc(st.full_name)}</b><div class="muted">${esc(studentTrackAr[st.track_code]||'بدون مسار')} · ${esc(categoryName(st))}${age!=null?` · ${age} سنة`:''}</div><div class="muted">حفظ ${fmt(m.hifz_pages)} ص · مراجعة ${fmt(m.review_pages)} ص · غياب ${m.absent_days||0}</div></div>${dup?'<span class="badge dup-badge">مكرر</span>':''}<span class="badge">${removed?'مزال':st.status==='active'?'نشط':esc(st.status)}</span></div>${g?`<div class="plan-bar"><div class="plan-label"><span>خطة الحفظ الشهرية</span><b>${pct}%</b></div><div class="progress"><i style="width:${pct}%"></i></div></div>`:''}<div class="actions">${!removed&&roleCanManage()?`<button class="mini" onclick="openDailyForStudent('${st.id}')">تسميع اليوم</button>`:''}<button class="mini" onclick="studentProfile('${st.id}')">الملف الشخصي</button>${!removed&&roleCanManage()?`<button class="mini" onclick="openPlan('${st.id}')">الخطة</button>`:''}${canManageStudents()?`<button class="mini" onclick="openStudent('${st.id}')">تعديل البيانات</button>`:''}${canManageStudents()&&!removed?`<button class="mini red" onclick="removeStudent('${st.id}')">إزالة</button>`:''}${canManageStudents()&&removed?`<button class="mini" onclick="restoreStudent('${st.id}')">استعادة</button>`:''}${isOwner()&&removed?`<button class="mini red" onclick="permanentlyDeleteStudent('${st.id}')">حذف نهائي</button>`:''}</div></div>`}).join('')}
function studentsPage(){let rows=filteredStudents(),dups=[...duplicateMap().values()].filter(x=>x.length>1).length,cats=state.categories.filter(c=>c.active!==false),removedCount=state.students.filter(s=>s.status==='withdrawn').length,title=state.studentStatus==='removed'?`الطلاب المُزالون (${removedCount})`:`الطلاب الحاليون (${activeStudents().length})`;return `<div class="section-head"><h3>${title}</h3><div class="actions">${canManageStudents()?'<button class="btn btn-primary" onclick="openStudent()">+ طالب</button><button class="btn btn-soft" onclick="toggleSelectionMode()">'+(state.selectionMode?'إنهاء التحديد':'تحديد الطلاب')+'</button>':''}</div></div><div class="student-tools"><div class="filter-grid"><input class="input" placeholder="بحث بالاسم أو الهوية أو الجوال" value="${esc(state.studentSearch)}" onchange="setStudentFilter('studentSearch',this.value)"><select onchange="setStudentFilter('studentHalaqa',this.value)"><option value="all">كل الحلقات</option>${state.halaqas.map(h=>`<option value="${h.id}" ${state.studentHalaqa===h.id?'selected':''}>${esc(h.name)}</option>`).join('')}</select><select onchange="setStudentFilter('studentCategory',this.value)"><option value="all">كل الفئات</option><option value="none" ${state.studentCategory==='none'?'selected':''}>بدون فئة</option>${cats.map(c=>`<option value="${c.id}" ${state.studentCategory===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select><select onchange="setStudentFilter('studentTrack',this.value)"><option value="all">كل المسارات</option><option value="none" ${state.studentTrack==='none'?'selected':''}>بدون مسار</option>${Object.entries(studentTrackAr).map(([k,v])=>`<option value="${k}" ${state.studentTrack===k?'selected':''}>${v}</option>`).join('')}</select><select onchange="setStudentFilter('studentStatus',this.value)"><option value="active" ${state.studentStatus==='active'?'selected':''}>الطلاب الحاليون</option><option value="removed" ${state.studentStatus==='removed'?'selected':''}>الطلاب المُزالون</option></select><select onchange="state.studentSort=this.value;render()"><option value="alpha" ${state.studentSort==='alpha'?'selected':''}>ترتيب أبجدي</option><option value="points" ${state.studentSort==='points'?'selected':''}>الأعلى نقاطاً</option><option value="oldest" ${state.studentSort==='oldest'?'selected':''}>الأكبر سناً</option><option value="youngest" ${state.studentSort==='youngest'?'selected':''}>الأصغر سناً</option><option value="joined_old" ${state.studentSort==='joined_old'?'selected':''}>الأقدم التحاقاً</option><option value="joined_new" ${state.studentSort==='joined_new'?'selected':''}>الأحدث التحاقاً</option></select></div><div class="actions">${canManageStudents()?`<button class="mini" onclick="openCategories(state.studentHalaqa!=='all'?state.studentHalaqa:state.halaqas[0]?.id)">إدارة الفئات</button><button class="mini" onclick="selectAllFiltered()">تحديد الظاهر (${rows.length})</button>${dups?`<button class="mini red" onclick="selectDuplicateCopies()">كشف المكرر (${dups} مجموعات)</button>`:''}`:''}</div></div>${studentCards(rows,true)}${state.selectionMode&&canManageStudents()?bulkStudentBar():''}`}
function bulkStudentBar(){let cats=state.categories.filter(c=>c.active!==false),removedView=state.studentStatus==='removed';return `<div class="bulk-bar"><b>المحدد: <span id="selectedCount">${state.selectedStudents.size}</span></b>${!removedView?`<select id="bulkCategory"><option value="">اختر فئة</option><option value="__none">بدون فئة</option>${cats.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select><button class="mini" onclick="bulkAssignCategory()">تعيين الفئة</button><select id="bulkTrack"><option value="">اختر مساراً</option><option value="__none">بدون مسار</option>${Object.entries(studentTrackAr).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select><button class="mini" onclick="bulkAssignTrack()">تعيين المسار</button><button class="mini red" onclick="bulkRemoveStudents()">إزالة المحدد</button>`:`<button class="mini" onclick="bulkRestoreStudents()">استعادة المحدد</button>${isOwner()?`<button class="mini red" onclick="bulkPermanentDeleteStudents()">حذف نهائي للمحدد</button>`:''}`}</div>`}
async function removeStudent(id){let st=state.students.find(x=>x.id===id);if(!st||!confirm(`إزالة الطالب «${st.full_name}» من القائمة الحالية؟\nلن نحذف سجله التاريخي أو تقاريره، ويمكن استعادته لاحقاً.`))return;let {error}=await db.from('students').update({status:'withdrawn',withdrawn_at:new Date().toISOString(),withdrawn_by:state.user.id}).eq('id',id);if(error)return toast(error.message);st.status='withdrawn';st.withdrawn_at=new Date().toISOString();state.selectedStudents.delete(id);toast('تمت إزالة الطالب مع حفظ سجله');render()}
async function restoreStudent(id){let st=state.students.find(x=>x.id===id);if(!st)return;let local=activeStudents().find(x=>x.halaqa_id===st.halaqa_id&&normalizeNameJs(x.full_name)===normalizeNameJs(st.full_name));if(local)return toast('لا يمكن الاستعادة: يوجد طالب حالي بنفس الاسم.');let {error}=await db.from('students').update({status:'active',withdrawn_at:null,withdrawn_by:null}).eq('id',id);if(error)return toast(error.message);st.status='active';st.withdrawn_at=null;st.withdrawn_by=null;toast('تمت استعادة الطالب');render()}
async function permanentlyDeleteStudent(id){if(!isOwner())return toast('الحذف النهائي متاح لمسؤول النظام فقط');let st=state.students.find(x=>x.id===id);if(!st)return;if(st.status!=='withdrawn')return toast('يجب إزالة الطالب أولاً قبل الحذف النهائي');if(!confirm(`حذف الطالب «${st.full_name}» نهائياً؟\nسيتم حذف سجلاته المرتبطة مثل الحضور والتسميع والخطط والملاحظات، ولا يمكن التراجع عن هذا الإجراء.`))return;if(!confirm('تأكيد أخير: هل تريد الحذف النهائي بالفعل؟'))return;if(st.photo_path){try{await db.storage.from('student-photos').remove([st.photo_path])}catch(e){}}let {error}=await db.from('students').delete().eq('id',id).eq('status','withdrawn');if(error)return toast(error.message);state.students=state.students.filter(x=>x.id!==id);state.goals=state.goals.filter(x=>x.student_id!==id);state.monthly=state.monthly.filter(x=>x.student_id!==id);state.dailySummary=state.dailySummary.filter(x=>x.student_id!==id);state.leaderDaily=state.leaderDaily.filter(x=>x.student_id!==id);state.leaderMonthly=state.leaderMonthly.filter(x=>x.student_id!==id);state.selectedStudents.delete(id);delete state.photoUrls[id];toast('تم حذف الطالب نهائياً');render()}
async function bulkRestoreStudents(){let ids=[...state.selectedStudents],rows=state.students.filter(s=>ids.includes(s.id)&&s.status==='withdrawn');if(!rows.length)return toast('لم تحدد طلاباً مُزالين');let blocked=[];for(let st of rows){let local=activeStudents().find(x=>x.halaqa_id===st.halaqa_id&&normalizeNameJs(x.full_name)===normalizeNameJs(st.full_name));if(local)blocked.push(st.full_name)}if(blocked.length)return toast(`تعذر الاستعادة لوجود أسماء حالية مكررة: ${blocked.slice(0,2).join('، ')}${blocked.length>2?'...':''}`);let {error}=await db.from('students').update({status:'active',withdrawn_at:null,withdrawn_by:null}).in('id',rows.map(x=>x.id));if(error)return toast(error.message);rows.forEach(s=>{s.status='active';s.withdrawn_at=null;s.withdrawn_by=null});state.selectedStudents.clear();state.selectionMode=false;toast(`تمت استعادة ${rows.length} طالباً`);render()}
async function bulkPermanentDeleteStudents(){if(!isOwner())return toast('الحذف النهائي متاح لمسؤول النظام فقط');let ids=[...state.selectedStudents],rows=state.students.filter(s=>ids.includes(s.id)&&s.status==='withdrawn');if(!rows.length)return toast('حدد طلاباً مُزالين أولاً');if(!confirm(`حذف ${rows.length} طالباً نهائياً؟\nسيتم حذف جميع سجلاتهم المرتبطة ولا يمكن التراجع.`))return;if(!confirm('تأكيد أخير للحذف النهائي الجماعي؟'))return;for(let st of rows.filter(x=>x.photo_path)){try{await db.storage.from('student-photos').remove([st.photo_path])}catch(e){}}let delIds=rows.map(x=>x.id);let {error}=await db.from('students').delete().in('id',delIds).eq('status','withdrawn');if(error)return toast(error.message);let gone=new Set(delIds);state.students=state.students.filter(x=>!gone.has(x.id));state.goals=state.goals.filter(x=>!gone.has(x.student_id));state.monthly=state.monthly.filter(x=>!gone.has(x.student_id));state.dailySummary=state.dailySummary.filter(x=>!gone.has(x.student_id));state.leaderDaily=state.leaderDaily.filter(x=>!gone.has(x.student_id));state.leaderMonthly=state.leaderMonthly.filter(x=>!gone.has(x.student_id));delIds.forEach(id=>delete state.photoUrls[id]);state.selectedStudents.clear();state.selectionMode=false;toast(`تم حذف ${delIds.length} طالباً نهائياً`);render()}
async function bulkAssignCategory(){let ids=[...state.selectedStudents],v=$('#bulkCategory')?.value;if(!ids.length)return toast('حدد طالباً واحداً على الأقل');if(!v)return toast('اختر الفئة');if(v!=='__none'){let c=state.categories.find(x=>x.id===v),bad=state.students.find(s=>state.selectedStudents.has(s.id)&&s.halaqa_id!==c?.halaqa_id);if(bad)return toast('الفئة تتبع حلقة مختلفة. حدّد طلاباً من نفس الحلقة أولاً.')}let {error}=await db.from('students').update({category_id:v==='__none'?null:v}).in('id',ids);if(error)return toast(error.message);state.students.forEach(s=>{if(state.selectedStudents.has(s.id))s.category_id=v==='__none'?null:v});toast('تم تحديث فئة الطلاب المحددين');render()}
async function bulkAssignTrack(){let ids=[...state.selectedStudents],v=$('#bulkTrack')?.value;if(!ids.length)return toast('حدد طالباً واحداً على الأقل');if(!v)return toast('اختر المسار');let {error}=await db.from('students').update({track_code:v==='__none'?null:v}).in('id',ids);if(error)return toast(error.message);state.students.forEach(s=>{if(state.selectedStudents.has(s.id))s.track_code=v==='__none'?null:v});toast('تم تحديث مسار الطلاب المحددين');render()}
async function bulkRemoveStudents(){let ids=[...state.selectedStudents];if(!ids.length)return toast('لم تحدد طلاباً');if(!confirm(`إزالة ${ids.length} طالباً من القائمة الحالية مع الاحتفاظ بسجلهم وتقاريرهم؟`))return;let {error}=await db.from('students').update({status:'withdrawn',withdrawn_at:new Date().toISOString(),withdrawn_by:state.user.id}).in('id',ids);if(error)return toast(error.message);state.students.forEach(s=>{if(state.selectedStudents.has(s.id))s.status='withdrawn'});state.selectedStudents.clear();state.selectionMode=false;toast('تمت الإزالة مع حفظ السجلات');render()}
function halaqasPage(){if(!roleCanManage())return '<div class="empty">لا توجد حلقات متاحة.</div>';return `<div class="hero"><h2>${isOwner()?'إدارة الحلقات والفئات':'الحلقات والفئات'}</h2><p>كل حلقة لها مشرف ومحفّظون، وفئات عمرية مرنة، وثلاثة مسارات واضحة: الحفظ العام، السرد، والتثبيت.</p></div><div class="section-head"><h3>الحلقات (${state.halaqas.length})</h3>${isOwner()?'<button class="btn btn-primary" onclick="openHalaqa()">+ حلقة</button>':''}</div>${state.halaqas.map(h=>{let sup=state.users.find(u=>u.id===h.supervisor_id),cats=state.categories.filter(c=>c.halaqa_id===h.id&&c.active!==false),sts=activeStudents().filter(s=>s.halaqa_id===h.id),tids=state.halaqaTeachers.filter(x=>x.halaqa_id===h.id).map(x=>x.teacher_id),teachers=state.users.filter(u=>tids.includes(u.id));return `<div class="card"><div class="row"><div class="avatar">ح</div><div class="grow"><b>${esc(h.name)}</b><div class="muted">${esc(h.location||'المكان غير محدد')} · ${esc(h.schedule_text||'البرنامج غير محدد')}</div><div class="muted">المشرف: ${esc(sup?.full_name||'غير معيّن')} · المحفّظون: ${teachers.length?teachers.map(x=>esc(x.full_name)).join('، '):(state.profile.role==='teacher'?'أنت / حسب الربط':'غير معيّنين')}</div></div><span class="badge">${h.active===false?'موقوفة':'نشطة'}</span></div><div class="structure-grid"><div class="structure-item"><b>${sts.length}</b>طالب</div><div class="structure-item"><b>${cats.length}</b>فئة</div><div class="structure-item"><b>${tids.length}</b>محفّظ</div></div><div class="actions">${isOwner()?`<button class="mini" onclick="openHalaqa('${h.id}')">تعديل الحلقة</button>`:''}<button class="mini" onclick="openCategories('${h.id}')">الفئات</button>${['admin','supervisor'].includes(state.profile.role)?`<button class="mini" onclick="openTeacherAssignments('${h.id}')">المحفّظون</button>`:''}<button class="mini" onclick="goToHalaqaStudents('${h.id}')">طلاب الحلقة</button></div><div class="muted" style="margin-top:9px">المسارات: حفظ عام ${sts.filter(s=>s.track_code==='general_hifz').length} · سرد ${sts.filter(s=>s.track_code==='sard').length} · تثبيت ${sts.filter(s=>s.track_code==='tathbit').length} · بدون مسار ${sts.filter(s=>!s.track_code).length}</div></div>`}).join('')||'<div class="empty">لا توجد حلقات بعد.</div>'}`}
function goToHalaqaStudents(hid){let h=state.halaqas.find(x=>x.id===hid);state.studentSearch='';state.studentHalaqa=hid;state.studentStatus='active';state.studentCategory='all';state.studentTrack='all';state.page='students';render();setTimeout(()=>{let rows=activeStudents().filter(s=>s.halaqa_id===hid);if(state.halaqas.length>1&&rows.length)toast(`عرض طلاب ${h?.name||'الحلقة'} عبر البحث والتصنيف`);},50)}
function openHalaqa(id=null){if(!isOwner())return toast('هذه الصفحة لمسؤول النظام فقط');let h=id?state.halaqas.find(x=>x.id===id):null;$('#hqId').value=h?.id||'';$('#hqName').value=h?.name||'';$('#hqDescription').value=h?.description||'';$('#hqLocation').value=h?.location||'';$('#hqSchedule').value=h?.schedule_text||'';let rows=state.users.filter(u=>u.role==='supervisor'&&u.approval_status==='approved'&&u.active);$('#hqSupervisor').innerHTML='<option value="">بدون تحديد</option>'+rows.map(u=>`<option value="${u.id}" ${h?.supervisor_id===u.id?'selected':''}>${esc(u.full_name)}</option>`).join('');$('#halaqaDlgTitle').textContent=h?'تعديل الحلقة':'إضافة حلقة';halaqaDlg.showModal()}
$('#halaqaForm').addEventListener('submit',async e=>{e.preventDefault();let id=$('#hqId').value,obj={name:$('#hqName').value.trim(),description:$('#hqDescription').value.trim()||null,location:$('#hqLocation').value.trim()||null,schedule_text:$('#hqSchedule').value.trim()||null,supervisor_id:$('#hqSupervisor').value||null};let res=id?await db.from('halaqas').update(obj).eq('id',id).select().single():await db.from('halaqas').insert(obj).select().single();if(res.error)return toast(res.error.message);halaqaDlg.close();toast(id?'تم تحديث الحلقة':'تم إنشاء الحلقة');await loadAll();render()})

function fillCategories(sel,hid,selected=''){let rows=state.categories.filter(c=>(!hid||c.halaqa_id===hid)&&c.active!==false);sel.innerHTML='<option value="">بدون فئة</option>'+rows.map(c=>`<option value="${c.id}" ${selected===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}
function openCategories(hid){hid=hid||state.halaqas[0]?.id;if(!hid)return toast('لا توجد حلقة');$('#catHalaqa').value=hid;$('#categoryForm').reset();$('#catHalaqa').value=hid;renderCategoryList();categoryDlg.showModal()}
function renderCategoryList(){let hid=$('#catHalaqa').value,rows=state.categories.filter(c=>c.halaqa_id===hid&&c.active!==false),counts={};activeStudents().forEach(s=>{if(s.category_id)counts[s.category_id]=(counts[s.category_id]||0)+1});$('#categoryList').innerHTML=rows.length?rows.map(c=>`<div class="category-row"><div><b>${esc(c.name)}</b><div class="muted">${c.min_age!=null||c.max_age!=null?`العمر: ${c.min_age??'—'}–${c.max_age??'—'} سنة · `:''}${counts[c.id]||0} طالب${c.description?` · ${esc(c.description)}`:''}</div></div><button type="button" class="mini red" onclick="deleteCategory('${c.id}')">إزالة</button></div>`).join(''):'<div class="empty">لا توجد فئات بعد. أضف الفئة الأولى.</div>'}
$('#categoryForm').addEventListener('submit',async e=>{e.preventDefault();let hid=$('#catHalaqa').value,name=$('#catName').value.trim();if(!name)return toast('اكتب اسم الفئة');let min=$('#catMin').value===''?null:Number($('#catMin').value),max=$('#catMax').value===''?null:Number($('#catMax').value);if(min!=null&&max!=null&&max<min)return toast('أعلى عمر يجب أن يكون أكبر من أو يساوي أقل عمر');let {data,error}=await db.from('student_categories').insert({halaqa_id:hid,name,min_age:min,max_age:max,description:$('#catDesc').value.trim()||null,created_by:state.user.id}).select().single();if(error)return toast(error.code==='23505'?'هذه الفئة موجودة بالفعل':error.message);state.categories.push(data);$('#catName').value='';$('#catMin').value='';$('#catMax').value='';$('#catDesc').value='';renderCategoryList();toast('تمت إضافة الفئة')})
async function deleteCategory(id){let c=state.categories.find(x=>x.id===id),n=activeStudents().filter(s=>s.category_id===id).length;if(!confirm(`إزالة فئة «${c?.name||''}»؟${n?`\nسيصبح ${n} طالباً بدون فئة.`:''}`))return;if(n){let r=await db.from('students').update({category_id:null}).eq('category_id',id);if(r.error)return toast(r.error.message);state.students.forEach(s=>{if(s.category_id===id)s.category_id=null})}let {error}=await db.from('student_categories').delete().eq('id',id);if(error)return toast(error.message);state.categories=state.categories.filter(x=>x.id!==id);renderCategoryList();toast('تمت إزالة الفئة')}
async function autoAssignCategories(){let hid=$('#catHalaqa').value,cats=state.categories.filter(c=>c.halaqa_id===hid&&c.active!==false&&(c.min_age!=null||c.max_age!=null)),changes=[];if(!cats.length)return toast('ضع حدود عمر لفئة واحدة على الأقل');for(let st of activeStudents().filter(s=>s.halaqa_id===hid&&s.date_of_birth)){let a=ageYears(st.date_of_birth),match=cats.find(c=>(c.min_age==null||a>=c.min_age)&&(c.max_age==null||a<=c.max_age));if(match&&st.category_id!==match.id)changes.push([st,match.id])}if(!changes.length)return toast('لا يوجد طلاب يحتاجون توزيعاً حسب الأعمار الحالية');if(!confirm(`سيتم توزيع ${changes.length} طالباً حسب العمر. متابعة؟`))return;for(let [st,cid] of changes){let {error}=await db.from('students').update({category_id:cid}).eq('id',st.id);if(!error)st.category_id=cid}renderCategoryList();toast('تم التوزيع حسب العمر')}
function openTeacherAssignments(hid){if(!['admin','supervisor'].includes(state.profile.role))return toast('هذه الصلاحية للمسؤول أو المشرف');$('#taHalaqa').value=hid;let assigned=new Set(state.halaqaTeachers.filter(x=>x.halaqa_id===hid).map(x=>x.teacher_id)),rows=state.users.filter(u=>u.role==='teacher'&&u.approval_status==='approved'&&u.active);$('#teacherAssignList').innerHTML=rows.length?rows.map(u=>`<label class="teacher-check"><input type="checkbox" name="taTeacher" value="${u.id}" ${assigned.has(u.id)?'checked':''}><span><b>${esc(u.full_name)}</b><div class="muted">${esc(u.email||'')}</div></span></label>`).join(''):'<div class="empty">لا توجد حسابات محفّظين معتمدة بعد.</div>';teacherAssignDlg.showModal()}
$('#teacherAssignForm').addEventListener('submit',async e=>{e.preventDefault();let hid=$('#taHalaqa').value,wanted=[...document.querySelectorAll('input[name="taTeacher"]:checked')].map(x=>x.value),old=state.halaqaTeachers.filter(x=>x.halaqa_id===hid),oldIds=old.map(x=>x.teacher_id),toAdd=wanted.filter(x=>!oldIds.includes(x)),toDel=oldIds.filter(x=>!wanted.includes(x));if(toDel.length){let q=await db.from('halaqa_teachers').delete().eq('halaqa_id',hid).in('teacher_id',toDel);if(q.error)return toast(q.error.message)}if(toAdd.length){let q=await db.from('halaqa_teachers').insert(toAdd.map((teacher_id,i)=>({halaqa_id:hid,teacher_id,is_primary:i===0&&oldIds.length===0})));if(q.error)return toast(q.error.message)}teacherAssignDlg.close();toast('تم تحديث محفّظي الحلقة');await loadAll();render()})

function communityPage(){let tabs=`<div class="seg"><button class="${state.communityTab==='announcements'?'active':''}" onclick="setCommunityTab('announcements')">الإعلانات</button><button class="${state.communityTab==='forum'?'active':''}" onclick="setCommunityTab('forum')">منتدى الحلقة</button></div>`;if(state.communityTab==='announcements'){let filters=['all','daily','monthly','schedule','achievement','urgent'];let f=`<div class="tabs" style="margin-top:12px">${filters.map(x=>`<button class="tab ${state.announcementFilter===x?'active':''}" onclick="setAnnouncementFilter('${x}')">${x==='all'?'الكل':categoryAr[x]}</button>`).join('')}</div>`;let rows=state.announcements.filter(a=>state.announcementFilter==='all'||a.category===state.announcementFilter);return `${tabs}${f}<div class="section-head"><h3>إعلانات الحلقة</h3>${roleCanManage()?'<button class="btn btn-primary" onclick="openAnnouncement()">+ إعلان</button>':''}</div>${announcementCards(rows)}`}
let addBtn=roleCanManage()?'<button class="btn btn-primary" onclick="openForum()">+ منشور</button>':`<button class="btn btn-primary" onclick="openForum(null,'question')">+ استفسار</button>`;return `${tabs}<div class="section-head"><h3>منتدى الحلقة</h3>${addBtn}</div><div class="notice">ولي الأمر يستطيع طرح استفسار والتعليق. صاحب المنشور يعدّل منشوره، وصاحب التعليق يعدّل تعليقه، والإدارة تستطيع الإشراف على المحتوى.</div><div style="height:10px"></div>${forumCards()}`}
function setCommunityTab(t){state.communityTab=t;setFab();render()}function setAnnouncementFilter(f){state.announcementFilter=f;render()}
function announcementCards(rows=state.announcements){if(!rows.length)return '<div class="empty">لا توجد إعلانات في هذا القسم.</div>';return rows.map(a=>`<div class="card announcement"><div class="row"><div class="grow"><b>${a.pinned?'📌 ':''}${esc(a.title)}</b><div class="muted">${categoryAr[a.category]||'عام'} · ${new Date(a.publish_at).toLocaleDateString('ar')}</div></div><span class="badge ${a.priority==='urgent'?'red':a.priority==='important'?'warn':''}">${a.priority==='urgent'?'عاجل':a.priority==='important'?'مهم':'إعلان'}</span></div><p style="margin-bottom:0;white-space:pre-wrap">${esc(a.body)}</p>${roleCanManage()?`<div class="actions"><button class="mini red" onclick="deleteAnnouncement('${a.id}')">إزالة الإعلان</button></div>`:''}</div>`).join('')}
async function deleteAnnouncement(id){if(!roleCanManage())return;if(!confirm('إزالة هذا الإعلان؟'))return;let {error}=await db.from('announcements').delete().eq('id',id);if(error)return toast(error.message);state.announcements=state.announcements.filter(x=>x.id!==id);toast('تمت إزالة الإعلان');render()}
function canEditPost(p){return state.demo||p.author_id===state.user?.id||roleCanManage()}function canEditComment(c){return state.demo||c.author_id===state.user?.id||roleCanManage()}
function forumCards(){if(!state.forum.length)return '<div class="empty">لا توجد منشورات بعد.</div>';return state.forum.map(p=>{let cs=state.comments.filter(c=>c.post_id===p.id);return `<div class="card forum-card"><div class="row"><div class="grow"><b>${p.pinned?'📌 ':''}${esc(p.title)}</b><div class="muted">${esc(p.author_name||'عضو الحلقة')} · ${new Date(p.created_at).toLocaleDateString('ar')} ${p.updated_at&&p.updated_at!==p.created_at?'<span class="edited">· تم التعديل</span>':''}</div></div><span class="badge">${p.post_type==='question'?'استفسار':p.post_type==='achievement'?'إنجاز':p.post_type==='notice'?'ملاحظة':'نقاش'}</span></div><p style="white-space:pre-wrap">${esc(p.body)}</p><div class="forum-tools">${canEditPost(p)?`<button class="mini" onclick="openForum('${p.id}')">تعديل المنشور</button>`:''}${canEditPost(p)?`<button class="mini red" onclick="deleteForumPost('${p.id}')">حذف</button>`:''}<span class="badge">💬 ${cs.length}</span></div>${p.comments_enabled===false?'<div class="muted" style="margin-top:8px">التعليقات مغلقة لهذا المنشور.</div>':`<div class="forum-comments">${cs.map(c=>commentHtml(c)).join('')||'<div class="muted">لا توجد تعليقات بعد.</div>'}<div class="comment-form"><textarea id="comment_${p.id}" rows="2" placeholder="اكتب تعليقك أو استفسارك..."></textarea><button class="btn btn-soft" onclick="submitForumComment('${p.id}')">إرسال</button></div></div>`}</div>`}).join('')}
function commentHtml(c){return `<div class="comment"><div class="comment-head"><b>${esc(c.author_name|| (c.author_id===state.user?.id?'أنت':'عضو الحلقة'))}</b><span class="muted">${new Date(c.created_at).toLocaleDateString('ar')}</span>${c.updated_at&&c.updated_at!==c.created_at?'<span class="edited">تم التعديل</span>':''}<span class="grow"></span>${canEditComment(c)?`<button class="mini" onclick="editForumComment('${c.id}')">تعديل</button><button class="mini red" onclick="deleteForumComment('${c.id}')">حذف</button>`:''}</div><div class="comment-body">${esc(c.body)}</div></div>`}
async function submitForumComment(postId){let el=$('#comment_'+postId),body=el?.value.trim();if(!body)return toast('اكتب التعليق أولاً');if(state.demo){state.comments.push({id:'c'+Date.now(),post_id:postId,author_id:state.user.id,author_name:state.profile.full_name,body,created_at:new Date().toISOString(),updated_at:new Date().toISOString()});render();return}let {data,error}=await db.from('forum_comments').insert({post_id:postId,author_id:state.user.id,body}).select().single();if(error)return toast(error.message);state.comments.push(data);render()}
function editForumComment(id){let c=state.comments.find(x=>x.id===id);if(!c)return;$('#fcId').value=id;$('#fcBody').value=c.body;commentDlg.showModal()}
$('#commentForm').addEventListener('submit',async e=>{e.preventDefault();let id=$('#fcId').value,body=$('#fcBody').value.trim();if(!body)return;if(state.demo){let c=state.comments.find(x=>x.id===id);c.body=body;c.updated_at=new Date().toISOString()}else{let {data,error}=await db.from('forum_comments').update({body}).eq('id',id).select().single();if(error)return toast(error.message);state.comments[state.comments.findIndex(x=>x.id===id)]=data}commentDlg.close();toast('تم تعديل التعليق');render()})
async function deleteForumComment(id){if(!confirm('حذف التعليق؟'))return;if(state.demo)state.comments=state.comments.filter(x=>x.id!==id);else{let {error}=await db.from('forum_comments').delete().eq('id',id);if(error)return toast(error.message);state.comments=state.comments.filter(x=>x.id!==id)}render()}
async function deleteForumPost(id){if(!confirm('حذف المنشور وتعليقاته؟'))return;if(state.demo){state.forum=state.forum.filter(x=>x.id!==id);state.comments=state.comments.filter(x=>x.post_id!==id)}else{let {error}=await db.from('forum_posts').delete().eq('id',id);if(error)return toast(error.message);state.forum=state.forum.filter(x=>x.id!==id);state.comments=state.comments.filter(x=>x.post_id!==id)}render()}

function plansPage(){let rows=state.students.map(s=>({s,g:state.goals.find(g=>g.student_id===s.id),m:state.monthly.find(m=>m.student_id===s.id)||{}}));return `<div class="hero"><h2>الخطط الشهرية</h2><p>حدد المطلوب من الطالب خلال الشهر، ويحسب التطبيق الورد اليومي ومقدار الإنجاز.</p></div><div class="section-head"><h3>خطط الشهر</h3>${roleCanManage()?'<button class="btn btn-primary" onclick="openPlan()">+ خطة</button>':''}</div>${rows.map(({s,g,m})=>{if(!g)return `<div class="card row">${avatarHtml(s)}<div class="grow"><b>${s.full_name}</b><div class="muted">لا توجد خطة لهذا الشهر</div></div>${roleCanManage()?`<button class="mini" onclick="openPlan('${s.id}')">إضافة</button>`:''}</div>`;let hp=Math.min(100,Math.round(Number(m.hifz_pages||0)/Math.max(Number(g.target_hifz_pages||1),1)*100)),rp=Math.min(100,Math.round(Number(m.review_pages||0)/Math.max(Number(g.target_review_pages||1),1)*100)),sp=Math.min(100,Math.round(Number(m.sard_pages||0)/Math.max(Number(g.target_sard_pages||1),1)*100));return `<div class="card"><div class="row">${avatarHtml(s)}<div class="grow"><b>${s.full_name}</b><div class="muted">الورد اليومي: حفظ ${fmt(g.target_daily_hifz_pages)} · مراجعة ${fmt(g.target_daily_review_pages)} · سرد ${fmt(g.target_daily_sard_pages)} صفحة</div></div></div>${planProgress('الحفظ',hp,m.hifz_pages,g.target_hifz_pages)}${planProgress('المراجعة',rp,m.review_pages,g.target_review_pages)}${planProgress('السرد',sp,m.sard_pages,g.target_sard_pages)}</div>`}).join('')}`}
function planProgress(label,pct,done,target){return `<div class="plan-bar"><div class="plan-label"><span>${label}: ${fmt(done)} / ${fmt(target)} صفحة</span><b>${pct}%</b></div><div class="progress"><i style="width:${pct}%"></i></div></div>`}

function reportStudents(){return activeStudents()}
function reportRowMonthly(st){let r=state.monthly.find(x=>x.student_id===st.id)||{};return {student:st,stats:r}}
function reportHeaderHtml(title,subtitle){let org=state.settings?.organization_name||'حلقتي',hqs=[...new Set(reportStudents().map(s=>state.halaqas.find(h=>h.id===s.halaqa_id)?.name).filter(Boolean))];return `<div class="report-brand"><div class="mark">ح</div><h2>${esc(org)}</h2><p>${esc(title)}</p></div><div class="report-meta"><span><b>الفترة:</b> ${esc(subtitle)}</span><span><b>الحلقة:</b> ${esc(hqs.join('، ')||'—')}</span><span><b>تاريخ الإصدار:</b> ${new Date().toLocaleDateString('ar')}</span></div>`}
function reportFooterHtml(){return `<div class="report-footer"><span>تقرير صادر من نظام حلقتي — يعتمد على البيانات الفعلية المسجلة في النظام</span><span dir="ltr">Designed by ${esc(state.settings?.designed_by||'Dr. Mohammed Samir')}</span></div>`}
function monthlyReportHtml(){let rows=reportStudents().map(reportRowMonthly),sum=k=>rows.reduce((a,x)=>a+Number(x.stats[k]||0),0);return `<div class="report-paper">${reportHeaderHtml('التقرير الشهري لأداء الطلاب',monthStart().slice(0,7))}<div class="report-summary"><div><b>${rows.length}</b>طالب</div><div><b>${fmt(sum('hifz_pages'))}</b>صفحة حفظ</div><div><b>${fmt(sum('review_pages'))}</b>صفحة مراجعة</div><div><b>${fmt(sum('sard_pages'))}</b>صفحة سرد</div></div><div style="overflow:auto"><table class="report-table"><thead><tr><th>#</th><th>الطالب</th><th>الفئة</th><th>المسار</th><th>الحفظ</th><th>المراجعة</th><th>السرد</th><th>حضور</th><th>غياب</th><th>بعذر</th><th>تأخر</th><th>أخطاء</th></tr></thead><tbody>${rows.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.student.full_name)}</td><td>${esc(categoryName(x.student))}</td><td>${esc(studentTrackAr[x.student.track_code]||'—')}</td><td>${fmt(x.stats.hifz_pages)}</td><td>${fmt(x.stats.review_pages)}</td><td>${fmt(x.stats.sard_pages)}</td><td>${x.stats.present_days||0}</td><td>${x.stats.absent_days||0}</td><td>${x.stats.excused_days||0}</td><td>${x.stats.late_days||0}</td><td>${x.stats.mistakes||0}</td></tr>`).join('')}</tbody></table></div>${reportFooterHtml()}</div>`}
function dailyReportHtml(){let rows=state.dailySummary;let sum=k=>rows.reduce((a,x)=>a+Number(x[k]||0),0);return `<div class="report-paper">${reportHeaderHtml('التقرير اليومي للجلسات',new Date().toLocaleDateString('ar'))}<div class="report-summary"><div><b>${rows.length}</b>طالب مسجل</div><div><b>${fmt(sum('hifz_pages'))}</b>حفظ</div><div><b>${fmt(sum('review_pages'))}</b>مراجعة</div><div><b>${fmt(sum('sard_pages'))}</b>سرد</div></div>${rows.length?`<div style="overflow:auto"><table class="report-table"><thead><tr><th>#</th><th>الطالب</th><th>الحضور</th><th>الحفظ</th><th>المراجعة</th><th>السرد</th><th>الأخطاء</th><th>السلوك</th><th>تعليق المحفّظ</th></tr></thead><tbody>${rows.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(r.full_name)}</td><td>${attAr[r.attendance_status]||'—'}</td><td>${fmt(r.hifz_pages)}</td><td>${fmt(r.review_pages)}</td><td>${fmt(r.sard_pages)}</td><td>${r.mistakes||0}</td><td>${behAr[r.behavior]||'—'}</td><td>${esc(r.teacher_comment||'')}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد تقارير يومية مسجلة لهذا اليوم.</div>'}${reportFooterHtml()}</div>`}
function reportsPage(){let tabs=`<div class="seg"><button class="${state.reportTab==='daily'?'active':''}" onclick="setReportTab('daily')">اليومي</button><button class="${state.reportTab==='monthly'?'active':''}" onclick="setReportTab('monthly')">الشهري</button></div>`,tools=`<div class="actions report-tools" style="margin:12px 0"><button class="mini" onclick="exportReportsExcel()">Excel</button><button class="mini" onclick="exportCurrentReportWord()">Word منسق</button><button class="mini" onclick="printCurrentReport()">PDF / طباعة</button><button class="mini" onclick="exportCurrentReportImage()">صورة PNG</button></div>`;return `${tabs}${tools}<div id="reportExportArea">${state.reportTab==='daily'?dailyReportHtml():monthlyReportHtml()}</div>`}
function setReportTab(t){state.reportTab=t;render()}
function dailyReportCards(){if(!state.dailySummary.length)return '<div class="empty">لم تُسجل تقارير اليوم بعد.</div>';return state.dailySummary.map(r=>`<div class="card"><div class="row"><div class="grow"><b>${r.full_name}</b><div class="muted">${attAr[r.attendance_status]||'لم يسجل'} · السلوك ${behAr[r.behavior]||'—'}</div></div><span class="badge">${fmt(r.hifz_pages)} ص حفظ</span></div><div class="grid stats">${stat('الحفظ',fmt(r.hifz_pages)+' ص')}${stat('المراجعة',fmt(r.review_pages)+' ص')}${stat('السرد',fmt(r.sard_pages)+' ص')}${stat('الأخطاء',r.mistakes||0)}</div>${r.teacher_comment?`<div class="notice">${r.teacher_comment}</div>`:''}</div>`).join('')}


function competitionKey(studentId,scope,track=state.competitionTrack,period=state.competitionPeriod){return `${studentId}:${scope}:${track}:${period}`}
async function ensureGuardianCompetition(){if(state.profile?.role!=='guardian'||!state.networkVerified)return;let children=activeStudents(),jobs=[];for(let st of children){for(let scope of ['center','category']){let k=competitionKey(st.id,scope);if(state.guardianCompetition[k]!==undefined)continue;jobs.push((async()=>{let r=await db.rpc('guardian_competition_board',{p_student_id:st.id,p_track:state.competitionTrack,p_scope:scope,p_period:state.competitionPeriod});state.guardianCompetition[k]=r.error?[]:(r.data||[])})())}}if(jobs.length){await Promise.all(jobs);cacheSnapshot()}}
function competitionRows(st,scope){return state.guardianCompetition[competitionKey(st.id,scope)]||[]}
function competitionActivity(rows){return rows.some(x=>Number(x.pages||0)>0||Number(x.points||0)>0)}
function competitionMyRow(rows){return rows.find(x=>x.is_my_child)||null}
function competitionBoardRows(rows){let has=competitionActivity(rows);if(!has)return `<div class="comp-empty">لم تبدأ نتائج هذا المسار بعد في الفترة المحددة. سيظهر الترتيب تلقائياً بعد تسجيل أول تسميع.</div>`;return `<div class="comp-list">${rows.map(x=>`<div class="comp-row ${x.is_my_child?'mine':''}"><div class="comp-rank">${x.rank_no}</div><div class="comp-name"><b>${esc(x.full_name)}${x.is_my_child?'<span class="comp-you">ابني</span>':''}</b><span>${esc(x.category_name||x.halaqa_name||'طالب بالمركز')}</span></div><div class="comp-score"><b>${fmt(x.pages)} ص</b><span>${fmt(x.points)} نقطة</span></div></div>`).join('')}</div>`}
function competitionScopeCard(st,scope){let rows=competitionRows(st,scope),mine=competitionMyRow(rows),has=competitionActivity(rows),isCat=scope==='category',cat=categoryName(st);if(isCat&&!st.category_id)return `<div class="comp-scope-card"><div class="comp-title"><h3>ترتيب الفئة</h3><span class="badge">غير محددة</span></div><div class="comp-empty">هذا الطالب غير موضوع في فئة بعد. حدّد فئته من ملف الطالب ليظهر ترتيبه مقارنة بطلاب نفس الفئة.</div></div>`;let total=mine?.total_students||rows[0]?.total_students||0,avg=mine?.avg_pages??rows[0]?.avg_pages??0,rank=has&&mine?mine.rank_no:'—',pages=mine?.pages||0,title=isCat?`ترتيب الفئة · ${esc(cat)}`:'الترتيب على المركز';return `<div class="comp-scope-card"><div class="comp-title"><h3>${title}</h3><span class="badge">${state.competitionPeriod==='day'?'اليوم':'هذا الشهر'}</span></div><div class="comp-summary"><div class="box"><span>ترتيب ابني</span><b>${rank}${rank!=='—'?` / ${total}`:''}</b></div><div class="box"><span>صفحات ابني</span><b>${fmt(pages)}</b></div><div class="box"><span>متوسط المجموعة</span><b>${fmt(avg)} ص</b></div></div><div class="muted" style="margin:8px 0">نعرض أعلى الطلاب، ومعهم الطلاب الأقرب لترتيب ابنك قبله وبعده.</div>${competitionBoardRows(rows)}</div>`}
function guardianCompetitionPage(){let children=activeStudents();return `${offlineNotice()}<div class="hero"><h2>إحصائيات ومنافسة أبنائي</h2><p>مقارنة تحفيزية بالصفحات والنقاط فقط، مع الحفاظ على خصوصية الملفات الشخصية.</p><div class="comp-hero-note">يمكنك رؤية ترتيب ابنك داخل فئته، وترتيبه على مستوى المركز، والطلاب الأقرب إليه في الترتيب.</div></div><div class="comp-controls"><div class="seg"><button class="${state.competitionPeriod==='day'?'active':''}" onclick="setCompetitionPeriod('day')">اليوم</button><button class="${state.competitionPeriod==='month'?'active':''}" onclick="setCompetitionPeriod('month')">الشهر</button></div><div class="tabs"><button class="tab ${state.competitionTrack==='hifz'?'active':''}" onclick="setCompetitionTrack('hifz')">الحفظ</button><button class="tab ${state.competitionTrack==='review'?'active':''}" onclick="setCompetitionTrack('review')">المراجعة</button><button class="tab ${state.competitionTrack==='sard'?'active':''}" onclick="setCompetitionTrack('sard')">السرد</button></div></div>${children.map(st=>`<div class="section-head"><h3>${esc(st.full_name)}</h3><button class="mini" onclick="studentProfile('${st.id}')">ملف ابني</button></div>${competitionScopeCard(st,'category')}${competitionScopeCard(st,'center')}`).join('')||'<div class="empty">لا يوجد طالب مربوط بهذا الحساب.</div>'}<div class="comp-privacy">تظهر هنا أسماء الطلاب وترتيبهم وعدد الصفحات والنقاط فقط لأغراض التحفيز. لا يمكن لولي الأمر فتح ملفات الطلاب الآخرين أو رؤية الهوية أو الجوال أو تاريخ الميلاد أو الملاحظات والتقارير الخاصة بهم.</div>`}
async function setCompetitionTrack(t){state.competitionTrack=t;await render()}
async function setCompetitionPeriod(p){state.competitionPeriod=p;await render()}

function guardianRankingPage(){let period=state.rankPeriod==='day'?'day':'month';return `${offlineNotice()}<div class="hero"><h2>ترتيب أبنائي</h2><p>يظهر ترتيب ابنك داخل الحلقة دون كشف نتائج أو ملفات الطلاب الآخرين.</p></div><div class="seg" style="margin-top:13px"><button class="${period==='day'?'active':''}" onclick="setRankPeriod('day')">اليوم</button><button class="${period==='month'?'active':''}" onclick="setRankPeriod('month')">الشهر</button></div>${activeStudents().map(st=>`<div class="card"><div class="row">${avatarHtml(st)}<div class="grow"><b>${esc(st.full_name)}</b><div class="muted">ترتيبه بين طلاب الحلقة</div></div></div>${guardianRankTiles(st,period)}</div>`).join('')||'<div class="empty">لا يوجد طالب مربوط بالحساب.</div>'}<div class="privacy-note">لا يعرض هذا القسم نقاط أو تقارير الطلاب الآخرين. تُستخدم نتائج الحلقة في الخادم لحساب ترتيب ابنك فقط.</div>`}
function rankingPage(){if(state.profile?.role==='guardian')return guardianRankingPage();let periodRows=state.rankPeriod==='day'?state.leaderDaily:state.leaderMonthly;let rows=periodRows.filter(x=>x.track===state.rankTrack).sort((a,b)=>Number(b.points||0)-Number(a.points||0)||Number(b.pages||0)-Number(a.pages||0)||Number(a.penalty_per_page??999)-Number(b.penalty_per_page??999));return `<div class="hero"><h2>الترتيب والإحصائيات</h2><p>ترتيب مستقل للحفظ والمراجعة والسرد؛ النقاط قريبة من عدد الصفحات وليست بالمئات.</p></div><div class="card"><b>معادلة V4</b><div class="muted">الخصم = الأخطاء × 1 + النقرات × 0.5 · النقاط = الصفحات − (الخصم × 0.25). التقييم نفسه يعتمد على الخصم لكل صفحة، لذلك خطأ واحد في خمس صفحات لا يُعامل كخطأ واحد في صفحة واحدة.</div><div class="score-explain"><div class="ex">ممتاز<br>≤ 0.5 خصم/صفحة</div><div class="vg">جيد جداً<br>≤ 1 خصم/صفحة</div><div class="gd">جيد<br>≤ 2 خصم/صفحة</div><div class="rp">يحتاج إعادة<br>&gt; 2 خصم/صفحة</div></div></div><div class="seg" style="margin-top:13px"><button class="${state.rankPeriod==='day'?'active':''}" onclick="setRankPeriod('day')">اليوم</button><button class="${state.rankPeriod==='month'?'active':''}" onclick="setRankPeriod('month')">الشهر</button></div><div class="tabs" style="margin-top:12px"><button class="tab ${state.rankTrack==='hifz'?'active':''}" onclick="setRankTrack('hifz')">الحفظ</button><button class="tab ${state.rankTrack==='review'?'active':''}" onclick="setRankTrack('review')">المراجعة</button><button class="tab ${state.rankTrack==='sard'?'active':''}" onclick="setRankTrack('sard')">السرد</button></div><div class="section-head"><h3>ترتيب ${trackAr[state.rankTrack]}</h3></div>${rows.map((x,i)=>`<div class="card rank-row track-${state.rankTrack}"><div class="rank">${i+1}</div><div class="grow"><b>${esc(x.full_name)}</b><div class="muted">${fmt(x.pages)} صفحة · ${x.mistakes||0} أخطاء · ${x.prompts||0} نقرات · ${fmt(x.penalty_per_page)} خصم/صفحة</div></div><div style="text-align:left"><b>${fmt(x.points)}</b><div class="muted">نقطة</div></div></div>`).join('')||'<div class="empty">لا توجد بيانات ترتيب بعد.</div>'}<div class="notice">عند تساوي النقاط: يُفضّل صاحب الصفحات الأكثر، ثم الأقل في الخصم لكل صفحة.</div>`}
function setRankTrack(t){state.rankTrack=t;render()}function setRankPeriod(p){state.rankPeriod=p;render()}

function quranPage(){return `<div class="hero"><h2>حاسبة القرآن</h2><p>مصحف المدينة 604 صفحات · 114 سورة · اختيار الجزء أو السور المتفرقة أو الصفحة مع آيات البداية والنهاية.</p></div><div class="card"><div class="seg"><button class="active" onclick="switchQTab(this,'ayahs')">السورة والآية</button><button onclick="switchQTab(this,'pages')">الصفحات</button><button onclick="switchQTab(this,'surahs')">سور متعددة</button><button onclick="switchQTab(this,'juz')">الأجزاء</button></div><div id="qAyahs" class="mode-panel">${qAyahPanel('qc')}</div><div id="qPages" class="mode-panel hidden">${qPagesPanel('qc')}</div><div id="qSurahs" class="mode-panel hidden">${qSurahsPanel('qc')}</div><div id="qJuz" class="mode-panel hidden">${qJuzPanel('qc')}</div><div id="qResult" class="qcalc-result"><span class="muted">المقدار المحسوب</span><div><strong>0</strong> صفحة</div></div></div><div class="notice"><b>حساب محلي دون إنترنت:</b> نطاقات الآيات والسور والأجزاء تُحسب وفق مواضع الآيات على سطور مصحف المدينة QCF4 (15 سطراً للصفحة)، وليس بنسبة عدد الآيات. اختيار صفحات كاملة يبقى عدّاً مباشراً.</div>`}
function switchQTab(btn,t){btn.parentElement.querySelectorAll('button').forEach(x=>x.classList.remove('active'));btn.classList.add('active');['Ayahs','Pages','Surahs','Juz'].forEach(x=>$('#q'+x)?.classList.add('hidden'));$('#q'+t[0].toUpperCase()+t.slice(1))?.classList.remove('hidden')}
function juzButtons(prefix,multi=false){return `<div class="juz-grid">${juzStarts.map((_,i)=>`<button id="${prefix}J${i+1}" type="button" class="juz-chip" onclick="${multi?`toggleJuzSelection('${prefix}',${i+1})`:`pickJuz('${prefix}',${i+1})`}">${i+1}</button>`).join('')}</div>`}
function qAyahPanel(prefix,row=false){let opts=surahs.map((x,i)=>`<option value="${i+1}">${i+1}. ${x}</option>`).join('');return `<div class="muted">اختر جزءاً كاملاً بسرعة</div>${juzButtons(prefix,false)}<div class="range-pair"><label class="field"><span>سورة البداية</span><select id="${prefix}SS">${opts}</select></label><label class="field"><span>آية البداية</span><input id="${prefix}SA" class="input" type="number" value="1" min="1"></label><label class="field"><span>سورة النهاية</span><select id="${prefix}ES">${opts}</select></label><label class="field"><span>آية النهاية</span><input id="${prefix}EA" class="input" type="number" value="7" min="1"></label></div>${!row?`<button class="btn btn-primary" type="button" onclick="calcStandaloneAyahs('${prefix}')">احسب الصفحات والآيات</button>`:''}`}
function qPagesPanel(prefix,row=false){return `<div class="range-pair"><label class="field"><span>من صفحة</span><input id="${prefix}PF" class="input" type="number" min="1" max="604" value="1"></label><label class="field"><span>إلى صفحة</span><input id="${prefix}PT" class="input" type="number" min="1" max="604" value="1"></label></div><div class="actions"><button class="btn btn-soft" type="button" onclick="previewPages('${prefix}')">عرض سور وآيات طرفي النطاق</button>${!row?`<button class="btn btn-primary" type="button" onclick="calcStandalonePages('${prefix}')">احسب</button>`:''}</div><div id="${prefix}PagePreview" class="page-preview"></div>`}
function qSurahsPanel(prefix,row=false){return `<div class="muted">يمكن اختيار سور غير متجاورة؛ اضغط السورة لإضافتها أو إزالتها.</div><div id="${prefix}SurahGrid" class="surah-select-grid">${surahs.map((x,i)=>`<button id="${prefix}Surah${i+1}" type="button" onclick="toggleSurahSelection('${prefix}',${i+1})">${i+1}. ${x}</button>`).join('')}</div><div id="${prefix}SurahSummary" class="selection-summary">لم يتم اختيار سور.</div>${!row?`<button class="btn btn-primary" type="button" onclick="calcStandaloneMultiSurahs('${prefix}')">احسب السور المختارة</button>`:''}`}
function qJuzPanel(prefix,row=false){return `<div class="muted">اختر جزءاً أو أكثر؛ يمكن اختيار أجزاء غير متجاورة.</div>${juzButtons(prefix,true)}<div id="${prefix}JuzSummary" class="selection-summary">لم يتم اختيار أجزاء.</div>${!row?`<button class="btn btn-primary" type="button" onclick="calcStandaloneJuz('${prefix}')">احسب الأجزاء المختارة</button>`:''}`}
function surahAyahFromGlobal(g){let s=1;while(s<=114&&ayahPrefix[s]<g)s++;return [s,g-ayahPrefix[s-1]]}
function pickJuz(prefix,j){let start=juzStarts[j-1],end;if(j<30){let ng=globalAyah(...juzStarts[j]);end=surahAyahFromGlobal(ng-1)}else end=[114,ayahCounts[113]];$('#'+prefix+'SS').value=start[0];$('#'+prefix+'SA').value=start[1];$('#'+prefix+'ES').value=end[0];$('#'+prefix+'EA').value=end[1];$$('.juz-chip').filter(b=>b.id?.startsWith(prefix+'J')).forEach(b=>b.classList.remove('active'));$('#'+prefix+'J'+j)?.classList.add('active');toast(`تم تحديد الجزء ${j} كاملاً`)}
function selectedNums(prefix,kind){let base=kind==='surah'?'Surah':'J';return $$(`button[id^="${prefix}${base}"]`).filter(b=>b.classList.contains('active')).map(b=>Number(b.id.replace(prefix+base,'')))}
function toggleSurahSelection(prefix,n){$('#'+prefix+'Surah'+n).classList.toggle('active');let arr=selectedNums(prefix,'surah');$('#'+prefix+'SurahSummary').textContent=arr.length?`المحدد: ${arr.map(x=>surahs[x-1]).join('، ')} · ${arr.length} سورة`:'لم يتم اختيار سور.'}
function toggleJuzSelection(prefix,n){$('#'+prefix+'J'+n).classList.toggle('active');let arr=selectedNums(prefix,'juz');$('#'+prefix+'JuzSummary').textContent=arr.length?`الأجزاء المحددة: ${arr.join('، ')}`:'لم يتم اختيار أجزاء.'}
async function calcStandalonePages(p){let a=Number($('#'+p+'PF').value),b=Number($('#'+p+'PT').value);if(!a||!b||b<a)return toast('تحقق من الصفحات');let sel=standalonePageSelections[p];if(sel?.start&&sel?.end){let d=await calculateAyahRangeData(sel.start.surah,sel.start.ayah,sel.end.surah,sel.end.ayah);showQResult(d.pages,`${d.ayahs} آية · تحديد جزئي من ص ${a} إلى ص ${b}`)}else showQResult(b-a+1,`صفحات كاملة من ${a} إلى ${b}`)}
async function calcStandaloneAyahs(p){let d=await calculateAyahRangeData(+$('#'+p+'SS').value,+$('#'+p+'SA').value,+$('#'+p+'ES').value,+$('#'+p+'EA').value);showQResult(d.pages,`${d.ayahs} آية · من صفحة ${d.startPage} إلى ${d.endPage}`)}
async function calcStandaloneMultiSurahs(p){let arr=selectedNums(p,'surah');if(!arr.length)return toast('اختر سورة واحدة على الأقل');let d=await calculateFullSurahs(arr);showQResult(d.pages,`${arr.length} سورة · ${d.ayahs} آية`)}
async function calcStandaloneJuz(p){let arr=selectedNums(p,'juz');if(!arr.length)return toast('اختر جزءاً واحداً على الأقل');let d=await calculateJuzs(arr);showQResult(d.pages,`${arr.length} جزء · ${d.ayahs} آية`)}
function showQResult(pages,detail=''){$('#qResult').innerHTML=`<span class="muted">المقدار المحسوب</span><div><strong>${fmt(pages)}</strong> صفحة</div><div class="muted">${esc(detail)}</div>`}
const standalonePageSelections={};
async function previewPages(prefix){let a=+$('#'+prefix+'PF').value,b=+$('#'+prefix+'PT').value;if(!a||!b||a<1||b>604||b<a)return toast('تحقق من الصفحات');let box=$('#'+prefix+'PagePreview');if(!(await internetReachable())){box.innerHTML='<div class="notice">الحساب الدقيق يعمل دون إنترنت، لكن عرض نص آيات الصفحة يحتاج اتصالاً.</div>';return}box.innerHTML='<div class="muted">جاري تحميل آيات الصفحة...</div>';try{let pages=[a,b],data=await Promise.all(pages.map(x=>apiGet(`https://api.alquran.cloud/v1/page/${x}/quran-uthmani-quran-academy`)));box.innerHTML=data.map((d,i)=>pageEndpointCard(prefix,pages[i],d.ayahs||[],i===0?'start':'end',a===b)).join('')}catch(e){box.innerHTML=`<div class="notice">${esc(e.message)}</div>`}}
function pageEndpointCard(prefix,page,ayahs,side,same){let label=side==='start'?'بداية التسميع':'نهاية التسميع';if(same&&side==='start')label='اختر آية البداية (ثم اضغط آية أخرى كنهاية من نفس الصفحة)';return `<div class="page-card"><h4>صفحة ${page} · ${label}</h4><div class="ayah-list">${ayahs.map(a=>`<button type="button" class="ayah-chip" onclick="selectPageAyah('${prefix}','${side}',${a.number},${a.surah.number},${a.numberInSurah},${page},this)"><span>${esc(a.surah.name||'')} ${a.numberInSurah}</span><span class="ayah-text">${esc(a.text||'')}</span></button>`).join('')}</div></div>`}
function selectPageAyah(prefix,side,global,surah,ayah,page,btn){let row=document.querySelector(`.rec-row[data-id="${prefix}"]`);let obj={global,surah,ayah,page};if(row){row.dataset[side+'Global']=global;row.dataset[side+'Surah']=surah;row.dataset[side+'Ayah']=ayah}else{standalonePageSelections[prefix] ||= {};standalonePageSelections[prefix][side]=obj}let box=$('#'+prefix+'PagePreview');box?.querySelectorAll('.ayah-chip').forEach(x=>x.classList.remove(side==='start'?'active-start':'active-end'));btn.classList.add(side==='start'?'active-start':'active-end');toast(`تم تحديد ${side==='start'?'البداية':'النهاية'}: ${surahs[surah-1]} آية ${ayah}`)}
const QURAN_LAYOUT_CACHE='halaqati_quran_qcf4_layout_v24';
let quranLayout=window.HALAQATI_QURAN_LAYOUT||null;
function loadQuranLayoutCache(){if(quranLayout)return quranLayout;try{quranLayout=JSON.parse(localStorage.getItem(QURAN_LAYOUT_CACHE)||'null')}catch(e){}return quranLayout}
function compactQcf4Verses(obj){
  let page=new Array(6237).fill(0),first=new Array(6237).fill(0),last=new Array(6237).fill(0);
  for(let [key,v] of Object.entries(obj||{})){
    let [ss,aa]=key.split(':').map(Number),g=globalAyah(ss,aa),lines=(v?.lines||[]).map(x=>Number(x.line)).filter(Boolean);
    page[g]=Number(v?.page||0);first[g]=lines.length?Math.min(...lines):0;last[g]=lines.length?Math.max(...lines):first[g]
  }
  return {version:1,source:'QCF4 Hafs · Madinah Mushaf 1441 AH',lineModel:15,page,first,last}
}
async function ensureQuranLayout(background=false){
  if(loadQuranLayoutCache()?.page?.length>6200)return quranLayout;
  if(!navigator.onLine){if(!background)toast('بيانات المصحف الدقيقة غير مخزنة بعد في نسخة HTML. نسخة APK تتضمنها تلقائياً.');return null}
  try{
    let urls=['https://raw.githubusercontent.com/MohamadHajjRabee/quran-qcf4/main/verses.json','https://cdn.jsdelivr.net/gh/MohamadHajjRabee/quran-qcf4@main/verses.json'],obj=null;
    for(let url of urls){try{let ctl=new AbortController(),tm=setTimeout(()=>ctl.abort(),7000),r=await fetch(url,{cache:'force-cache',signal:ctl.signal});clearTimeout(tm);if(r.ok){obj=await r.json();break}}catch(e){}}
    if(!obj)throw new Error('layout unavailable');
    quranLayout=compactQcf4Verses(obj);try{localStorage.setItem(QURAN_LAYOUT_CACHE,JSON.stringify(quranLayout))}catch(e){}
    return quranLayout
  }catch(e){if(!background)toast('تعذر تنزيل بيانات المصحف الدقيقة حالياً');return null}
}
function quranLineSetForRange(gs,ge,layout){let set=new Set(),sp=0,ep=0;for(let g=gs;g<=ge;g++){let p=Number(layout.page[g]||0),a=Number(layout.first[g]||0),b=Number(layout.last[g]||a);if(!p||!a)continue;if(!sp)sp=p;ep=p;for(let line=a;line<=b;line++)set.add(`${p}:${line}`)}return {set,startPage:sp,endPage:ep}}
function layoutRangeData(ss,sa,es,ea,layout){let gs=globalAyah(ss,sa),ge=globalAyah(es,ea),u=quranLineSetForRange(gs,ge,layout),lineModel=Number(layout.lineModel||15);return {pages:Math.round((u.set.size/lineModel)*100)/100,ayahs:ge-gs+1,startPage:u.startPage||'—',endPage:u.endPage||'—',surahs:es-ss+1,preciseLines:true,source:layout.source}}
const apiCache={};async function apiGet(url){if(apiCache[url])return apiCache[url];let r=await fetch(url);if(!r.ok)throw new Error('تعذر الوصول لبيانات المصحف');let j=await r.json();apiCache[url]=j.data;return j.data}
async function calculateAyahRangeData(ss,sa,es,ea){
  if(ss<1||es>114||sa<1||ea<1)throw new Error('نطاق غير صحيح');if(sa>ayahCounts[ss-1]||ea>ayahCounts[es-1])throw new Error('رقم الآية يتجاوز عدد آيات السورة');let gs=globalAyah(ss,sa),ge=globalAyah(es,ea);if(ge<gs)throw new Error('نهاية النطاق قبل بدايته');
  let layout=loadQuranLayoutCache()||await ensureQuranLayout(true);if(layout?.page?.[gs]&&layout?.page?.[ge])return layoutRangeData(ss,sa,es,ea,layout);
  // Page-boundary fallback when running the loose HTML before its first metadata download.
  try{let [sm,em]=await Promise.all([apiGet(`https://api.alquran.cloud/v1/ayah/${gs}`),apiGet(`https://api.alquran.cloud/v1/ayah/${ge}`)]);let sp=sm.page,ep=em.page,pages=Math.max(1/15,ep-sp+1);return {pages:Math.round(pages*100)/100,ayahs:ge-gs+1,startPage:sp,endPage:ep,surahs:es-ss+1,estimated:true}}catch(e){let frac=(ge-gs+1)/6236*604;return {pages:Math.round(frac*100)/100,ayahs:ge-gs+1,startPage:'—',endPage:'—',surahs:es-ss+1,estimated:true}}
}
async function calculateSelectedRanges(ranges){
  let layout=loadQuranLayoutCache()||await ensureQuranLayout(true),all=new Set(),ayahs=0,minP=0,maxP=0;
  if(layout){for(let [ss,sa,es,ea] of ranges){let gs=globalAyah(ss,sa),ge=globalAyah(es,ea),u=quranLineSetForRange(gs,ge,layout);u.set.forEach(x=>all.add(x));ayahs+=ge-gs+1;if(u.startPage&&(!minP||u.startPage<minP))minP=u.startPage;if(u.endPage>maxP)maxP=u.endPage}return {pages:Math.round((all.size/Number(layout.lineModel||15))*100)/100,ayahs,startPage:minP||'—',endPage:maxP||'—',preciseLines:true,source:layout.source}}
  let total={pages:0,ayahs:0};for(let r of ranges){let d=await calculateAyahRangeData(...r);total.pages+=d.pages;total.ayahs+=d.ayahs}total.pages=Math.round(total.pages*100)/100;return total
}
async function calculateFullSurahs(arr){let d=await calculateSelectedRanges(arr.map(n=>[n,1,n,ayahCounts[n-1]]));d.surahs=arr.length;return d}
async function calculateJuzs(arr){let ranges=[];for(let j of arr){let start=juzStarts[j-1],end;if(j<30){let ng=globalAyah(...juzStarts[j]);end=surahAyahFromGlobal(ng-1)}else end=[114,ayahCounts[113]];ranges.push([start[0],start[1],end[0],end[1]])}return calculateSelectedRanges(ranges)}

function supervisionPage(){return `<div class="hero"><h2>متابعة المحفّظ</h2><p>مؤشرات تشغيلية تساعد المشرف على اكتشاف النقص مبكراً.</p></div><div class="grid stats">${stat('جلسات هذا الشهر',state.sessions.filter(x=>x.session_date>=monthStart()).length)}${stat('طلاب بلا خطة',state.students.filter(s=>!state.goals.some(g=>g.student_id===s.id)).length)}${stat('تقارير اليوم',state.dailySummary.length)}${stat('غياب اليوم',state.dailySummary.filter(x=>x.attendance_status==='absent').length)}</div><div class="card"><h3>قائمة متابعة</h3><div class="actions"><span class="badge">الحضور</span><span class="badge">الحفظ والمراجعة</span><span class="badge">السلوك</span><span class="badge">التعليقات اليومية</span><span class="badge">الخطط الشهرية</span></div></div>`}
function dataPage(){let canImport=canManageStudents(),advanced=roleCanAdmin();return `<div class="hero"><h2>الاستيراد والتصدير</h2><p>تصدير بيانات الطلاب الأساسية واستيراد البيانات مع مرحلة مراجعة قبل الحفظ.</p></div><div class="section-head"><h3>تصدير بيانات الطلاب</h3></div><div class="data-actions"><button class="action-card" onclick="exportStudentsExcel()"><b>تصدير الطلاب Excel</b><span>الاسم، الحلقة، الفئة، المسار، الجنس، الهوية، الجوال، الميلاد وبقية البيانات الأساسية</span></button><button class="action-card" onclick="exportStudentsWord()"><b>تصدير الطلاب Word</b><span>نفس بيانات Excel في جدول Word منسق</span></button><button class="action-card" onclick="openStudentsPdfPreview()"><b>تصدير الطلاب PDF</b><span>معاينة داخل التطبيق ثم حفظ PDF مع التحكم بالخط والاتجاه</span></button></div>${canImport?`<div class="section-head"><h3>استيراد</h3></div><div class="data-actions"><button class="action-card" onclick="openImport('students')"><b>إضافة طلاب جماعياً</b><span>Excel، CSV، DOCX، PDF أو صورة بعد المراجعة — المكرر لا يُضاف</span></button>${advanced?`<button class="action-card" onclick="openImport('recitations')"><b>استيراد تسميعات سابقة</b><span>الطالب، التاريخ، النوع، الصفحات، الأخطاء والنقرات</span></button><button class="action-card" onclick="openImport('plans')"><b>استيراد الخطط</b><span>الأهداف الشهرية للطلاب</span></button>`:''}<button class="action-card" onclick="downloadImportTemplate('students')"><b>قالب الطلاب</b><span>يشمل الاسم والفئة والمسار وبقية البيانات الاختيارية</span></button></div><div class="notice" style="margin-top:12px">PDF والصور وWord لا تُعتمد مباشرة؛ يتم استخراج النص ثم مراجعته أولاً لتقليل أخطاء OCR والتنسيق.</div>`:''}`}
function settingsPage(){let local=getThemePrefs(),global=state.settings||{};return `<div class="hero"><h2>الإعدادات</h2><p>المظهر والتفضيلات ونظام التقييم.</p></div><div class="card"><h3>المظهر</h3><div class="settings-row"><div><b>الوضع الداكن</b><div class="muted">يُحفظ على هذا الجهاز</div></div><input id="setDark" type="checkbox" ${local.dark?'checked':''} onchange="previewSettings()"></div><div class="settings-row"><div><b>اللون الأساسي</b><div class="muted">يمكن اختيار أي لون</div></div><input id="setPrimary" type="color" value="${local.primary||global.primary_color||'#0d3b2f'}" onchange="previewSettings()"></div><div class="settings-row"><div><b>اللون المساند</b></div><input id="setAccent" type="color" value="${local.accent||global.accent_color||'#2f8b69'}" onchange="previewSettings()"></div><div class="actions"><button class="theme-preset" style="background:#0d3b2f" onclick="setPreset('#0d3b2f','#2f8b69')" title="أخضر"></button><button class="theme-preset" style="background:#12345b" onclick="setPreset('#12345b','#2d6cdf')" title="أزرق"></button><button class="theme-preset" style="background:#5a3825" onclick="setPreset('#5a3825','#ad744f')" title="بني"></button><button class="theme-preset" style="background:#342b5f" onclick="setPreset('#342b5f','#765bc4')" title="بنفسجي"></button></div><div class="form-actions"><button class="btn btn-primary" onclick="saveThemeSettings()">حفظ المظهر</button><button class="btn btn-ghost" onclick="resetTheme()">إعادة الافتراضي</button></div></div><div class="card"><h3>معيار التقييم الحالي</h3><div class="muted">القاعدة في قاعدة البيانات أيضاً، وليست مجرد لون في الواجهة.</div><div class="score-explain"><div class="ex">ممتاز<br>≤ ${fmt(global.excellent_max_penalty_per_page??.5)} خصم/صفحة</div><div class="vg">جيد جداً<br>≤ ${fmt(global.very_good_max_penalty_per_page??1)}</div><div class="gd">جيد<br>≤ ${fmt(global.good_max_penalty_per_page??2)}</div><div class="rp">يحتاج إعادة<br>أعلى من ذلك</div></div><div class="notice">كل خطأ = 1 وحدة خصم، وكل نقرة = 0.5. النقاط = الصفحات − ربع وحدات الخصم. مثال: 5 صفحات + خطأ واحد = 4.75 نقطة وتقييم ممتاز لأن الكثافة 0.2 خطأ/صفحة.</div></div><div class="card"><h3>كلمة المرور</h3><div class="muted">يمكنك تغيير كلمة مرور حسابك الحالي في أي وقت.</div><div class="form-grid" style="margin-top:10px"><label class="field"><span>كلمة المرور الجديدة</span><input id="settingsPassword" class="input" type="password" minlength="6" autocomplete="new-password"></label><label class="field"><span>تأكيد كلمة المرور</span><input id="settingsPassword2" class="input" type="password" minlength="6" autocomplete="new-password"></label></div><button class="btn btn-primary" onclick="changeMyPassword()">تغيير كلمة المرور</button></div><div class="card"><b>Designed by Dr. Mohammed Samir</b><div class="muted">Halaqati Official 2.10</div></div>`}
function getThemePrefs(){try{return JSON.parse(localStorage.getItem('halaqati_theme_v4')||'{}')}catch{return {}}}
function applySavedTheme(){let p=getThemePrefs(),g=state.settings||{};let primary=p.primary||g.primary_color||'#0d3b2f',accent=p.accent||g.accent_color||'#2f8b69';document.documentElement.style.setProperty('--green',primary);document.documentElement.style.setProperty('--green3',accent);document.body.classList.toggle('dark',!!p.dark);document.querySelector('meta[name="theme-color"]')?.setAttribute('content',primary)}
function previewSettings(){let p=$('#setPrimary')?.value,a=$('#setAccent')?.value,d=$('#setDark')?.checked;if(p)document.documentElement.style.setProperty('--green',p);if(a)document.documentElement.style.setProperty('--green3',a);document.body.classList.toggle('dark',!!d)}
function setPreset(p,a){$('#setPrimary').value=p;$('#setAccent').value=a;previewSettings()}
function saveThemeSettings(){let p={dark:$('#setDark').checked,primary:$('#setPrimary').value,accent:$('#setAccent').value};localStorage.setItem('halaqati_theme_v4',JSON.stringify(p));applySavedTheme();toast('تم حفظ المظهر')}
function resetTheme(){localStorage.removeItem('halaqati_theme_v4');applySavedTheme();render()}
async function changeMyPassword(){let p1=$('#settingsPassword')?.value||'',p2=$('#settingsPassword2')?.value||'';if(p1.length<6)return toast('كلمة المرور يجب أن تكون 6 أحرف على الأقل');if(p1!==p2)return toast('كلمتا المرور غير متطابقتين');let {error}=await db.auth.updateUser({password:p1});if(error)return toast('تعذر تغيير كلمة المرور: '+error.message);$('#settingsPassword').value='';$('#settingsPassword2').value='';toast('تم تغيير كلمة المرور بنجاح')}
function printCurrentReport(){window.print()}
function downloadBlob(blob,name){let a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function studentDirectoryRows(){return activeStudents().slice().sort((a,b)=>String(a.full_name||'').localeCompare(String(b.full_name||''),'ar')).map((st,i)=>({'#':i+1,'اسم الطالب':st.full_name||'','الحلقة':state.halaqas.find(h=>h.id===st.halaqa_id)?.name||'','الفئة':categoryName(st),'المسار':studentTrackAr[st.track_code]||st.program_name||'','الجنس':st.gender==='male'?'ذكر':st.gender==='female'?'أنثى':'','رقم الهوية':st.national_id||'','الجوال':st.phone||'','تاريخ الميلاد':st.date_of_birth||'','المرحلة الدراسية':st.school_grade||'','بريد ولي الأمر':st.guardian_email||'','جوال ولي الأمر':st.guardian_phone||'','العنوان':st.address||'','تاريخ الالتحاق':st.enrollment_date||''}))}
async function exportStudentsExcel(){if(!window.XLSX)return toast('مكتبة Excel لم تُحمّل');let rows=studentDirectoryRows();if(!rows.length)return toast('لا يوجد طلاب للتصدير');let wb=XLSX.utils.book_new(),ws=XLSX.utils.json_to_sheet(rows);ws['!cols']=[{wch:5},{wch:30},{wch:28},{wch:18},{wch:20},{wch:10},{wch:16},{wch:16},{wch:14},{wch:18},{wch:28},{wch:18},{wch:28},{wch:16}];XLSX.utils.book_append_sheet(wb,ws,'الطلاب');let name=`طلاب_حلقتي_${today()}.xlsx`;if(isNativeHalaqati()){let b64=XLSX.write(wb,{bookType:'xlsx',type:'base64'});await saveOrShareBase64(b64,name,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}else XLSX.writeFile(wb,name)}
function studentsWordHtml(){let rows=studentDirectoryRows();let cols=['#','اسم الطالب','الحلقة','الفئة','المسار','الجنس','رقم الهوية','الجوال','تاريخ الميلاد','المرحلة الدراسية','بريد ولي الأمر','جوال ولي الأمر','العنوان','تاريخ الالتحاق'];return `<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>body{font-family:Arial,Tahoma,sans-serif;direction:rtl;color:#18231f;padding:22px}h1{text-align:center;color:#0d3b2f}p{text-align:center;color:#65716b}table{width:100%;border-collapse:collapse;font-size:9.5pt}th{background:#0d3b2f;color:#fff;padding:7px;border:1px solid #d7e0dc}td{padding:6px;border:1px solid #d7e0dc;text-align:center}td.name{text-align:right;font-weight:bold}</style></head><body><h1>حلقتي — بيانات الطلاب</h1><p>تاريخ الإصدار: ${today()} · عدد الطلاب: ${rows.length}</p><table><thead><tr>${cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${cols.map(c=>`<td class="${c==='اسم الطالب'?'name':''}">${esc(r[c])}</td>`).join('')}</tr>`).join('')}</tbody></table></body></html>`}
async function exportStudentsWord(){let rows=studentDirectoryRows();if(!rows.length)return toast('لا يوجد طلاب للتصدير');let blob=new Blob(['\\ufeff',studentsWordHtml()],{type:'application/msword'}),name=`طلاب_حلقتي_${today()}.doc`;if(isNativeHalaqati())await saveOrShareBase64(await blobToBase64(blob),name,'application/msword');else downloadBlob(blob,name)}
function reportExportRows(){if(state.reportTab==='daily')return state.dailySummary.map(r=>({'الطالب':r.full_name,'التاريخ':r.session_date,'الحضور':attAr[r.attendance_status]||'','الحفظ':r.hifz_pages||0,'المراجعة':r.review_pages||0,'السرد':r.sard_pages||0,'الأخطاء':r.mistakes||0,'السلوك':behAr[r.behavior]||'','تعليق المحفظ':r.teacher_comment||''}));return reportStudents().map(st=>{let r=state.monthly.find(x=>x.student_id===st.id)||{};return {'الطالب':st.full_name,'الفئة':categoryName(st),'المسار':studentTrackAr[st.track_code]||'','الشهر':r.month_start||monthStart(),'الحفظ':r.hifz_pages||0,'المراجعة':r.review_pages||0,'السرد':r.sard_pages||0,'الحضور':r.present_days||0,'الغياب':r.absent_days||0,'بعذر':r.excused_days||0,'التأخر':r.late_days||0,'الأخطاء':r.mistakes||0}})}
function exportReportsExcel(){if(!window.XLSX)return toast('مكتبة Excel لم تُحمّل');let wb=XLSX.utils.book_new(),ws=XLSX.utils.json_to_sheet(reportExportRows());XLSX.utils.book_append_sheet(wb,ws,state.reportTab==='daily'?'يومي':'شهري');XLSX.writeFile(wb,`تقرير_حلقتي_${today()}.xlsx`)}
function professionalWordHtml(){let body=state.reportTab==='daily'?dailyReportHtml():monthlyReportHtml();return `<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>body{font-family:Arial,Tahoma,sans-serif;color:#18231f;padding:24px}.report-paper{border:2px solid #0d3b2f;padding:24px;position:relative}.report-brand{text-align:center;border-bottom:2px solid #c89d4a;padding-bottom:12px;margin-bottom:14px}.mark{margin:auto;background:#0d3b2f;color:#fff;width:48px;height:48px;line-height:48px;border-radius:12px;font-size:24px;font-weight:bold}.report-brand h2{color:#0d3b2f;margin:7px 0 2px}.report-meta,.report-footer{display:flex;justify-content:space-between;gap:12px;font-size:11px}.report-summary{display:table;width:100%;margin:14px 0}.report-summary>div{display:table-cell;border:1px solid #dfe6e2;text-align:center;padding:8px}.report-summary b{display:block;color:#0d3b2f;font-size:17px}table{border-collapse:collapse;width:100%;font-size:10px}th{background:#0d3b2f;color:#fff;padding:7px}td{border:1px solid #dfe6e2;padding:6px;text-align:center}.report-footer{border-top:1px solid #ddd;margin-top:15px;padding-top:8px;color:#777}</style></head><body>${body}</body></html>`}
function exportCurrentReportWord(){downloadBlob(new Blob(['\ufeff',professionalWordHtml()],{type:'application/msword'}),`تقرير_حلقتي_${today()}.doc`)}
async function exportCurrentReportImage(){if(!window.html2canvas)return toast('مكتبة الصور لم تُحمّل');let el=$('#reportExportArea')||$('#content'),canvas=await html2canvas(el,{scale:2,backgroundColor:'#ffffff'});canvas.toBlob(b=>downloadBlob(b,`تقرير_حلقتي_${today()}.png`),'image/png')}
function openImport(kind='students'){if(kind==='students'&&!canManageStudents())return toast('لا تملك صلاحية استيراد الطلاب');if(kind!=='students'&&!roleCanAdmin())return toast('هذا النوع من الاستيراد للمشرف فقط');state.importRows=[];$('#importKind').value=kind;fillHalaqas($('#importHalaqa'));$('#importRaw').value='';$('#importPreview').innerHTML='';$('#importFile').value='';$('#importStatus').textContent='اختر ملفاً للقراءة والمراجعة.';importDlg.showModal()}
function normHeader(h){return String(h||'').replace(/[\u200e\u200f\ufeff]/g,'').trim().toLowerCase().replace(/[\s_\-–—:：/\\.،,()\[\]{}]+/g,'').replace(/ـ/g,'')}
function rowVal(row,names){let keys=Object.keys(row);for(let n of names){let k=keys.find(x=>normHeader(x)===normHeader(n));if(k!=null&&row[k]!=null)return row[k]}return ''}
async function readImportFile(file){if(!file)return;$('#importStatus').textContent='جاري قراءة الملف...';try{let ext=file.name.split('.').pop().toLowerCase(),rows=[],raw='';if(['xlsx','xls','csv'].includes(ext)){let ab=await file.arrayBuffer(),wb=XLSX.read(ab,{type:'array'}),ws=wb.Sheets[wb.SheetNames[0]];rows=XLSX.utils.sheet_to_json(ws,{defval:'',raw:false});raw=XLSX.utils.sheet_to_csv(ws,{FS:'\t'})}else if(ext==='docx'){let ab=await file.arrayBuffer(),res=await mammoth.extractRawText({arrayBuffer:ab});raw=res.value}else if(ext==='pdf'){if(!window.pdfjsLib)throw new Error('تعذر تحميل قارئ PDF');pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';let pdf=await pdfjsLib.getDocument({data:await file.arrayBuffer()}).promise,parts=[];for(let i=1;i<=pdf.numPages;i++){let pg=await pdf.getPage(i),tx=await pg.getTextContent();parts.push(tx.items.map(x=>x.str).join(' | '))}raw=parts.join('\n')}else if(file.type.startsWith('image/')){if(!window.Tesseract)throw new Error('تعذر تحميل OCR');$('#importStatus').textContent='جاري OCR العربي؛ قد يستغرق بعض الوقت...';let r=await Tesseract.recognize(file,'ara+eng',{logger:m=>{if(m.progress)$('#importStatus').textContent=`OCR ${Math.round(m.progress*100)}%`}});raw=r.data.text}else throw new Error('نوع ملف غير مدعوم');$('#importRaw').value=raw;if(rows.length){state.importRows=rows;showImportPreview()}else parseImportRaw();$('#importStatus').textContent=`تمت القراءة: ${file.name}. راجع الصفوف قبل الاعتماد.`}catch(e){$('#importStatus').textContent='خطأ: '+e.message}}
function parseImportRaw(){let raw=$('#importRaw').value.trim();if(!raw){state.importRows=[];return showImportPreview()}let lines=raw.split(/\r?\n/).map(x=>x.trim()).filter(Boolean),delim=lines[0]?.includes('\t')?'\t':lines[0]?.includes('|')?'|':lines[0]?.includes(',')?',':null;if(!delim){state.importRows=lines.map(x=>({'الاسم':x}));return showImportPreview()}let headers=lines[0].split(delim).map(x=>x.trim());state.importRows=lines.slice(1).map(line=>Object.fromEntries(line.split(delim).map((v,i)=>[headers[i]||`حقل${i+1}`,v.trim()])));showImportPreview()}
function showImportPreview(){let rows=state.importRows;if(!rows.length){$('#importPreview').innerHTML='<div class="empty">لا توجد صفوف جاهزة.</div>';return}let hs=Object.keys(rows[0]);$('#importPreview').innerHTML=`<table><thead><tr>${hs.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.slice(0,20).map(r=>`<tr>${hs.map(h=>`<td>${esc(r[h])}</td>`).join('')}</tr>`).join('')}</tbody></table>${rows.length>20?`<div class="muted" style="padding:8px">معاينة أول 20 من ${rows.length} صف.</div>`:''}`}
function downloadImportTemplate(kind=$('#importKind')?.value||'students'){if(!window.XLSX)return toast('مكتبة Excel لم تُحمّل');let sample=kind==='students'?[{'الاسم':'أحمد محمد','الجنس':'','رقم الهوية':'','الجوال':'','تاريخ الميلاد':'','الفئة':'','المسار':'مسار الحفظ العام','المرحلة':'','بريد ولي الأمر':'','جوال ولي الأمر':''}]:kind==='plans'?[{'الطالب':'أحمد محمد','الشهر':'2026-09','هدف الحفظ':40,'هدف المراجعة':120,'هدف السرد':40,'أيام التسميع':20}]:[{'الطالب':'أحمد محمد','التاريخ':'2026-08-26','النوع':'حفظ','الصفحات':2.5,'الأخطاء':1,'النقرات':0,'ملاحظة':'جيد'}];let wb=XLSX.utils.book_new(),ws=XLSX.utils.json_to_sheet(sample);XLSX.utils.book_append_sheet(wb,ws,'نموذج');XLSX.writeFile(wb,`نموذج_${kind}_حلقتي.xlsx`)}
function importText(v){if(v==null)return '';if(typeof v==='number'&&Number.isFinite(v))return String(v).replace(/\.0+$/,'');return String(v).trim()}
function importDate(v){if(v==null||v==='')return null;if(v instanceof Date&&!isNaN(v))return v.toISOString().slice(0,10);if(typeof v==='number'&&Number.isFinite(v)){let d=new Date(Date.UTC(1899,11,30)+Math.round(v)*86400000);return isNaN(d)?null:d.toISOString().slice(0,10)}let x=String(v).trim();if(!x)return null;if(/^\d{4}-\d{1,2}-\d{1,2}$/.test(x)){let [y,m,d]=x.split('-').map(Number);return `${String(y).padStart(4,'0')}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`}let m=x.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/);if(m){let d=+m[1],mo=+m[2],y=+m[3];if(y<100)y+=2000;if(mo>=1&&mo<=12&&d>=1&&d<=31)return `${String(y).padStart(4,'0')}-${String(mo).padStart(2,'0')}-${String(d).padStart(2,'0')}`}if(/^\d{4,5}$/.test(x)){let n=Number(x);if(n>20000&&n<80000){let d=new Date(Date.UTC(1899,11,30)+n*86400000);return d.toISOString().slice(0,10)}}return null}
function studentImportName(row){return rowVal(row,['الاسم','اسم الطالب','الاسم الرباعي','اسم الطالب الرباعي','الاسم الكامل','اسم الطالب الكامل','اسم ولقب الطالب','student name','studentname','fullname','name'])}
function trackFromText(v){let x=String(v||'').trim();if(!x)return null;if(x.includes('سرد'))return 'sard';if(x.includes('تثبيت')||x.includes('مراج'))return 'tathbit';if(x.includes('حفظ'))return 'general_hifz';if(['general_hifz','sard','tathbit'].includes(x))return x;return null}
async function ensureImportCategory(hid,name){name=String(name||'').trim();if(!name)return null;let c=state.categories.find(x=>x.halaqa_id===hid&&normalizeNameJs(x.name)===normalizeNameJs(name));if(c)return c.id;let {data,error}=await db.from('student_categories').insert({halaqa_id:hid,name,created_by:state.user.id}).select().single();if(error){let again=state.categories.find(x=>x.halaqa_id===hid&&normalizeNameJs(x.name)===normalizeNameJs(name));if(again)return again.id;throw error}state.categories.push(data);return data.id}
async function commitImport(){if(!state.importRows.length)return toast('لا توجد صفوف للاعتماد');let kind=$('#importKind').value,hid=$('#importHalaqa').value;if(!hid)return toast('اختر الحلقة');if(!confirm(`سيتم اعتماد ${state.importRows.length} صف. الصف المكرر لن يُضاف. هل راجعت البيانات؟`))return;let ok=0,fail=0,notes=[],seen=new Set(activeStudents().filter(s=>s.halaqa_id===hid).map(s=>normalizeNameJs(s.full_name)));if(state.demo){toast('تم اعتماد الاستيراد التجريبي');importDlg.close();return}for(let r of state.importRows){try{if(kind==='students'){let name=importText(studentImportName(r));if(!name)throw new Error('اسم مفقود: استخدم عمود الاسم أو الاسم الرباعي');let nk=normalizeNameJs(name);if(seen.has(nk))throw new Error(`مكرر: ${name}`);let gtxt=importText(rowVal(r,['الجنس','gender'])),gender=gtxt.includes('أنث')?'female':gtxt.includes('ذكر')?'male':null,birth=importDate(rowVal(r,['تاريخ الميلاد','الميلاد','birthdate','dateofbirth','dob'])),catName=importText(rowVal(r,['الفئة','فئة','المجموعة','category','group'])),catId=await ensureImportCategory(hid,catName),track=trackFromText(rowVal(r,['المسار','البرنامج','track','program']));let obj={full_name:name,halaqa_id:hid,gender,national_id:importText(rowVal(r,['رقم الهوية','الهوية','رقم الهوية الوطنية','nationalid']))||null,phone:importText(rowVal(r,['الجوال','رقم الجوال','رقم الهاتف','الهاتف','الموبايل','phone','mobile']))||null,date_of_birth:birth,category_id:catId,track_code:track,program_name:importText(rowVal(r,['البرنامج الإضافي','وصف البرنامج']))||null,school_grade:importText(rowVal(r,['المرحلة','الصف','الصف الدراسي','grade']))||null,guardian_email:importText(rowVal(r,['بريد ولي الأمر','ايميل ولي الأمر','إيميل ولي الأمر','guardianemail']))||null,guardian_phone:importText(rowVal(r,['جوال ولي الأمر','رقم ولي الأمر','هاتف ولي الأمر','guardianphone']))||null,enrollment_date:today()};let {error}=await db.from('students').insert(obj);if(error)throw error;seen.add(nk)}else if(kind==='plans'){let name=String(rowVal(r,['الطالب','الاسم','student'])).trim(),st=activeStudents().find(x=>normalizeNameJs(x.full_name)===normalizeNameJs(name));if(!st)throw new Error('الطالب غير موجود: '+name);let ym=String(rowVal(r,['الشهر','month'])||monthStart().slice(0,7)).slice(0,7),days=Number(rowVal(r,['أيام التسميع','days'])||20),h=Number(rowVal(r,['هدف الحفظ','hifz'])||0),rv=Number(rowVal(r,['هدف المراجعة','review'])||0),sd=Number(rowVal(r,['هدف السرد','sard'])||0),obj={student_id:st.id,period_start:ym+'-01',period_end:monthEnd(ym),target_hifz_pages:h,target_review_pages:rv,target_sard_pages:sd,target_daily_hifz_pages:h/days,target_daily_review_pages:rv/days,target_daily_sard_pages:sd/days,expected_session_days:days,created_by:state.user.id};let {error}=await db.from('student_goals').upsert(obj,{onConflict:'student_id,period_start'});if(error)throw error}else{let name=String(rowVal(r,['الطالب','الاسم','student'])).trim(),st=activeStudents().find(x=>normalizeNameJs(x.full_name)===normalizeNameJs(name));if(!st)throw new Error('الطالب غير موجود: '+name);let date=String(rowVal(r,['التاريخ','date'])||today()).slice(0,10),typ=String(rowVal(r,['النوع','type'])||'حفظ'),act=typ.includes('سرد')?'sard':typ.includes('مراج')?'review_near':'new_hifz',pages=Number(rowVal(r,['الصفحات','pages'])||0),mist=Number(rowVal(r,['الأخطاء','mistakes'])||0),prom=Number(rowVal(r,['النقرات','prompts'])||0),se=state.sessions.find(x=>x.halaqa_id===hid&&x.session_date===date);if(!se){let res=await db.from('sessions').insert({halaqa_id:hid,session_date:date,session_type:act==='sard'?'sard':act==='review_near'?'review':'tasmee',title:'جلسة مستوردة',status:'closed',created_by:state.user.id}).select().single();if(res.error)throw res.error;se=res.data;state.sessions.push(se)}let {error}=await db.from('recitation_entries').insert({session_id:se.id,student_id:st.id,activity_type:act,input_method:'import',pages_count:pages,mistakes:mist,prompts:prom,teacher_note:String(rowVal(r,['ملاحظة','note'])||'')||null,created_by:state.user.id,selection_data:{imported:true}});if(error)throw error}ok++}catch(e){fail++;notes.push(e.message)}}await db.from('data_import_jobs').insert({halaqa_id:hid,file_name:$('#importFile').files[0]?.name||'manual',file_type:$('#importFile').files[0]?.type||'text',import_kind:kind,rows_detected:state.importRows.length,rows_imported:ok,rows_failed:fail,status:fail?(ok?'partial':'failed'):'completed',notes:notes.slice(0,12).join(' | ')||null,created_by:state.user.id});toast(`تم الاستيراد: ${ok} ناجح · ${fail} فشل${fail?' (المكرر لا يُضاف)':''}`);importDlg.close();await loadAll();render()}

async function usersPage(){if(!canManageUsers())return '<div class="empty">إدارة الحسابات والصلاحيات متاحة لمسؤول النظام فقط.</div>';let pending=state.users.filter(u=>u.approval_status==='pending'),approved=state.users.filter(u=>u.approval_status==='approved'),rejected=state.users.filter(u=>u.approval_status==='rejected');let row=u=>{let owner=u.role==='admin',requested=requestRoleAr[u.requested_role]||'ولي أمر';return `<tr><td><b>${esc(u.full_name)}</b><div class="muted">${esc(u.phone||'')}</div></td><td>${esc(u.email||'—')}</td><td>${owner?'<span class="badge blue">مسؤول النظام</span>':u.approval_status==='pending'?`<select id="role_${u.id}"><option value="guardian" ${u.requested_role==='guardian'?'selected':''}>ولي أمر</option><option value="teacher" ${u.requested_role==='teacher'?'selected':''}>محفّظ الحلقة</option><option value="supervisor" ${u.requested_role==='supervisor'?'selected':''}>مشرف الحلقات</option></select><div class="muted">الطلب: ${requested}</div>`:`<select onchange="changeRole('${u.id}',this.value)"><option value="guardian" ${u.role==='guardian'?'selected':''}>ولي أمر</option><option value="teacher" ${u.role==='teacher'?'selected':''}>محفّظ الحلقة</option><option value="supervisor" ${u.role==='supervisor'?'selected':''}>مشرف الحلقات</option></select>`}</td><td>${u.approval_status==='pending'?'<span class="badge warn">بانتظار الاعتماد</span>':u.approval_status==='rejected'?'<span class="badge red">مرفوض</span>':u.active?'<span class="badge good">نشط</span>':'<span class="badge red">موقوف</span>'}</td><td>${owner?'—':u.approval_status==='pending'?`<button class="mini" onclick="approveUser('${u.id}')">اعتماد</button><button class="mini red" onclick="rejectUser('${u.id}')">رفض</button>`:u.approval_status==='rejected'?`<button class="mini" onclick="approveUser('${u.id}')">اعتماد من جديد</button>`:`<button class="mini ${u.active?'red':''}" onclick="toggleUserActive('${u.id}',${!u.active})">${u.active?'إيقاف':'تفعيل'}</button>`}</td></tr>`};return `<div class="hero"><h2>الحسابات والصلاحيات</h2><p>كل حساب جديد يبقى معلقاً حتى تعتمد هويته وتحدد صلاحية الوصول. لا يستطيع المستخدم منح نفسه صلاحية إدارية.</p></div>${pending.length?`<div class="section-head"><h3>طلبات جديدة (${pending.length})</h3></div><div class="notice">راجع الاسم والبريد ونوع الحساب المطلوب قبل الضغط على «اعتماد».</div>`:''}<div style="height:10px"></div><div class="table-wrap"><table><thead><tr><th>المستخدم</th><th>البريد</th><th>الصلاحية</th><th>الحالة</th><th>الإجراء</th></tr></thead><tbody>${[...pending,...approved,...rejected].map(row).join('')}</tbody></table></div>`}
async function approveUser(id){let el=$('#role_'+id),u=state.users.find(x=>x.id===id),role=el?.value||(u?.requested_role&&['guardian','teacher','supervisor'].includes(u.requested_role)?u.requested_role:'guardian');let {error}=await db.from('profiles').update({role,requested_role:role,approval_status:'approved',active:true,approved_at:new Date().toISOString(),approved_by:state.user.id,rejection_reason:null}).eq('id',id);if(error)return toast(error.message);toast('تم اعتماد الحساب وتحديد الصلاحية');await loadAll();render()}
async function rejectUser(id){let reason=prompt('سبب الرفض (اختياري):','');if(reason===null)return;let {error}=await db.from('profiles').update({approval_status:'rejected',active:false,rejection_reason:reason||null}).eq('id',id);if(error)return toast(error.message);toast('تم رفض الطلب');await loadAll();render()}
async function changeRole(id,role){let u=state.users.find(x=>x.id===id);if(u?.role==='admin')return toast('لا يمكن تغيير صلاحية مسؤول النظام من هنا');let {error}=await db.from('profiles').update({role,requested_role:role}).eq('id',id);if(error)return toast(error.message);toast('تم تغيير الصلاحية');await loadAll();render()}
async function toggleUserActive(id,active){let {error}=await db.from('profiles').update({active}).eq('id',id);if(error)return toast(error.message);toast(active?'تم تفعيل الحساب':'تم إيقاف الحساب');await loadAll();render()}
function profilePage(){if(state.profile?.role==='guardian')return `${offlineNotice()}<div class="hero"><h2>ملف أبنائي</h2><p>لا تظهر هنا إلا الملفات المرتبطة بحساب ولي الأمر هذا.</p></div>${studentCards(activeStudents())}`;return studentCards()}

async function render(){if(state.page==='competition'&&state.profile?.role==='guardian'&&state.networkVerified)await ensureGuardianCompetition();buildNav();setFab();let titles={home:'الرئيسية',halaqas:'الحلقات والفئات',community:'الإعلانات ومنتدى الحلقة',sessions:'الجلسات اليومية',students:'الطلاب',plans:'الخطط الشهرية',reports:'التقارير',competition:'إحصائيات ومنافسة',quran:'حاسبة القرآن',ranking:'الترتيب والإحصائيات',data:'الاستيراد والتصدير',settings:'الإعدادات',supervision:'متابعة المحفّظ',users:'المستخدمون',profile:'ملف الطالب'};$('#pageTitle').textContent=titles[state.page]||'حلقتي';let html='';if(state.page==='home')html=homePage();if(state.page==='halaqas')html=halaqasPage();if(state.page==='community')html=communityPage();if(state.page==='sessions')html=sessionsPage();if(state.page==='students')html=studentsPage();if(state.page==='plans')html=plansPage();if(state.page==='reports')html=reportsPage();if(state.page==='competition')html=guardianCompetitionPage();if(state.page==='quran')html=quranPage();if(state.page==='ranking')html=rankingPage();if(state.page==='data')html=dataPage();if(state.page==='settings')html=settingsPage();if(state.page==='supervision')html=supervisionPage();if(state.page==='users')html=await usersPage();if(state.page==='profile')html=profilePage();$('#content').innerHTML=html}
function fillHalaqas(sel,allowAll=false){sel.innerHTML=(allowAll?'<option value="">كل الحلقات</option>':'')+state.halaqas.map(h=>`<option value="${h.id}">${h.name}</option>`).join('')}
function fillStudents(sel,selected=''){sel.innerHTML=activeStudents().map(s=>`<option value="${s.id}" ${s.id===selected?'selected':''}>${s.full_name}</option>`).join('')}
function fillTeachers(sel,hid=''){let rows=state.users.filter(u=>u.role==='teacher'&&u.approval_status==='approved'&&u.active);if(state.profile?.role==='teacher'&&!rows.some(u=>u.id===state.profile.id))rows=[state.profile];if(hid){let ids=state.halaqaTeachers.filter(x=>x.halaqa_id===hid).map(x=>x.teacher_id);rows=rows.filter(u=>ids.includes(u.id)||u.id===state.profile?.id)}sel.innerHTML='<option value="">بدون تحديد</option>'+rows.map(u=>`<option value="${u.id}">${u.full_name}</option>`).join('')}
function openSession(){if(!state.halaqas.length)return setupFirstHalaqa();fillHalaqas($('#sessionHalaqa'));$('#sessionDate').value=today();sessionDlg.showModal()}
function fillGuardianAccounts(selected=''){let sel=$('#stGuardianAccount');if(!sel)return;let rows=state.guardianAccounts||[];sel.innerHTML='<option value="">بدون ربط</option>'+rows.map(g=>`<option value="${g.id}" ${g.id===selected?'selected':''}>${esc(g.full_name)}${g.email?` · ${esc(g.email)}`:''}</option>`).join('')}
function filterGuardianOptions(q=''){let sel=$('#stGuardianAccount');if(!sel)return;let selected=sel.value,n=normalizeNameJs(q),rows=(state.guardianAccounts||[]).filter(g=>!n||normalizeNameJs(g.full_name).includes(n)||String(g.email||'').toLowerCase().includes(String(q).toLowerCase()));sel.innerHTML='<option value="">بدون ربط</option>'+rows.map(g=>`<option value="${g.id}" ${g.id===selected?'selected':''}>${esc(g.full_name)}${g.email?` · ${esc(g.email)}`:''}</option>`).join('')}
async function openStudent(id=''){if(!canManageStudents())return toast('لا تملك صلاحية تعديل الطلاب');if(!state.halaqas.length)return setupFirstHalaqa();fillHalaqas($('#stHalaqa'));$('#studentForm').reset();$('#stId').value=id;$('#stJoin').value=today();$('#stTarget').value=7;$('#stGuardianSearch').value='';let st=state.students.find(x=>x.id===id),hqField=$('#stHalaqaField'),more=$('#stMore'),hid=st?.halaqa_id||(state.halaqas.length===1?state.halaqas[0].id:state.halaqas[0]?.id||'');if(state.halaqas.length===1){$('#stHalaqa').value=state.halaqas[0].id;hqField.classList.add('hidden')}else{hqField.classList.remove('hidden');if(hid)$('#stHalaqa').value=hid}fillTeachers($('#stTeacher'),hid);fillCategories($('#stCategory'),hid,st?.category_id||'');let guardianId='';if(st){if(navigator.onLine){let g=await db.from('student_guardians').select('guardian_id,is_primary').eq('student_id',st.id).eq('is_primary',true).maybeSingle();guardianId=g.data?.guardian_id||''}if(!guardianId&&st.guardian_email){guardianId=state.guardianAccounts.find(g=>String(g.email||'').toLowerCase()===String(st.guardian_email).toLowerCase())?.id||''}}fillGuardianAccounts(guardianId);$('#studentDlgTitle').textContent=st?'تعديل بيانات الطالب':'إضافة طالب';$('#studentSaveBtn').textContent=st?'حفظ التعديلات':'إضافة الطالب';more.open=!!st;if(st){$('#stName').value=st.full_name||'';$('#stHalaqa').value=st.halaqa_id||'';$('#stGender').value=st.gender||'';$('#stNationalId').value=st.national_id||'';$('#stPhone').value=st.phone||'';$('#stBirthDate').value=st.date_of_birth||'';$('#stCategory').value=st.category_id||'';$('#stTrack').value=st.track_code||'';$('#stProgram').value=st.program_name||'';$('#stGrade').value=st.school_grade||'';$('#stTeacher').value=st.primary_teacher_id||'';$('#stGuardianPhone').value=st.guardian_phone||'';$('#stJoin').value=st.enrollment_date||today();$('#stTarget').value=st.target_pages_weekly||7;$('#stAddress').value=st.address||'';$('#stNotes').value=st.notes||'';if(st.guardian_email&&!guardianId)$('#stGuardianHint').textContent=`الحساب السابق بالبريد ${st.guardian_email} غير مربوط بحساب ولي أمر معتمد حالياً.`;else $('#stGuardianHint').textContent='اختر ولي الأمر من الحسابات المعتمدة مباشرة.'}else $('#stGuardianHint').textContent='اختر ولي الأمر من الحسابات المعتمدة مباشرة.';$('#stHalaqa').onchange=()=>{fillTeachers($('#stTeacher'),$('#stHalaqa').value);fillCategories($('#stCategory'),$('#stHalaqa').value,'')};studentDlg.showModal()}
function openAnnouncement(){fillHalaqas($('#anHalaqa'),true);announcementDlg.showModal()}
function openForum(id=null,forceType=null){fillHalaqas($('#fpHalaqa'));$('#forumForm').reset();$('#fpId').value=id||'';let p=state.forum.find(x=>x.id===id);$('#forumDlgTitle').textContent=p?'تعديل منشور':'منشور في منتدى الحلقة';$('#forumSaveBtn').textContent=p?'حفظ التعديل':'نشر';if(p){$('#fpHalaqa').value=p.halaqa_id;$('#fpType').value=p.post_type;$('#fpTitle').value=p.title;$('#fpBody').value=p.body;$('#fpComments').value=String(p.comments_enabled!==false);$('#fpPinned').value=String(!!p.pinned)}else if(forceType)$('#fpType').value=forceType;forumDlg.showModal()}
function openPlan(sid=''){fillStudents($('#plStudent'),sid);$('#plMonth').value=monthStart().slice(0,7);planDlg.showModal()}
async function setupFirstHalaqa(){if(!isOwner())return toast('إنشاء الحلقات لمسؤول النظام فقط');go('halaqas');setTimeout(()=>openHalaqa(),50)}
$('#sessionForm').addEventListener('submit',async e=>{e.preventDefault();let obj={halaqa_id:$('#sessionHalaqa').value,session_date:$('#sessionDate').value,session_type:$('#sessionType').value,title:$('#sessionTitle').value||null,notes:$('#sessionNotes').value||null,status:'open',created_by:state.user.id};let data;if(state.demo){data={...obj,id:'se'+Date.now()}}else if(!(await internetReachable())||state.offline){let localId='offline-se-'+Date.now();data={...obj,id:localId,_offline:true};enqueueOffline({type:'session',key:'session:'+localId,localId,obj});state.offlineRosterCache[localId]={attendance:[],notes:[],recitations:[]};toast('تم إنشاء الجلسة محلياً — ستُرفع عند عودة الإنترنت')}else{let r=await db.from('sessions').insert(obj).select().single();if(r.error){if(isNetworkError(r.error)){let localId='offline-se-'+Date.now();data={...obj,id:localId,_offline:true};enqueueOffline({type:'session',key:'session:'+localId,localId,obj});state.offlineRosterCache[localId]={attendance:[],notes:[],recitations:[]};toast('انقطع الاتصال؛ حُفظت الجلسة على الجهاز')}else return toast(r.error.message)}else data=r.data}state.sessions.unshift(data);sessionDlg.close();state.sessionView=data.id;state.sessionRoster={attendance:[],notes:[],recitations:[]};cacheSnapshot();render()})
$('#studentForm').addEventListener('submit',async e=>{e.preventDefault();if(!navigator.onLine)return toast('إضافة أو تعديل ملف الطالب يحتاج اتصالاً بالإنترنت. تسجيل الجلسات اليومية فقط يعمل دون إنترنت.');let id=$('#stId').value,hid=$('#stHalaqa').value||(state.halaqas.length===1?state.halaqas[0].id:''),name=$('#stName').value.trim();if(!name)return toast('اسم الطالب مطلوب');if(!hid)return toast('اختر الحلقة');let dup=activeStudents().find(x=>x.id!==id&&x.halaqa_id===hid&&normalizeNameJs(x.full_name)===normalizeNameJs(name));if(dup)return toast(`الطالب مكرر: «${dup.full_name}» مسجل بالفعل في هذه الحلقة.`);let nid=$('#stNationalId').value.trim(),dupId=nid&&activeStudents().find(x=>x.id!==id&&x.halaqa_id===hid&&x.national_id===nid);if(dupId)return toast(`رقم الهوية مستخدم للطالب «${dupId.full_name}».`);let guardianId=$('#stGuardianAccount').value||null,obj={full_name:name,halaqa_id:hid,gender:$('#stGender').value||null,national_id:nid||null,phone:$('#stPhone').value.trim()||null,date_of_birth:$('#stBirthDate').value||null,category_id:$('#stCategory').value||null,track_code:$('#stTrack').value||null,program_name:$('#stProgram').value.trim()||null,school_grade:$('#stGrade').value.trim()||null,primary_teacher_id:$('#stTeacher').value||null,guardian_phone:$('#stGuardianPhone').value.trim()||null,enrollment_date:$('#stJoin').value||today(),target_pages_weekly:Number($('#stTarget').value||7),address:$('#stAddress').value.trim()||null,notes:$('#stNotes').value||null};let res=id?await db.from('students').update(obj).eq('id',id).select().single():await db.from('students').insert(obj).select().single();if(res.error){let msg=res.error.message||'';return toast(msg)}let data=res.data;let link=await db.rpc('set_student_primary_guardian',{p_student_id:data.id,p_guardian_id:guardianId});if(link.error)toast('تم حفظ الطالب، لكن تعذر ربط ولي الأمر: '+link.error.message);let chosen=!link.error?state.guardianAccounts.find(g=>g.id===guardianId):null;if(!link.error){data.guardian_email=chosen?.email||null;if(chosen?.phone)data.guardian_phone=chosen.phone;}let file=$('#stPhoto').files[0];if(file){let ext=(file.name.split('.').pop()||'jpg').toLowerCase(),path=`${data.id}/${Date.now()}.${ext}`,up=await db.storage.from('student-photos').upload(path,file,{upsert:false});if(!up.error){await db.from('students').update({photo_path:path}).eq('id',data.id);data.photo_path=path}}let ix=state.students.findIndex(x=>x.id===data.id);if(ix>=0)state.students[ix]=data;else state.students.push(data);studentDlg.close();toast(id?'تم حفظ التعديلات وربط ولي الأمر':'تمت إضافة الطالب وربط ولي الأمر');await loadAll();render()})
$('#announcementForm').addEventListener('submit',async e=>{e.preventDefault();let exp=$('#anExpires').value?new Date($('#anExpires').value+'T23:59:59').toISOString():null;let obj={title:$('#anTitle').value,body:$('#anBody').value,category:$('#anCategory').value,halaqa_id:$('#anHalaqa').value||null,audience:$('#anAudience').value,priority:$('#anPriority').value,pinned:$('#anPinned').value==='true',expires_at:exp,created_by:state.user.id};if(state.demo){obj.id='a'+Date.now();obj.publish_at=new Date().toISOString();state.announcements.unshift(obj)}else{let {data,error}=await db.from('announcements').insert(obj).select().single();if(error)return toast(error.message);state.announcements.unshift(data)}announcementDlg.close();toast('تم نشر الإعلان');render()})
$('#forumForm').addEventListener('submit',async e=>{e.preventDefault();let id=$('#fpId').value,obj={halaqa_id:$('#fpHalaqa').value,author_id:state.user.id,post_type:$('#fpType').value,title:$('#fpTitle').value.trim(),body:$('#fpBody').value.trim(),comments_enabled:$('#fpComments').value==='true',pinned:$('#fpPinned').value==='true'};if(!obj.title||!obj.body)return toast('العنوان والمحتوى مطلوبان');if(state.demo){if(id){let p=state.forum.find(x=>x.id===id);Object.assign(p,obj,{updated_at:new Date().toISOString()})}else{obj.id='f'+Date.now();obj.created_at=obj.updated_at=new Date().toISOString();obj.author_name=state.profile.full_name;state.forum.unshift(obj)}}else{let res=id?await db.from('forum_posts').update({post_type:obj.post_type,title:obj.title,body:obj.body,comments_enabled:obj.comments_enabled,pinned:obj.pinned}).eq('id',id).select().single():await db.from('forum_posts').insert(obj).select().single();if(res.error)return toast(res.error.message);if(id)state.forum[state.forum.findIndex(x=>x.id===id)]=res.data;else state.forum.unshift(res.data)}forumDlg.close();toast(id?'تم تعديل المنشور':'تم نشر المنشور');render()})
$('#planForm').addEventListener('submit',async e=>{e.preventDefault();let ym=$('#plMonth').value,start=ym+'-01',end=monthEnd(ym),days=+$('#plDays').value||20,h=+$('#plHifz').value||0,r=+$('#plReview').value||0,s=+$('#plSard').value||0,obj={student_id:$('#plStudent').value,period_start:start,period_end:end,target_hifz_pages:h,target_review_pages:r,target_sard_pages:s,target_daily_hifz_pages:Math.round(h/days*100)/100,target_daily_review_pages:Math.round(r/days*100)/100,target_daily_sard_pages:Math.round(s/days*100)/100,expected_session_days:days,note:$('#plNote').value||null,created_by:state.user.id};if(state.demo){state.goals=state.goals.filter(x=>!(x.student_id===obj.student_id&&x.period_start===start));obj.id='g'+Date.now();state.goals.push(obj)}else{let old=state.goals.find(x=>x.student_id===obj.student_id&&x.period_start===start);let res=old?await db.from('student_goals').update(obj).eq('id',old.id).select().single():await db.from('student_goals').insert(obj).select().single();if(res.error)return toast(res.error.message);await loadAll()}planDlg.close();toast('تم حفظ الخطة الشهرية');render()})

async function openSessionRoster(id){state.sessionView=id;await loadSessionRosterData(id);render()}
function closeSessionRoster(){state.sessionView=null;state.sessionRoster={attendance:[],notes:[],recitations:[]};render()}
async function loadSessionRosterData(id){let cached=state.offlineRosterCache[id];if(state.demo||!state.networkVerified||String(id).startsWith('offline-')){state.sessionRoster=cached?cloneJson(cached):{attendance:[],notes:[],recitations:[]};return}let [a,n,r]=await Promise.all([db.from('attendance_records').select('*').eq('session_id',id),db.from('student_daily_notes').select('*').eq('session_id',id),db.from('recitation_entries').select('*').eq('session_id',id).order('created_at')]);if((a.error&&isNetworkError(a.error))||(n.error&&isNetworkError(n.error))||(r.error&&isNetworkError(r.error))){state.offline=true;state.sessionRoster=cached?cloneJson(cached):{attendance:[],notes:[],recitations:[]};updateSyncBadge();return}state.sessionRoster={attendance:a.data||[],notes:n.data||[],recitations:r.data||[]};if(cached){let by=(arr,k)=>new Map(arr.map(x=>[x[k],x]));let am=by(state.sessionRoster.attendance,'student_id');cached.attendance?.forEach(x=>am.set(x.student_id,x));let nm=by(state.sessionRoster.notes,'student_id');cached.notes?.forEach(x=>nm.set(x.student_id,x));let server=state.sessionRoster.recitations.filter(x=>!cached.recitations?.some(c=>c.student_id===x.student_id));state.sessionRoster={attendance:[...am.values()],notes:[...nm.values()],recitations:[...server,...(cached.recitations||[])]}}}
function rosterAttendance(sid){return state.sessionRoster.attendance.find(x=>x.student_id===sid)||null}
function rosterNote(sid){return state.sessionRoster.notes.find(x=>x.student_id===sid)||null}
function rosterRecitations(sid){return state.sessionRoster.recitations.filter(x=>x.student_id===sid)}
function behaviorScoreFor(v){return ({excellent:5,good:4,normal:3,needs_attention:2,warning:1})[v]||3}
function recitationRangeText(r){let mode=r.selection_data?.mode||r.input_method;if(r.start_surah&&r.end_surah){let a=`${surahs[r.start_surah-1]||'سورة'} ${r.start_ayah||''}`.trim(),b=`${surahs[r.end_surah-1]||'سورة'} ${r.end_ayah||''}`.trim();return a===b?a:`${a} ← ${b}`}if(r.start_page||r.end_page){let a=r.start_page||r.end_page,b=r.end_page||r.start_page;return a===b?`صفحة ${fmt(a)}`:`صفحات ${fmt(a)}–${fmt(b)}`}if(Array.isArray(r.selected_surahs)&&r.selected_surahs.length)return r.selected_surahs.map(x=>surahs[x-1]).filter(Boolean).join('، ');let juz=r.selection_data?.selected_juz;if(Array.isArray(juz)&&juz.length)return `الأجزاء ${juz.join('، ')}`;if(Number(r.pages_count)>0)return `${fmt(r.pages_count)} صفحة`;return 'تم تسجيل التسميع'}
function recitationMiniCard(r){let ev=r.evaluation||r.rating||null,points=Number(r.points||0);return `<div class="roster-rec"><div class="roster-rec-type">${esc(actAr[r.activity_type]||r.activity_type)}</div><div><div class="roster-rec-range">${esc(recitationRangeText(r))}</div><div class="roster-rec-meta">${fmt(r.pages_count)} ص · ${r.mistakes||0} أخطاء · ${r.prompts||0} نقرات${ev?` · ${esc(evalAr[ev]||ev)}`:''}</div></div><div class="roster-rec-score">${points?`<b>${fmt(points)}</b><span class="muted">نقطة</span>`:''}</div></div>`}
function filterSessionRosterDom(v=''){state.sessionSearch=v;let q=normalizeNameJs(v),n=0;$$('[data-roster-name]').forEach(c=>{let show=!q||c.dataset.rosterName.includes(q);c.style.display=show?'':'none';if(show)n++});let x=$('#rosterVisibleCount');if(x)x.textContent=n}
function setSessionSort(v){state.sessionSort=v;render()}
function sessionRosterPage(id){let se=state.sessions.find(x=>x.id===id);if(!se)return '<div class="empty">الجلسة غير موجودة.</div>';let all=sortStudentsList(activeStudents().filter(x=>x.halaqa_id===se.halaqa_id),state.sessionSort),q=normalizeNameJs(state.sessionSearch),students=q?all.filter(x=>normalizeNameJs(x.full_name).includes(q)):all,a=state.sessionRoster.attendance,present=a.filter(x=>x.status==='present').length,abs=a.filter(x=>['absent','excused'].includes(x.status)).length,recorded=new Set(state.sessionRoster.recitations.map(x=>x.student_id)).size;let cards=students.map(st=>{let at=rosterAttendance(st.id),note=rosterNote(st.id),recs=rosterRecitations(st.id),status=at?.status||'',presentOn=status==='present',beh=note?.behavior||'normal';return `<div class="card roster-card" id="roster_${st.id}" data-roster-name="${esc(normalizeNameJs(st.full_name))}"><div class="roster-top">${avatarHtml(st)}<div class="grow"><b>${esc(st.full_name)}</b><div class="muted">${esc(categoryName(st))} · ${esc(studentTrackAr[st.track_code]||'بدون مسار')} · ${fmt(monthlyPointsForStudent(st.id))} نقطة</div></div>${st._offline?'<span class="offline-mark">محلي</span>':''}<span class="badge ${status==='present'?'good':status?'red':''}">${status?attAr[status]:'لم يسجل'}</span></div><div class="roster-controls"><div class="presence-box"><b>الحضور</b><label class="presence-switch" title="تشغيل = حاضر، إيقاف = غائب"><input type="checkbox" ${presentOn?'checked':''} onchange="quickPresenceToggle('${st.id}','${se.id}',this.checked)"><span class="presence-slider"></span></label><select class="att-status-select" onchange="quickAttendance('${st.id}','${se.id}',this.value,this)" aria-label="حالة الحضور"><option value="" ${!status?'selected':''}>غير مسجل</option><option value="present" ${status==='present'?'selected':''}>حاضر</option><option value="absent" ${status==='absent'?'selected':''}>غائب</option><option value="excused" ${status==='excused'?'selected':''}>غائب بعذر</option><option value="late" ${status==='late'?'selected':''}>متأخر</option></select></div><div class="behavior-box"><span class="behavior-dot ${beh}"></span><b>السلوك</b><select class="behavior-select" onchange="quickBehavior('${st.id}','${se.id}',this.value,this)">${Object.entries(behAr).map(([k,v])=>`<option value="${k}" ${beh===k?'selected':''}>${v}</option>`).join('')}</select></div></div><div class="roster-recitations">${recs.length?recs.map(recitationMiniCard).join(''):'<div class="roster-empty-rec">لم يُسجل حفظ / مراجعة / سرد لهذا الطالب في هذه الجلسة.</div>'}</div><div class="roster-actions"><div class="quick-rec-buttons"><button onclick="quickOpenRecitation('${st.id}','${se.id}','new_hifz')">+ حفظ</button><button onclick="quickOpenRecitation('${st.id}','${se.id}','review_near')">+ مراجعة</button><button onclick="quickOpenRecitation('${st.id}','${se.id}','sard')">+ سرد</button></div><button class="mini" onclick="openDailyForStudent('${st.id}','${se.id}')">${recs.length?'تعديل التفاصيل':'إضافة التفاصيل'}</button></div></div>`}).join('');return `${offlineNotice()}<div class="session-live-head"><div><h2 style="margin:0">${esc(se.title||sesAr[se.session_type])}</h2><div class="muted">${se.session_date} · ${sesAr[se.session_type]} · ${all.length} طالب ${se._offline?'· محفوظ محلياً':''}</div></div><button class="mini" onclick="closeSessionRoster()">رجوع</button></div><div class="session-live-stats"><span>حاضر: ${present}</span><span>غائب/بعذر: ${abs}</span><span>تم تسجيل التسميع: ${recorded}/${all.length}</span></div><div class="session-tools"><input class="input" type="search" placeholder="ابحث عن اسم الطالب داخل الجلسة" value="${esc(state.sessionSearch)}" oninput="filterSessionRosterDom(this.value)"><select onchange="setSessionSort(this.value)"><option value="alpha" ${state.sessionSort==='alpha'?'selected':''}>ترتيب أبجدي</option><option value="points" ${state.sessionSort==='points'?'selected':''}>الأعلى نقاطاً</option><option value="oldest" ${state.sessionSort==='oldest'?'selected':''}>الأكبر سناً</option><option value="youngest" ${state.sessionSort==='youngest'?'selected':''}>الأصغر سناً</option><option value="joined_old" ${state.sessionSort==='joined_old'?'selected':''}>الأقدم التحاقاً</option><option value="joined_new" ${state.sessionSort==='joined_new'?'selected':''}>الأحدث التحاقاً</option></select></div><div class="roster-filter-count">المعروض: <span id="rosterVisibleCount">${students.length}</span> من ${all.length}</div><div style="height:10px"></div>${cards||'<div class="empty">لا يوجد طالب مطابق للبحث.</div>'}`}
async function quickPresenceToggle(sid,seId,on){return quickAttendance(sid,seId,on?'present':'absent')}
async function quickAttendance(sid,seId,status,el=null){if(!status){if(el){let old=rosterAttendance(sid)?.status||'';el.value=old}return}let existing=rosterAttendance(sid),extra={};if(status==='excused'){let r=prompt('سبب العذر (اختياري):',existing?.excuse_reason||'');if(r===null){if(el)el.value=existing?.status||'';return}extra.excuse_reason=r||null}else if(status==='late'){let r=prompt('عدد دقائق التأخر (اختياري):',existing?.arrival_minutes_late||'');if(r===null){if(el)el.value=existing?.status||'';return}extra.arrival_minutes_late=Math.max(0,Number(r)||0)}else extra.excuse_reason=null;if(!(await internetReachable())||String(seId).startsWith('offline-')){localAttendanceSave(sid,seId,status,extra);flashRosterCard(sid);render();return}let error,data;if(existing&&!String(existing.id).startsWith('offline-')){let res=await db.from('attendance_records').update({status,...extra,recorded_by:state.user.id,recorded_at:new Date().toISOString()}).eq('id',existing.id).select().single();error=res.error;data=res.data}else{let res=await db.from('attendance_records').upsert({session_id:seId,student_id:sid,status,...extra,recorded_by:state.user.id},{onConflict:'session_id,student_id'}).select().single();error=res.error;data=res.data}if(error){if(isNetworkError(error)){localAttendanceSave(sid,seId,status,extra);toast('انقطع الإنترنت؛ تم حفظ الحضور على الجهاز');render();return}return toast(error.message)}if(existing)Object.assign(existing,data);else state.sessionRoster.attendance.push(data);rememberRoster(seId);flashRosterCard(sid);render()}
async function quickBehavior(sid,seId,behavior,el=null){let existing=rosterNote(sid),payload={behavior,behavior_score:behaviorScoreFor(behavior),created_by:state.user.id};if(!(await internetReachable())||String(seId).startsWith('offline-')){localBehaviorSave(sid,seId,behavior);flashRosterCard(sid);render();return}let error,data;if(existing&&!String(existing.id).startsWith('offline-')){let res=await db.from('student_daily_notes').update(payload).eq('id',existing.id).select().single();error=res.error;data=res.data}else{let res=await db.from('student_daily_notes').upsert({session_id:seId,student_id:sid,...payload,parent_visible:true},{onConflict:'session_id,student_id'}).select().single();error=res.error;data=res.data}if(error){if(isNetworkError(error)){localBehaviorSave(sid,seId,behavior);toast('انقطع الإنترنت؛ تم حفظ السلوك على الجهاز');render();return}return toast(error.message)}if(existing)Object.assign(existing,data);else state.sessionRoster.notes.push(data);rememberRoster(seId);flashRosterCard(sid);render()}
function flashRosterCard(sid){requestAnimationFrame(()=>{let c=document.getElementById('roster_'+sid);if(c){c.classList.remove('saved-flash');void c.offsetWidth;c.classList.add('saved-flash')}})}
async function quickOpenRecitation(sid,seId,type){await openDailyForStudent(sid,seId);addRecitationRow(type)}
function latestSession(){return state.sessions.find(s=>s.session_date===today())||state.sessions[0]}
async function openDailyForStudent(sid,seId=null){let st=state.students.find(x=>x.id===sid),se=seId?state.sessions.find(x=>x.id===seId):latestSession();if(!se)return openSession();let attendance=null,note=null,recs=[];if(state.sessionView===se.id){attendance=rosterAttendance(sid);note=rosterNote(sid);recs=rosterRecitations(sid)}else if(!state.demo&&state.networkVerified&&!String(se.id).startsWith('offline-')){let [a,n,r]=await Promise.all([db.from('attendance_records').select('*').eq('session_id',se.id).eq('student_id',sid).maybeSingle(),db.from('student_daily_notes').select('*').eq('session_id',se.id).eq('student_id',sid).maybeSingle(),db.from('recitation_entries').select('*').eq('session_id',se.id).eq('student_id',sid).order('created_at')]);attendance=a.data||null;note=n.data||null;recs=r.data||[]}else{let c=state.offlineRosterCache[se.id]||{attendance:[],notes:[],recitations:[]};attendance=c.attendance?.find(x=>x.student_id===sid)||null;note=c.notes?.find(x=>x.student_id===sid)||null;recs=(c.recitations||[]).filter(x=>x.student_id===sid)}$('#rpStudent').value=sid;$('#rpSession').value=se.id;$('#rpName').textContent=st.full_name;$('#rpAvatar').innerHTML=state.photoUrls[sid]?`<img src="${state.photoUrls[sid]}">`:st.full_name[0];$('#rpSessionLabel').textContent=`${se.session_date} · ${sesAr[se.session_type]}`;$('#rpAttendance').value=attendance?.status||'present';$('#rpExcuse').value=attendance?.excuse_reason||'';$('#rpBehavior').value=note?.behavior||'normal';$('#rpBehaviorScore').value=String(note?.behavior_score||behaviorScoreFor(note?.behavior||'normal'));$('#rpComment').value=note?.teacher_comment||'';$('#rpHomework').value=note?.homework||'';$('#recitationRows').innerHTML='';state.reportExistingRecIds=recs.map(x=>x.id);if(recs.length)recs.forEach(addRecitationRowFromData);else addRecitationRow(se.session_type==='sard'?'sard':se.session_type==='review'?'review_near':'new_hifz');reportDlg.showModal()}
function addRecitationRowFromData(rec){addRecitationRow(rec.activity_type||'new_hifz');let row=$$('#recitationRows .rec-row').at(-1),id=row.dataset.id;row.dataset.dbId=rec.id||'';row.dataset.pages=rec.pages_count||0;row.dataset.ayahs=rec.ayahs_count||0;row.dataset.surahs=rec.surahs_count||0;row.dataset.startPage=rec.start_page||'';row.dataset.endPage=rec.end_page||'';row.dataset.startSurah=rec.start_surah||'';row.dataset.startAyah=rec.start_ayah||'';row.dataset.endSurah=rec.end_surah||'';row.dataset.endAyah=rec.end_ayah||'';row.dataset.selectedSurahs=JSON.stringify(rec.selected_surahs||[]);row.dataset.selectedJuz=JSON.stringify(rec.selection_data?.selected_juz||[]);let mode=rec.selection_data?.mode||rec.input_method||'ayahs';if(!['ayahs','pages','surahs','juz'].includes(mode))mode=rec.start_page?'pages':'ayahs';row.dataset.mode=mode;row.querySelector('.rType').value=rec.activity_type||'new_hifz';row.querySelectorAll('.rec-body>.tabs .tab').forEach(b=>b.classList.remove('active'));let typeBtns=[...row.querySelectorAll('.rec-body>.tabs .tab')],idx=rec.activity_type==='new_hifz'?0:String(rec.activity_type).includes('review')?1:rec.activity_type==='sard'?2:3;if(typeBtns[idx])typeBtns[idx].classList.add('active');let segBtns=[...row.querySelectorAll('.seg button')],midx={ayahs:0,pages:1,surahs:2,juz:3}[mode]??0;segBtns.forEach((b,i)=>b.classList.toggle('active',i===midx));row.querySelector('.rAyahs').classList.toggle('hidden',mode!=='ayahs');row.querySelector('.rPages').classList.toggle('hidden',mode!=='pages');row.querySelector('.rSurahs').classList.toggle('hidden',mode!=='surahs');row.querySelector('.rJuz').classList.toggle('hidden',mode!=='juz');if(rec.start_surah)$('#'+id+'SS').value=rec.start_surah;if(rec.start_ayah)$('#'+id+'SA').value=rec.start_ayah;if(rec.end_surah)$('#'+id+'ES').value=rec.end_surah;if(rec.end_ayah)$('#'+id+'EA').value=rec.end_ayah;if(rec.start_page)$('#'+id+'PF').value=rec.start_page;if(rec.end_page)$('#'+id+'PT').value=rec.end_page;(rec.selected_surahs||[]).forEach(n=>$('#'+id+'Surah'+n)?.classList.add('active'));(rec.selection_data?.selected_juz||[]).forEach(n=>$('#'+id+'J'+n)?.classList.add('active'));row.querySelector('.rPagesCount').textContent=fmt(rec.pages_count||0);row.querySelector('.rAyahsCount').textContent=rec.ayahs_count?`· ${rec.ayahs_count} آية`:'';row.querySelector('.rCalcStatus').textContent='بيانات محفوظة — يمكنك تعديلها';row.querySelector('.rMist').textContent=rec.mistakes||0;row.querySelector('.rPrompt').textContent=rec.prompts||0;row.querySelector('.rNote').value=rec.teacher_note||'';updateEval(row)}
function recId(){return 'rr'+Math.random().toString(36).slice(2,9)}
function addRecitationRow(type='new_hifz'){let id=recId(),d=document.createElement('div');d.className='card rec-row';d.dataset.id=id;d.dataset.pages='0';d.dataset.ayahs='0';d.dataset.surahs='0';d.dataset.startPage='';d.dataset.endPage='';d.dataset.mode='ayahs';d.innerHTML=`<div class="rec-head"><div><b>بند تسميع</b><div class="muted">اختر النوع وطريقة تحديد المقدار</div></div><button class="mini red" type="button" onclick="this.closest('.rec-row').remove()">حذف</button></div><div class="rec-body"><div class="tabs"><button class="tab ${type==='new_hifz'?'active':''}" type="button" onclick="setRecType(this,'new_hifz')">حفظ</button><button class="tab ${type.includes('review')?'active':''}" type="button" onclick="setRecType(this,'review_near')">مراجعة</button><button class="tab ${type==='sard'?'active':''}" type="button" onclick="setRecType(this,'sard')">سرد</button><button class="tab" type="button" onclick="setRecType(this,'tilawah')">تلاوة</button></div><input type="hidden" class="rType" value="${type}"><div class="seg"><button class="active" type="button" onclick="setRecMode(this,'ayahs')">السورة والآية</button><button type="button" onclick="setRecMode(this,'pages')">الصفحات</button><button type="button" onclick="setRecMode(this,'surahs')">سور متعددة</button><button type="button" onclick="setRecMode(this,'juz')">الأجزاء</button></div><div class="rAyahs mode-panel">${qAyahPanel(id,true)}</div><div class="rPages mode-panel hidden">${qPagesPanel(id,true)}</div><div class="rSurahs mode-panel hidden">${qSurahsPanel(id,true)}</div><div class="rJuz mode-panel hidden">${qJuzPanel(id,true)}</div><div class="actions"><button class="btn btn-soft" type="button" onclick="calcRecRow(this.closest('.rec-row'))">حساب المقدار</button><button class="btn btn-ghost" type="button" onclick="openRowMushaf(this.closest('.rec-row'))">📖 فتح المصحف</button></div><div class="range-summary"><span class="muted">المقدار الفعلي</span><div><strong class="rPagesCount">0</strong> صفحة <span class="muted rAyahsCount"></span></div><div class="calc-status rCalcStatus">اختر النطاق ثم اضغط حساب المقدار</div></div><div class="form-grid"><label class="field"><span>عدد الأخطاء</span><div class="counter"><button type="button" onclick="stepCounter(this,1,'mist')">＋</button><div class="num rMist">0</div><button type="button" onclick="stepCounter(this,-1,'mist')">−</button></div></label><label class="field"><span>عدد النقرات / التلقينات</span><div class="counter"><button type="button" onclick="stepCounter(this,1,'prompt')">＋</button><div class="num rPrompt">0</div><button type="button" onclick="stepCounter(this,-1,'prompt')">−</button></div></label></div><div class="eval-box"><div class="row"><span class="eval-dot eval-excellent rEvalDot"></span><div><b class="rEvalText">غير مقيّم</b><div class="muted rEvalMeta">التقييم يتغير حسب الخصم لكل صفحة</div></div></div><div style="text-align:left"><b class="rPoints">0</b><div class="muted">نقطة</div></div></div><label class="field"><span>ملاحظة خاصة بهذا التسميع</span><input class="input rNote" placeholder="اختياري"></label></div>`;$('#recitationRows').appendChild(d);updateEval(d)}
function setRecType(btn,type){let row=btn.closest('.rec-row');row.querySelectorAll('.tabs .tab').forEach(x=>x.classList.remove('active'));btn.classList.add('active');row.querySelector('.rType').value=type}
function setRecMode(btn,mode){let row=btn.closest('.rec-row');row.dataset.mode=mode;btn.parentElement.querySelectorAll('button').forEach(x=>x.classList.remove('active'));btn.classList.add('active');row.querySelector('.rAyahs').classList.toggle('hidden',mode!=='ayahs');row.querySelector('.rPages').classList.toggle('hidden',mode!=='pages');row.querySelector('.rSurahs').classList.toggle('hidden',mode!=='surahs');row.querySelector('.rJuz').classList.toggle('hidden',mode!=='juz')}
function stepCounter(btn,delta,kind){let row=btn.closest('.rec-row'),el=row.querySelector(kind==='mist'?'.rMist':'.rPrompt');el.textContent=Math.max(0,+el.textContent+delta);updateEval(row)}
function computeEval(pages,mist,prompt){let cfg=state.settings||{},mp=Number(cfg.mistake_penalty??1),pp=Number(cfg.prompt_penalty??.5),w=Number(cfg.point_penalty_weight??.25),ex=Number(cfg.excellent_max_penalty_per_page??.5),vg=Number(cfg.very_good_max_penalty_per_page??1),gd=Number(cfg.good_max_penalty_per_page??2),p=Math.max(Number(pages)||0,0),penalty=(Number(mist)||0)*mp+(Number(prompt)||0)*pp;if(p<=0)return {penalty,density:null,ev:'not_rated',points:0};let density=penalty/p,ev=density<=ex?'excellent':density<=vg?'very_good':density<=gd?'good':'repeat',points=Math.max(0,p-penalty*w);return {penalty,density,ev,points:Math.round(points*100)/100}}
function updateEval(row){let d=computeEval(+row.dataset.pages||0,+row.querySelector('.rMist').textContent,+row.querySelector('.rPrompt').textContent);row.querySelector('.rEvalText').textContent=evalAr[d.ev];row.querySelector('.rEvalDot').className='eval-dot rEvalDot '+evalDot(d.ev==='not_rated'?'repeat':d.ev);row.querySelector('.rPoints').textContent=fmt(d.points);row.querySelector('.rEvalMeta').textContent=d.density==null?'حدد مقدار التسميع أولاً':`خصم ${fmt(d.penalty)} · ${fmt(d.density)} لكل صفحة`;row.dataset.evaluation=d.ev;row.dataset.points=d.points;row.dataset.penalty=d.penalty;row.dataset.penaltyPerPage=d.density??''}
function openRowMushaf(row){let id=row.dataset.id,s=+row.dataset.startSurah||+$('#'+id+'SS')?.value||1,a=+row.dataset.startAyah||+$('#'+id+'SA')?.value||1;window.open(`https://quran.com/${s}/${a}`,'_blank')}
async function calcRecRow(row){let id=row.dataset.id,mode=row.dataset.mode;try{row.querySelector('.rCalcStatus').textContent='جاري الحساب...';let d,selectedSurahs=[],selectedJuz=[];if(mode==='pages'){let a=+$('#'+id+'PF').value,b=+$('#'+id+'PT').value;if(!a||!b||b<a)throw new Error('تحقق من الصفحات');if(row.dataset.startSurah&&row.dataset.endSurah)d=await calculateAyahRangeData(+row.dataset.startSurah,+row.dataset.startAyah,+row.dataset.endSurah,+row.dataset.endAyah);else d={pages:b-a+1,ayahs:0,surahs:0,startPage:a,endPage:b};row.dataset.startPage=a;row.dataset.endPage=b}else if(mode==='surahs'){selectedSurahs=selectedNums(id,'surah');if(!selectedSurahs.length)throw new Error('اختر سورة واحدة على الأقل');d=await calculateFullSurahs(selectedSurahs);d.surahs=selectedSurahs.length}else if(mode==='juz'){selectedJuz=selectedNums(id,'juz');if(!selectedJuz.length)throw new Error('اختر جزءاً واحداً على الأقل');d=await calculateJuzs(selectedJuz);d.surahs=0}else{let ss=+$('#'+id+'SS').value,sa=+$('#'+id+'SA').value,es=+$('#'+id+'ES').value,ea=+$('#'+id+'EA').value;d=await calculateAyahRangeData(ss,sa,es,ea);row.dataset.startSurah=ss;row.dataset.endSurah=es;row.dataset.startAyah=sa;row.dataset.endAyah=ea}row.dataset.pages=d.pages;row.dataset.ayahs=d.ayahs||0;row.dataset.surahs=d.surahs||0;row.dataset.selectedSurahs=JSON.stringify(selectedSurahs);row.dataset.selectedJuz=JSON.stringify(selectedJuz);if(d.startPage)row.dataset.startPage=d.startPage;if(d.endPage)row.dataset.endPage=d.endPage;row.querySelector('.rPagesCount').textContent=fmt(d.pages);row.querySelector('.rAyahsCount').textContent=d.ayahs?`· ${d.ayahs} آية`:'';row.querySelector('.rCalcStatus').textContent=d.preciseLines?'محسوب محلياً حسب سطور مصحف المدينة (15 سطراً)':d.estimated?'تقدير احتياطي؛ بيانات المصحف الدقيقة غير جاهزة':'تم حساب المقدار';updateEval(row)}catch(e){row.querySelector('.rCalcStatus').textContent=e.message;toast(e.message)}}
$('#reportForm').addEventListener('submit',async e=>{e.preventDefault();let sid=$('#rpStudent').value,seId=$('#rpSession').value,attendance={session_id:seId,student_id:sid,status:$('#rpAttendance').value,excuse_reason:$('#rpExcuse').value||null,recorded_by:state.user.id},note={session_id:seId,student_id:sid,behavior:$('#rpBehavior').value,behavior_score:+$('#rpBehaviorScore').value,teacher_comment:$('#rpComment').value||null,homework:$('#rpHomework').value||null,parent_visible:true,created_by:state.user.id};let formRows=$$('.rec-row').map(r=>{let data={session_id:seId,student_id:sid,activity_type:r.querySelector('.rType').value,input_method:r.dataset.mode,start_surah:+r.dataset.startSurah||null,start_ayah:+r.dataset.startAyah||null,end_surah:+r.dataset.endSurah||null,end_ayah:+r.dataset.endAyah||null,start_page:+r.dataset.startPage||null,end_page:+r.dataset.endPage||null,pages_count:+r.dataset.pages||0,ayahs_count:+r.dataset.ayahs||0,surahs_count:+r.dataset.surahs||0,mistakes:+r.querySelector('.rMist').textContent||0,prompts:+r.querySelector('.rPrompt').textContent||0,teacher_note:r.querySelector('.rNote').value||null,selected_surahs:JSON.parse(r.dataset.selectedSurahs||'[]'),selection_data:{mode:r.dataset.mode,selected_juz:JSON.parse(r.dataset.selectedJuz||'[]'),start_global:r.dataset.startGlobal||null,end_global:r.dataset.endGlobal||null},created_by:state.user.id};return {dbId:r.dataset.dbId||null,data:decorateRecForOffline(data)}});let payload={sessionId:seId,studentId:sid,attendance,note,rows:formRows,existingRecIds:[...(state.reportExistingRecIds||[])]};if(state.demo){reportDlg.close();toast('تم حفظ التقرير التجريبي');return}if(!(await internetReachable())||String(seId).startsWith('offline-')){saveReportOffline(payload);reportDlg.close();render();return}try{await syncReportPayload(payload,{});reportDlg.close();toast('تم حفظ الحضور والسلوك والتسميع');await loadAll();if(state.sessionView===seId)await loadSessionRosterData(seId);render()}catch(err){if(isNetworkError(err)){saveReportOffline(payload);reportDlg.close();render()}else toast(err.message||err)}})

function studentProfile(id){if(state.profile?.role==='guardian'&&!state.students.some(x=>x.id===id)){toast('لا تملك صلاحية فتح ملف هذا الطالب');go('home');return}let st=state.students.find(x=>x.id===id),m=state.monthly.find(x=>x.student_id===id)||{},g=state.goals.find(x=>x.student_id===id),leaders=state.leaderMonthly.filter(x=>x.student_id===id);if(!st)return;$('#content').innerHTML=`<div class="card"><div class="row">${avatarHtml(st,'photo-lg')}<div class="grow"><h2 style="margin:0">${esc(st.full_name)}</h2><div class="muted">${esc(st.program_name||'بدون مسار')} · ${esc(st.guardian_email||'ولي الأمر غير مربوط')}</div><div class="actions"><span class="badge">${st.status==='active'?'طالب نشط':esc(st.status)}</span>${canManageStudents()?`<button class="mini" onclick="openStudent('${st.id}')">تعديل الملف</button>`:''}</div></div></div><div class="profile-details" style="margin-top:13px"><div class="detail"><span>الجنس</span><b>${st.gender==='male'?'ذكر':st.gender==='female'?'أنثى':'—'}</b></div><div class="detail"><span>رقم الهوية</span><b>${esc(st.national_id||'—')}</b></div><div class="detail"><span>الجوال</span><b>${esc(st.phone||'—')}</b></div><div class="detail"><span>تاريخ الميلاد</span><b>${esc(st.date_of_birth||'—')}</b></div><div class="detail"><span>المرحلة</span><b>${esc(st.school_grade||'—')}</b></div><div class="detail"><span>جوال ولي الأمر</span><b>${esc(st.guardian_phone||'—')}</b></div></div></div><div class="grid stats">${stat('حفظ الشهر',fmt(m.hifz_pages)+' ص')}${stat('المراجعة',fmt(m.review_pages)+' ص')}${stat('السرد',fmt(m.sard_pages)+' ص')}${stat('الحضور',m.present_days||0)}</div>${g?`<div class="card"><h3>الخطة الشهرية</h3><div class="muted">ورد يومي: حفظ ${fmt(g.target_daily_hifz_pages)} · مراجعة ${fmt(g.target_daily_review_pages)} · سرد ${fmt(g.target_daily_sard_pages)} صفحة</div>${planProgress('الحفظ',Math.min(100,Math.round((m.hifz_pages||0)/(g.target_hifz_pages||1)*100)),m.hifz_pages,g.target_hifz_pages)}${planProgress('المراجعة',Math.min(100,Math.round((m.review_pages||0)/(g.target_review_pages||1)*100)),m.review_pages,g.target_review_pages)}${planProgress('السرد',Math.min(100,Math.round((m.sard_pages||0)/(g.target_sard_pages||1)*100)),m.sard_pages,g.target_sard_pages)}</div>`:''}<div class="card"><h3>النقاط هذا الشهر</h3>${leaders.map(x=>`<div class="row" style="padding:8px 0;border-bottom:1px dashed var(--line)"><span class="grow">${trackAr[x.track]}</span><span class="muted">${fmt(x.pages)} ص · ${fmt(x.penalty_per_page)} خصم/ص</span><b>${fmt(x.points)}</b></div>`).join('')||'<div class="muted">لا توجد نقاط بعد.</div>'}</div><button class="btn btn-ghost" onclick="go(state.profile.role==='guardian'?'profile':'students')">رجوع</button>`}

window.addEventListener('offline',()=>{state.networkVerified=false;state.offline=true;updateSyncBadge();if(state.user){cacheSnapshot();toast('انقطع الإنترنت — العمل مستمر محلياً وسيتم رفع البيانات لاحقاً')}});
window.addEventListener('online',()=>{setTimeout(async()=>{if(await internetReachable(true)){state.offline=false;updateSyncBadge();if(state.user){await syncOfflineQueue();refreshFromServer({renderAfter:true})}}},250)});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&state.user)setTimeout(async()=>{if(await internetReachable(true)){await syncOfflineQueue();refreshFromServer({renderAfter:true})}},100)});

/* ==================== Halaqati v2.10 compatibility/restoration patch ==================== */
Object.assign(state,{
  halaqaSupervisors:state.halaqaSupervisors||[],
  reportMode:state.reportMode||'month',reportDay:state.reportDay||today(),reportMonth:state.reportMonth||today().slice(0,7),
  reportFrom:state.reportFrom||monthStart(),reportTo:state.reportTo||today(),reportHalaqa:state.reportHalaqa||'all',
  reportSessionType:state.reportSessionType||'all',reportType:state.reportType||'halaqa',reportIncludePhotos:state.reportIncludePhotos!==false,
  reportIncludeBirthDate:state.reportIncludeBirthDate!==false,reportIncludeTeacher:state.reportIncludeTeacher!==false,
  reportLoadedKey:state.reportLoadedKey||'',reportLoading:false,reportRows:state.reportRows||[],reportData:state.reportData||{sessions:[],attendance:[],recitations:[],notes:[]}
});

/* ----- faster cache also includes multi-supervisor mappings ----- */
function cacheSnapshot(){let k=cacheKey();if(!k||!state.profile)return;let snap={savedAt:new Date().toISOString(),profile:state.profile,halaqas:state.halaqas,students:state.students,sessions:state.sessions,announcements:state.announcements,goals:state.goals,monthly:state.monthly,leaderDaily:state.leaderDaily,leaderMonthly:state.leaderMonthly,dailySummary:state.dailySummary,forum:state.forum,comments:state.comments,categories:state.categories,halaqaTeachers:state.halaqaTeachers,halaqaSupervisors:state.halaqaSupervisors,guardianAccounts:state.guardianAccounts,guardianDirectory:state.guardianDirectory,guardianRanksMonth:state.guardianRanksMonth,guardianRanksDay:state.guardianRanksDay,guardianCompetition:state.guardianCompetition,competitionTrack:state.competitionTrack,competitionPeriod:state.competitionPeriod,settings:state.settings,offlineRosterCache:state.offlineRosterCache};try{localStorage.setItem(k,JSON.stringify(snap))}catch(e){}}
function restoreSnapshot(){let k=cacheKey();if(!k)return false;try{let x=JSON.parse(localStorage.getItem(k)||'null');if(!x||!x.profile)return false;state.profile=x.profile;for(let p of ['halaqas','students','sessions','announcements','goals','monthly','leaderDaily','leaderMonthly','dailySummary','forum','comments','categories','halaqaTeachers','halaqaSupervisors','guardianAccounts','guardianDirectory'])state[p]=x[p]||[];state.guardianRanksMonth=x.guardianRanksMonth||{};state.guardianRanksDay=x.guardianRanksDay||{};state.guardianCompetition=x.guardianCompetition||{};state.competitionTrack=x.competitionTrack||'hifz';state.competitionPeriod=x.competitionPeriod||'month';state.settings=x.settings||null;state.offlineRosterCache=x.offlineRosterCache||{};state.users=[];state.offline=true;return true}catch(e){return false}}

async function loadAll(forceNetwork=false){
  let online=forceNetwork?true:await internetReachable();
  if(!online){if(restoreSnapshot()){state.pendingSync=readOfflineQueue().length;applySavedTheme();updateSyncBadge();return}state.offline=true;updateSyncBadge();return}
  state.networkVerified=true;state.offline=false;
  let queries=[
    db.from('halaqas').select('*').order('created_at'),db.from('students').select('*').order('full_name'),db.from('sessions').select('*').order('session_date',{ascending:false}).limit(120),
    db.from('announcements').select('*').order('pinned',{ascending:false}).order('publish_at',{ascending:false}).limit(80),db.from('student_goals').select('*').gte('period_end',monthStart()).limit(300),
    db.from('monthly_student_stats').select('*').gte('month_start',monthStart()),db.from('leaderboard_daily').select('*').eq('period_date',today()),db.from('leaderboard_monthly').select('*').gte('month_start',monthStart()),
    db.from('daily_student_summary').select('*').eq('session_date',today()).limit(300),db.from('forum_posts').select('*').order('pinned',{ascending:false}).order('created_at',{ascending:false}).limit(80),
    db.from('forum_comments').select('*').order('created_at').limit(500),db.from('app_settings').select('*').eq('id',1).single(),db.from('student_categories').select('*').order('min_age',{ascending:true,nullsFirst:false}).order('name'),
    db.from('halaqa_teachers').select('*'),db.from('halaqa_supervisors').select('*')
  ];
  if(roleCanAdmin())queries.push(db.from('profiles').select('id,full_name,email,phone,role,requested_role,approval_status,active,approved_at,rejection_reason,created_at').order('created_at',{ascending:false}));
  let r;try{r=await withTimeout(Promise.all(queries),6500,'load timeout')}catch(e){state.networkVerified=false;state.offline=true;if(restoreSnapshot()){updateSyncBadge();return}throw e}
  let critical=r.slice(0,3).find(x=>x.error&&isNetworkError(x.error));if(critical&&restoreSnapshot()){state.networkVerified=false;state.offline=true;state.pendingSync=readOfflineQueue().length;updateSyncBadge();return}
  [state.halaqas,state.students,state.sessions,state.announcements,state.goals,state.monthly,state.leaderDaily,state.leaderMonthly,state.dailySummary,state.forum,state.comments]=r.slice(0,11).map(x=>x.data||[]);
  state.settings=r[11]?.data||null;state.categories=r[12]?.data||[];state.halaqaTeachers=r[13]?.data||[];state.halaqaSupervisors=r[14]?.data||[];state.users=roleCanAdmin()?(r[15]?.data||[]):[];
  await loadRoleExtras();applySavedTheme();await loadPhotoUrls();state.pendingSync=readOfflineQueue().length;cacheSnapshot();updateSyncBadge()
}

/* ----- many-to-many supervisors ----- */
function supervisorIdsForHalaqa(hid){let ids=(state.halaqaSupervisors||[]).filter(x=>x.halaqa_id===hid).map(x=>x.supervisor_id),h=state.halaqas.find(x=>x.id===hid);if(h?.supervisor_id)ids.push(h.supervisor_id);return [...new Set(ids.filter(Boolean))]}
function supervisorNamesForHalaqa(hid){let ids=supervisorIdsForHalaqa(hid),names=ids.map(id=>state.users.find(u=>u.id===id)?.full_name).filter(Boolean);if(names.length)return names.join('، ');return ids.length?`${ids.length} مشرف`:'غير معيّن'}
function openSupervisorAssignments(hid){if(!isOwner())return toast('إدارة مشرفي الحلقات لمسؤول النظام فقط');$('#saHalaqa').value=hid;let assigned=new Set(supervisorIdsForHalaqa(hid)),rows=state.users.filter(u=>u.role==='supervisor'&&u.approval_status==='approved'&&u.active);$('#supervisorAssignList').innerHTML=rows.length?rows.map(u=>`<label class="supervisor-check"><input type="checkbox" name="saSupervisor" value="${u.id}" ${assigned.has(u.id)?'checked':''}><span><b>${esc(u.full_name)}</b><div class="muted">${esc(u.email||'')}</div></span></label>`).join(''):'<div class="empty">لا توجد حسابات مشرفين معتمدة بعد.</div>';supervisorAssignDlg.showModal()}
$('#supervisorAssignForm')?.addEventListener('submit',async e=>{e.preventDefault();if(!isOwner())return;let hid=$('#saHalaqa').value,wanted=[...document.querySelectorAll('input[name="saSupervisor"]:checked')].map(x=>x.value),old=(state.halaqaSupervisors||[]).filter(x=>x.halaqa_id===hid),oldIds=old.map(x=>x.supervisor_id),toAdd=wanted.filter(x=>!oldIds.includes(x)),toDel=oldIds.filter(x=>!wanted.includes(x));try{if(toDel.length){let q=await db.from('halaqa_supervisors').delete().eq('halaqa_id',hid).in('supervisor_id',toDel);if(q.error)throw q.error}if(toAdd.length){let q=await db.from('halaqa_supervisors').insert(toAdd.map(supervisor_id=>({halaqa_id:hid,supervisor_id,created_by:state.user.id})));if(q.error)throw q.error}let q=await db.from('halaqas').update({supervisor_id:wanted[0]||null}).eq('id',hid);if(q.error)throw q.error;supervisorAssignDlg.close();toast('تم تحديث مشرفي الحلقة');await loadAll();render()}catch(err){toast('تعذر حفظ المشرفين: '+(err?.message||err))}})
function halaqasPage(){if(!roleCanManage())return '<div class="empty">لا توجد حلقات متاحة.</div>';return `<div class="hero"><h2>${isOwner()?'إدارة الحلقات والفئات':'الحلقات والفئات'}</h2><p>يمكن ربط أكثر من مشرف وأكثر من محفّظ بالحَلَقة، والمشرف الواحد يستطيع متابعة أكثر من حلقة.</p></div><div class="section-head"><h3>الحلقات (${state.halaqas.length})</h3>${isOwner()?'<button class="btn btn-primary" onclick="openHalaqa()">+ حلقة</button>':''}</div>${state.halaqas.map(h=>{let cats=state.categories.filter(c=>c.halaqa_id===h.id&&c.active!==false),sts=activeStudents().filter(s=>s.halaqa_id===h.id),tids=state.halaqaTeachers.filter(x=>x.halaqa_id===h.id).map(x=>x.teacher_id),teachers=state.users.filter(u=>tids.includes(u.id)),sids=supervisorIdsForHalaqa(h.id);return `<div class="card"><div class="row"><div class="avatar">ح</div><div class="grow"><b>${esc(h.name)}</b><div class="muted">${esc(h.location||'المكان غير محدد')} · ${esc(h.schedule_text||'البرنامج غير محدد')}</div><div class="muted">المشرفون: ${esc(supervisorNamesForHalaqa(h.id))} · المحفّظون: ${teachers.length?teachers.map(x=>esc(x.full_name)).join('، '):(state.profile.role==='teacher'?'أنت / حسب الربط':'غير معيّنين')}</div></div><span class="badge">${h.active===false?'موقوفة':'نشطة'}</span></div><div class="structure-grid"><div class="structure-item"><b>${sts.length}</b>طالب</div><div class="structure-item"><b>${cats.length}</b>فئة</div><div class="structure-item"><b>${sids.length}</b>مشرف</div></div><div class="actions">${isOwner()?`<button class="mini" onclick="openHalaqa('${h.id}')">تعديل الحلقة</button><button class="mini" onclick="openSupervisorAssignments('${h.id}')">المشرفون</button>`:''}<button class="mini" onclick="openCategories('${h.id}')">الفئات</button>${['admin','supervisor'].includes(state.profile.role)?`<button class="mini" onclick="openTeacherAssignments('${h.id}')">المحفّظون</button>`:''}<button class="mini" onclick="goToHalaqaStudents('${h.id}')">طلاب الحلقة</button></div><div class="muted" style="margin-top:9px">المسارات: حفظ عام ${sts.filter(s=>s.track_code==='general_hifz').length} · سرد ${sts.filter(s=>s.track_code==='sard').length} · تثبيت ${sts.filter(s=>s.track_code==='tathbit').length} · بدون مسار ${sts.filter(s=>!s.track_code).length}</div></div>`}).join('')||'<div class="empty">لا توجد حلقات بعد.</div>'}`}

/* ----- v2.8.2 delete controls + monthly plan display ----- */
function removeSessionFromDevice(id){state.sessions=state.sessions.filter(x=>x.id!==id);delete state.offlineRosterCache[id];let q=readOfflineQueue().filter(op=>op?.data?.sessionId!==id&&op?.data?.session_id!==id&&!String(op.key||'').includes(id));writeOfflineQueue(q);if(state.sessionView===id){state.sessionView=null;state.sessionRoster={attendance:[],notes:[],recitations:[]}}cacheSnapshot()}
function clearDeletedSessionDerivedState(){state.dailySummary=[];state.monthly=[];state.leaderDaily=[];state.leaderMonthly=[];cacheSnapshot()}
function sessionCards(rows=state.sessions){if(!rows.length)return '<div class="empty">لا توجد جلسات.</div>';return rows.map(s=>`<div class="card row"><div class="avatar">${s.session_type==='sard'?'س':'ت'}</div><div class="grow"><b>${esc(s.title||sesAr[s.session_type])}</b><div class="muted">${s.session_date} · ${sesAr[s.session_type]} · ${s.status==='open'?'مفتوحة':s.status==='cancelled'?'ملغاة':'مسجلة'} ${s._offline?'· محفوظ محلياً':''}</div></div>${roleCanManage()?`${s.status!=='cancelled'?`<button class="mini" onclick="openSessionRoster('${s.id}')">فتح</button>`:''}<button class="mini red" onclick="cancelSession('${s.id}')">حذف</button>`:''}</div>`).join('')}
async function cancelSession(id){if(!roleCanManage())return;let se=state.sessions.find(x=>x.id===id);if(!se)return;if(!confirm(`حذف جلسة «${se.title||sesAr[se.session_type]||'الجلسة'}» نهائياً؟\nسيتم حذف الجلسة وكل الحضور والتسميع والسلوك المرتبط بها.`))return;if(!confirm('تأكيد أخير: لا يمكن استرجاع هذه الجلسة بعد الحذف. متابعة؟'))return;if(String(id).startsWith('offline-')){removeSessionFromDevice(id);clearDeletedSessionDerivedState();toast('تم حذف الجلسة المحلية وجميع بياناتها');return render()}if(!navigator.onLine||state.offline)return toast('الحذف النهائي لجلسة مسجلة يحتاج اتصالاً بالإنترنت');try{let {data,error}=await db.from('sessions').delete().eq('id',id).select('id');if(error)throw error;if(!data?.length)throw new Error('لم تسمح الصلاحيات بحذف الجلسة');removeSessionFromDevice(id);clearDeletedSessionDerivedState();await loadAll();toast('تم حذف الجلسة نهائياً');render()}catch(e){toast('تعذر حذف الجلسة: '+(e?.message||e))}}
function recitationMiniCard(r){let ev=r.evaluation||r.rating||null,points=Number(r.points||0),del=roleCanManage()?(String(r.id||'').startsWith('offline-')?'<span class="badge">محلي — احذفه من تعديل التفاصيل</span>':`<button class="mini red" type="button" onclick="deleteRecitationEntry('${r.id}')">حذف التسميع</button>`):'';return `<div class="roster-rec"><div class="roster-rec-type">${esc(actAr[r.activity_type]||r.activity_type)}</div><div><div class="roster-rec-range">${esc(recitationRangeText(r))}</div><div class="roster-rec-meta">${fmt(r.pages_count)} ص · ${r.mistakes||0} أخطاء · ${r.prompts||0} نقرات${ev?` · ${esc(evalAr[ev]||ev)}`:''}</div></div><div class="roster-rec-score">${points?`<b>${fmt(points)}</b><span class="muted">نقطة</span>`:''}</div>${del?`<div class="roster-rec-actions">${del}</div>`:''}</div>`}
async function deleteRecitationEntry(id){if(!roleCanManage())return;let r=(state.sessionRoster.recitations||[]).find(x=>x.id===id);if(!r)return toast('التسميع غير موجود');if(String(id).startsWith('offline-'))return toast('التسميع محلي؛ افتح تعديل التفاصيل واحذف البند ثم احفظ');if(!confirm('حذف هذا التسميع نهائياً؟ سيُزال من نقاط الطالب وترتيبه وتقاريره.'))return;if(!navigator.onLine||state.offline)return toast('الحذف النهائي يحتاج اتصالاً بالإنترنت');try{let {data,error}=await db.from('recitation_entries').delete().eq('id',id).select('id');if(error)throw error;if(!data?.length)throw new Error('لم تسمح الصلاحيات بالحذف');state.sessionRoster.recitations=state.sessionRoster.recitations.filter(x=>x.id!==id);clearDeletedSessionDerivedState();await loadAll();if(state.sessionView)await loadSessionRosterData(state.sessionView);toast('تم حذف التسميع وتحديث التقارير');render()}catch(e){toast('تعذر حذف التسميع: '+(e?.message||e))}}
function currentGoalForStudent(sid){let now=monthStart();return state.goals.find(g=>g.student_id===sid&&String(g.period_start||'').slice(0,7)===now.slice(0,7))||state.goals.find(g=>g.student_id===sid)}
function plansPage(){let rows=activeStudents().map(s=>({s,g:currentGoalForStudent(s.id),m:state.monthly.find(m=>m.student_id===s.id)||{}}));return `<div class="hero"><h2>الخطط الشهرية</h2><p>حدد هدف كل طالب، وتابع الإنجاز والورد اليومي، مع إمكانية تعديل الخطة أو حذفها.</p></div><div class="section-head"><h3>خطط الشهر</h3>${roleCanManage()?'<button class="btn btn-primary" onclick="openPlan()">+ خطة</button>':''}</div>${rows.map(({s,g,m})=>{if(!g)return `<div class="card row">${avatarHtml(s)}<div class="grow"><b>${esc(s.full_name)}</b><div class="muted">لا توجد خطة لهذا الشهر</div></div>${roleCanManage()?`<button class="mini" onclick="openPlan('${s.id}')">إضافة</button>`:''}</div>`;let hp=Math.min(100,Math.round(Number(m.hifz_pages||0)/Math.max(Number(g.target_hifz_pages||1),1)*100)),rp=Math.min(100,Math.round(Number(m.review_pages||0)/Math.max(Number(g.target_review_pages||1),1)*100)),sp=Math.min(100,Math.round(Number(m.sard_pages||0)/Math.max(Number(g.target_sard_pages||1),1)*100));return `<div class="card"><div class="row">${avatarHtml(s)}<div class="grow"><b>${esc(s.full_name)}</b><div class="muted">${String(g.period_start||'').slice(0,7)} · الورد اليومي: حفظ ${fmt(g.target_daily_hifz_pages)} · مراجعة ${fmt(g.target_daily_review_pages)} · سرد ${fmt(g.target_daily_sard_pages)} صفحة</div></div></div><div class="plan-target-grid"><div><b>${fmt(g.target_hifz_pages)}</b><span>هدف الحفظ</span></div><div><b>${fmt(g.target_review_pages)}</b><span>هدف المراجعة</span></div><div><b>${fmt(g.target_sard_pages)}</b><span>هدف السرد</span></div><div><b>${fmt(g.expected_session_days||0)}</b><span>أيام الخطة</span></div></div>${planProgress('الحفظ',hp,m.hifz_pages,g.target_hifz_pages)}${planProgress('المراجعة',rp,m.review_pages,g.target_review_pages)}${planProgress('السرد',sp,m.sard_pages,g.target_sard_pages)}${g.note?`<div class="muted" style="margin-top:10px">ملاحظة: ${esc(g.note)}</div>`:''}${roleCanManage()?`<div class="plan-card-actions"><button class="mini" onclick="openPlan('${s.id}','${g.id}')">تعديل الخطة</button><button class="mini red" onclick="deleteMonthlyPlan('${g.id}')">حذف الخطة نهائياً</button></div>`:''}</div>`}).join('')}`}
function openPlan(sid='',gid=''){fillStudents($('#plStudent'),sid);let g=gid?state.goals.find(x=>x.id===gid):(sid?currentGoalForStudent(sid):null);$('#plMonth').value=g?String(g.period_start||monthStart()).slice(0,7):monthStart().slice(0,7);$('#plHifz').value=g?.target_hifz_pages??40;$('#plReview').value=g?.target_review_pages??120;$('#plSard').value=g?.target_sard_pages??40;$('#plDays').value=g?.expected_session_days??20;$('#plNote').value=g?.note||'';planDlg.showModal()}
async function deleteMonthlyPlan(id){if(!roleCanManage())return;let g=state.goals.find(x=>x.id===id);if(!g)return toast('الخطة غير موجودة');let st=state.students.find(x=>x.id===g.student_id);if(!confirm(`حذف خطة ${st?.full_name||'الطالب'} لشهر ${String(g.period_start||'').slice(0,7)} نهائياً؟\nلن تُحذف التسميعات الفعلية.`))return;if(!navigator.onLine||state.offline)return toast('حذف الخطة يحتاج اتصالاً بالإنترنت');try{let {data,error}=await db.from('student_goals').delete().eq('id',id).select('id');if(error)throw error;if(!data?.length)throw new Error('لم تسمح الصلاحيات بحذف الخطة');state.goals=state.goals.filter(x=>x.id!==id);toast('تم حذف الخطة الشهرية');await loadAll();render()}catch(e){toast('تعذر حذف الخطة: '+(e?.message||e))}}

/* ----- v2.8.2 professional report studio ----- */
function reportBounds(){if(state.reportMode==='day'){let d=state.reportDay||today();return {from:d,to:d}}if(state.reportMode==='month'){let ym=state.reportMonth||today().slice(0,7);return {from:ym+'-01',to:monthEnd(ym)}}return {from:state.reportFrom,to:state.reportTo}}
function reportStudents(){let rows=activeStudents();if(state.reportHalaqa&&state.reportHalaqa!=='all')rows=rows.filter(x=>x.halaqa_id===state.reportHalaqa);return rows}
function reportKey(){let b=reportBounds();return `${state.reportMode}:${b.from}:${b.to}:${state.reportHalaqa}:${state.reportSessionType}`}
function reportHalaqas(){let ids=[...new Set(reportStudents().map(x=>x.halaqa_id))];return ids.map(id=>state.halaqas.find(h=>h.id===id)).filter(Boolean)}
function reportMainHalaqa(){let hs=reportHalaqas();return hs.length===1?hs[0]:null}
function reportPeriodLabel(){let b=reportBounds();return b.from===b.to?b.from:`${b.from} إلى ${b.to}`}
function reportFileStamp(){return `${reportTypeLabel(state.reportType)}_${reportPeriodLabel()}`.replace(/[^\d\u0600-\u06FF_-]+/g,'_')}
function reportTypeLabel(t){return {leaders:'لائحة_الأوائل',points:'نقاط_الطلاب',students:'تقارير_الطلاب',halaqa:'تقرير_الحلقة',attendance:'حضور_الحلقة',recitations:'سجل_التسميعات'}[t]||'تقرير'}
function reportTypeTitle(t){return {leaders:'لائحة الأوائل',points:'نقاط الطلاب',students:'تقرير لكل طالب',halaqa:'تقرير الحلقة',attendance:'حضور الحلقة',recitations:'سجل التسميعات'}[t]||'تقرير الحلقة'}
function reportSessions(){return state.reportData?.sessions||[]}
function reportAttendance(){return state.reportData?.attendance||[]}
function reportRecitations(){return state.reportData?.recitations||[]}
function reportNotes(){return state.reportData?.notes||[]}
function recPoints(r){if(r.points!=null)return Number(r.points||0);return Math.max(0,Number(r.pages_count||0)-(Number(r.mistakes||0)+Number(r.prompts||0)*.5)*.25)}
function recGroup(r,st){if(r.activity_type==='new_hifz')return st?.track_code==='tathbit'?'tathbit':'hifz';if(String(r.activity_type||'').includes('review'))return 'review';if(r.activity_type==='sard')return 'sard';return 'tilawah'}
function reportStatsRows(){let students=reportStudents(),sidSet=new Set(students.map(x=>x.id)),sessions=reportSessions(),seSet=new Set(sessions.map(x=>x.id)),at=reportAttendance().filter(x=>sidSet.has(x.student_id)&&seSet.has(x.session_id)),recs=reportRecitations().filter(x=>sidSet.has(x.student_id)&&seSet.has(x.session_id)),notes=reportNotes().filter(x=>sidSet.has(x.student_id)&&seSet.has(x.session_id));return students.map(st=>{let a=at.filter(x=>x.student_id===st.id),rr=recs.filter(x=>x.student_id===st.id),nn=notes.filter(x=>x.student_id===st.id),out={student:st,hifzPages:0,tathbitPages:0,reviewPages:0,sardPages:0,tilawahPages:0,mistakes:0,prompts:0,points:0,present:0,absent:0,excused:0,late:0,notes:nn};for(let x of a){if(x.status==='present')out.present++;else if(x.status==='absent')out.absent++;else if(x.status==='excused')out.excused++;else if(x.status==='late')out.late++}for(let r of rr){let g=recGroup(r,st),p=Number(r.pages_count||0);if(g==='hifz')out.hifzPages+=p;else if(g==='tathbit')out.tathbitPages+=p;else if(g==='review')out.reviewPages+=p;else if(g==='sard')out.sardPages+=p;else out.tilawahPages+=p;out.mistakes+=Number(r.mistakes||0);out.prompts+=Number(r.prompts||0);out.points+=recPoints(r)}out.totalPages=out.hifzPages+out.tathbitPages+out.reviewPages+out.sardPages+out.tilawahPages;out.sessions=a.length;return out}).filter(x=>x.totalPages>0||x.present+x.absent+x.excused+x.late>0||x.notes.length>0).sort((a,b)=>b.points-a.points||b.totalPages-a.totalPages||a.student.full_name.localeCompare(b.student.full_name,'ar'))}
function reportFilterHtml(){let hs=state.halaqas,modes=`<div class="report-period-tabs"><button class="${state.reportMode==='day'?'active':''}" onclick="setReportMode('day')">يوم معين</button><button class="${state.reportMode==='range'?'active':''}" onclick="setReportMode('range')">فترة</button><button class="${state.reportMode==='month'?'active':''}" onclick="setReportMode('month')">شهر معين</button></div>`,dateInputs=state.reportMode==='day'?`<label class="field"><span>اليوم</span><input class="input" type="date" value="${esc(state.reportDay)}" onchange="state.reportDay=this.value;state.reportLoadedKey=''" ></label>`:state.reportMode==='month'?`<label class="field"><span>الشهر</span><input class="input" type="month" value="${esc(state.reportMonth)}" onchange="state.reportMonth=this.value;state.reportLoadedKey=''" ></label>`:`<><label class="field"><span>من</span><input class="input" type="date" value="${esc(state.reportFrom)}" onchange="state.reportFrom=this.value;state.reportLoadedKey=''" ></label><label class="field"><span>إلى</span><input class="input" type="date" value="${esc(state.reportTo)}" onchange="state.reportTo=this.value;state.reportLoadedKey=''" ></label></>`;return `<div class="report-control-card">${modes}<div class="report-control-grid">${dateInputs}<label class="field"><span>الحلقة</span><select onchange="state.reportHalaqa=this.value;state.reportLoadedKey='';render()"><option value="all">جميع الحلقات</option>${hs.map(h=>`<option value="${h.id}" ${state.reportHalaqa===h.id?'selected':''}>${esc(h.name)}</option>`).join('')}</select></label><label class="field"><span>نوع اللقاء</span><select onchange="state.reportSessionType=this.value;state.reportLoadedKey='';render()"><option value="all">جميع الأنواع</option>${Object.entries(sesAr).map(([k,v])=>`<option value="${k}" ${state.reportSessionType===k?'selected':''}>${v}</option>`).join('')}</select></label></div><div class="report-option-row"><label><input type="checkbox" ${state.reportIncludePhotos?'checked':''} onchange="state.reportIncludePhotos=this.checked;render()"> صور الطلاب</label><label><input type="checkbox" ${state.reportIncludeBirthDate?'checked':''} onchange="state.reportIncludeBirthDate=this.checked;render()"> تاريخ الميلاد</label><label><input type="checkbox" ${state.reportIncludeTeacher?'checked':''} onchange="state.reportIncludeTeacher=this.checked;render()"> معلومات المحفّظ</label></div><button class="btn btn-primary" style="width:100%;margin-top:10px" onclick="loadSelectedReport()">تجهيز التقرير</button>${state.reportLoading?'<div class="report-loading">جاري جلب بيانات التقرير…</div>':''}</div>`}
function reportTypeGrid(){let items=[['leaders','🏆','لائحة الأوائل','منصة أوائل + ترتيب كامل'],['points','▥','نقاط الطلاب','تفصيل النقاط والصفحات'],['students','👤','تقرير لكل طالب','ملخص + تسميعات + تعليقات'],['halaqa','▦','تقرير حلقة','إنجازات وجداول شاملة'],['attendance','☑','حضور الحلقة','اللقاءات + سجل الحضور'],['recitations','📖','سجل التسميعات','كل التسميعات بالتفصيل']];return `<div class="report-type-grid">${items.map(x=>`<button class="report-type-card ${state.reportType===x[0]?'active':''}" onclick="setReportType('${x[0]}')"><span class="rti">${x[1]}</span><span><b>${x[2]}</b><small>${x[3]}</small></span></button>`).join('')}</div>`}
function setReportType(t){state.reportType=t;render()}
function setReportMode(m){state.reportMode=m;state.reportLoadedKey='';if(m==='day'&&!state.reportDay)state.reportDay=today();if(m==='month'&&!state.reportMonth)state.reportMonth=today().slice(0,7);if(m==='range'){if(!state.reportFrom)state.reportFrom=monthStart();if(!state.reportTo)state.reportTo=today()}render()}
function setReportTab(t){setReportMode(t==='daily'?'day':'month')}
async function reportQueryIn(table,ids){let out=[];for(let i=0;i<ids.length;i+=80){let r=await db.from(table).select('*').in('session_id',ids.slice(i,i+80));if(r.error)throw r.error;out.push(...(r.data||[]))}return out}
function offlineReportFromCache(){let b=reportBounds(),sessions=state.sessions.filter(s=>s.session_date>=b.from&&s.session_date<=b.to&&(state.reportHalaqa==='all'||s.halaqa_id===state.reportHalaqa)&&(state.reportSessionType==='all'||s.session_type===state.reportSessionType)),attendance=[],notes=[],recitations=[];for(let se of sessions){let c=state.offlineRosterCache?.[se.id];if(c){attendance.push(...(c.attendance||[]));notes.push(...(c.notes||[]));recitations.push(...(c.recitations||[]))}}return {sessions,attendance,notes,recitations}}
async function loadSelectedReport(){if(state.reportLoading)return;let b=reportBounds();if(!b.from||!b.to||b.from>b.to)return toast('تأكد من تاريخ البداية والنهاية');if(!(await internetReachable())){let cached=offlineReportFromCache();if(!cached.sessions.length&&state.reportMode==='day'&&state.reportDay===today()){state.reportRows=state.dailySummary||[];return toast('لا توجد تفاصيل جلسات مخزنة محلياً لهذا التقرير')}state.reportData=cached;state.reportLoadedKey=reportKey();render();return toast('تم تجهيز التقرير من البيانات المخزنة على الجهاز')}state.reportLoading=true;render();try{let q=db.from('sessions').select('*').neq('status','cancelled').gte('session_date',b.from).lte('session_date',b.to).order('session_date',{ascending:true}).limit(600);if(state.reportHalaqa!=='all')q=q.eq('halaqa_id',state.reportHalaqa);if(state.reportSessionType!=='all')q=q.eq('session_type',state.reportSessionType);let sr=await q;if(sr.error)throw sr.error;let sessions=sr.data||[],ids=sessions.map(x=>x.id),attendance=[],recitations=[],notes=[];if(ids.length)[attendance,recitations,notes]=await Promise.all([reportQueryIn('attendance_records',ids),reportQueryIn('recitation_entries',ids),reportQueryIn('student_daily_notes',ids)]);state.reportData={sessions,attendance,recitations,notes};state.reportLoadedKey=reportKey();cacheSnapshot();}catch(e){toast('تعذر تجهيز التقرير: '+(e?.message||e))}finally{state.reportLoading=false;render()}}
function reportReadySummaryHtml(){if(state.reportLoadedKey!==reportKey())return `<div class="report-ready-card"><div class="report-ready-head"><div class="report-ready-icon">▤</div><div class="grow"><b>التقرير غير مجهّز بعد</b><span>حدد الفترة والحلقة والنوع ثم اضغط «تجهيز التقرير».</span></div></div></div>`;let rows=reportStatsRows(),sessions=reportSessions(),h=reportMainHalaqa();return `<div class="report-ready-card"><div class="report-ready-head"><div class="report-ready-icon">✓</div><div class="grow"><b>${esc(reportTypeTitle(state.reportType))} جاهز</b><span>${esc(h?.name||'جميع الحلقات')} · ${esc(reportPeriodLabel())}</span></div></div><div class="report-ready-grid"><div class="box"><b>${rows.length}</b><span>طالب</span></div><div class="box"><b>${sessions.length}</b><span>لقاء</span></div><div class="box"><b>${fmt(rows.reduce((a,x)=>a+x.totalPages,0))}</b><span>إجمالي الصفحات</span></div><div class="box"><b>${fmt(rows.reduce((a,x)=>a+x.points,0))}</b><span>إجمالي النقاط</span></div></div></div>`}
function reportHeader(title,sub=''){let h=reportMainHalaqa();return `<div class="pro-head"><div class="pro-head-logo">ح</div><div class="pro-head-title"><h1>حلقتي</h1><p>${esc(title)}${sub?' · '+esc(sub):''}</p></div><div class="pro-head-logo">۞</div></div><div class="pro-meta"><span><b>الحلقة:</b> ${esc(h?.name||'جميع الحلقات')}</span><span><b>الفترة:</b> ${esc(reportPeriodLabel())}</span><span><b>تاريخ الإصدار:</b> ${today()}</span></div>`}
function proFooter(){return `<div class="pro-footer"><span>حلقتي · النظام الرسمي لإدارة ومتابعة حلقات القرآن الكريم</span><span>الإصدار ${APP_VERSION_NAME}</span></div>`}
function kpiHtml(rows){return `<div class="pro-kpis"><div class="pro-kpi"><b>${rows.length}</b><span>طلاب</span></div><div class="pro-kpi"><b>${fmt(rows.reduce((a,x)=>a+x.hifzPages,0))}</b><span>حفظ</span></div><div class="pro-kpi"><b>${fmt(rows.reduce((a,x)=>a+x.reviewPages,0))}</b><span>مراجعة</span></div><div class="pro-kpi"><b>${fmt(rows.reduce((a,x)=>a+x.sardPages,0))}</b><span>سرد</span></div><div class="pro-kpi"><b>${rows.reduce((a,x)=>a+x.present,0)}</b><span>حضور</span></div><div class="pro-kpi"><b>${rows.reduce((a,x)=>a+x.absent+x.excused,0)}</b><span>غياب</span></div></div>`}
function halaqaReportHtml(){let rows=reportStatsRows();return `<div class="pro-report"><section class="pro-report-page">${reportHeader('التقرير الشامل للحلقة')}${kpiHtml(rows)}<div class="pro-table-wrap"><table class="pro-table"><thead><tr><th>#</th><th>الطالب</th><th>الفئة</th><th>المسار</th><th>الحفظ</th><th>التثبيت</th><th>المراجعة</th><th>السرد</th><th>النقاط</th><th>حضور</th><th>غياب</th><th>أخطاء</th></tr></thead><tbody>${rows.map((x,i)=>`<tr><td>${i+1}</td><td class="name">${esc(x.student.full_name)}</td><td>${esc(categoryName(x.student))}</td><td>${esc(studentTrackAr[x.student.track_code]||'—')}</td><td>${fmt(x.hifzPages)}</td><td>${fmt(x.tathbitPages)}</td><td>${fmt(x.reviewPages)}</td><td>${fmt(x.sardPages)}</td><td><b>${fmt(x.points)}</b></td><td>${x.present}</td><td>${x.absent+x.excused}</td><td>${x.mistakes}</td></tr>`).join('')}</tbody></table></div>${rows.length?'':'<div class="report-empty-pro">لا توجد بيانات في الفترة المحددة.</div>'}${proFooter()}</section></div>`}
function leadersReportHtml(){let rows=reportStatsRows().slice().sort((a,b)=>b.points-a.points),top=rows.slice(0,3);return `<div class="pro-report"><section class="pro-report-page">${reportHeader('لائحة الأوائل')}${top.length?`<div class="podium">${[top[1],top[0],top[2]].filter(Boolean).map((x,i)=>{let actual=i===0&&top[1]?2:i===1?1:3,cl=actual===1?'first':actual===2?'second':'third';return `<div class="podium-person ${cl}">${state.reportIncludePhotos?`<div class="podium-avatar">${state.photoUrls[x.student.id]?`<img src="${state.photoUrls[x.student.id]}">`:esc(x.student.full_name[0])}</div>`:''}<div class="podium-step"><div class="podium-rank">${actual}</div><div class="podium-name">${esc(x.student.full_name)}</div><div class="podium-score">${fmt(x.points)} نقطة · ${fmt(x.totalPages)} ص</div></div></div>`}).join('')}</div>`:''}<div class="pro-table-wrap"><table class="pro-table"><thead><tr><th>الترتيب</th><th>الطالب</th><th>النقاط</th><th>الصفحات</th><th>الأخطاء</th><th>الحضور</th></tr></thead><tbody>${rows.map((x,i)=>`<tr><td>${i+1}</td><td class="name">${esc(x.student.full_name)}</td><td>${fmt(x.points)}</td><td>${fmt(x.totalPages)}</td><td>${x.mistakes}</td><td>${x.present}</td></tr>`).join('')}</tbody></table></div>${proFooter()}</section></div>`}
function pointsReportHtml(){let rows=reportStatsRows();return `<div class="pro-report"><section class="pro-report-page">${reportHeader('نقاط الطلاب')}${kpiHtml(rows)}<div class="pro-table-wrap"><table class="pro-table"><thead><tr><th>الطالب</th><th>حفظ</th><th>تثبيت</th><th>مراجعة</th><th>سرد</th><th>أخطاء</th><th>نقرات</th><th>المجموع</th></tr></thead><tbody>${rows.map(x=>`<tr><td class="name">${esc(x.student.full_name)}</td><td>${fmt(x.hifzPages)}</td><td>${fmt(x.tathbitPages)}</td><td>${fmt(x.reviewPages)}</td><td>${fmt(x.sardPages)}</td><td>${x.mistakes}</td><td>${x.prompts}</td><td><b>${fmt(x.points)}</b></td></tr>`).join('')}</tbody></table></div>${proFooter()}</section></div>`}
function attendanceReportHtml(){let rows=reportStatsRows();return `<div class="pro-report"><section class="pro-report-page">${reportHeader('حضور الحلقة')}${kpiHtml(rows)}<div class="pro-table-wrap"><table class="pro-table"><thead><tr><th>الطالب</th><th>حاضر</th><th>غائب</th><th>بعذر</th><th>متأخر</th><th>إجمالي التسجيلات</th></tr></thead><tbody>${rows.map(x=>`<tr><td class="name">${esc(x.student.full_name)}</td><td>${x.present}</td><td>${x.absent}</td><td>${x.excused}</td><td>${x.late}</td><td>${x.present+x.absent+x.excused+x.late}</td></tr>`).join('')}</tbody></table></div>${proFooter()}</section></div>`}
function recitationRangeForReport(r){if(r.start_page&&r.end_page)return `ص ${r.start_page}–${r.end_page}`;if(r.start_surah&&r.start_ayah)return `${surahs[(r.start_surah||1)-1]||''} ${r.start_ayah}${r.end_surah?` → ${surahs[(r.end_surah||1)-1]||''} ${r.end_ayah||''}`:''}`;if(Array.isArray(r.selected_surahs)&&r.selected_surahs.length)return r.selected_surahs.map(n=>surahs[n-1]).join('، ');let j=r.selection_data?.selected_juz;if(Array.isArray(j)&&j.length)return `الأجزاء ${j.join('، ')}`;return `${fmt(r.pages_count)} صفحة`}
function recitationsReportHtml(){let seMap=Object.fromEntries(reportSessions().map(s=>[s.id,s])),stMap=Object.fromEntries(state.students.map(s=>[s.id,s])),rows=reportRecitations().slice().sort((a,b)=>(seMap[a.session_id]?.session_date||'').localeCompare(seMap[b.session_id]?.session_date||''));return `<div class="pro-report"><section class="pro-report-page">${reportHeader('سجل التسميعات')}<div class="pro-table-wrap"><table class="pro-table"><thead><tr><th>التاريخ</th><th>الطالب</th><th>النوع</th><th>النطاق</th><th>صفحات</th><th>أخطاء</th><th>نقرات</th><th>تقييم</th><th>نقاط</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${seMap[r.session_id]?.session_date||'—'}</td><td class="name">${esc(stMap[r.student_id]?.full_name||'—')}</td><td>${esc(actAr[r.activity_type]||r.activity_type||'—')}</td><td>${esc(recitationRangeForReport(r))}</td><td>${fmt(r.pages_count)}</td><td>${r.mistakes||0}</td><td>${r.prompts||0}</td><td>${esc(evalAr[r.evaluation]||r.evaluation||r.rating||'—')}</td><td>${fmt(recPoints(r))}</td></tr>`).join('')}</tbody></table></div>${rows.length?'':'<div class="report-empty-pro">لا توجد تسميعات.</div>'}${proFooter()}</section></div>`}
function studentSingleReportHtml(x,i,total){let st=x.student,recs=reportRecitations().filter(r=>r.student_id===st.id),notes=reportNotes().filter(n=>n.student_id===st.id),seMap=Object.fromEntries(reportSessions().map(s=>[s.id,s]));return `<section class="pro-report-page">${reportHeader(`تقرير الطالب ${i+1}/${total}`,st.full_name)}<div class="student-report-card">${state.reportIncludePhotos?`<div class="student-report-photo">${state.photoUrls[st.id]?`<img src="${state.photoUrls[st.id]}">`:esc(st.full_name[0])}</div>`:''}<div><h2 style="margin:0;color:#0d3b2f">${esc(st.full_name)}</h2><div class="student-info-grid"><div>المسار<b>${esc(studentTrackAr[st.track_code]||'—')}</b></div><div>الفئة<b>${esc(categoryName(st))}</b></div>${state.reportIncludeBirthDate?`<div>الميلاد<b>${esc(st.date_of_birth||'—')}</b></div>`:''}<div>الحفظ<b>${fmt(x.hifzPages)} ص</b></div><div>المراجعة<b>${fmt(x.reviewPages)} ص</b></div><div>السرد<b>${fmt(x.sardPages)} ص</b></div></div></div></div><div class="pro-section-title">التسميعات</div><div class="pro-table-wrap"><table class="pro-table"><thead><tr><th>التاريخ</th><th>النوع</th><th>النطاق</th><th>صفحات</th><th>أخطاء</th><th>نقاط</th></tr></thead><tbody>${recs.map(r=>`<tr><td>${seMap[r.session_id]?.session_date||'—'}</td><td>${esc(actAr[r.activity_type]||r.activity_type||'—')}</td><td>${esc(recitationRangeForReport(r))}</td><td>${fmt(r.pages_count)}</td><td>${r.mistakes||0}</td><td>${fmt(recPoints(r))}</td></tr>`).join('')}</tbody></table></div>${notes.length?`<div class="pro-section-title">تعليقات ومتابعة</div><div class="pro-table-wrap"><table class="pro-table"><thead><tr><th>التاريخ</th><th>السلوك</th><th>الواجب</th><th>تعليق المحفّظ</th></tr></thead><tbody>${notes.map(n=>`<tr><td>${seMap[n.session_id]?.session_date||'—'}</td><td>${esc(behAr[n.behavior]||n.behavior||'—')}</td><td class="text-cell">${esc(n.homework||'—')}</td><td class="text-cell">${esc(n.teacher_comment||'—')}</td></tr>`).join('')}</tbody></table></div>`:''}${proFooter()}</section>`}
function studentsReportHtml(){let rows=reportStatsRows();return `<div class="pro-report">${rows.length?rows.map((x,i)=>studentSingleReportHtml(x,i,rows.length)).join(''):`<section class="pro-report-page">${reportHeader('تقارير الطلاب')}<div class="report-empty-pro">لا توجد بيانات.</div>${proFooter()}</section>`}</div>`}
function currentProfessionalReportHtml(){if(state.reportType==='leaders')return leadersReportHtml();if(state.reportType==='points')return pointsReportHtml();if(state.reportType==='students')return studentsReportHtml();if(state.reportType==='attendance')return attendanceReportHtml();if(state.reportType==='recitations')return recitationsReportHtml();return halaqaReportHtml()}
function reportsPage(){if(state.reportHalaqa==='all'&&state.halaqas.length===1)state.reportHalaqa=state.halaqas[0].id;let ready=state.reportLoadedKey===reportKey();return `<div class="report-studio"><div class="hero"><h2>استوديو التقارير</h2><p>تقارير يومية أو لفترة أو لشهر، مع لائحة الأوائل ونقاط الطلاب وتقارير الأفراد والحضور وسجل التسميعات.</p></div>${reportFilterHtml()}<div class="report-control-card"><b>نوع التقرير</b>${reportTypeGrid()}</div><div class="report-export-bar"><button class="primary" onclick="openReportPreview()">👁️ معاينة PDF</button><button onclick="exportReportsExcel()">📊 Excel</button><button onclick="exportCurrentReportWord()">📝 Word</button><button onclick="exportCurrentReportImage()">🖼️ PNG</button><button onclick="shareReportText()">↗ مشاركة</button></div>${reportReadySummaryHtml()}<div id="reportExportArea">${ready?currentProfessionalReportHtml():''}</div></div>`}
function reportExportRows(){return reportStatsRows().map((x,i)=>({'#':i+1,'الطالب':x.student.full_name,'الحلقة':state.halaqas.find(h=>h.id===x.student.halaqa_id)?.name||'','الفئة':categoryName(x.student),'المسار':studentTrackAr[x.student.track_code]||'','الفترة':reportPeriodLabel(),'الحفظ':x.hifzPages,'التثبيت':x.tathbitPages,'المراجعة':x.reviewPages,'السرد':x.sardPages,'إجمالي الصفحات':x.totalPages,'النقاط':x.points,'الحضور':x.present,'الغياب':x.absent,'بعذر':x.excused,'التأخر':x.late,'الأخطاء':x.mistakes,'النقرات':x.prompts}))}
async function blobToBase64(blob){return await new Promise((res,rej)=>{let r=new FileReader();r.onload=()=>res(String(r.result).split(',')[1]||'');r.onerror=rej;r.readAsDataURL(blob)})}
async function saveOrShareBase64(b64,name,mime){if(isNativeHalaqati()&&window.Capacitor?.Plugins?.Filesystem&&window.Capacitor?.Plugins?.Share){try{let fs=window.Capacitor.Plugins.Filesystem,share=window.Capacitor.Plugins.Share,path='reports/'+name;await fs.writeFile({path,data:b64,directory:'CACHE',recursive:true});let u=await fs.getUri({path,directory:'CACHE'});await share.share({title:name,text:'تقرير من تطبيق حلقتي',url:u.uri,dialogTitle:'حفظ أو مشاركة التقرير'});return}catch(e){console.warn('native share fallback',e)}}let bin=atob(b64),arr=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);downloadBlob(new Blob([arr],{type:mime}),name)}
async function exportReportsExcel(){if(state.reportLoadedKey!==reportKey())return toast('جهّز التقرير أولاً');if(!window.XLSX)return toast('مكتبة Excel لم تُحمّل');let rows=reportExportRows();if(!rows.length)return toast('لا توجد بيانات');let wb=XLSX.utils.book_new(),ws=XLSX.utils.json_to_sheet(rows);XLSX.utils.book_append_sheet(wb,ws,'تقرير حلقتي');let name=`تقرير_حلقتي_${reportFileStamp()}.xlsx`;if(isNativeHalaqati()){let b64=XLSX.write(wb,{bookType:'xlsx',type:'base64'});await saveOrShareBase64(b64,name,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}else XLSX.writeFile(wb,name)}
function professionalWordHtml(){return `<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>body{font-family:Arial,Tahoma,sans-serif;color:#18231f;padding:20px}table{border-collapse:collapse;width:100%;font-size:10px}th{background:#0d3b2f;color:#fff;padding:7px}td{border:1px solid #dfe6e2;padding:6px;text-align:center}.pro-report-page{page-break-after:always;padding:20px}.pro-report-page:last-child{page-break-after:auto}.pro-head{text-align:center;border-bottom:2px solid #c89d4a;padding-bottom:10px}.pro-kpis{display:table;width:100%;margin:10px 0}.pro-kpi{display:table-cell;border:1px solid #ddd;padding:7px;text-align:center}.pro-kpi b{display:block;color:#0d3b2f}</style></head><body>${currentProfessionalReportHtml()}</body></html>`}
async function exportCurrentReportWord(){if(state.reportLoadedKey!==reportKey())return toast('جهّز التقرير أولاً');let blob=new Blob(['\ufeff',professionalWordHtml()],{type:'application/msword'}),name=`تقرير_حلقتي_${reportFileStamp()}.doc`;if(isNativeHalaqati())await saveOrShareBase64(await blobToBase64(blob),name,'application/msword');else downloadBlob(blob,name)}
async function reportCanvas(){if(state.reportLoadedKey!==reportKey())throw new Error('جهّز التقرير أولاً');let el=$('#reportExportArea');if(!el||!el.innerHTML.trim())throw new Error('لا توجد معاينة تقرير');return await html2canvas(el,{scale:1.65,useCORS:true,backgroundColor:'#ffffff',logging:false,windowWidth:Math.max(1100,el.scrollWidth)})}
async function exportCurrentReportImage(){try{let c=await reportCanvas(),blob=await new Promise(r=>c.toBlob(r,'image/png',.96)),name=`تقرير_حلقتي_${reportFileStamp()}.png`;if(isNativeHalaqati())await saveOrShareBase64(await blobToBase64(blob),name,'image/png');else downloadBlob(blob,name)}catch(e){toast('تعذر إنشاء الصورة: '+(e?.message||e))}}
async function exportCurrentReportPdf(){try{if(!window.jspdf?.jsPDF){window.print();return}let c=await reportCanvas(),img=c.toDataURL('image/jpeg',.94),{jsPDF}=window.jspdf,pdf=new jsPDF({orientation:'landscape',unit:'mm',format:'a4'}),pw=297,ph=210,margin=7,w=pw-margin*2,h=c.height*w/c.width,y=margin;pdf.addImage(img,'JPEG',margin,y,w,h);while(y+h>ph-margin){y-=ph-margin*2;pdf.addPage();pdf.addImage(img,'JPEG',margin,y,w,h)}let name=`تقرير_حلقتي_${reportFileStamp()}.pdf`;if(isNativeHalaqati()){let blob=pdf.output('blob');await saveOrShareBase64(await blobToBase64(blob),name,'application/pdf')}else pdf.save(name)}catch(e){toast('تعذر إنشاء PDF: '+(e?.message||e))}}
async function shareReportText(){let rows=reportStatsRows();if(!rows.length)return toast('جهّز التقرير أولاً');let text=`حلقتي — ${reportTypeTitle(state.reportType)}\n${reportPeriodLabel()}\n`+rows.slice(0,20).map((x,i)=>`${i+1}. ${x.student.full_name}: ${fmt(x.totalPages)} ص · ${fmt(x.points)} نقطة`).join('\n');try{if(navigator.share)await navigator.share({title:'تقرير حلقتي',text});else{await navigator.clipboard.writeText(text);toast('تم نسخ ملخص التقرير')}}catch(e){}}

/* ----- restored in-app update system from 2.8.x ----- */
function nativePlugin(name){return window.Capacitor?.Plugins?.[name]||null}
function updatePrefs(){try{return JSON.parse(localStorage.getItem('halaqati_update_prefs')||'{}')}catch(e){return {}}}
function saveUpdatePrefs(p){try{localStorage.setItem('halaqati_update_prefs',JSON.stringify(p||{}))}catch(e){}}
function autoUpdateCheckEnabled(){let p=updatePrefs();return p.autoCheck!==false}
function setAutoUpdateCheck(v){let p=updatePrefs();p.autoCheck=!!v;saveUpdatePrefs(p);toast(v?'تم تفعيل الفحص التلقائي للتحديثات':'تم إيقاف الفحص التلقائي')}
function normalizeUpdateNotes(notes){if(Array.isArray(notes))return notes.map(String);if(typeof notes==='string')return notes.split(/\n+/).map(x=>x.trim()).filter(Boolean);return []}
function updateInfoHtml(){let u=halaqatiUpdateState;if(u.checking)return `<div class="update-card"><div class="update-card-head"><div class="update-icon">↻</div><div><b>جاري فحص التحديثات…</b><div class="update-note">الإصدار الحالي ${esc(u.currentVersionName)}</div></div></div></div>`;if(u.error)return `<div class="update-card"><div class="update-card-head"><div class="update-icon">!</div><div><b>تعذر فحص التحديث</b><div class="update-note">${esc(u.error)}</div></div></div><button class="mini" style="margin-top:10px" onclick="checkForAppUpdate()">إعادة المحاولة</button></div>`;let info=u.info,available=info&&Number(info.versionCode||0)>Number(u.currentVersionCode||APP_VERSION_CODE);if(!info)return `<div class="update-card"><div class="update-card-head"><div class="update-icon">⬇</div><div><b>تحديث التطبيق</b><div class="update-note">الإصدار الحالي ${esc(u.currentVersionName||APP_VERSION_NAME)}</div></div></div><button class="mini" style="margin-top:10px" onclick="checkForAppUpdate()">فحص الآن</button></div>`;if(!available)return `<div class="update-card"><div class="update-card-head"><div class="update-icon">✓</div><div><b>أنت على أحدث إصدار</b><div class="update-note">${esc(u.currentVersionName)} · آخر فحص الآن</div></div></div><button class="mini" style="margin-top:10px" onclick="checkForAppUpdate()">فحص مرة أخرى</button></div>`;let notes=normalizeUpdateNotes(info.notes);return `<div class="update-card"><div class="update-card-head"><div class="update-icon">⬆</div><div class="grow"><b>يتوفر تحديث ${esc(info.versionName||'جديد')}</b><div class="update-note">الإصدار الحالي ${esc(u.currentVersionName)} → ${esc(info.versionName||'')}</div></div></div>${notes.length?`<ul style="margin:10px 18px 0 0;font-size:11px">${notes.map(n=>`<li>${esc(n)}</li>`).join('')}</ul>`:''}${u.message?`<div class="update-note">${esc(u.message)}</div><div class="update-progress"><i style="width:${Math.max(0,Math.min(100,u.progress||0))}%"></i></div>`:''}<div class="actions" style="margin-top:10px"><button class="btn btn-primary" onclick="downloadAndInstallUpdate()">تنزيل وتثبيت التحديث</button><button class="btn btn-ghost" onclick="checkForAppUpdate()">إعادة الفحص</button></div></div>`}
function refreshUpdateCard(){let e=$('#updateCardStatus');if(e)e.innerHTML=updateInfoHtml()}
async function checkForAppUpdate(silent=false){if(halaqatiUpdateState.checking)return;halaqatiUpdateState.checking=true;halaqatiUpdateState.error='';refreshUpdateCard();try{let p=nativePlugin('HalaqatiUpdater');if(isNativeHalaqati()&&p?.getVersion){let cur=await p.getVersion();halaqatiUpdateState.currentVersionName=cur.versionName||APP_VERSION_NAME;halaqatiUpdateState.currentVersionCode=Number(cur.versionCode||APP_VERSION_CODE)}let r=await fetch(UPDATE_MANIFEST_URL+'?t='+Date.now(),{cache:'no-store'});if(!r.ok)throw new Error('تعذر الوصول إلى ملف التحديث');let info=await r.json();if(!info?.versionCode||!info?.apkUrl)throw new Error('ملف التحديث غير مكتمل');halaqatiUpdateState.info=info;let available=Number(info.versionCode)>Number(halaqatiUpdateState.currentVersionCode);if(!silent)toast(available?`يتوفر تحديث ${info.versionName||''}`:'أنت على أحدث إصدار')}catch(e){halaqatiUpdateState.error=e?.message||String(e);if(!silent)toast('تعذر فحص التحديثات')}finally{halaqatiUpdateState.checking=false;refreshUpdateCard()}}
async function requestUpdateInstallPermission(){let p=nativePlugin('HalaqatiUpdater');if(!p?.openInstallPermissionSettings)return toast('إعداد التثبيت غير متاح');try{await p.openInstallPermissionSettings();toast('فعّل «السماح من هذا المصدر»، ثم ارجع واضغط تنزيل وتثبيت')}catch(e){toast('تعذر فتح إعداد السماح بالتثبيت')}}
async function downloadAndInstallUpdate(){let info=halaqatiUpdateState.info;if(!info||Number(info.versionCode||0)<=Number(halaqatiUpdateState.currentVersionCode||APP_VERSION_CODE))return toast('لا يوجد تحديث أحدث');if(!isNativeHalaqati())return window.open(info.apkUrl,'_blank');let p=nativePlugin('HalaqatiUpdater');if(!p?.downloadAndInstall)return toast('إضافة التحديث غير متاحة في هذه النسخة');try{let cur=await p.getVersion();if(cur.canInstallPackages===false){if(confirm('Android يحتاج السماح لتطبيق حلقتي بتثبيت التحديثات. فتح الإعداد الآن؟'))await requestUpdateInstallPermission();return}halaqatiUpdateState.progress=0;halaqatiUpdateState.message='بدء تنزيل التحديث…';refreshUpdateCard();if(p.addListener){try{await p.removeAllListeners?.()}catch(e){}p.addListener('downloadProgress',ev=>{halaqatiUpdateState.progress=Number(ev?.percent||0);halaqatiUpdateState.message=`جاري التنزيل ${Math.round(halaqatiUpdateState.progress)}%`;refreshUpdateCard()})}let res=await p.downloadAndInstall({url:info.apkUrl,expectedPackage:'com.mohammedsamir.halaqati',expectedVersionCode:Number(info.versionCode||0)});if(res?.permissionRequired){await requestUpdateInstallPermission();return}halaqatiUpdateState.progress=100;halaqatiUpdateState.message='اكتمل التنزيل — أكمل التثبيت من نافذة Android';refreshUpdateCard();toast('اكتمل تنزيل التحديث. أكمل التثبيت من شاشة Android.')}catch(e){halaqatiUpdateState.message='';toast('تعذر تثبيت التحديث: '+(e?.message||e));refreshUpdateCard()}}
async function maybeAutoCheckForUpdate(){if(!isNativeHalaqati()||!autoUpdateCheckEnabled()||!navigator.onLine)return;let p=updatePrefs(),now=Date.now(),last=Number(p.lastCheck||0);if(now-last<6*60*60*1000)return;p.lastCheck=now;saveUpdatePrefs(p);await checkForAppUpdate(true)}
function settingsPage(){let local=getThemePrefs(),global=state.settings||{};return `<div class="hero"><h2>الإعدادات</h2><p>المظهر ونظام التقييم والتحديثات والحساب.</p></div><div class="card"><h3>المظهر</h3><div class="settings-row"><div><b>الوضع الداكن</b><div class="muted">يُحفظ على هذا الجهاز</div></div><input id="setDark" type="checkbox" ${local.dark?'checked':''} onchange="previewSettings()"></div><div class="settings-row"><div><b>اللون الأساسي</b></div><input id="setPrimary" type="color" value="${local.primary||global.primary_color||'#0d3b2f'}" onchange="previewSettings()"></div><div class="settings-row"><div><b>اللون المساند</b></div><input id="setAccent" type="color" value="${local.accent||global.accent_color||'#2f8b69'}" onchange="previewSettings()"></div><div class="actions"><button class="theme-preset" style="background:#0d3b2f" onclick="setPreset('#0d3b2f','#2f8b69')"></button><button class="theme-preset" style="background:#12345b" onclick="setPreset('#12345b','#2d6cdf')"></button><button class="theme-preset" style="background:#5a3825" onclick="setPreset('#5a3825','#ad744f')"></button><button class="theme-preset" style="background:#342b5f" onclick="setPreset('#342b5f','#765bc4')"></button></div><div class="form-actions"><button class="btn btn-primary" onclick="saveThemeSettings()">حفظ المظهر</button><button class="btn btn-ghost" onclick="resetTheme()">إعادة الافتراضي</button></div></div><div class="card"><h3>تحديث التطبيق</h3><div class="settings-row"><div><b>الفحص التلقائي</b><div class="muted">يفحص مرة كل عدة ساعات عند وجود الإنترنت</div></div><input type="checkbox" ${autoUpdateCheckEnabled()?'checked':''} onchange="setAutoUpdateCheck(this.checked)"></div><div id="updateCardStatus">${updateInfoHtml()}</div></div><div class="card"><h3>معيار التقييم الحالي</h3><div class="muted">القاعدة في قاعدة البيانات أيضاً.</div><div class="score-explain"><div class="ex">ممتاز<br>≤ ${fmt(global.excellent_max_penalty_per_page??.5)} خصم/صفحة</div><div class="vg">جيد جداً<br>≤ ${fmt(global.very_good_max_penalty_per_page??1)}</div><div class="gd">جيد<br>≤ ${fmt(global.good_max_penalty_per_page??2)}</div><div class="rp">يحتاج إعادة<br>أعلى من ذلك</div></div><div class="notice">كل خطأ = 1 وحدة خصم، وكل نقرة = 0.5. النقاط = الصفحات − ربع وحدات الخصم.</div></div><div class="card"><h3>كلمة المرور</h3><div class="muted">يمكن للحسابات التي تستخدم كلمة مرور تغييرها من هنا.</div><div class="form-grid" style="margin-top:10px"><label class="field"><span>كلمة المرور الجديدة</span><input id="settingsPassword" class="input" type="password" minlength="6"></label><label class="field"><span>تأكيد كلمة المرور</span><input id="settingsPassword2" class="input" type="password" minlength="6"></label></div><button class="btn btn-primary" onclick="changeMyPassword()">تغيير كلمة المرور</button></div><div class="card"><b>Designed by Dr. Mohammed Samir</b><div class="muted">Halaqati Official ${APP_VERSION_NAME}</div></div>`}
function showApp(){$('#auth').classList.add('hidden');$('#app').classList.remove('hidden');$('#roleLabel').textContent=roleAr[state.profile.role]||state.profile.role;$('#userName').textContent=state.profile.full_name;$('#drawerUser').textContent=`${state.profile.full_name} · ${roleAr[state.profile.role]}`;$('#userAvatar').textContent=(state.profile.full_name||'ح')[0];updateSyncBadge();render();setTimeout(maybeAutoCheckForUpdate,1200)}
/* ==================== end v2.10 patch ==================== */

applySavedTheme();
const recoveryInUrl=location.hash.includes('type=recovery')||location.search.includes('type=recovery');
db.auth.onAuthStateChange((event,session)=>{if(event==='PASSWORD_RECOVERY')setTimeout(()=>showPasswordRecovery(),0)});
(async()=>{if(recoveryInUrl){showPasswordRecovery();return}let session=null;try{let r=await withTimeout(db.auth.getSession(),500,'session timeout');session=r?.data?.session||null}catch(e){}if(session?.user)await boot(session.user);else{let last=readOfflineAuth();if(last){state.user=last;if(restoreSnapshot()){state.fastStarted=true;showApp();setTimeout(()=>refreshFromServer({renderAfter:true}),80)}}}})();
setTimeout(()=>ensureQuranLayout(true),900);
setInterval(async()=>{if(state.user&&readOfflineQueue().length&&navigator.onLine&&!state.syncing){if(await internetReachable(true))await syncOfflineQueue()}},20000);
// Service Worker registration moved to src/core/pwa.js in v2.12.

/* ---- migrated from v2.11 legacy runtime ---- */

/* Halaqati Web/Reports Hotfix — 2026-08-29 */
(function(){
  'use strict';
  const HOTFIX_VERSION='2026.08.29.2';

  function say(msg){
    try{ if(typeof toast==='function') return toast(msg); }catch(_e){}
    console.log('[Halaqati]',msg);
  }
  if(typeof state==='undefined'||typeof db==='undefined'){
    console.error('Halaqati hotfix: app globals are unavailable');
    return;
  }

  async function fetchPaged(makeQuery,pageSize=900){
    const out=[];
    for(let from=0;;from+=pageSize){
      const r=await makeQuery().range(from,from+pageSize-1);
      if(r.error) throw r.error;
      const rows=r.data||[];
      out.push(...rows);
      if(rows.length<pageSize) break;
      if(from>50000) throw new Error('حجم البيانات أكبر من الحد الآمن للتقرير');
    }
    return out;
  }

  async function bySessionIds(table,ids){
    const out=[];
    for(let i=0;i<ids.length;i+=70){
      const chunk=ids.slice(i,i+70);
      out.push(...await fetchPaged(()=>db.from(table).select('*').in('session_id',chunk)));
    }
    return out;
  }

  async function byStudentIds(table,ids,filterFn){
    const out=[];
    for(let i=0;i<ids.length;i+=70){
      const chunk=ids.slice(i,i+70);
      out.push(...await fetchPaged(()=>{
        let q=db.from(table).select('*').in('student_id',chunk);
        return filterFn?filterFn(q):q;
      }));
    }
    return out;
  }

  const originalOfflineReportFromCache=window.offlineReportFromCache;

  /* Always use the fresh student set captured for this report. */
  window.reportStudents=function(){
    let rows=Array.isArray(state.reportData?.students)
      ? state.reportData.students
      : (typeof activeStudents==='function'?activeStudents():(state.students||[]));
    rows=(rows||[]).filter(s=>s&&s.status!=='withdrawn');
    if(state.reportHalaqa&&state.reportHalaqa!=='all') rows=rows.filter(s=>s.halaqa_id===state.reportHalaqa);
    return rows.slice().sort((a,b)=>String(a.full_name||'').localeCompare(String(b.full_name||''),'ar'));
  };

  window.reportQueryIn=bySessionIds;

  /* Dedicated report loader: reads fresh students + sessions + all report-related records. */
  window.loadSelectedReport=async function(){
    if(state.reportLoading) return;
    const b=reportBounds();
    if(!b.from||!b.to||b.from>b.to) return say('تأكد من تاريخ البداية والنهاية');

    if(!(await internetReachable())){
      const cached=typeof originalOfflineReportFromCache==='function'
        ? originalOfflineReportFromCache()
        : {sessions:[],attendance:[],notes:[],recitations:[]};
      cached.students=(typeof activeStudents==='function'?activeStudents():(state.students||[]))
        .filter(s=>state.reportHalaqa==='all'||s.halaqa_id===state.reportHalaqa);
      cached.points=[];cached.goals=[];cached.monthlyComments=[];cached.monthlyStats=[];cached.dailySummary=[];
      state.reportData=cached;
      state.reportLoadedKey=reportKey();
      render();
      return say('تم تجهيز التقرير من البيانات المخزنة على الجهاز');
    }

    state.reportLoading=true;
    render();
    try{
      const students=await fetchPaged(()=>{
        let q=db.from('students').select('*').neq('status','withdrawn').order('full_name');
        if(state.reportHalaqa!=='all') q=q.eq('halaqa_id',state.reportHalaqa);
        return q;
      });

      const sessions=await fetchPaged(()=>{
        let q=db.from('sessions').select('*')
          .neq('status','cancelled')
          .gte('session_date',b.from).lte('session_date',b.to)
          .order('session_date',{ascending:true});
        if(state.reportHalaqa!=='all') q=q.eq('halaqa_id',state.reportHalaqa);
        if(state.reportSessionType!=='all') q=q.eq('session_type',state.reportSessionType);
        return q;
      });

      const sessionIds=sessions.map(x=>x.id);
      const studentIds=students.map(x=>x.id);
      let attendance=[],recitations=[],notes=[],points=[],goals=[],monthlyComments=[],monthlyStats=[],dailySummary=[];

      if(sessionIds.length){
        [attendance,recitations,notes]=await Promise.all([
          bySessionIds('attendance_records',sessionIds),
          bySessionIds('recitation_entries',sessionIds),
          bySessionIds('student_daily_notes',sessionIds)
        ]);
      }

      if(studentIds.length){
        const firstMonth=b.from.slice(0,7)+'-01';
        const lastMonth=b.to.slice(0,7)+'-01';
        [points,goals,monthlyComments,monthlyStats,dailySummary]=await Promise.all([
          byStudentIds('student_points',studentIds,q=>q.gte('awarded_at',b.from).lte('awarded_at',b.to)),
          byStudentIds('student_goals',studentIds,q=>q.lte('period_start',b.to).gte('period_end',b.from)),
          byStudentIds('monthly_comments',studentIds,q=>q.gte('month_start',firstMonth).lte('month_start',lastMonth)),
          byStudentIds('monthly_student_stats',studentIds,q=>q.gte('month_start',firstMonth).lte('month_start',lastMonth)),
          byStudentIds('daily_student_summary',studentIds,q=>q.gte('session_date',b.from).lte('session_date',b.to))
        ]);
      }

      state.reportData={students,sessions,attendance,recitations,notes,points,goals,monthlyComments,monthlyStats,dailySummary};
      state.reportLoadedKey=reportKey();
      try{cacheSnapshot();}catch(_e){}
      say(`تم تجهيز التقرير: ${students.length} طالب · ${sessions.length} لقاء`);
    }catch(e){
      console.error('Halaqati report load error',e);
      say('تعذر تجهيز التقرير: '+(e?.message||e));
    }finally{
      state.reportLoading=false;
      render();
    }
  };

  /* Keep ALL active students. Zero-activity students remain in the report with zeros. */
  window.reportStatsRows=function(){
    const students=reportStudents();
    const sidSet=new Set(students.map(x=>x.id));
    const sessions=reportSessions();
    const seSet=new Set(sessions.map(x=>x.id));
    const at=reportAttendance().filter(x=>sidSet.has(x.student_id)&&seSet.has(x.session_id));
    const recs=reportRecitations().filter(x=>sidSet.has(x.student_id)&&seSet.has(x.session_id));
    const notes=reportNotes().filter(x=>sidSet.has(x.student_id)&&seSet.has(x.session_id));
    const extraPoints=(state.reportData?.points||[]).filter(x=>sidSet.has(x.student_id));
    const goals=(state.reportData?.goals||[]).filter(x=>sidSet.has(x.student_id));
    const comments=(state.reportData?.monthlyComments||[]).filter(x=>sidSet.has(x.student_id));

    return students.map(st=>{
      const a=at.filter(x=>x.student_id===st.id);
      const rr=recs.filter(x=>x.student_id===st.id);
      const nn=notes.filter(x=>x.student_id===st.id);
      const pp=extraPoints.filter(x=>x.student_id===st.id);
      const gg=goals.filter(x=>x.student_id===st.id);
      const cc=comments.filter(x=>x.student_id===st.id);
      const out={student:st,hifzPages:0,tathbitPages:0,reviewPages:0,sardPages:0,tilawahPages:0,mistakes:0,prompts:0,points:0,recitationPoints:0,bonusPoints:0,present:0,absent:0,excused:0,late:0,notes:nn,goals:gg,monthlyComments:cc};

      for(const x of a){
        if(x.status==='present') out.present++;
        else if(x.status==='absent') out.absent++;
        else if(x.status==='excused') out.excused++;
        else if(x.status==='late') out.late++;
      }
      for(const r of rr){
        const g=recGroup(r,st),p=Number(r.pages_count||0);
        if(g==='hifz') out.hifzPages+=p;
        else if(g==='tathbit') out.tathbitPages+=p;
        else if(g==='review') out.reviewPages+=p;
        else if(g==='sard') out.sardPages+=p;
        else out.tilawahPages+=p;
        out.mistakes+=Number(r.mistakes||0);
        out.prompts+=Number(r.prompts||0);
        out.recitationPoints+=Number(recPoints(r)||0);
      }
      out.bonusPoints=pp.reduce((sum,x)=>sum+Number(x.points||0),0);
      out.points=out.recitationPoints+out.bonusPoints;
      out.totalPages=out.hifzPages+out.tathbitPages+out.reviewPages+out.sardPages+out.tilawahPages;
      out.sessions=a.length;
      return out;
    }).sort((a,b)=>b.points-a.points||b.totalPages-a.totalPages||String(a.student.full_name||'').localeCompare(String(b.student.full_name||''),'ar'));
  };

  /* -------- Built-in PDF preview/editor -------- */
  const previewCss=`
  #reportPreviewDlg{width:min(1500px,98vw);max-width:none;height:96vh;max-height:96vh;border-radius:18px;overflow:hidden;padding:0}
  #reportPreviewDlg::backdrop{background:#061b16cc}
  .hf-preview-shell{height:96vh;display:grid;grid-template-rows:auto 1fr;background:#eef2f0;direction:rtl}
  .hf-preview-toolbar{background:#fff;border-bottom:1px solid #dfe6e2;padding:10px 12px;display:flex;gap:9px;align-items:end;flex-wrap:wrap;z-index:2}
  .hf-preview-toolbar label{display:grid;gap:4px;font-size:10px;color:#68736e;min-width:105px}
  .hf-preview-toolbar select{border:1px solid #dfe6e2;border-radius:9px;padding:7px;background:#fff;min-height:37px}
  .hf-preview-toolbar input[type=range]{width:135px}
  .hf-preview-toolbar input[type=color]{width:50px;height:37px;border:1px solid #dfe6e2;border-radius:9px;background:#fff;padding:3px}
  .hf-preview-spacer{flex:1}
  .hf-preview-btn{border:0;border-radius:11px;padding:9px 13px;font-weight:800;background:#e9f3ee;color:#0d3b2f;min-height:39px}
  .hf-preview-btn.primary{background:#0d3b2f;color:#fff}
  .hf-preview-btn.closex{background:#fff0f0;color:#a43a3a}
  .hf-preview-viewport{overflow:auto;padding:18px;direction:ltr}
  #reportPreviewPaper{margin:auto;direction:rtl;background:#fff;box-shadow:0 14px 50px #0d3b2f26;transform-origin:top center;transition:width .15s ease;outline:none;color:#18231f}
  #reportPreviewPaper[data-orientation=landscape]{width:1120px;min-height:792px}
  #reportPreviewPaper[data-orientation=portrait]{width:792px;min-height:1120px}
  #reportPreviewPaper .pro-report-page{box-shadow:none!important;margin:0 0 18px!important;border-radius:0!important;border:0!important;min-height:auto;background:#fff;box-sizing:border-box;overflow:visible!important}
  #reportPreviewPaper[data-orientation=landscape] .pro-report-page{width:1120px}
  #reportPreviewPaper[data-orientation=portrait] .pro-report-page{width:792px}
  #reportPreviewPaper .pro-table-wrap{overflow:visible!important}
  #reportPreviewPaper .pro-table{width:100%!important;min-width:0!important;table-layout:fixed!important}
  #reportPreviewPaper .pro-table th,#reportPreviewPaper .pro-table td{white-space:normal!important;word-break:normal!important;overflow-wrap:break-word!important;letter-spacing:normal!important;text-align:center}
  #reportPreviewPaper .pro-table .name{width:20%!important;min-width:0!important;text-align:right!important;word-break:keep-all!important;overflow-wrap:normal!important}
  #reportPreviewPaper[data-orientation=portrait] .pro-table th,#reportPreviewPaper[data-orientation=portrait] .pro-table td{padding-left:3px!important;padding-right:3px!important}
  #reportPreviewPaper[data-orientation=portrait] .pro-kpis{grid-template-columns:repeat(3,1fr)!important}
  #reportPreviewPaper[contenteditable=true]:focus{outline:2px dashed #2f8b69;outline-offset:3px}
  .hf-edit-note{font-size:10px;color:#6f7a75;padding:0 5px 5px;direction:rtl}
  .hf-pdf-continuation-label{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:5px 0 8px;padding:6px 9px;border:1px solid #dfe6e2;border-radius:9px;background:#f8fbf9;color:#53615b;font-size:9px;direction:rtl}
  .hf-pdf-continuation-label b{color:#0d3b2f;font-size:10px}
  .hf-pdf-render-stage{position:fixed!important;left:0!important;top:0!important;margin:0!important;padding:0!important;background:#fff!important;visibility:visible!important;opacity:1!important;pointer-events:none!important;z-index:2147483000!important;transform:none!important;overflow:visible!important;box-shadow:none!important}
  .hf-pdf-render-stage>.pro-report-page{margin:0!important;visibility:visible!important;opacity:1!important;display:block!important;background:#fff!important;transform:none!important}
  .hf-pdf-progress{position:fixed;inset:0;z-index:2147483600;background:rgba(247,247,242,.98);display:grid;place-items:center;direction:rtl;font-family:Cairo,Tahoma,Arial,sans-serif;color:#0d3b2f}
  .hf-pdf-progress>div{background:#fff;border:1px solid #dfe6e2;border-radius:18px;padding:18px 22px;box-shadow:0 16px 50px #0d3b2f22;text-align:center;min-width:220px}
  .hf-pdf-progress b{display:block;font-size:16px;margin-bottom:4px}.hf-pdf-progress span{font-size:11px;color:#6f7a75}
  @media(max-width:700px){.hf-preview-toolbar{max-height:42vh;overflow:auto}.hf-preview-viewport{padding:8px}}
  `;

  function ensurePreviewUi(){
    if(!document.getElementById('halaqatiReportHotfixStyle')){
      const style=document.createElement('style');
      style.id='halaqatiReportHotfixStyle';
      style.textContent=previewCss;
      document.head.appendChild(style);
    }
    if(document.getElementById('reportPreviewDlg')) return;
    const dlg=document.createElement('dialog');
    dlg.id='reportPreviewDlg';
    dlg.innerHTML=`<div class="hf-preview-shell">
      <div class="hf-preview-toolbar">
        <label>اتجاه الصفحة<select id="hfOrientation"><option value="landscape">أفقي A4</option><option value="portrait">رأسي A4</option></select></label>
        <label>نوع الخط<select id="hfFont"><option value="Cairo">Cairo</option><option value="Tahoma">Tahoma</option><option value="Arial">Arial</option><option value="serif">Serif</option></select></label>
        <label>حجم الخط <span id="hfFontSizeVal">11px</span><input id="hfFontSize" type="range" min="8" max="18" step="1" value="11"></label>
        <label>لون النص<input id="hfTextColor" type="color" value="#18231f"></label>
        <label>لون العناوين<input id="hfAccentColor" type="color" value="#0d3b2f"></label>
        <label>التكبير <span id="hfZoomVal">100%</span><input id="hfZoom" type="range" min="60" max="130" step="5" value="100"></label>
        <div class="hf-preview-spacer"></div>
        <button class="hf-preview-btn" type="button" id="hfReset">إعادة الضبط</button>
        <button class="hf-preview-btn primary" type="button" id="hfSavePdf">تنزيل PDF</button>
        <button class="hf-preview-btn closex" type="button" id="hfClosePreview">إغلاق</button>
      </div>
      <div class="hf-preview-viewport"><div><div class="hf-edit-note">يمكنك تعديل النص والخط والحجم واللون والاتجاه قبل تنزيل PDF عالي الجودة.</div><div id="reportPreviewPaper" data-orientation="landscape" contenteditable="true" spellcheck="false"></div></div></div>
    </div>`;
    document.body.appendChild(dlg);

    const paper=dlg.querySelector('#reportPreviewPaper');
    const orientation=dlg.querySelector('#hfOrientation');
    const font=dlg.querySelector('#hfFont');
    const fontSize=dlg.querySelector('#hfFontSize');
    const textColor=dlg.querySelector('#hfTextColor');
    const accent=dlg.querySelector('#hfAccentColor');
    const zoom=dlg.querySelector('#hfZoom');

    function apply(){
      paper.dataset.orientation=orientation.value;
      paper.style.fontFamily=font.value+', sans-serif';
      paper.style.color=textColor.value;
      paper.style.transform=`scale(${Number(zoom.value)/100})`;
      const factor=Number(fontSize.value)/11;
      const targets=paper.querySelectorAll('.pro-head-title h1,.pro-head-title p,.pro-meta,.pro-meta *, .pro-kpi b,.pro-kpi span,.pro-section-title,.pro-table th,.pro-table td,.student-info-grid div,.student-info-grid b,.pro-footer,.pro-footer *, .podium-rank,.podium-name,.podium-score,.student-report-card h2,.report-empty-pro');
      targets.forEach(el=>{
        if(!el.dataset.hfBaseFont) el.dataset.hfBaseFont=String(parseFloat(getComputedStyle(el).fontSize)||11);
        el.style.fontSize=(Number(el.dataset.hfBaseFont)*factor).toFixed(2)+'px';
      });
      dlg.querySelector('#hfFontSizeVal').textContent=fontSize.value+'px';
      dlg.querySelector('#hfZoomVal').textContent=zoom.value+'%';
      paper.querySelectorAll('.pro-head-title h1,.pro-section-title,.pro-kpi b,.student-report-card h2').forEach(el=>el.style.color=accent.value);
      paper.querySelectorAll('.pro-head-logo,.pro-table th').forEach(el=>el.style.background=accent.value);
    }
    [orientation,font,fontSize,textColor,accent,zoom].forEach(x=>x.addEventListener('input',apply));
    dlg.querySelector('#hfReset').onclick=()=>{
      orientation.value='landscape';font.value='Cairo';fontSize.value='11';textColor.value='#18231f';accent.value='#0d3b2f';zoom.value='100';apply();
    };
    dlg.querySelector('#hfClosePreview').onclick=()=>dlg.close();
    dlg.querySelector('#hfSavePdf').onclick=()=>window.downloadReportPdfFromPreview();
    apply();
  }

  let previewContext='report';
  function studentsDirectoryPdfHtml(){
    const rows=studentDirectoryRows(),pages=[],chunkSize=10;
    for(let i=0;i<rows.length;i+=chunkSize){
      const chunk=rows.slice(i,i+chunkSize);
      pages.push(`<section class="pro-report-page"><div class="pro-head"><div class="pro-head-logo">ح</div><div class="pro-head-title"><h1>حلقتي</h1><p>بيانات الطلاب الأساسية · ${i+1}-${Math.min(i+chunkSize,rows.length)} من ${rows.length}</p></div><div class="pro-head-logo">۞</div></div><div class="pro-meta"><span><b>تاريخ الإصدار:</b> ${today()}</span><span><b>عدد الطلاب:</b> ${rows.length}</span><span><b>النطاق:</b> الطلاب النشطون المتاحون للحساب</span></div><div class="pro-table-wrap"><table class="pro-table"><thead><tr><th>#</th><th>الطالب</th><th>الحلقة</th><th>الفئة</th><th>المسار</th><th>الجنس</th><th>الهوية</th><th>الجوال</th><th>الميلاد</th><th>المرحلة</th></tr></thead><tbody>${chunk.map(r=>`<tr><td>${r['#']}</td><td class="name">${esc(r['اسم الطالب'])}</td><td>${esc(r['الحلقة'])}</td><td>${esc(r['الفئة'])}</td><td>${esc(r['المسار'])}</td><td>${esc(r['الجنس'])}</td><td>${esc(r['رقم الهوية'])}</td><td>${esc(r['الجوال'])}</td><td>${esc(r['تاريخ الميلاد'])}</td><td>${esc(r['المرحلة الدراسية'])}</td></tr>`).join('')}</tbody></table></div><div class="pro-section-title">بيانات إضافية</div><div class="pro-table-wrap"><table class="pro-table"><thead><tr><th>الطالب</th><th>بريد ولي الأمر</th><th>جوال ولي الأمر</th><th>العنوان</th><th>تاريخ الالتحاق</th></tr></thead><tbody>${chunk.map(r=>`<tr><td class="name">${esc(r['اسم الطالب'])}</td><td>${esc(r['بريد ولي الأمر'])}</td><td>${esc(r['جوال ولي الأمر'])}</td><td>${esc(r['العنوان'])}</td><td>${esc(r['تاريخ الالتحاق'])}</td></tr>`).join('')}</tbody></table></div><div class="pro-footer"><span>حلقتي · بيانات إدارية أساسية</span><span>لا يتضمن بيانات الحفظ أو الإنجاز</span></div></section>`);
    }
    return `<div class="pro-report">${pages.join('')}</div>`;
  }
  window.openStudentsPdfPreview=function(){
    const rows=studentDirectoryRows();
    if(!rows.length) return say('لا يوجد طلاب للتصدير');
    ensurePreviewUi();previewContext='students';
    const paper=document.getElementById('reportPreviewPaper');
    paper.innerHTML=studentsDirectoryPdfHtml();paper.contentEditable='true';
    const orientation=document.getElementById('hfOrientation');orientation.value='landscape';orientation.dispatchEvent(new Event('input'));
    document.getElementById('reportPreviewDlg').showModal();
  };

  window.openReportPreview=function(){
    previewContext='report';
    if(state.reportLoadedKey!==reportKey()) return say('جهّز التقرير أولاً');
    ensurePreviewUi();
    const paper=document.getElementById('reportPreviewPaper');
    let html='';
    try{html=currentProfessionalReportHtml();}catch(e){return say('تعذر إنشاء المعاينة: '+(e?.message||e));}
    if(!html||!html.trim()) return say('لا توجد بيانات للمعاينة');
    paper.innerHTML=html;
    paper.contentEditable='true';
    document.getElementById('hfOrientation').dispatchEvent(new Event('input'));
    document.getElementById('reportPreviewDlg').showModal();
  };

  function normalizePdfClone(clone,sourcePage){
    clone.style.margin='0';
    clone.style.width=sourcePage.scrollWidth+'px';
    clone.style.maxWidth='none';
    clone.style.height='auto';
    clone.style.minHeight='0';
    clone.style.overflow='visible';
    clone.style.visibility='visible';
    clone.style.opacity='1';
    clone.style.display='block';
    clone.style.transform='none';
    return clone;
  }

  function buildRowSafePdfPages(sourcePage,maxPageHeight){
    const tables=[...sourcePage.querySelectorAll('.pro-table')];
    const table=tables.length===1?tables[0]:null;
    const tbody=table?.tBodies?.[0];

    // Always render a clone. Never move the live preview page into the render stage.
    if(!table||!tbody||!tbody.rows.length||sourcePage.scrollHeight<=maxPageHeight+2){
      return {pages:[normalizePdfClone(sourcePage.cloneNode(true),sourcePage)],cleanup:()=>{},applied:false};
    }

    const host=sourcePage.parentElement;
    const sandbox=document.createElement('div');
    sandbox.className='hf-pdf-pagination-sandbox';
    // Hidden only for MEASUREMENT. These nodes are moved out of this sandbox
    // into a visible render stage before html2canvas is called.
    sandbox.style.cssText=`position:absolute;left:-100000px;top:0;width:${sourcePage.scrollWidth}px;visibility:hidden;pointer-events:none;z-index:-1;`;
    host.appendChild(sandbox);

    const rows=[...tbody.rows].map(r=>r.cloneNode(true));
    const result=[];
    let cursor=0,first=true;

    function makeShell(isFirst){
      const clone=normalizePdfClone(sourcePage.cloneNode(true),sourcePage);
      const cloneTables=[...clone.querySelectorAll('.pro-table')];
      const cloneTable=cloneTables[0];
      const body=cloneTable.tBodies[0];
      body.innerHTML='';

      if(!isFirst){
        const wrap=cloneTable.closest('.pro-table-wrap');
        const head=clone.querySelector('.pro-head');
        const meta=clone.querySelector('.pro-meta');
        const footer=clone.querySelector('.pro-footer');
        [...clone.children].forEach(ch=>{
          if(ch===head||ch===meta||ch===wrap||ch===footer)return;
          ch.remove();
        });
        const marker=document.createElement('div');
        marker.className='hf-pdf-continuation-label';
        marker.innerHTML='<b>تابع التقرير</b><span class="hf-pdf-page-counter"></span>';
        clone.insertBefore(marker,wrap);
      }

      sandbox.appendChild(clone);
      return {clone,body};
    }

    while(cursor<rows.length){
      const shell=makeShell(first);
      let added=0;
      while(cursor<rows.length){
        const row=rows[cursor].cloneNode(true);
        shell.body.appendChild(row);
        const tooTall=shell.clone.scrollHeight>maxPageHeight;
        if(tooTall&&added>0){
          row.remove();
          break;
        }
        cursor++;
        added++;
        if(tooTall)break;
      }
      result.push(shell.clone);
      first=false;
    }

    result.forEach((page,i)=>{
      const counter=page.querySelector('.hf-pdf-page-counter');
      if(counter)counter.textContent=`صفحة ${i+1} من ${result.length}`;
    });
    return {pages:result,cleanup:()=>sandbox.remove(),applied:true};
  }

  function createPdfProgressOverlay(){
    const old=document.querySelector('.hf-pdf-progress');
    if(old)old.remove();
    const el=document.createElement('div');
    el.className='hf-pdf-progress';
    el.innerHTML='<div><b>جاري إنشاء ملف PDF</b><span>يتم ترتيب الصفوف والتحقق من جودة الصفحات…</span></div>';
    const root=document.getElementById('reportPreviewDlg')||document.body;
    root.appendChild(el);
    return el;
  }

  function createPdfRenderStage(paper,width){
    const old=paper.querySelector('.hf-pdf-render-stage');
    if(old)old.remove();
    const stage=document.createElement('div');
    stage.className='hf-pdf-render-stage';
    stage.style.width=Math.max(1,width)+'px';
    paper.appendChild(stage);
    return stage;
  }

  async function waitForPdfPaint(){
    try{if(document.fonts?.ready)await document.fonts.ready}catch(_e){}
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
  }

  function canvasLooksBlank(canvas){
    if(!canvas||canvas.width<10||canvas.height<10)return true;
    // Probe a tiny downscaled copy instead of allocating a full-size ImageData
    // buffer. This keeps the blank-output safety check cheap on low-memory phones.
    try{
      const probe=document.createElement('canvas');probe.width=96;probe.height=96;
      const pctx=probe.getContext('2d',{alpha:false,willReadFrequently:true});
      pctx.fillStyle='#fff';pctx.fillRect(0,0,96,96);pctx.drawImage(canvas,0,0,96,96);
      const data=pctx.getImageData(0,0,96,96).data;
      let ink=0;
      for(let i=0;i<data.length;i+=4){
        const r=data[i],g=data[i+1],b=data[i+2],a=data[i+3];
        if(a>20&&(r<242||g<242||b<242)){ink++;if(ink>=12)return false}
      }
      return true;
    }catch(_e){return false}
  }

  async function renderPdfElement(element,stage,scale){
    stage.replaceChildren(element);
    element.style.visibility='visible';
    element.style.opacity='1';
    element.style.display='block';
    element.style.transform='none';
    stage.style.width=Math.max(1,element.scrollWidth)+'px';
    await waitForPdfPaint();

    const opts={scale,useCORS:true,backgroundColor:'#ffffff',logging:false,windowWidth:Math.max(800,element.scrollWidth),windowHeight:Math.max(600,element.scrollHeight),scrollX:0,scrollY:0};
    let canvas=null,firstError=null;
    try{canvas=await html2canvas(element,opts)}catch(e){firstError=e}
    if(!canvas||canvasLooksBlank(canvas)){
      if(canvas){canvas.width=1;canvas.height=1}
      await waitForPdfPaint();
      try{canvas=await html2canvas(element,{...opts,scale:Math.min(2,scale)})}
      catch(e){throw new Error('تعذر رسم صفحة التقرير: '+(e?.message||firstError?.message||e))}
    }
    if(canvasLooksBlank(canvas)){
      canvas.width=1;canvas.height=1;
      throw new Error('فشل رسم محتوى التقرير. لم يتم حفظ ملف فارغ. حاول مرة أخرى.');
    }
    return canvas;
  }

  function collectSafeCanvasCuts(element,canvas){
    try{
      const root=element.getBoundingClientRect(),scaleY=canvas.height/Math.max(1,root.height);
      const nodes=[...element.querySelectorAll('.pro-head,.pro-meta,.pro-kpis,.student-report-card,.pro-section-title,.pro-table tr,.pro-footer')];
      const cuts=nodes.map(n=>Math.round((n.getBoundingClientRect().bottom-root.top)*scaleY)).filter(y=>y>0&&y<canvas.height);
      return [...new Set(cuts)].sort((a,b)=>a-b);
    }catch(_e){return []}
  }

  async function addCanvasSlicePages(pdf,canvas,orientation,boxW,boxH,margin,stateObj,safeCuts=[]){
    const sliceHeight=Math.max(1,Math.floor(canvas.width*(boxH/boxW)));
    let top=0;
    while(top<canvas.height){
      let bottom=Math.min(canvas.height,top+sliceHeight);
      if(bottom<canvas.height&&safeCuts.length){
        const minAdvance=top+Math.floor(sliceHeight*.45);
        const candidates=safeCuts.filter(y=>y>minAdvance&&y<=bottom);
        if(candidates.length)bottom=candidates[candidates.length-1];
      }
      if(bottom<=top)bottom=Math.min(canvas.height,top+sliceHeight);
      const h=bottom-top,crop=document.createElement('canvas');
      crop.width=canvas.width;crop.height=h;
      const ctx=crop.getContext('2d',{alpha:false});ctx.fillStyle='#fff';ctx.fillRect(0,0,crop.width,crop.height);ctx.drawImage(canvas,0,top,canvas.width,h,0,0,canvas.width,h);
      if(stateObj.count++)pdf.addPage('a4',orientation);
      const img=crop.toDataURL('image/png'),outH=h*boxW/canvas.width;
      pdf.addImage(img,'PNG',margin,margin,boxW,outH,undefined,'SLOW');
      crop.width=1;crop.height=1;
      top=bottom;
    }
  }

  window.downloadReportPdfFromPreview=async function(){
    const paper=document.getElementById('reportPreviewPaper');
    let oldTransform='',stage=null,progress=null;
    try{
      if(!window.jspdf?.jsPDF) throw new Error('مكتبة PDF غير متاحة');
      if(!window.html2canvas) throw new Error('مكتبة المعاينة غير متاحة');
      if(!paper||!paper.innerHTML.trim()) throw new Error('افتح المعاينة أولاً');
      const orientation=document.getElementById('hfOrientation')?.value||'landscape';
      const {jsPDF}=window.jspdf;
      const pdf=new jsPDF({orientation,unit:'mm',format:'a4',compress:true});
      const pw=orientation==='landscape'?297:210,ph=orientation==='landscape'?210:297,margin=7;
      const boxW=pw-margin*2,boxH=ph-margin*2,printScale=300/96;
      const sourcePages=[...paper.querySelectorAll('.pro-report-page')];
      if(!sourcePages.length)sourcePages.push(paper);
      const pageState={count:0};
      oldTransform=paper.style.transform;paper.style.transform='none';
      progress=createPdfProgressOverlay();
      stage=createPdfRenderStage(paper,sourcePages[0]?.scrollWidth||paper.scrollWidth);

      for(const sourcePage of sourcePages){
        const maxPageHeight=Math.max(1,Math.floor(sourcePage.scrollWidth*(boxH/boxW)));
        const rowSafe=buildRowSafePdfPages(sourcePage,maxPageHeight);
        try{
          for(const renderPage of rowSafe.pages){
            const canvas=await renderPdfElement(renderPage,stage,printScale);
            const outH=canvas.height*boxW/canvas.width;

            if(rowSafe.applied){
              // A row-safe page is never sliced again. If browser rounding makes it
              // a little taller than A4, scale the WHOLE page down so no <tr> is cut.
              const fit=Math.min(1,boxH/outH);
              const w=boxW*fit,h=outH*fit,x=margin+(boxW-w)/2;
              if(pageState.count++)pdf.addPage('a4',orientation);
              pdf.addImage(canvas.toDataURL('image/png'),'PNG',x,margin,w,h,undefined,'SLOW');
            }else if(outH<=boxH+0.5){
              if(pageState.count++)pdf.addPage('a4',orientation);
              pdf.addImage(canvas.toDataURL('image/png'),'PNG',margin,margin,boxW,Math.min(outH,boxH),undefined,'SLOW');
            }else{
              await addCanvasSlicePages(pdf,canvas,orientation,boxW,boxH,margin,pageState,collectSafeCanvasCuts(renderPage,canvas));
            }
            canvas.width=1;canvas.height=1;
            stage.replaceChildren();
          }
        }finally{rowSafe.cleanup()}
      }

      if(pageState.count===0)throw new Error('لم يتم إنشاء أي صفحة PDF.');
      const stem=previewContext==='students'?'بيانات_طلاب_حلقتي':`تقرير_حلقتي_${reportFileStamp()}`;
      const name=`${stem}_${today()}.pdf`.replace(/__+/g,'_');
      if(typeof isNativeHalaqati==='function'&&isNativeHalaqati()){let blob=pdf.output('blob');if(!blob||blob.size<2000)throw new Error('ملف PDF الناتج غير صالح');await saveOrShareBase64(await blobToBase64(blob),name,'application/pdf')}else pdf.save(name);
      say('تم إنشاء PDF عالي الجودة مع الحفاظ على الصفوف كاملة');
    }catch(e){console.error('Halaqati preview PDF error',e);say('تعذر إنشاء PDF: '+(e?.message||e))}
    finally{
      try{stage?.remove()}catch(_e){}
      try{progress?.remove()}catch(_e){}
      if(paper)paper.style.transform=oldTransform;
    }
  };

  /* Clicking PDF now opens the built-in preview, never the system print dialog. */
  window.exportCurrentReportPdf=window.openReportPreview;

  const originalReportsPage=window.reportsPage;
  if(typeof originalReportsPage==='function'){
    window.reportsPage=function(){
      let html=originalReportsPage();
      html=html.replace(/onclick="exportCurrentReportPdf\(\)"/g,'onclick="openReportPreview()"');
      html=html.replace(/🖨️ PDF/g,'👁️ معاينة PDF');
      return html;
    };
  }

  /* Extra browser OAuth recovery after Google redirects/back navigation. */
  async function recoverWebSession(){
    try{
      if(typeof isNativeHalaqati==='function'&&isNativeHalaqati()) return;
      const r=await db.auth.getSession();
      const user=r?.data?.session?.user;
      if(user&&!state.user&&typeof boot==='function') await boot(user);
    }catch(e){ console.warn('Halaqati OAuth session recovery',e); }
  }
  window.addEventListener('pageshow',()=>setTimeout(recoverWebSession,30));
  window.addEventListener('hashchange',()=>setTimeout(recoverWebSession,30));

  ensurePreviewUi();
  console.info('Halaqati report hotfix loaded',HOTFIX_VERSION);
})();
