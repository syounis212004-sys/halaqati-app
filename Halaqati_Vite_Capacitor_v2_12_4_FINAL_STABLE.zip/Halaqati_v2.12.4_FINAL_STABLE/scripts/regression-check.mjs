import fs from 'node:fs';
const f='src/legacy/app.js';
const s=fs.readFileSync(f,'utf8');
const required=[
  'function settingsPage()', 'function getThemePrefs()', 'function applySavedTheme()',
  'function previewSettings()', 'function setPreset(', 'function saveThemeSettings()',
  'function resetTheme()', 'async function changeMyPassword()',
  'function studentDirectoryRows()', 'async function exportStudentsExcel()',
  'async function exportStudentsWord()', 'window.openStudentsPdfPreview=function()',
  'window.openReportPreview=function()', 'function buildRowSafePdfPages(',
  'function createPdfRenderStage(', 'function canvasLooksBlank(', 'async function renderPdfElement(', 'function collectSafeCanvasCuts(',
  'window.downloadReportPdfFromPreview=async function()'
];
for(const token of required){if(!s.includes(token)){console.error('MISSING:',token);process.exit(1)}}

const dataStart=s.indexOf('function dataPage(){');
const settingsStart=s.indexOf('\nfunction settingsPage(){',dataStart);
const dataBlock=s.slice(dataStart,settingsStart);
if(dataBlock.includes('exportReportsExcel()')){console.error('Regression: report Excel is back on data page');process.exit(1)}

if(!dataBlock.includes('exportStudentsExcel()')||!dataBlock.includes('exportStudentsWord()')||!dataBlock.includes('openStudentsPdfPreview()')){console.error('Regression: student-only export actions missing');process.exit(1)}
if(!s.includes("paper.dataset.orientation=orientation.value")){console.error('Regression: PDF orientation control is not wired');process.exit(1)}
if(!s.includes("const factor=Number(fontSize.value)/11")){console.error('Regression: PDF font-size control is not wired');process.exit(1)}

const finalReports=s.lastIndexOf('function reportsPage(){');
const reportBlock=s.slice(finalReports,s.indexOf('\nfunction reportExportRows()',finalReports));
if(!reportBlock.includes('onclick="openReportPreview()"')){console.error('Regression: report PDF does not open built-in preview directly');process.exit(1)}

const paginationStart=s.indexOf('function buildRowSafePdfPages(');
const downloadStart=s.indexOf('window.downloadReportPdfFromPreview=async function()',paginationStart);
const pdfBlock=s.slice(paginationStart,s.indexOf('/* Clicking PDF now opens',downloadStart));
if(!pdfBlock.includes('stage.replaceChildren(element)')){console.error('Regression: PDF page is not moved to visible render stage before capture');process.exit(1)}
if(!pdfBlock.includes("stage.className='hf-pdf-render-stage'")){console.error('Regression: visible PDF render stage missing');process.exit(1)}
if(!pdfBlock.includes("element.style.visibility='visible'")){console.error('Regression: render page visibility is not forced visible');process.exit(1)}
if(!pdfBlock.includes('canvasLooksBlank(canvas)')){console.error('Regression: blank-canvas guard missing');process.exit(1)}
if(!pdfBlock.includes("throw new Error('فشل رسم محتوى التقرير. لم يتم حفظ ملف فارغ. حاول مرة أخرى.')")){console.error('Regression: blank PDF must be rejected, not saved');process.exit(1)}
if(!pdfBlock.includes('collectSafeCanvasCuts(renderPage,canvas)')){console.error('Regression: generic PDF slicing lacks DOM-safe cut boundaries');process.exit(1)}
if(!pdfBlock.includes('if(rowSafe.applied)')){console.error('Regression: row-safe pages are not protected from secondary slicing');process.exit(1)}
if(!pdfBlock.includes('const fit=Math.min(1,boxH/outH)')){console.error('Regression: row-safe page must fit whole page instead of being sliced');process.exit(1)}

// The measurement sandbox may be visibility:hidden, but html2canvas must never capture directly from it.
const directHiddenCapture=/html2canvas\(renderPage/.test(pdfBlock);
if(directHiddenCapture){console.error('Regression: html2canvas is capturing pagination clone directly from hidden sandbox');process.exit(1)}

if(!s.includes("const APP_VERSION_NAME='2.12.4';")||!s.includes('const APP_VERSION_CODE=21204;')){console.error('Version mismatch');process.exit(1)}
console.log('Regression checks passed: settings, previews, student exports, visible PDF render stage, blank guard, row-safe pagination, version.');
