package com.mohammedsamir.halaqati.ui.screens

import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.data.OfflineQueue
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** RC53: data layer shared by the supervisor / administrator staff-monitoring screens. */

/** A text field that is empty when the JSON value is missing or null (optString would return the word "null"). */
internal fun JSONObject.supStr(key: String): String = if (!has(key) || isNull(key)) "" else optString(key).let { if (it == "null") "" else it }

internal fun JSONArray.sRows(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }

/**
 * Supervisor visits stay usable without internet: a visit saved offline sits in the outbox until it uploads.
 * This overlay lays the not-yet-uploaded creations / edits / deletions over the last server copy, and marks pending rows
 * with `_pending = true` so the list can show "بانتظار الرفع".
 */
object VisitOverlay {
    private val idInPath = Regex("(?:^|[?&])id=eq\\.([^&]+)")

    fun apply(server: List<JSONObject>, queue: List<OfflineQueue.SnapshotItem>): List<JSONObject> {
        val rows = LinkedHashMap<String, JSONObject>()
        server.forEach { rows[it.optString("id")] = JSONObject(it.toString()) }
        val pending = HashSet<String>()
        queue.filter { it.path.startsWith("/rest/v1/supervisor_visits") }.sortedBy { it.created }.forEach { q ->
            val pathId = idInPath.find(q.path)?.groupValues?.getOrNull(1)
            when (q.method) {
                "POST" -> {
                    val body = runCatching { JSONObject(q.body ?: "") }.getOrNull()
                    val id = body?.optString("id").orEmpty()
                    if (body != null && id.isNotBlank()) {
                        val merged = rows[id] ?: JSONObject()
                        body.keys().forEach { k -> merged.put(k, body.opt(k)) }
                        rows[id] = merged
                        pending.add(id)
                    }
                }
                "PATCH" -> {
                    val body = runCatching { JSONObject(q.body ?: "") }.getOrNull()
                    val target = if (pathId != null) rows[pathId] else null
                    if (body != null && target != null && pathId != null) {
                        body.keys().forEach { k -> target.put(k, body.opt(k)) }
                        pending.add(pathId)
                    }
                }
                "DELETE" -> if (pathId != null) {
                    rows.remove(pathId)
                    pending.remove(pathId)
                }
            }
        }
        pending.forEach { id -> rows[id]?.put("_pending", true) }
        return rows.values.sortedWith(
            compareByDescending<JSONObject> { it.optString("visit_date") }.thenByDescending { it.optString("created_at") },
        )
    }
}

enum class TeacherDayState { NOT_STARTED, IN_PROGRESS, CLOSED }

data class SupHalaqa(
    val id: String,
    val name: String,
    val teacherIds: List<String>,
    val teacherNames: List<String>,
    /** RC63: saved photo (data URL) of each teacher, same order as [teacherNames]; null when none. */
    val teacherPhotos: List<String?> = emptyList(),
    val students: Int,
    val state: TeacherDayState,
    val present: Int,
    val absent: Int,
    val excused: Int,
    val recited: Int,
    val monthSessions: Int,
    val lastVisitDate: String?,
    val lastVisitScore: Double?,
) {
    val stateLabel: String get() = when (state) {
        TeacherDayState.NOT_STARTED -> "لم يبدأ الجلسة"
        TeacherDayState.IN_PROGRESS -> "الجلسة جارية"
        TeacherDayState.CLOSED -> "أنهى الجلسة"
    }
    val teacherLine: String get() = teacherNames.joinToString("، ").ifBlank { "بلا محفّظ" }
    val recitedPercent: Int get() = if (students <= 0) 0 else ((recited * 100.0) / students).toInt().coerceIn(0, 100)
}

data class SupBoard(
    val halaqas: List<SupHalaqa>,
    val visits: List<JSONObject>,
    val staff: List<JSONObject>,
    val sessionsByCreator: Map<String, Int>,
    val daysByCreator: Map<String, Int>,
    val closedByCreator: Map<String, Int>,
    val lastSessionByCreator: Map<String, String>,
    /** Number of distinct days this month on which any session was held (the yardstick for a teacher's commitment). */
    val monthDays: Int,
)

internal fun staffProfiles(): List<JSONObject> {
    val repo = AppGraph.repo
    // RC61: the list itself (names, roles) is always read from the server when online, so a newly approved staff member shows up at once.
    val fresh = repo.online()
    val people = repo.table("profiles", "select=id,full_name,role,phone,active,updated_at&role=in.(teacher,supervisor)&order=full_name.asc&limit=500", forceRefresh = fresh).sRows()
    // RC79: a person's photo is downloaded ONCE and kept on the device (owner-scoped Room cache). It is downloaded again only when that
    // person's row changed on the server (updated_at differs from the stamp saved with the stored photo).
    val owner = repo.currentUserId() ?: return people
    val cache = AppGraph.cache
    fun stored(id: String): String? = cache.get(owner, "staff-photo:$id")?.takeIf { it.isNotBlank() && it != "-" }
    fun stamp(id: String): String? = cache.get(owner, "staff-photo-stamp:$id")
    if (fresh) {
        val need = people.filter { row -> val id = row.optString("id"); stamp(id) != row.optString("updated_at") }
        need.map { it.optString("id") }.filter { it.isNotBlank() }.chunked(40).forEach { ids ->
            runCatching {
                repo.api.select("profiles", "select=id,avatar_path&id=in.(${ids.joinToString(",")})")
            }.onSuccess { arr ->
                val got = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.associate { it.optString("id") to it.optString("avatar_path") }
                ids.forEach { id ->
                    val photo = got[id]?.takeIf { it.isNotBlank() && it != "null" }
                    cache.put(owner, "staff-photo:$id", photo ?: "-")
                    cache.put(owner, "staff-photo-stamp:$id", people.firstOrNull { it.optString("id") == id }?.optString("updated_at").orEmpty().ifBlank { "-" })
                }
            }
        }
    }
    return people.map { row -> row.also { r -> stored(r.optString("id"))?.let { r.put("avatar_path", it) } } }
}

/** Reads everything the supervisor home needs from the local / server tables (cached tables; works offline). */
internal fun loadSupBoard(supervisorOnly: Boolean = false): SupBoard {
    val repo = AppGraph.repo
    val now = LocalDate.now()
    val today = now.toString()
    val monthStart = now.withDayOfMonth(1).toString()
    val online = repo.online()
    // RC84: the halaqa list and its teachers are read fresh when online (a deleted halaqa must disappear at once).
    val allHalaqas = repo.table("halaqas", "select=id,name,active,halaqa_type&active=eq.true&order=name.asc&limit=200", forceRefresh = online).sRows()
        .filter { it.optString("halaqa_type", "regular").let { t -> t.isBlank() || t == "regular" || t == "null" } }
    // RC84: a halaqa supervisor sees only the halaqat assigned to him and their teachers (the server enforces the same rule).
    val myId = repo.currentUserId().orEmpty()
    val mine = if (!supervisorOnly) null else repo.table("halaqa_supervisors", "select=halaqa_id,supervisor_id&supervisor_id=eq.$myId&limit=200", forceRefresh = online)
        .sRows().map { it.optString("halaqa_id") }.toSet()
    val halaqas = if (mine == null) allHalaqas else allHalaqas.filter { it.optString("id") in mine }
    val links = repo.table("halaqa_teachers", "select=halaqa_id,teacher_id&limit=1000", forceRefresh = online).sRows()
    val myTeacherIds = if (mine == null) null else links.filter { it.optString("halaqa_id") in mine }.map { it.optString("teacher_id") }.toSet()
    val staff = staffProfiles().let { all -> if (myTeacherIds == null) all else all.filter { it.optString("id") in myTeacherIds } }
    val staffById = staff.associateBy { it.optString("id") }
    val sessions = repo.table("sessions", "select=id,halaqa_id,session_date,status,created_by&session_date=gte.$monthStart&order=session_date.desc&limit=1500").sRows()
        .filter { it.optString("status") != "cancelled" }
    val todaySessions = sessions.filter { it.optString("session_date") == today }
    val todayIds = todaySessions.map { it.optString("id") }.filter { it.isNotBlank() }
    val attendance = if (todayIds.isEmpty()) emptyList() else
        repo.table("attendance_records", "select=session_id,student_id,status&session_id=in.(${todayIds.joinToString(",")})&limit=3000").sRows()
    val recitations = if (todayIds.isEmpty()) emptyList() else
        repo.table("recitation_entries", "select=session_id,student_id&session_id=in.(${todayIds.joinToString(",")})&limit=4000").sRows()
    // RC84: the student list is refreshed from the server once per cycle (a stale copy showed 14 students instead of 44).
    val studentsDue = online && com.mohammedsamir.halaqati.data.RefreshGate.due("sup-students")
    val students = repo.students(forceRefresh = studentsDue).filter { it.status == "active" }
    if (studentsDue) com.mohammedsamir.halaqati.data.RefreshGate.mark("sup-students")
    val visits = VisitOverlay.apply(
        repo.table("supervisor_visits", "select=*&order=visit_date.desc&limit=300", forceRefresh = repo.online()).sRows(),
        repo.queueSnapshot(500),
    )

    val sessionHalaqa = todaySessions.associate { it.optString("id") to it.optString("halaqa_id") }
    val out = halaqas.map { h ->
        val hid = h.optString("id")
        val teacherIds = links.filter { it.optString("halaqa_id") == hid }.map { it.optString("teacher_id") }.distinct()
        val todayOfHalaqa = todaySessions.filter { it.optString("halaqa_id") == hid }
        val state = when {
            todayOfHalaqa.isEmpty() -> TeacherDayState.NOT_STARTED
            todayOfHalaqa.all { it.optString("status") == "closed" } -> TeacherDayState.CLOSED
            else -> TeacherDayState.IN_PROGRESS
        }
        val ids = todayOfHalaqa.map { it.optString("id") }.toSet()
        val att = attendance.filter { it.optString("session_id") in ids }
        val lastVisit = visits.firstOrNull { it.optString("halaqa_id") == hid }
        val score = lastVisit?.let { v ->
            val xs = listOf("organization_score", "teaching_score", "followup_score").filter { !v.isNull(it) && v.has(it) }.map { v.optInt(it).toDouble() }
            if (xs.isEmpty()) null else xs.average()
        }
        SupHalaqa(
            id = hid,
            name = h.optString("name", "حلقة"),
            teacherIds = teacherIds,
            teacherNames = teacherIds.map { id -> staffById[id]?.optString("full_name")?.takeIf { n -> n.isNotBlank() } ?: "محفّظ (لم يُحمَّل الاسم)" },
            teacherPhotos = teacherIds.map { id -> staffById[id]?.optString("avatar_path")?.takeIf { p -> p.isNotBlank() && p != "null" } },
            students = students.count { it.halaqaId == hid },
            state = state,
            present = att.count { it.optString("status") == "present" || it.optString("status") == "late" },
            absent = att.count { it.optString("status") == "absent" },
            excused = att.count { it.optString("status") == "excused" },
            recited = recitations.filter { sessionHalaqa[it.optString("session_id")] == hid }.map { it.optString("student_id") }.distinct().size,
            monthSessions = sessions.count { it.optString("halaqa_id") == hid },
            lastVisitDate = lastVisit?.optString("visit_date")?.takeIf { it.isNotBlank() },
            lastVisitScore = score,
        )
    }
    val byCreator = (if (mine == null) sessions else sessions.filter { it.optString("halaqa_id") in mine }).groupBy { it.optString("created_by") }
    return SupBoard(
        halaqas = out,
        visits = visits,
        staff = staff,
        sessionsByCreator = byCreator.mapValues { it.value.size },
        daysByCreator = byCreator.mapValues { e -> e.value.map { it.optString("session_date") }.distinct().size },
        closedByCreator = byCreator.mapValues { e -> e.value.count { it.optString("status") == "closed" } },
        lastSessionByCreator = byCreator.mapValues { e -> e.value.maxOf { it.optString("session_date") } },
        monthDays = (if (mine == null) sessions else sessions.filter { it.optString("halaqa_id") in mine }).map { it.optString("session_date") }.distinct().size,
    )
}

internal fun visitAverage(v: JSONObject): Double? {
    val xs = listOf("organization_score", "teaching_score", "followup_score").filter { !v.isNull(it) && v.has(it) }.map { v.optInt(it).toDouble() }
    return if (xs.isEmpty()) null else xs.average()
}

internal fun oneDecimal(v: Double): String = String.format(java.util.Locale.US, "%.1f", v)
