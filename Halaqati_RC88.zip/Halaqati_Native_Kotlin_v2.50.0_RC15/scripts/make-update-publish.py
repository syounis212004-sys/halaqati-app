from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.90.1',
    'versionCode':29001,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "إصلاح: قاعدة البيانات المحلية (halaqati-rc7.db) كانت غير مستثناة من النسخ الاحتياطي لجوجل، وصارت مستثناة",
        "تسجيل الدخول بـ Google صار بنظام PKCE برمز لمرة واحدة، فلا يصلح رابط مزوّر من تطبيق آخر لتسجيل الدخول",
        "روابط الدخول التي تحمل مفاتيح مباشرة لا تُقبل إلا للاسترجاع والتأكيد أو أثناء تسجيل دخول بدأه التطبيق",
        "التحديث من داخل التطبيق يشترط رابط https",
        "قاعدة البيانات: سُحبت صلاحية التنفيذ من الزوار (anon) عن دوال مسؤول النظام والمشرف وعن دوال المشغّلات الداخلية",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
