from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.60.3',
    'versionCode':26003,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    'notes':[
        'رأس أصغر وأيقونة اتصال صغيرة بدل شريطي التنبيه الأصفرين.',
        'حقل بحث موحّد من سطر واحد في الطلاب والخطط والإشعارات.',
        'رسالة الرئيسية تتغير حسب الدور وحالة اليوم مع أيقونة مناسبة.',
        'تقليل المسافات الفارغة في الرئيسية والخطط الذكية والقوائم، وكثافة مدمجة افتراضيًا.',
        'الحفاظ على كل ميزات RC24.2.'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
