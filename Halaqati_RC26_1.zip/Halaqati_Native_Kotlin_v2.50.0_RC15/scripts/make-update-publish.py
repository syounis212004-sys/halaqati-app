from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.62.1',
    'versionCode':26201,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    'notes':[
        'إصلاح فشل مزامنة تعديل الخطط الذكية (نطاق الصفحات في المسار العكسي) وإعادة المحجوب منها تلقائيًا.',
        'إصلاح اختفاء المقرر اليومي (الحفظ والمراجعة والسرد) لمن تجاوز نهاية نطاق خطته القديم، مع رسالة توضح السبب.',
        'زر «ضبط النطاق» في الخطط (للمدير والمحفظ) بمعاينة قبل التطبيق، وضبط تلقائي لحالات التجاوز الواضحة عند بدء شهر جديد.',
        'بطاقة في الرئيسية بالطلاب الذين يحتاجون ضبط النطاق.',
        'تنظيم المؤسسة: شريط حلقة حالية قابل للتبديل، ونظرة عامة على الحلقات للمشرف والمدير.',
        'الجلسات والخطط مجمّعة حسب الحلقة ثم الشهر (الحالي والسابق مفتوحان والأقدم مطويّ).',
        'الطلاب مجمّعون حسب الحلقة، وإصلاح ذاتي للجلسة المحذوفة، وشاشة استرجاع الجلسات المحذوفة للمدير.',
        'يلزم تنفيذ ملف SQL الخاص بالنسخة مرة واحدة (بعد ملف 2.60.4).'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
