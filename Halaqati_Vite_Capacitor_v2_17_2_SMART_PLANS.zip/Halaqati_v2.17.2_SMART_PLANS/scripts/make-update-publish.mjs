import fs from 'node:fs';
import path from 'node:path';

const cwd = process.cwd();
const apkArg = process.argv[2];
if (!apkArg) {
  console.error('Usage: node scripts/make-update-publish.mjs <signed-apk>');
  process.exit(1);
}

const apkPath = path.resolve(cwd, apkArg);
if (!fs.existsSync(apkPath) || fs.statSync(apkPath).size === 0) {
  console.error(`Signed APK not found or empty: ${apkPath}`);
  process.exit(1);
}

const pkg = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf8'));
const versionName = String(pkg.version || '1.0.0');
const [major=0, minor=0, patch=0] = versionName.split('.').map(x => Number.parseInt(x, 10) || 0);
const versionCode = major * 10000 + minor * 100 + patch;

const outDir = path.join(cwd, 'update-publish');
fs.mkdirSync(outDir, { recursive: true });

const latestApk = path.join(outDir, 'Halaqati-latest.apk');
fs.copyFileSync(apkPath, latestApk);

const apkUrl = 'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk';
const manifest = {
  versionName,
  versionCode,
  apkUrl,
  mandatory: false,
  notes: [
    'إضافة قسم الخطط المؤرشفة مع الاستعادة والحذف النهائي بعد التأكيد للمحفّظ والمشرف ومسؤول النظام، مع بقاء التسميعات والجلسات التاريخية.',
    'تحسين عناوين الصفحات على الهاتف حتى تبقى داخل الترويسة ولا تتداخل مع محتوى الصفحة.',
    'إعادة تصميم اختيار السورة والآية: أجزاء 1–30 أفقياً، ثم السور، ثم نطاق الآيات بمقبضين وإدخال رقمي.',
    'إذا امتدت السورة على أكثر من جزء تظهر السورة كاملة في كل جزء تتقاطع معه، مع أعداد آيات حقيقية.',
    'بيانات القرآن وحساب أجزاء الصفحات تُضمّن داخل التطبيق بعد البناء لتعمل دون إنترنت، مع الحفاظ على المزامنة والإشعارات وPDF العربي.'
  ],
  publishedAt: new Date().toISOString()
};

fs.writeFileSync(
  path.join(outDir, 'version.json'),
  JSON.stringify(manifest, null, 2) + '\n',
  'utf8'
);

console.log(`Update package prepared for v${versionName} (${versionCode})`);
console.log(`APK: ${latestApk}`);
console.log(`Manifest: ${path.join(outDir, 'version.json')}`);
