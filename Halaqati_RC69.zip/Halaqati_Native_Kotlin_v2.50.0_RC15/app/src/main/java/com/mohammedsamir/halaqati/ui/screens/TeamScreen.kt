package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.ui.components.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class TeamMember(val id: String, val name: String, val role: String, val phone: String, val photo: String?, val active: Boolean, val halaqat: List<String>)

/** RC65: "فريق الجمعية" — the association's staff by level (supervisors above teachers) with each teacher's halaqat. Read-only. */
@Composable
fun TeamScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    var members by remember { mutableStateOf<List<TeamMember>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    val syncEpoch by AppGraph.connectivity.syncEpoch.collectAsState()
    LaunchedEffect(syncEpoch, tick) {
        runCatching {
            withContext(Dispatchers.IO) {
                val repo = AppGraph.repo
                val staff = staffProfiles()
                val halaqas = repo.table("halaqas", "select=id,name&limit=300").sRows().associate { it.optString("id") to it.optString("name") }
                val links = repo.table("halaqa_teachers", "select=halaqa_id,teacher_id&limit=1500").sRows()
                staff.map { p ->
                    val id = p.optString("id")
                    TeamMember(id, p.supStr("full_name"), p.supStr("role"), p.supStr("phone"), p.supStr("avatar_path").ifBlank { null }, p.optBoolean("active", true),
                        links.filter { it.optString("teacher_id") == id }.mapNotNull { halaqas[it.optString("halaqa_id")] })
                }
            }
        }.onSuccess { members = it; error = null }.onFailure { error = it.message ?: "تعذر تحميل الفريق" }
        loading = false
    }
    val shown = members.filter { query.isBlank() || it.name.contains(query.trim()) }
    val supervisors = shown.filter { it.role == "supervisor" }
    val teachers = shown.filter { it.role == "teacher" }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("فريق الجمعية", onRefresh = { tick++; onRefresh() }, pending = pending)
        error?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        CompactSearchField(value = query, onValueChange = { query = it }, placeholder = "بحث بالاسم", modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp))
        if (loading && members.isEmpty()) LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp))
        LazyColumn(
            state = rememberLazyListState(), modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { Text("المشرفون (${supervisors.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold) }
            items(supervisors, key = { "sup-" + it.id }) { TeamCard(it) }
            item { Text("المحفّظون (${teachers.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp)) }
            items(teachers, key = { "tch-" + it.id }) { TeamCard(it) }
            if (!loading && shown.isEmpty()) item { EmptyState("لا يوجد أعضاء مطابقون") }
        }
    }
}

@Composable
private fun TeamCard(m: TeamMember) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = RoundedCornerShape(16.dp), color = cs.surface, border = BorderStroke(1.dp, cs.outlineVariant), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StudentAvatar(m.photo, m.name, size = 52.dp)
            Column(Modifier.weight(1f)) {
                Text(m.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 2)
                Text(if (m.role == "supervisor") "مشرف" else "محفّظ" + if (m.halaqat.isNotEmpty()) " · " + m.halaqat.joinToString("، ") else " · بلا حلقة", style = MaterialTheme.typography.bodyMedium)
                if (m.phone.isNotBlank()) Text(m.phone, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            }
            if (!m.active) StatusPill("مجمَّد", "error")
        }
    }
}
