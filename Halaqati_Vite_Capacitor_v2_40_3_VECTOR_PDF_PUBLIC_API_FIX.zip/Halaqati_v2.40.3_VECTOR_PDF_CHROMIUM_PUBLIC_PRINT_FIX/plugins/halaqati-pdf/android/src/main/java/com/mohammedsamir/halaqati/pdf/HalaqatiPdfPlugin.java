package com.mohammedsamir.halaqati.pdf;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "HalaqatiPdf")
public class HalaqatiPdfPlugin extends Plugin {
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Map<String, WebView> activePrintViews = new ConcurrentHashMap<>();

    @PluginMethod
    public void exportPdf(PluginCall call) {
        final String html = call.getString("html", "");
        final String requestedName = call.getString("filename", "halaqati-report.pdf");
        final String orientation = call.getString("orientation", "landscape");

        if (html == null || html.trim().isEmpty()) {
            call.reject("PDF HTML is empty");
            return;
        }
        if (html.length() > 12_000_000) {
            call.reject("PDF HTML is too large");
            return;
        }

        final Activity activity = getActivity();
        if (activity == null) {
            call.reject("Android activity is unavailable");
            return;
        }

        final String filename = safePdfName(requestedName);
        activity.runOnUiThread(() -> openChromiumPrint(activity, call, html, filename, orientation));
    }

    private void openChromiumPrint(Activity activity, PluginCall call, String html, String filename, String orientation) {
        final AtomicBoolean terminal = new AtomicBoolean(false);
        final WebView webView = new WebView(activity);
        final Runnable[] timeoutRef = new Runnable[1];
        final int[] pollCount = new int[]{0};

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setLoadsImagesAutomatically(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        webView.setBackgroundColor(0xFFFFFFFF);

        Runnable cleanup = () -> {
            try { webView.stopLoading(); } catch (Throwable ignored) {}
            try { webView.loadUrl("about:blank"); } catch (Throwable ignored) {}
            try { webView.destroy(); } catch (Throwable ignored) {}
        };

        Runnable timeout = () -> {
            if (!terminal.compareAndSet(false, true)) return;
            cleanup.run();
            call.reject("انتهت مهلة تجهيز PDF. حاول مرة أخرى.");
        };
        timeoutRef[0] = timeout;
        mainHandler.postDelayed(timeout, 30_000L);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                waitForReady(view, activity, call, filename, orientation, terminal, timeoutRef, cleanup, pollCount);
            }
        });

        webView.loadDataWithBaseURL("https://halaqati.local/", html, "text/html", "UTF-8", null);
    }

    private void waitForReady(WebView webView, Activity activity, PluginCall call, String filename, String orientation,
                              AtomicBoolean terminal, Runnable[] timeoutRef, Runnable cleanup, int[] pollCount) {
        if (terminal.get()) return;
        final String readyJs = "(function(){try{return (!!document.body && document.readyState==='complete' && (!document.fonts || document.fonts.status==='loaded') && Array.prototype.every.call(document.images,function(i){return i.complete;})) ? 'READY' : 'WAIT';}catch(e){return 'WAIT';}})();";
        webView.evaluateJavascript(readyJs, value -> {
            if (terminal.get()) return;
            String v = value == null ? "" : value.replace("\"", "");
            if ("READY".equals(v) || pollCount[0]++ >= 80) {
                launchPrintManager(webView, activity, call, filename, orientation, terminal, timeoutRef, cleanup);
            } else {
                mainHandler.postDelayed(() -> waitForReady(webView, activity, call, filename, orientation, terminal, timeoutRef, cleanup, pollCount), 120L);
            }
        });
    }

    private void launchPrintManager(WebView webView, Activity activity, PluginCall call, String filename, String orientation,
                                    AtomicBoolean terminal, Runnable[] timeoutRef, Runnable cleanup) {
        if (terminal.get()) return;
        if (timeoutRef[0] != null) mainHandler.removeCallbacks(timeoutRef[0]);

        PrintManager printManager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
        if (printManager == null) {
            if (terminal.compareAndSet(false, true)) {
                cleanup.run();
                call.reject("خدمة الطباعة غير متاحة على هذا الجهاز");
            }
            return;
        }

        PrintAttributes.MediaSize media = PrintAttributes.MediaSize.ISO_A4;
        if ("landscape".equalsIgnoreCase(orientation)) media = media.asLandscape();
        else media = media.asPortrait();

        PrintAttributes attrs = new PrintAttributes.Builder()
                .setMediaSize(media)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build();

        try {
            PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(filename);
            PrintJob job = printManager.print(filename, adapter, attrs);
            String jobKey = job.getId().toString();
            activePrintViews.put(jobKey, webView);
            monitorPrintJob(jobKey, job, cleanup, 0);

            if (terminal.compareAndSet(false, true)) {
                JSObject out = new JSObject();
                out.put("opened", true);
                out.put("saved", false);
                out.put("printDialog", true);
                out.put("filename", filename);
                out.put("engine", "chromium-webview-system-print");
                call.resolve(out);
            }
        } catch (Throwable e) {
            if (terminal.compareAndSet(false, true)) {
                cleanup.run();
                call.reject("تعذر فتح شاشة حفظ PDF: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
            }
        }
    }

    private void monitorPrintJob(String key, PrintJob job, Runnable cleanup, int ticks) {
        mainHandler.postDelayed(() -> {
            try {
                if (job.isCompleted() || job.isCancelled() || job.isFailed() || ticks >= 1800) {
                    activePrintViews.remove(key);
                    cleanup.run();
                    return;
                }
            } catch (Throwable ignored) {
                activePrintViews.remove(key);
                cleanup.run();
                return;
            }
            monitorPrintJob(key, job, cleanup, ticks + 1);
        }, 500L);
    }

    private String safePdfName(String value) {
        String s = value == null ? "halaqati-report.pdf" : value.trim();
        s = s.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "_");
        if (!s.toLowerCase().endsWith(".pdf")) s += ".pdf";
        if (s.length() > 120) s = s.substring(0, 116) + ".pdf";
        return s.isEmpty() ? "halaqati-report.pdf" : s;
    }
}
