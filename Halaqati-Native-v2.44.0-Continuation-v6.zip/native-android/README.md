# Halaqati Native Android

This module is Kotlin + Jetpack Compose and uses the same Supabase REST tables and JSON fields as the v2.44.0 web release. The original Vite/Capacitor source remains outside this module and is checked by `verification/baseline-sha256.json`.

## Local build

Use JDK 17, Android SDK 35, and Gradle 8.13:

```bash
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
gradle --no-daemon :app:assembleRelease :app:bundleRelease
```

The default application id is `com.mohammedsamir.halaqati.nativepreview` so a preview build cannot overwrite the existing Capacitor installation. A release handoff should set the production id and signing config through Gradle/CI secrets only after migration acceptance.

## Covered native paths

- encrypted session and snapshot storage, guarded optimistic outbox, idempotent replay and conflict retention;
- approval-aware sign-in, account registration/recovery, students, sessions, attendance, notes, forum posts/comments;
- V6 scoring and the smart-plan engine (create/edit, schedule, pause/catch-up, retry, milestones, effective plans and review suggestions);
- Quran page/ayah/surah/juz range selection using the pinned Hafs metadata;
- interactive RTL Compose plan progress and recitation screens, vector session PDF export, responsive rail/bottom navigation.

The native module does not yet claim exact parity for FCM/Google sign-in, guardian linking, import/OCR/backup UI, every report/certificate template, lesson-specific fields, or the QCF4 line map. Those remain explicit release gates; no web feature was removed or altered.
