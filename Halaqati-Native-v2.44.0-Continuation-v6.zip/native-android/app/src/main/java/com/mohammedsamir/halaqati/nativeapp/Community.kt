package com.mohammedsamir.halaqati.nativeapp

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONObject

@Composable fun ForumScreen(state:AppState,id:String,repo:Repository,open:(String)->Unit,form:(String)->Unit) {
    var comment by rememberSaveable(id) {mutableStateOf("")}
    var editing by rememberSaveable(id) {mutableStateOf("")}
    val rows=state.data["forum"].orEmpty().filter {id.isBlank()||it.text("id")==id}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {if(id.isBlank())Button({form("forum:new")}){Text(if(canManage(state.profile))"إضافة منشور" else "طرح استفسار")};state.errors["forum"]?.let{Text(it,color=MaterialTheme.colorScheme.error)}}
        items(rows,key={it.text("id")}) {p->
            ElevatedCard(onClick={if(id.isBlank())open(p.text("id"))},modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Text(p.text("title"),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                    Text(p.text("body"),maxLines=if(id.isBlank())4 else Int.MAX_VALUE)
                    if(p.optBoolean("_pending"))Text("محفوظ على الجهاز · بانتظار الإرسال",style=MaterialTheme.typography.labelSmall)
                    if(id.isNotBlank()&&(canManage(state.profile)||p.text("author_id")==repo.userId))TextButton({form("forum:${p.text("id")}")}){Text("تعديل المنشور")}
                }
            }
        }
        if(id.isNotBlank()) {
            item {Text("التعليقات",style=MaterialTheme.typography.titleMedium);state.errors["comments_$id"]?.let{Text(it,color=MaterialTheme.colorScheme.error)}}
            items(state.data["comments_$id"].orEmpty(),key={it.text("id")}) {c->
                Card(Modifier.fillMaxWidth()) {Column(Modifier.padding(14.dp)) {
                    Text(c.text("body"));Text(c.text("created_at").take(10),style=MaterialTheme.typography.labelSmall)
                    if(c.text("author_id")==repo.userId||canManage(state.profile))TextButton({editing=c.text("id");comment=c.text("body")}){Text("تعديل")}
                }}
            }
            if(rows.firstOrNull()?.optBoolean("comments_enabled",true)==true)item {
                OutlinedTextField(comment,{comment=it},Modifier.fillMaxWidth(),label={Text(if(editing.isBlank())"تعليق جديد" else "تعديل التعليق")},minLines=2)
                Button({repo.launch {saveForumComment(id,editing.takeIf{it.isNotBlank()},comment);comment="";editing=""}},enabled=!state.busy&&comment.isNotBlank()){Text("حفظ التعليق")}
                if(editing.isNotBlank())TextButton({editing="";comment=""}){Text("إلغاء التعديل")}
            }
        }
    }
}
@Composable fun ForumForm(state:AppState,id:String?,repo:Repository,close:()->Unit) {
    val old=state.data["forum"].orEmpty().find {it.text("id")==id}
    var title by rememberSaveable(id){mutableStateOf(old?.text("title").orEmpty())}
    var body by rememberSaveable(id){mutableStateOf(old?.text("body").orEmpty())}
    var halaqa by rememberSaveable(id){mutableStateOf(old?.text("halaqa_id")?:state.data["halaqas"]?.firstOrNull()?.text("id").orEmpty())}
    var type by rememberSaveable(id){mutableStateOf(old?.text("post_type")?:if(canManage(state.profile))"discussion" else "question")}
    var comments by rememberSaveable(id){mutableStateOf(old?.optBoolean("comments_enabled",true)?:true)}
    var pinned by rememberSaveable(id){mutableStateOf(old?.optBoolean("pinned",false)?:false)}
    FormBody(if(id==null)"منشور جديد" else "تعديل المنشور") {
        if(id==null)Select("الحلقة",halaqa,state.data["halaqas"].orEmpty().associate {it.text("id") to it.text("name")}){halaqa=it}
        Select("نوع المنشور",type,if(canManage(state.profile))linkedMapOf("discussion" to "نقاش","question" to "استفسار","achievement" to "إنجاز","notice" to "ملاحظة")else linkedMapOf("question" to "استفسار")){type=it}
        Field("العنوان",title,{title=it});Field("المحتوى",body,{body=it},lines=5)
        Row {Checkbox(comments,{comments=it});Text("السماح بالتعليقات",Modifier.padding(top=12.dp))}
        if(canManage(state.profile))Row {Checkbox(pinned,{pinned=it});Text("تثبيت المنشور",Modifier.padding(top=12.dp))}
        Button({repo.launch {saveForumPost(id,JSONObject().put("halaqa_id",halaqa).put("title",title.trim()).put("body",body.trim()).put("post_type",type).put("comments_enabled",comments).put("pinned",pinned));close()}},enabled=!state.busy&&title.isNotBlank()&&body.isNotBlank()&&halaqa.isNotBlank()){Text("حفظ المنشور")}
    }
}
