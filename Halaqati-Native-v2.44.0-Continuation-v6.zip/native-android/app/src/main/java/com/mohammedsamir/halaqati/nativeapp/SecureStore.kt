package com.mohammedsamir.halaqati.nativeapp
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
class SecureStore(context:Context) {
    private val directory=File(context.noBackupFilesDir,"native-v1").apply { mkdirs() }
    private val key:SecretKey by lazy {
        val ks=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("halaqati-native-session-v1",null) as? SecretKey) ?: KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder("halaqati-native-session-v1",KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    private fun file(name:String):AtomicFile { require(name.matches(Regex("[a-zA-Z0-9_-]+"))); return AtomicFile(File(directory,name)) }
    @Synchronized fun read(name:String):String? {
        val f=file(name); if(!f.baseFile.exists()) return null
        val bytes=f.readFully(); require(bytes.size>28) { "التخزين المحلي غير صالح" }
        val cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE,key,GCMParameterSpec(128,bytes.copyOfRange(0,12)))
        return cipher.doFinal(bytes.copyOfRange(12,bytes.size)).toString(Charsets.UTF_8)
    }
    @Synchronized fun write(name:String,value:String) {
        val cipher=Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE,key) }
        val bytes=cipher.iv+cipher.doFinal(value.toByteArray(Charsets.UTF_8)); val f=file(name); val out=f.startWrite()
        try { out.write(bytes); f.finishWrite(out) } catch(e:Exception) { f.failWrite(out); throw e }
    }
    @Synchronized fun remove(name:String) { file(name).delete() }
}
