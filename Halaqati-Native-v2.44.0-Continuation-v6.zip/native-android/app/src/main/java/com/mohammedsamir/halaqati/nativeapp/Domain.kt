package com.mohammedsamir.halaqati.nativeapp

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.LocalDate
import java.util.Locale
import kotlin.math.floor

fun JSONObject.text(key: String): String = if (isNull(key)) "" else optString(key, "")
fun JSONArray.rows(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
fun List<JSONObject>.json(): JSONArray = JSONArray().also { a -> forEach { a.put(it) } }
fun JSONObject.copyJson(): JSONObject = JSONObject(toString())
fun query(values: Map<String, String>): String = values.entries.joinToString("&") { URLEncoder.encode(it.key,"UTF-8")+"="+URLEncoder.encode(it.value,"UTF-8") }
fun today(): String = LocalDate.now().toString()
fun monthStart(): String = LocalDate.now().withDayOfMonth(1).toString()
fun number(n: Double): String = String.format(Locale.US,"%.2f",n).trimEnd('0').trimEnd('.')
fun canonicalTrack(code: String): String = if(code=="sard") "general_hifz" else code
val tracks = linkedMapOf("general_hifz" to "مسار الحفظ العام","tathbit" to "مسار التثبيت")
val roleNames = mapOf("admin" to "مسؤول النظام","supervisor" to "مشرف الحلقات","teacher" to "محفّظ","guardian" to "ولي الأمر")
val sessionNames = linkedMapOf("tasmee" to "تسميع","sard" to "سرد","review" to "مراجعة","test" to "اختبار","tajweed" to "تجويد","lesson" to "جلسة تربوية","other" to "أخرى")
val activityNames = linkedMapOf("new_hifz" to "حفظ جديد","review_near" to "مراجعة قريبة","review_far" to "مراجعة بعيدة","sard" to "سرد","tilawah" to "تلاوة","test" to "اختبار")
val attendanceNames = linkedMapOf("present" to "حاضر","absent" to "غائب","excused" to "بعذر","late" to "متأخر")
val evaluationNames = mapOf("excellent" to "ممتاز","very_good" to "جيد جداً","good" to "جيد","repeat" to "يحتاج إعادة","not_rated" to "غير مقيّم")
val statusNames = mapOf("active" to "نشط","archived" to "مؤرشف","paused" to "متوقف","draft" to "مسودة","completed" to "مكتمل","open" to "مفتوحة","closed" to "مرفوعة","cancelled" to "ملغاة")
fun isApproved(p: JSONObject?): Boolean = p?.text("approval_status")=="approved" && p.optBoolean("active",false)
fun canManage(p: JSONObject?): Boolean = isApproved(p) && p?.text("role") in setOf("admin","supervisor","teacher")
/** True when a smart plan may be attached to this student's recitation. */
fun planAppliesToStudent(plan: JSONObject, student: JSONObject?): Boolean {
    if (student == null) return false
    if (plan.text("halaqa_id").isNotBlank() && plan.text("halaqa_id") != student.text("halaqa_id")) return false
    return when (plan.text("scope_type")) {
        "student" -> plan.text("student_id") == student.text("id")
        "category" -> plan.text("category_id").isNotBlank() && plan.text("category_id") == student.text("category_id")
        "halaqa" -> true
        else -> false
    }
}
fun accessMessage(p: JSONObject?): String = when {
    p==null -> "تعذر تحميل ملف الحساب. أعد المحاولة."
    p.text("approval_status")=="rejected" -> p.text("rejection_reason").ifBlank { "لم تتم الموافقة على الحساب" }
    p.text("approval_status")=="approved" && !p.optBoolean("active") -> "الحساب موقوف. راجع مسؤول الحلقة."
    else -> "الحساب بانتظار اعتماد المسؤول"
}
/** Exact v2.44.0 computeRecitationV6 rule. No alternative ranking formula. */
fun scoreV6(input: JSONObject): JSONObject {
    val pages=input.optDouble("pages_count",0.0).coerceAtLeast(0.0)
    val mistakes=input.optDouble("mistakes",0.0).coerceAtLeast(0.0)
    val prompts=input.optDouble("prompts",0.0).coerceAtLeast(0.0)
    require(listOf(pages,mistakes,prompts).all { it.isFinite() })
    val keys=input.optJSONObject("selection_data")?.optJSONArray("qcf_line_keys")
    val lines=if(keys!=null && keys.length()>0) (0 until keys.length()).map { keys.get(it).toString() }.toSet().size.toDouble() else pages*15
    val units=mistakes+prompts*.5
    val normalized=if(lines>0) units*15/lines else 0.0
    val safety=if(lines>0) (100-normalized*20).coerceIn(0.0,100.0) else 0.0
    val evaluation=when { lines<=0 -> "not_rated"; safety>=90 -> "excellent"; safety>=80 -> "very_good"; safety>=70 -> "good"; else -> "repeat" }
    return JSONObject().put("penalty_units",units).put("penalty_per_page",if(pages>0) units/pages else 0)
        .put("safety_percentage",floor(safety*10+.5)/10).put("evaluation",evaluation)
        .put("points",if(pages<=0) 0.0 else (floor((pages-units*.25)*100+.5)/100).coerceAtLeast(0.0)).put("scoring_version","V6")
}
suspend fun collectPages(fetch: suspend (Int)->List<JSONObject>): List<JSONObject> {
    val result=mutableListOf<JSONObject>(); var offset=0; var previous=""
    while(true) {
        val page=fetch(offset); if(page.isEmpty()) return result.distinctBy { it.text("id").ifBlank { it.toString() } }
        val signature=page.json().toString(); check(signature!=previous) { "أعاد الخادم الصفحة نفسها؛ لم يكتمل التحميل" }
        previous=signature; result.addAll(page); offset+=page.size; check(offset<100000) { "اختر نطاقاً زمنياً أصغر" }
    }
}
fun equivalentJson(a:Any?,b:Any?):Boolean = when {
    a==null || a===JSONObject.NULL -> b==null || b===JSONObject.NULL
    b==null || b===JSONObject.NULL -> false
    a is Number && b is Number -> a.toDouble()==b.toDouble()
    a is JSONObject && b is JSONObject -> a.keys().asSequence().toSet()==b.keys().asSequence().toSet() && a.keys().asSequence().all { equivalentJson(a.opt(it),b.opt(it)) }
    a is JSONArray && b is JSONArray -> a.length()==b.length() && (0 until a.length()).all { equivalentJson(a.opt(it),b.opt(it)) }
    else -> a==b
}
fun sameFields(row:JSONObject,desired:JSONObject):Boolean = desired.keys().asSequence().all { equivalentJson(row.opt(it),desired.opt(it)) }
fun changedFields(before: JSONObject, desired: JSONObject): JSONObject = JSONObject().apply {
    desired.keys().forEach { k -> if(!sameFields(before,JSONObject().put(k,desired.get(k)))) put(k,desired.get(k)) }
}
fun guardedFilters(identity: Map<String,String>, before: JSONObject, changed: JSONObject): Map<String,String> = identity + changed.keys().asSequence().associateWith {
    if(before.isNull(it)) "is.null" else "eq.${before.get(it)}"
}
data class SessionToken(val access:String,val refresh:String,val userId:String,val expires:Long) {
    fun json()=JSONObject().put("access",access).put("refresh",refresh).put("userId",userId).put("expires",expires)
    companion object {
        fun fromAuth(v:JSONObject)=SessionToken(v.getString("access_token"),v.getString("refresh_token"),v.getJSONObject("user").getString("id"), if(v.has("expires_at")) v.getLong("expires_at") else System.currentTimeMillis()/1000+v.getLong("expires_in"))
        fun fromStored(v:JSONObject)=SessionToken(v.getString("access"),v.getString("refresh"),v.getString("userId"),v.getLong("expires"))
    }
}
data class Dataset(val key:String,val table:String,val filters:Map<String,String> = emptyMap(),val order:String="id.asc")
val datasets get()=listOf(
    Dataset("halaqas","halaqas",order="created_at.asc,id.asc"),Dataset("students","students",order="full_name.asc,id.asc"),
    Dataset("sessions","sessions",order="session_date.desc,id.asc"),Dataset("plans","smart_plans",order="start_date.desc,id.asc"),
    Dataset("plan_events","smart_plan_events",order="created_at.desc,id.asc"),
    Dataset("announcements","announcements",order="pinned.desc,publish_at.desc,id.asc"),Dataset("categories","student_categories",order="name.asc,id.asc"),
    Dataset("forum","forum_posts",order="created_at.desc,id.asc"))
