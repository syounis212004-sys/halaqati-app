package com.mohammedsamir.halaqati.nativeapp

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import org.json.JSONArray
import java.util.UUID
import java.util.concurrent.TimeUnit

data class AppState(val starting:Boolean=true,val signedIn:Boolean=false,val busy:Boolean=false,val profile:JSONObject?=null,
    val data:Map<String,List<JSONObject>> = emptyMap(),val errors:Map<String,String> = emptyMap(),val cached:Set<String> = emptySet(),
    val queue:List<JSONObject> = emptyList(),val message:String?=null,val updatedAt:String="")
class Repository private constructor(private val context:Context) {
    private val store=SecureStore(context); private val api=Api(store); private val lock=Mutex()
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private val _state=MutableStateFlow(AppState()); val state=_state.asStateFlow()
    private var initialized=false
    val userId get()=api.userId
    suspend fun initialize()=lock.withLock {
        if(initialized) return@withLock
        try {
            val signed=api.restore(); _state.update { it.copy(starting=false,signedIn=signed) }
            if(signed) restore()
        } finally { initialized=true; _state.update { it.copy(starting=false) } }
    }
    private fun errorText(e:Exception)=when(e) {
        is java.io.IOException -> "تعذر الاتصال. التعديلات محفوظة وسيعاد إرسالها عند عودة الإنترنت."
        is ApiFailure -> if(e.status==401) "انتهت جلسة الدخول. أعد تسجيل الدخول بالحساب نفسه." else e.message ?: "رفض الخادم الطلب"
        else -> e.message ?: "تعذر إكمال العملية"
    }
    fun launch(block:suspend Repository.()->Unit) { scope.launch {
        _state.update { it.copy(busy=true,message=null) }
        try { block() } catch(e:CancellationException) { throw e } catch(e:Exception) { _state.update { it.copy(message=errorText(e)) } }
        finally { _state.update { it.copy(busy=false) } }
    } }
    fun dismiss() { _state.update { it.copy(message=null) } }
    suspend fun signIn(email:String,password:String)=lock.withLock {
        require(email.contains('@') && password.isNotBlank()) { "أدخل البريد وكلمة المرور" }
        val old=api.userId
        api.signIn(email,password,if(_state.value.queue.isNotEmpty()) old else null)
        _state.value=AppState(starting=false,signedIn=true,busy=true)
        restore(); refreshLocked()
    }
    suspend fun refresh()=lock.withLock { refreshLocked() }
    private suspend fun refreshLocked() {
        val id=api.userId ?: return
        _state.update { it.copy(cached=it.data.keys+"profile") }
        val profile=api.list("profiles",mapOf("id" to "eq.$id")).singleOrNull() ?: error("ملف الحساب غير موجود")
        _state.update { it.copy(profile=profile,cached=it.cached-"profile") }
        if(!isApproved(profile)) { _state.update { it.copy(data=emptyMap(),cached=emptySet()) }; persist(); return }
        try { flushLocked() } catch(e:CancellationException) { throw e } catch(e:Exception) { _state.update { it.copy(message=errorText(e)) } }
        coroutineScope { (datasets+Dataset("notifications","notifications",mapOf("recipient_id" to "eq.$id"),"created_at.desc,id.asc")).map { d->async { fetch(d) } }.awaitAll() }
        _state.update { it.copy(updatedAt=java.time.LocalDateTime.now().withNano(0).toString().replace('T',' ')) }; persist()
    }
    private suspend fun fetch(d:Dataset) {
        try {
            val remote=api.list(d.table,d.filters,d.order)
            val pending=_state.value.queue.filter { it.text("table")==d.table }
            val merged=remote.associateBy { it.text("id") }.toMutableMap()
            pending.filter { it.text("dataset")==d.key }.forEach { op -> merged[op.text("row_id")]=op.getJSONObject("display") }
            _state.update { it.copy(data=it.data+(d.key to merged.values.toList()),errors=it.errors-d.key,cached=it.cached-d.key) }
        } catch(e:CancellationException) { throw e } catch(e:Exception) { _state.update { it.copy(errors=it.errors+(d.key to errorText(e)),cached=it.cached+d.key) } }
    }
    suspend fun loadRoster(id:String)=lock.withLock {
        require(isApproved(_state.value.profile))
        coroutineScope { listOf("attendance_records","student_daily_notes","recitation_entries").map { table -> async { fetch(Dataset("${table}_$id",table,mapOf("session_id" to "eq.$id"))) } }.awaitAll() }; persist()
    }
    suspend fun loadStudent(id:String)=lock.withLock {
        require(isApproved(_state.value.profile)); fetch(Dataset("recitations_$id","recitation_entries",mapOf("student_id" to "eq.$id"),"created_at.desc,id.asc"))
        try {
            val result=api.rpc("guardian_student_dashboard_range",JSONObject().put("p_student_id",id).put("p_from",monthStart()).put("p_to",today()))
            _state.update { it.copy(data=it.data+("dashboard_$id" to listOf(result)),errors=it.errors-"dashboard_$id",cached=it.cached-"dashboard_$id") }
        } catch(e:CancellationException) { throw e } catch(e:Exception) { _state.update { it.copy(errors=it.errors+("dashboard_$id" to errorText(e))) } }; persist()
    }
    suspend fun loadPlanActivity(planId:String,studentId:String)=lock.withLock {
        require(isApproved(_state.value.profile))
        val plan=_state.value.data["plans"].orEmpty().find { it.text("id")==planId } ?: error("الخطة غير موجودة")
        val halaqa=plan.text("halaqa_id")
        fetch(Dataset("plan_recitations_$planId","recitation_entries",mapOf("student_id" to "eq.$studentId"),"created_at.asc,id.asc"))
        if(halaqa.isNotBlank()) fetch(Dataset("plan_sessions_$planId","sessions",mapOf("halaqa_id" to "eq.$halaqa"),"session_date.asc,id.asc"))
        fetch(Dataset("plan_events_$planId","smart_plan_events",mapOf("plan_id" to "eq.$planId","student_id" to "eq.$studentId"),"created_at.asc,id.asc"))
        persist()
    }
    suspend fun loadComments(id:String)=lock.withLock { fetch(Dataset("comments_$id","forum_comments",mapOf("post_id" to "eq.$id"),"created_at.asc,id.asc")); persist() }
    /** Persist both optimistic display and queue in the same encrypted atomic document. */
    private suspend fun enqueueLocked(table:String,dataset:String,desired:JSONObject,before:JSONObject?) {
        require(table in Api.MUTABLE_TABLES)
        val owner=api.userId ?: error("سجّل الدخول")
        val id=desired.text("id").ifBlank { UUID.randomUUID().toString() }; desired.put("id",id)
        val current=_state.value
        val previous=current.queue.find { it.text("table")==table && it.text("row_id")==id }
        val base=previous?.optJSONObject("before") ?: if(previous==null) before else null
        val combined=(previous?.optJSONObject("desired")?:JSONObject()).copyJson()
        desired.keys().forEach { combined.put(it,desired.get(it)) }
        val display=(before?:JSONObject()).copyJson(); combined.keys().forEach { display.put(it,combined.get(it)) }; display.put("_pending",true)
        if(table=="recitation_entries") { val score=scoreV6(display); score.keys().forEach { display.put(it,score.get(it)) } }
        val op=JSONObject().put("id",previous?.text("id") ?: UUID.randomUUID().toString()).put("owner",owner).put("row_id",id)
            .put("table",table).put("dataset",dataset).put("desired",combined).put("display",display).put("created_at",previous?.text("created_at") ?: java.time.Instant.now().toString())
        if(base!=null) op.put("before",base)
        val rows=current.data[dataset].orEmpty().filterNot { it.text("id")==id }+display
        val nextData=(current.data+(dataset to rows)).toMutableMap()
        if(table=="sessions" && before==null) listOf("attendance_records","student_daily_notes","recitation_entries").forEach { nextData.putIfAbsent("${it}_$id",emptyList()) }
        val next=current.copy(data=nextData,queue=if(previous==null) current.queue+op else current.queue.map { if(it.text("id")==previous.text("id")) op else it },message="حُفظ على الجهاز؛ بانتظار المزامنة")
        persist(next); _state.value=next; scheduleSync()
    }
    suspend fun saveStudent(id:String?,fields:JSONObject)=lock.withLock {
        require(canManage(_state.value.profile)) { "لا تملك صلاحية تعديل الطلاب" }
        val before=_state.value.data["students"].orEmpty().find { it.text("id")==id }
        if(id!=null) require(before!=null) { "حمّل الطالب قبل تعديله" }
        val name=fields.text("full_name").trim(); require(name.isNotBlank()) { "اسم الطالب مطلوب" }
        val hid=fields.text("halaqa_id"); require(hid.isNotBlank()) { "اختر الحلقة" }
        val track=fields.text("track_code"); require(track in tracks || track.isBlank())
        require(_state.value.data["students"].orEmpty().none { it.text("id")!=id && it.text("status")=="active" && it.text("halaqa_id")==hid && it.text("full_name").trim()==name }) { "طالب بهذا الاسم مسجل في الحلقة" }
        val desired=fields.copyJson().put("full_name",name)
        if(id!=null) desired.put("id",id) else desired.put("status","active").put("enrollment_date",today())
        enqueueLocked("students","students",desired,before)
    }
    suspend fun saveSession(id:String?,fields:JSONObject)=lock.withLock {
        require(canManage(_state.value.profile)); require(fields.text("halaqa_id").isNotBlank()); LocalDateCheck(fields.text("session_date"))
        require(fields.text("session_type") in sessionNames)
        val before=_state.value.data["sessions"].orEmpty().find { it.text("id")==id }
        if(id!=null) require(before!=null)
        val row=fields.copyJson(); if(id!=null) row.put("id",id) else row.put("status","open").put("created_by",api.userId).put("activity_data",JSONObject())
        enqueueLocked("sessions","sessions",row,before)
    }
    suspend fun setSessionStatus(id:String,status:String)=lock.withLock {
        require(canManage(_state.value.profile)); require(status in setOf("open","closed"))
        val before=_state.value.data["sessions"].orEmpty().find { it.text("id")==id } ?: error("الجلسة غير موجودة")
        enqueueLocked("sessions","sessions",JSONObject().put("id",id).put("status",status),before)
    }
    private fun checkSession(id:String) {
        require(canManage(_state.value.profile)); val session=_state.value.data["sessions"].orEmpty().find { it.text("id")==id } ?: error("الجلسة غير موجودة")
        require(session.text("status")=="open") { "افتح الجلسة للتعديل أولاً" }
    }
    suspend fun attendance(sessionId:String,studentId:String,status:String)=lock.withLock {
        checkSession(sessionId); require(status in attendanceNames)
        val key="attendance_records_$sessionId"; require(key in _state.value.data) { "حمّل كشف الجلسة قبل تعديل الحضور" }
        val before=_state.value.data[key].orEmpty().find { it.text("student_id")==studentId }
        val row=JSONObject().put("session_id",sessionId).put("student_id",studentId).put("status",status).put("recorded_by",api.userId)
        if(before!=null) row.put("id",before.text("id"))
        enqueueLocked("attendance_records",key,row,before)
    }
    suspend fun saveRecitation(sessionId:String,studentId:String,startPage:Int,endPage:Int,mistakes:Int,prompts:Int,activity:String,note:String,planId:String?) =
        saveSelectedRecitation(sessionId,studentId,RecitationSelection.pages(startPage,endPage),mistakes,prompts,activity,note,planId)

    suspend fun saveSelectedRecitation(sessionId:String,studentId:String,selection:JSONObject,mistakes:Int,prompts:Int,activity:String,note:String,planId:String?)=lock.withLock {
        checkSession(sessionId); require(mistakes>=0 && prompts>=0); require(activity in activityNames)
        val mode=selection.text("input_method").ifBlank { selection.optJSONObject("selection_data")?.text("mode").orEmpty() }
        require(mode in setOf("pages","ayahs","surahs","juz")) { "نوع نطاق التسميع غير مدعوم" }
        val details=(selection.optJSONObject("selection_data") ?: JSONObject()).copyJson()
        if(!planId.isNullOrBlank()) {
            val plan=_state.value.data["plans"].orEmpty().find { it.text("id")==planId } ?: error("الخطة غير موجودة")
            val student=_state.value.data["students"].orEmpty().find { it.text("id")==studentId }
            require(planAppliesToStudent(plan,student)) { "الخطة لا تنطبق على هذا الطالب" }
            details.put("smart_plan_id",planId).put("smart_plan_type",plan.text("plan_type"))
        }
        val date=_state.value.data["sessions"].orEmpty().find { it.text("id")==sessionId }?.text("session_date").orEmpty()
        details.put("smart_plan_date",date)
        val row=selection.copyJson()
        // range_* are picker aliases kept inside selection_data; recitation_entries
        // persists the established start_*/end_* columns instead.
        listOf("range_start_surah","range_start_ayah","range_end_surah","range_end_ayah").forEach { row.remove(it) }
        row.put("session_id",sessionId).put("student_id",studentId).put("activity_type",activity)
            .put("input_method",mode).put("mistakes",mistakes).put("prompts",prompts)
            .put("teacher_note",note.ifBlank { JSONObject.NULL }).put("selection_data",details).put("created_by",api.userId)
        if(!row.has("selected_surahs")) row.put("selected_surahs",JSONArray())
        enqueueLocked("recitation_entries","recitation_entries_$sessionId",row,null)
    }
    suspend fun saveNote(sessionId:String,studentId:String,comment:String,homework:String)=lock.withLock {
        checkSession(sessionId); val key="student_daily_notes_$sessionId"; require(key in _state.value.data)
        val before=_state.value.data[key].orEmpty().find { it.text("student_id")==studentId }
        val row=JSONObject().put("session_id",sessionId).put("student_id",studentId).put("teacher_comment",comment).put("homework",homework).put("parent_visible",true)
        if(before==null) row.put("created_by",api.userId).put("behavior","normal").put("behavior_score",0).put("participation","normal") else row.put("id",before.text("id"))
        enqueueLocked("student_daily_notes",key,row,before)
    }
    suspend fun register(email:String,password:String,name:String,phone:String,role:String)=lock.withLock {
        require(_state.value.queue.isEmpty()) { "زامن التعديلات قبل تغيير الحساب" }
        require(email.contains('@')&&name.trim().length>=3&&password.length>=6) { "تحقق من الاسم والبريد وكلمة المرور (6 أحرف على الأقل)" }
        val signed=api.register(email,password,name,phone,role)
        if(signed){_state.value=AppState(starting=false,signedIn=true,busy=true);refreshLocked()}
        else _state.update { it.copy(message="تم إرسال طلب الحساب. أكد البريد إن طُلب، ثم انتظر اعتماد المسؤول.") }
    }
    suspend fun resetPassword(email:String)=lock.withLock {
        require(email.contains('@')) { "أدخل البريد الإلكتروني" };api.resetPassword(email)
        _state.update { it.copy(message="تم إرسال رابط الاسترجاع. افحص البريد الوارد والرسائل غير المرغوب فيها.") }
    }
    suspend fun saveForumPost(id:String?,fields:JSONObject)=lock.withLock {
        require(isApproved(_state.value.profile))
        val before=_state.value.data["forum"].orEmpty().find { it.text("id")==id }
        if(id!=null)require(before!=null&&(before.text("author_id")==api.userId||canManage(_state.value.profile)))
        require(fields.text("title").isNotBlank()&&fields.text("body").isNotBlank()) { "العنوان والمحتوى مطلوبان" }
        val row=fields.copyJson()
        if(id==null){require(row.text("halaqa_id").isNotBlank());row.put("author_id",api.userId)}else row.put("id",id).remove("halaqa_id")
        enqueueLocked("forum_posts","forum",row,before)
    }
    suspend fun saveForumComment(postId:String,id:String?,body:String)=lock.withLock {
        require(isApproved(_state.value.profile));require(body.trim().isNotEmpty())
        val post=_state.value.data["forum"].orEmpty().find { it.text("id")==postId } ?: error("المنشور غير موجود")
        require(post.optBoolean("comments_enabled",true)) { "التعليقات مغلقة" }
        val key="comments_$postId";val before=_state.value.data[key].orEmpty().find { it.text("id")==id }
        if(id!=null)require(before!=null&&(before.text("author_id")==api.userId||canManage(_state.value.profile)))
        val row=JSONObject().put("body",body.trim())
        if(id==null)row.put("post_id",postId).put("author_id",api.userId)else row.put("id",id)
        enqueueLocked("forum_comments",key,row,before)
    }
    suspend fun savePlanStatus(id:String,status:String)=lock.withLock {
        require(canManage(_state.value.profile));require(status in setOf("active","archived"))
        val before=_state.value.data["plans"].orEmpty().find { it.text("id")==id } ?: error("الخطة غير موجودة")
        enqueueLocked("smart_plans","plans",JSONObject().put("id",id).put("status",status),before)
    }
    suspend fun saveSmartPlan(plan:JSONObject)=lock.withLock {
        require(canManage(_state.value.profile))
        require(plan.text("halaqa_id").isNotBlank()) { "اختر الحلقة" }
        require(plan.text("scope_type") in setOf("student","category","halaqa")) { "نطاق الخطة غير صحيح" }
        require(plan.text("plan_type") in setOf("hifz","review","sard","tathbit")) { "نوع الخطة غير صحيح" }
        require(plan.text("start_date").matches(Regex("\\d{4}-\\d{2}-\\d{2}")) && plan.text("end_date").matches(Regex("\\d{4}-\\d{2}-\\d{2}")) && plan.text("end_date") >= plan.text("start_date")) { "تحقق من تاريخي البداية والنهاية" }
        val weekdays=plan.optJSONArray("schedule_weekdays") ?: JSONArray()
        require(weekdays.length()>0) { "اختر يوم دوام واحداً على الأقل" }
        if(plan.text("scope_type")=="student") require(plan.text("student_id").isNotBlank()) { "اختر الطالب" }
        if(plan.text("scope_type")=="category") require(plan.text("category_id").isNotBlank()) { "اختر الفئة" }
        val before=plan.text("id").takeIf { it.isNotBlank() }?.let { id -> _state.value.data["plans"].orEmpty().find { it.text("id")==id } }
        val row=plan.copyJson().apply {
            if(!has("status") || isNull("status")) put("status",before?.text("status") ?: "active")
            if(!has("settings") || isNull("settings")) put("settings",JSONObject())
            if(!has("revision") || isNull("revision")) put("revision",before?.optInt("revision",1) ?: 1)
        }
        enqueueLocked("smart_plans","plans",row,before)
    }
    suspend fun savePlanEvent(planId:String,studentId:String,eventType:String,payload:JSONObject)=lock.withLock {
        require(canManage(_state.value.profile)); require(eventType in setOf("milestone_approved","auto_extension","manual_credit","manual_debit","pause","resume","notification_sent","retry_required","catch_up"))
        val plan=_state.value.data["plans"].orEmpty().find { it.text("id")==planId } ?: error("الخطة غير موجودة")
        val student=_state.value.data["students"].orEmpty().find { it.text("id")==studentId }
        require(planAppliesToStudent(plan,student)) { "الخطة لا تنطبق على هذا الطالب" }
        val clientEventId=UUID.randomUUID().toString()
        val row=JSONObject().put("client_event_id",clientEventId).put("plan_id",planId).put("student_id",studentId).put("event_type",eventType)
            .put("event_date",today()).put("payload",payload.copyJson()).put("created_by",api.userId)
        enqueueLocked("smart_plan_events","plan_events_$planId",row,null)
    }
    suspend fun updateName(name:String)=lock.withLock { val p=_state.value.profile ?: error("ملف الحساب غير محمّل"); val updated=api.updateName(name,p); _state.update { it.copy(profile=updated,message="تم حفظ الاسم") }; persist() }
    suspend fun sync()=lock.withLock {
        val id=api.userId ?: return@withLock
        val p=api.list("profiles",mapOf("id" to "eq.$id")).singleOrNull(); require(isApproved(p)) { "الحساب غير معتمد أو موقوف" }
        flushLocked()
    }
    private suspend fun flushLocked() {
        while(_state.value.queue.isNotEmpty()) {
            val op=_state.value.queue.first()
            try {
                val confirmed=api.applyOperation(op)
                val current=_state.value; val key=op.text("dataset")
                val rows=current.data[key].orEmpty().map { if(it.text("id")==op.text("row_id")) confirmed else it }
                val next=current.copy(queue=current.queue.drop(1),data=current.data+(key to rows)); persist(next); _state.value=next
            } catch(e:CancellationException) { throw e } catch(e:Exception) {
                val marked=op.copyJson().put("error",errorText(e)); val next=_state.value.copy(queue=listOf(marked)+_state.value.queue.drop(1),message=errorText(e)); persist(next); _state.value=next; throw e
            }
        }
    }
    suspend fun discardOperation(id:String)=lock.withLock {
        val op=_state.value.queue.find { it.text("id")==id } ?: return@withLock
        val key=op.text("dataset"); val rowId=op.text("row_id")
        require(_state.value.queue.none { it.text("id")!=id && it.getJSONObject("desired").text("session_id")==rowId }) { "توجد تعديلات تابعة لهذه الجلسة؛ لا يمكن إسقاطها وحدها" }
        val rows=_state.value.data[key].orEmpty().filterNot { it.text("id")==rowId }+listOfNotNull(op.optJSONObject("before"))
        val next=_state.value.copy(queue=_state.value.queue.filterNot { it.text("id")==id },data=_state.value.data+(key to rows)); persist(next); _state.value=next
    }
    suspend fun signOut()=lock.withLock {
        require(_state.value.queue.isEmpty()) { "توجد تعديلات لم تُرفع بعد. زامنها قبل تسجيل الخروج" }
        val id=api.userId
        try { api.signOut() } finally { if(id!=null) withContext(Dispatchers.IO) { store.remove("snapshot_$id") }; _state.value=AppState(starting=false) }
    }
    private suspend fun persist(value:AppState=_state.value)=withContext(Dispatchers.IO) {
        val id=api.userId ?: return@withContext
        val body=JSONObject().put("owner",id).put("profile",value.profile).put("updatedAt",value.updatedAt).put("queue",value.queue.json())
            .put("data",JSONObject().apply { value.data.forEach { (k,v)->put(k,v.json()) } })
        store.write("snapshot_$id",body.toString())
    }
    private suspend fun restore()=withContext(Dispatchers.IO) {
        val id=api.userId ?: return@withContext; val raw=store.read("snapshot_$id") ?: return@withContext; val body=JSONObject(raw)
        check(body.getString("owner")==id); val data=body.getJSONObject("data"); val map=data.keys().asSequence().associateWith { data.getJSONArray(it).rows() }
        _state.update { it.copy(profile=body.optJSONObject("profile"),data=map,cached=map.keys+"profile",queue=body.optJSONArray("queue")?.rows().orEmpty(),updatedAt=body.text("updatedAt")) }
    }
    private fun scheduleSync() {
        val constraints=Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val work=OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(constraints).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).build()
        WorkManager.getInstance(context).enqueueUniqueWork("halaqati-native-outbox",ExistingWorkPolicy.APPEND_OR_REPLACE,work)
    }
    companion object {
        // Only applicationContext is retained through the private constructor.
        @android.annotation.SuppressLint("StaticFieldLeak")
        @Volatile private var instance:Repository?=null
        fun get(c:Context):Repository=instance ?: synchronized(this) { instance ?: Repository(c.applicationContext).also { instance=it } }
    }
}
private fun LocalDateCheck(s:String) { java.time.LocalDate.parse(s) }
class SyncWorker(context:Context,params:WorkerParameters):CoroutineWorker(context,params) {
    override suspend fun doWork():Result {
        val repo=Repository.get(applicationContext)
        return try { repo.initialize(); repo.sync(); Result.success() }
        catch(e:CancellationException) { throw e }
        catch(_:Conflict) { Result.failure() }
        catch(e:ApiFailure) { if(e.status>=500 || e.status==429) Result.retry() else Result.failure() }
        catch(_:java.io.IOException) { Result.retry() }
        catch(_:Exception) { Result.failure() }
    }
}
