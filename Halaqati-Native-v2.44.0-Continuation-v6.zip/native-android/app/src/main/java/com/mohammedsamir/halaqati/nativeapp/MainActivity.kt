package com.mohammedsamir.halaqati.nativeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.EventNote
import androidx.compose.material.icons.automirrored.outlined.Assignment
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); enableEdgeToEdge(); setContent { HalaqatiApp() } }
}
data class Destination(val key:String,val title:String,val icon:ImageVector)
private val navigation=listOf(Destination("home","الرئيسية",Icons.Outlined.Home),Destination("students","الطلاب",Icons.Outlined.People),Destination("sessions","الجلسات",Icons.AutoMirrored.Outlined.EventNote),Destination("plans","الخطط",Icons.AutoMirrored.Outlined.Assignment),Destination("more","المزيد",Icons.Outlined.MoreHoriz))
private val extras=listOf(Destination("halaqas","الحلقات والفئات",Icons.Outlined.GridView),Destination("announcements","الإعلانات",Icons.Outlined.Campaign),Destination("forum","المنتدى",Icons.AutoMirrored.Outlined.Chat),Destination("notifications","الإشعارات",Icons.Outlined.Notifications),Destination("sync","حالة المزامنة",Icons.Outlined.Sync),Destination("settings","الحساب والإعدادات",Icons.Outlined.Settings))
private val padding=PaddingValues(16.dp,12.dp,16.dp,28.dp)
private val green=Color(0xFF126B56)

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun HalaqatiApp() {
    val context=LocalContext.current; val repo=remember { Repository.get(context) }; val state by repo.state.collectAsStateWithLifecycle()
    var route by rememberSaveable { mutableStateOf("home") }; var detail by rememberSaveable { mutableStateOf("") }
    var theme by rememberSaveable { mutableStateOf("system") }; var form by rememberSaveable { mutableStateOf("") }
    val snackbar=remember { SnackbarHostState() }
    val dark=theme=="dark" || (theme=="system" && isSystemInDarkTheme())
    val colors=if(dark) darkColorScheme(primary=Color(0xFF86D8B9),background=Color(0xFF101B17),surface=Color(0xFF17261F)) else lightColorScheme(primary=green,background=Color(0xFFF5F8F6),surface=Color.White)
    fun navigate(key:String) { route=key; detail=""; form="" }
    LaunchedEffect(Unit) { repo.launch { initialize(); if(repo.state.value.signedIn) refresh() } }
    LaunchedEffect(state.signedIn) { if(!state.signedIn) navigate("home") }
    LaunchedEffect(state.message) { state.message?.let { snackbar.showSnackbar(it); repo.dismiss() } }
    BackHandler(form.isNotBlank() || detail.isNotBlank() || route!="home") { when { form.isNotBlank()->form=""; detail.isNotBlank()->detail=""; else->route="home" } }
    MaterialTheme(colorScheme=colors,shapes=Shapes(medium=RoundedCornerShape(18.dp),large=RoundedCornerShape(24.dp))) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize()) {
                if(state.starting) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) { CircularProgressIndicator() }
                else if(!state.signedIn) Scaffold(snackbarHost={ SnackbarHost(snackbar) }) { inset-> LoginScreen(state.busy,{e,p->repo.launch { signIn(e,p) }},Modifier.padding(inset),repo=repo) }
                else if(!isApproved(state.profile)) Scaffold(snackbarHost={ SnackbarHost(snackbar) }) { inset->
                    Column(Modifier.fillMaxSize().padding(inset).padding(28.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
                        Icon(Icons.Outlined.VerifiedUser,null,Modifier.size(64.dp),tint=MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(20.dp)); Text(state.profile?.text("full_name").orEmpty(),style=MaterialTheme.typography.headlineSmall)
                        Text(accessMessage(state.profile),Modifier.padding(vertical=24.dp))
                        Button({repo.launch { refresh() }},enabled=!state.busy) { Text("تحقق من الاعتماد") }
                        TextButton({repo.launch { signOut() }},enabled=!state.busy) { Text("تسجيل الخروج") }
                    }
                } else {
                    val tabs=if(state.profile?.text("role")=="guardian") navigation.filter { it.key!="sessions" } else navigation
                    BoxWithConstraints {
                        val wide=maxWidth>=840.dp
                        Row(Modifier.fillMaxSize()) {
                            if(wide) NavigationRail(Modifier.fillMaxHeight().statusBarsPadding()) {
                                Icon(Icons.AutoMirrored.Outlined.MenuBook,"حلقاتي",Modifier.padding(16.dp).size(32.dp),tint=MaterialTheme.colorScheme.primary)
                                tabs.forEach { d->NavigationRailItem(selected=route==d.key,onClick={navigate(d.key)},icon={Icon(d.icon,d.title)},label={Text(d.title)}) }
                            }
                            Scaffold(modifier=Modifier.weight(1f),snackbarHost={SnackbarHost(snackbar)},topBar={
                                TopAppBar(title={Text(if(detail.isBlank()) (navigation+extras).find { it.key==route }?.title ?: "حلقاتي" else "التفاصيل",fontWeight=FontWeight.Bold)},navigationIcon={
                                    if(detail.isNotBlank()) IconButton({detail=""}) { Icon(Icons.AutoMirrored.Outlined.ArrowBack,"رجوع") }
                                },actions={
                                    if(state.queue.isNotEmpty()) TextButton({navigate("sync")}) { Text("${state.queue.size} معلّقة") }
                                    IconButton({repo.launch { refresh() }},enabled=!state.busy) { Icon(Icons.Outlined.Refresh,"تحديث") }
                                })
                            },bottomBar={if(!wide) NavigationBar { tabs.forEach { d->NavigationBarItem(selected=route==d.key,onClick={navigate(d.key)},icon={Icon(d.icon,d.title)},label={Text(d.title)}) } }}) { inset ->
                                PullToRefreshBox(isRefreshing=state.busy,onRefresh={repo.launch { refresh() }},modifier=Modifier.fillMaxSize().padding(inset)) {
                                    AnimatedContent(targetState=route to detail,transitionSpec={fadeIn() togetherWith fadeOut()},label="page") { (page,id)->
                                        when(page) {
                                            "home"->HomeScreen(state,::navigate)
                                            "students"->if(id.isBlank()) StudentsScreen(state,{detail=it;repo.launch{loadStudent(it)}},{form="student:new"}) else StudentScreen(state,id,repo,{form="student:$id"})
                                            "sessions"->if(id.isBlank()) SessionsScreen(state,{detail=it;repo.launch{loadRoster(it)}},{form="session:new"}) else RosterScreen(state,id,repo,{form=it})
                                            "plans"->NativePlansScreen(state,id,repo,{detail=it},{form="plan:new"},{form="plan:$it"})
                                            "halaqas"->HalaqasScreen(state)
                                            "announcements","notifications"->ContentScreen(state,page,id,repo) {detail=it}
                                            "forum"->ForumScreen(state,id,repo,{detail=it;repo.launch{loadComments(it)}},{form=it})
                                            "sync"->SyncScreen(state,repo) {form="reauth"}
                                            "settings"->SettingsScreen(state,repo,theme,{theme=it},{form="name"})
                                            else->LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(12.dp)) {items(extras){d->ItemCard(d.title,"",d.icon,{navigate(d.key)})}}
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if(form.isNotBlank()) ModalBottomSheet(onDismissRequest={form=""},sheetState=rememberModalBottomSheetState(skipPartiallyExpanded=true)) {
                        when {
                            form.startsWith("student:")->StudentForm(state,form.substringAfter(':').takeUnless {it=="new"},repo) {form=""}
                            form.startsWith("session:")->SessionForm(state,form.substringAfter(':').takeUnless {it=="new"},repo) {form=""}
                            form.startsWith("rec:")->NativeRecitationForm(state,detail,form.substringAfter(':'),repo) {form=""}
                            form.startsWith("plan:")->NativeSmartPlanForm(state,form.substringAfter(':').takeUnless { it=="new" },repo) {form=""}
                            form.startsWith("note:")->NoteForm(state,detail,form.substringAfter(':'),repo) {form=""}
                            form=="reauth"->LoginScreen(state.busy,{e,p->repo.launch{signIn(e,p)};form=""},Modifier.heightIn(max=600.dp))
                            form.startsWith("forum:")->ForumForm(state,form.substringAfter(':').takeUnless {it=="new"},repo){form=""}
                            form=="name"->NameForm(state,repo) {form=""}
                        }
                    }
                }
            }
        }
    }
}
@Composable private fun LoginScreen(busy:Boolean,login:(String,String)->Unit,modifier:Modifier=Modifier,repo:Repository?=null) {
    var mode by rememberSaveable { mutableStateOf("login") };var name by rememberSaveable {mutableStateOf("")};var phone by rememberSaveable {mutableStateOf("")};var role by rememberSaveable {mutableStateOf("guardian")}
    var email by rememberSaveable { mutableStateOf("") };var password by remember { mutableStateOf("") }
    Box(modifier.fillMaxSize().imePadding(),contentAlignment=Alignment.Center) {
        Column(Modifier.widthIn(max=460.dp).verticalScroll(rememberScrollState()).padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(16.dp)) {
            Surface(shape=RoundedCornerShape(26.dp),color=MaterialTheme.colorScheme.primaryContainer) { Icon(Icons.AutoMirrored.Outlined.MenuBook,null,Modifier.padding(22.dp).size(56.dp),tint=MaterialTheme.colorScheme.primary) }
            Text("حلقاتي",style=MaterialTheme.typography.displaySmall,fontWeight=FontWeight.Bold);Text("أهل القرآن وأثرهم كل يوم")
            OutlinedTextField(email,{email=it},Modifier.fillMaxWidth(),label={Text("البريد الإلكتروني")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Email),enabled=!busy)
            if(mode=="signup"){OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("الاسم الكامل")});OutlinedTextField(phone,{phone=it},Modifier.fillMaxWidth(),label={Text("الهاتف")});Choices("نوع الحساب",linkedMapOf("guardian" to "ولي الأمر","teacher" to "محفّظ","supervisor" to "مشرف"),role){role=it}}
            if(mode!="reset") OutlinedTextField(password,{password=it},Modifier.fillMaxWidth(),label={Text("كلمة المرور")},singleLine=true,visualTransformation=PasswordVisualTransformation(),enabled=!busy)
            Button({
                when(mode){
                    "signup"->repo?.launch { register(email,password,name,phone,role);password="" }
                    "reset"->repo?.launch { resetPassword(email) }
                    else->login(email,password)
                }
            },Modifier.fillMaxWidth().heightIn(min=52.dp),enabled=!busy&&email.isNotBlank()&&(mode=="reset"||password.isNotBlank())){Text(when(mode){"signup"->"إرسال طلب الحساب";"reset"->"إرسال رابط الاسترجاع";else->"تسجيل الدخول"})}
            if(repo!=null){TextButton({mode=if(mode=="signup")"login" else "signup"},enabled=!busy){Text(if(mode=="signup")"لدي حساب" else "إنشاء حساب")};TextButton({mode=if(mode=="reset")"login" else "reset"},enabled=!busy){Text(if(mode=="reset")"العودة للدخول" else "نسيت كلمة المرور")}}
            if(busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        }
    }
}
@Composable private fun ErrorBanner(state:AppState,key:String) {
    val message=state.errors[key] ?: if(key in state.cached) "بيانات محفوظة على الجهاز · اسحب للتحديث" else null
    if(message!=null) Surface(color=if(key in state.errors) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,shape=RoundedCornerShape(12.dp)) {Text(message,Modifier.fillMaxWidth().padding(12.dp),style=MaterialTheme.typography.bodySmall)}
}
@Composable private fun EmptyState(text:String="لا توجد بيانات في هذا العرض") {Column(Modifier.fillMaxWidth().padding(32.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Outlined.Inbox,null,Modifier.size(40.dp));Spacer(Modifier.height(12.dp));Text(text)}}
@Composable private fun ItemCard(title:String,subtitle:String,icon:ImageVector,onClick:(()->Unit)?=null,content:@Composable ColumnScope.()->Unit={}) {
    val body:@Composable ColumnScope.()->Unit={
        Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            Surface(shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.primaryContainer){Icon(icon,null,Modifier.padding(12.dp).size(24.dp),tint=MaterialTheme.colorScheme.primary)}
            Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.SemiBold);if(subtitle.isNotBlank())Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}
            if(onClick!=null) Icon(Icons.Outlined.ChevronLeft,null)
        };content()
    }
    if(onClick!=null) ElevatedCard(onClick=onClick,modifier=Modifier.fillMaxWidth().animateContentSize(),content=body) else ElevatedCard(modifier=Modifier.fillMaxWidth().animateContentSize(),content=body)
}
@Composable private fun Info(label:String,value:String) {if(value.isNotBlank())Row(Modifier.fillMaxWidth().padding(vertical=6.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){Text(label,Modifier.weight(.4f),color=MaterialTheme.colorScheme.onSurfaceVariant);Text(value,Modifier.weight(.6f))}}
@Composable private fun Section(text:String){Text(text,Modifier.padding(top=8.dp,bottom=4.dp),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)}
@OptIn(ExperimentalLayoutApi::class)
@Composable private fun Choices(label:String, choices:Map<String,String>, selected:String, select:(String)->Unit) {
    Column {
        Text(label,style=MaterialTheme.typography.labelMedium)
        FlowRow(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            choices.forEach { (key,title) ->
                FilterChip(selected=key==selected,onClick={select(key)},label={Text(title)})
            }
        }
    }
}
@Composable private fun HomeScreen(state:AppState,navigate:(String)->Unit) {
    LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(green,Color(0xFF214A43))),RoundedCornerShape(24.dp)).padding(24.dp)){Text("السلام عليكم",color=Color.White.copy(alpha=.8f));Text(state.profile?.text("full_name").orEmpty(),color=Color.White,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(18.dp));Text("${roleNames[state.profile?.text("role")].orEmpty()} · ${today()}",color=Color(0xFFE6C275))} }
        item {ErrorBanner(state,"profile");ErrorBanner(state,"students");ErrorBanner(state,"sessions")}
        item {Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){Metric("الطلاب النشطون",state.data["students"]?.count{it.text("status")=="active"}?.toString()?:"—",Modifier.weight(1f)){navigate("students")};Metric("جلسات اليوم",state.data["sessions"]?.count{it.text("session_date")==today()&&it.text("status")!="cancelled"}?.toString()?:"—",Modifier.weight(1f)){navigate("sessions")}}}
        if(canManage(state.profile)) item {Button({navigate("sessions")},Modifier.fillMaxWidth().heightIn(min=52.dp)){Icon(Icons.Outlined.PlayArrow,null);Text("جلسة اليوم")}}
        if(state.queue.isNotEmpty()) item {ItemCard("${state.queue.size} تعديلات بانتظار المزامنة","تبقى محفوظة عند انقطاع الإنترنت",Icons.Outlined.CloudUpload,{navigate("sync")})}
        item {Section("وصول سريع")}
        items((navigation.filter{it.key !in setOf("home","more")}+extras).chunked(2)) {group->Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){group.forEach{d->Card(onClick={navigate(d.key)},modifier=Modifier.weight(1f)){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Icon(d.icon,null,tint=MaterialTheme.colorScheme.primary);Text(d.title)}}};if(group.size==1)Spacer(Modifier.weight(1f))}}
    }
}
@Composable private fun Metric(label:String,value:String,modifier:Modifier,click:()->Unit){OutlinedCard(onClick=click,modifier=modifier){Column(Modifier.padding(18.dp)){Text(value,style=MaterialTheme.typography.headlineMedium,color=MaterialTheme.colorScheme.primary);Text(label,style=MaterialTheme.typography.bodySmall)}}}
@Composable private fun StudentsScreen(state:AppState,open:(String)->Unit,add:()->Unit){
    var search by rememberSaveable{mutableStateOf("")};var track by rememberSaveable{mutableStateOf("all")};var all by rememberSaveable{mutableStateOf(false)}
    val rows=state.data["students"].orEmpty().filter{(all||it.text("status")=="active")&&(track=="all"||canonicalTrack(it.text("track_code"))==track)&&it.text("full_name").contains(search.trim(),true)}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{ErrorBanner(state,"students")}
        item{OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),label={Text("ابحث عن طالب")},leadingIcon={Icon(Icons.Outlined.Search,null)},singleLine=true)}
        item{Choices("المسار",linkedMapOf("all" to "الجميع")+tracks,track){track=it}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){FilterChip(all,{all=!all},label={Text("جميع الحالات")});if(canManage(state.profile))FilledTonalButton(add){Icon(Icons.Outlined.Add,null);Text("إضافة طالب")}}}
        item{Text("${rows.size} طالب")};if(rows.isEmpty())item{EmptyState()}
        items(rows,key={it.text("id")}){s->ItemCard(s.text("full_name"),tracks[canonicalTrack(s.text("track_code"))].orEmpty()+if(s.optBoolean("_pending"))" · غير مرفوع" else "",Icons.Outlined.Person,{open(s.text("id"))})}
    }
}
@Composable private fun StudentScreen(state:AppState,id:String,repo:Repository,edit:()->Unit){
    val s=state.data["students"].orEmpty().find{it.text("id")==id};if(s==null){EmptyState("الطالب غير متاح");return}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{ItemCard(s.text("full_name"),tracks[canonicalTrack(s.text("track_code"))].orEmpty(),Icons.Outlined.Person)}
        item{if(canManage(state.profile))FilledTonalButton(edit,enabled=!state.busy){Text("تعديل بيانات الطالب")}}
        item{ElevatedCard{Column(Modifier.padding(16.dp)){Info("الحالة",statusNames[s.text("status")]?:s.text("status"));Info("تاريخ الالتحاق",s.text("enrollment_date"));Info("الفئة",state.data["categories"].orEmpty().find{it.text("id")==s.text("category_id")}?.text("name").orEmpty());Info("الميلاد",s.text("date_of_birth"));Info("الصف",s.text("school_grade"));if(canManage(state.profile)){Info("هاتف ولي الأمر",s.text("guardian_phone"));Info("العنوان",s.text("address"));Info("ملاحظات",s.text("notes"))}}}}
        item{OutlinedButton({repo.launch{loadStudent(id)}},enabled=!state.busy){Text("تحديث تفاصيل الطالب")};ErrorBanner(state,"dashboard_$id");Section("إنجاز الشهر · ${monthStart()} — ${today()}")}
        val ranks=state.data["dashboard_$id"]?.firstOrNull()?.optJSONObject("ranks")
        if(ranks!=null)items(listOf("hifz" to "الحفظ","review" to "المراجعة","sard" to "السرد")){(key,label)->ranks.optJSONObject(key)?.let{v->ItemCard(label,"",Icons.Outlined.EmojiEvents){Column(Modifier.padding(16.dp)){Info("الصفحات",v.text("pages"));Info("النقاط",v.text("points"));Info("ترتيب الحلقة",v.text("halaqa_rank").ifBlank{"لم يُحتسب"});Info("ترتيب الفئة",v.text("category_rank").ifBlank{"لم يُحتسب"})}}}}
        item{Section("سجل التسميع");ErrorBanner(state,"recitations_$id")}
        items(state.data["recitations_$id"].orEmpty(),key={it.text("id")}){RecitationCard(it)}
    }
}
@Composable private fun RecitationCard(r:JSONObject){ItemCard(activityNames[r.text("activity_type")]?:r.text("activity_type"),evaluationNames[r.text("evaluation")]?:r.text("evaluation"),Icons.AutoMirrored.Outlined.MenuBook){Column(Modifier.padding(16.dp)){Info("الصفحات",r.text("pages_count"));Info("النقاط",r.text("points"));Info("من صفحة",r.text("start_page"));Info("إلى صفحة",r.text("end_page"));Info("الأخطاء",r.text("mistakes"));Info("التنبيهات",r.text("prompts"));Info("ملاحظة",r.text("teacher_note"))}}}
@Composable private fun SessionsScreen(state:AppState,open:(String)->Unit,add:()->Unit){var kind by rememberSaveable{mutableStateOf("all")};val rows=state.data["sessions"].orEmpty().filter{kind=="all"||it.text("session_type")==kind}.sortedByDescending{it.text("session_date")}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{ErrorBanner(state,"sessions");if(canManage(state.profile))Button(add,enabled=!state.busy){Icon(Icons.Outlined.Add,null);Text("إنشاء جلسة")}}
        item{Choices("نوع الجلسة",linkedMapOf("all" to "الكل")+sessionNames,kind){kind=it}}
        if(rows.isEmpty())item{EmptyState()};items(rows,key={it.text("id")}){s->ItemCard(s.text("title").ifBlank{sessionNames[s.text("session_type")]?:"جلسة"},"${s.text("session_date")} · ${statusNames[s.text("status")].orEmpty()}"+if(s.optBoolean("_pending"))" · غير مرفوعة" else "",Icons.AutoMirrored.Outlined.EventNote,{open(s.text("id"))})}
    }
}
@OptIn(ExperimentalLayoutApi::class)
@Composable private fun RosterScreen(state:AppState,id:String,repo:Repository,showForm:(String)->Unit){
    val context=LocalContext.current;val session=state.data["sessions"].orEmpty().find{it.text("id")==id};if(session==null){EmptyState("الجلسة غير موجودة");return}
    val ak="attendance_records_$id";val nk="student_daily_notes_$id";val rk="recitation_entries_$id"
    val attendance=state.data[ak].orEmpty();val notes=state.data[nk].orEmpty();val recs=state.data[rk].orEmpty()
    val recorded=(attendance+notes+recs).map{it.text("student_id")}.toSet()
    val students=state.data["students"].orEmpty().filter{it.text("id") in recorded || (it.text("halaqa_id")==session.text("halaqa_id")&&it.text("status")=="active")}
    var confirmClose by remember{mutableStateOf(false)}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{ItemCard(session.text("title").ifBlank{"الجلسة اليومية"},session.text("session_date"),Icons.AutoMirrored.Outlined.EventNote)}
        item{FlowRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton({repo.launch{loadRoster(id)}},enabled=!state.busy){Text("تحديث الكشف")}
            if(canManage(state.profile)){OutlinedButton({showForm("session:$id")},enabled=!state.busy){Text("تعديل الجلسة")};FilledTonalButton({confirmClose=true},enabled=!state.busy){Text(if(session.text("status")=="open")"إنهاء الجلسة" else "فتح للتعديل")}}
            OutlinedButton({repo.launch{val file=withContext(Dispatchers.IO){NativePdf.sessionReport(context,state,id)};NativePdf.share(context,file)}},enabled=!state.busy){Icon(Icons.Outlined.PictureAsPdf,null);Text("تقرير الجلسة")}
        }}
        item{ErrorBanner(state,ak);ErrorBanner(state,nk);ErrorBanner(state,rk)}
        if(students.isEmpty())item{EmptyState()}
        items(students,key={it.text("id")}){s->
            val sid=s.text("id");var expanded by rememberSaveable(id,sid){mutableStateOf(false)}
            val a=attendance.find{it.text("student_id")==sid};val n=notes.find{it.text("student_id")==sid}
            ItemCard(s.text("full_name"),if(ak !in state.data)"لم يُحمّل الحضور" else attendanceNames[a?.text("status")]?:"لم يُسجّل حضور",Icons.Outlined.Person,{expanded=!expanded}){
                if(canManage(state.profile)&&session.text("status")=="open")FlowRow(Modifier.padding(horizontal=12.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                    attendanceNames.forEach{(value,label)->FilterChip(selected=a?.text("status")==value,onClick={repo.launch{attendance(id,sid,value)}},enabled=!state.busy,label={Text(label)})}
                    FilledTonalButton({showForm("rec:$sid")},enabled=!state.busy){Text("تسميع")};OutlinedButton({showForm("note:$sid")},enabled=!state.busy){Text("ملاحظة")}
                }
                if(expanded)Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Info("ملاحظة المحفّظ",n?.text("teacher_comment").orEmpty());Info("الواجب",n?.text("homework").orEmpty());recs.filter{it.text("student_id")==sid}.forEach{RecitationCard(it)}}
            }
        }
    }
    if(confirmClose)AlertDialog(onDismissRequest={confirmClose=false},title={Text("تغيير حالة الجلسة؟")},text={Text("ستُحفظ الحالة وتُزامن مع بقية الأجهزة.")},confirmButton={TextButton({confirmClose=false;repo.launch{setSessionStatus(id,if(session.text("status")=="open")"closed" else "open")}}){Text("تأكيد")}},dismissButton={TextButton({confirmClose=false}){Text("إلغاء")}})
}
@Composable private fun PlansScreen(state:AppState,id:String,open:(String)->Unit){var status by rememberSaveable{mutableStateOf("active")};val rows=state.data["plans"].orEmpty().filter{if(id.isNotBlank())it.text("id")==id else status=="all"||it.text("status")==status}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{ErrorBanner(state,"plans");if(id.isBlank())Choices("حالة الخطة",linkedMapOf("active" to "نشطة","archived" to "مؤرشفة","all" to "الجميع"),status){status=it}}
        if(rows.isEmpty())item{EmptyState()};items(rows,key={it.text("id")}){p->ItemCard(p.text("title"),state.data["students"].orEmpty().find{it.text("id")==p.text("student_id")}?.text("full_name").orEmpty(),Icons.AutoMirrored.Outlined.Assignment,if(id.isBlank())({open(p.text("id"))})else null){if(id.isNotBlank())Column(Modifier.padding(16.dp)){Info("الحالة",statusNames[p.text("status")].orEmpty());Info("البداية",p.text("start_date"));Info("النهاية",p.text("end_date"));Info("الهدف بالصفحات",p.text("target_pages"));Info("صفحة البداية",p.text("range_start_page"));Info("صفحة النهاية",p.text("range_end_page"));Info("ملاحظات",p.text("note"))}}}
    }
}
@Composable private fun HalaqasScreen(state:AppState) {
    LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { ErrorBanner(state,"halaqas") }
        items(state.data["halaqas"].orEmpty(),key={it.text("id")}) { h ->
            ItemCard(h.text("name"),h.text("center_name"),Icons.Outlined.GridView) {
                Column(Modifier.padding(16.dp)) {
                    Info("الوصف",h.text("description"))
                    state.data["categories"].orEmpty().filter { it.text("halaqa_id")==h.text("id") }.forEach { Info("الفئة",it.text("name")) }
                }
            }
        }
    }
}
@Composable private fun ContentScreen(state:AppState,page:String,id:String,repo:Repository,open:(String)->Unit){val rows=state.data[page].orEmpty().filter{id.isBlank()||it.text("id")==id};LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(12.dp)){
    item{ErrorBanner(state,page)};if(rows.isEmpty())item{EmptyState()};items(rows,key={it.text("id")}){r->ItemCard(r.text("title"),r.text("created_at").take(10),extras.find{it.key==page}?.icon?:Icons.Outlined.Campaign,if(id.isBlank())({open(r.text("id"))})else null){Text(r.text("body").ifBlank{r.text("content")}.ifBlank{r.text("message")},Modifier.padding(16.dp),maxLines=if(id.isBlank())3 else Int.MAX_VALUE)}}
    if(page=="forum"&&id.isNotBlank()){item{OutlinedButton({repo.launch{loadComments(id)}},enabled=!state.busy){Text("تحديث التعليقات")};ErrorBanner(state,"comments_$id")};items(state.data["comments_$id"].orEmpty(),key={it.text("id")}){r->ItemCard(r.text("created_at").take(10),"",Icons.AutoMirrored.Outlined.Chat){Text(r.text("body"),Modifier.padding(16.dp))}}}
}}
@Composable private fun SyncScreen(state:AppState,repo:Repository,reauth:()->Unit){var discard by remember{mutableStateOf<String?>(null)};LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(12.dp)){
    item{Section("${state.queue.size} تعديلات محفوظة");Text("العمليات تُرسل بترتيبها. يبقى أي تعارض محفوظاً للمراجعة.")}
    item{Button({repo.launch{refresh()}},enabled=!state.busy){Text("مزامنة الآن")};OutlinedButton(reauth,enabled=!state.busy){Text("إعادة التحقق من تسجيل الدخول")}}
    items(state.queue,key={it.text("id")}){op->ItemCard(op.getJSONObject("display").text("full_name").ifBlank{op.getJSONObject("display").text("title")}.ifBlank{"تعديل محفوظ"},op.text("created_at").take(16),Icons.Outlined.CloudUpload){Column(Modifier.padding(16.dp)){if(op.text("error").isNotBlank())Text(op.text("error"),color=MaterialTheme.colorScheme.error);TextButton({discard=op.text("id")},enabled=!state.busy){Text("إلغاء هذا التعديل المحلي")}}}}
    if(state.queue.isEmpty())item{EmptyState("لا توجد تعديلات معلّقة")}
};if(discard!=null)AlertDialog(onDismissRequest={discard=null},title={Text("إلغاء التعديل المحلي؟")},text={Text("سيُحذف هذا الطلب من الجهاز ولن يُرفع إلى الخادم.")},confirmButton={TextButton({val id=discard!!;discard=null;repo.launch{discardOperation(id)}}){Text("إلغاء التعديل")}},dismissButton={TextButton({discard=null}){Text("رجوع")}})}
@Composable private fun SettingsScreen(state:AppState,repo:Repository,theme:String,setTheme:(String)->Unit,editName:()->Unit){var logout by remember{mutableStateOf(false)};LazyColumn(Modifier.fillMaxSize(),contentPadding=padding,verticalArrangement=Arrangement.spacedBy(14.dp)){
    item{ItemCard(state.profile?.text("full_name").orEmpty(),roleNames[state.profile?.text("role")].orEmpty(),Icons.Outlined.AccountCircle,editName)}
    item{Choices("المظهر",linkedMapOf("system" to "حسب الجهاز","light" to "فاتح","dark" to "داكن"),theme,setTheme)}
    item{OutlinedButton({logout=true},enabled=!state.busy){Text("تسجيل الخروج")};Text(BuildConfig.VERSION_NAME,style=MaterialTheme.typography.bodySmall)}
};if(logout)AlertDialog(onDismissRequest={logout=false},title={Text("تسجيل الخروج؟")},text={Text("يجب رفع التعديلات المعلقة أولاً. ستُمسح نسخة العرض المحفوظة من هذا التطبيق.")},confirmButton={TextButton({logout=false;repo.launch{signOut()}}){Text("تسجيل الخروج")}},dismissButton={TextButton({logout=false}){Text("إلغاء")}})}
