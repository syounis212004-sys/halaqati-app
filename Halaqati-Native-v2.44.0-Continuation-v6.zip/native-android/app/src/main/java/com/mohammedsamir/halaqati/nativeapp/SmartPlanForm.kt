package com.mohammedsamir.halaqati.nativeapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private val weekdayLabels = linkedMapOf(0 to "الأحد", 1 to "الاثنين", 2 to "الثلاثاء", 3 to "الأربعاء", 4 to "الخميس", 5 to "الجمعة", 6 to "السبت")
private val planTypeLabels = linkedMapOf("hifz" to "حفظ جديد", "review" to "مراجعة", "sard" to "سرد", "tathbit" to "تثبيت")
private val goalUnitLabels = linkedMapOf("pages" to "صفحات", "juz" to "أجزاء", "rub" to "أرباع", "surah" to "سور", "ayahs" to "آيات")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NativeSmartPlanForm(state: AppState, planId: String?, repo: Repository, close: () -> Unit) {
    val old = state.data["plans"].orEmpty().find { it.text("id") == planId }
    val firstHalaqa = state.data["halaqas"].orEmpty().firstOrNull()?.text("id").orEmpty()
    val firstStudent = state.data["students"].orEmpty().firstOrNull { it.text("status") == "active" && it.text("halaqa_id") == firstHalaqa }?.text("id").orEmpty()
    var scope by rememberSaveable(planId) { mutableStateOf(old?.text("scope_type").orEmpty().ifBlank { "student" }) }
    var halaqa by rememberSaveable(planId) { mutableStateOf(old?.text("halaqa_id").orEmpty().ifBlank { firstHalaqa }) }
    var student by rememberSaveable(planId) { mutableStateOf(old?.text("student_id").orEmpty().ifBlank { firstStudent }) }
    var category by rememberSaveable(planId) { mutableStateOf(old?.text("category_id").orEmpty()) }
    var type by rememberSaveable(planId) { mutableStateOf(old?.text("plan_type").orEmpty().ifBlank { "hifz" }) }
    var unit by rememberSaveable(planId) { mutableStateOf(old?.text("goal_unit").orEmpty().ifBlank { "pages" }) }
    var start by rememberSaveable(planId) { mutableStateOf(rangeStart(old, unit)) }
    var end by rememberSaveable(planId) { mutableStateOf(rangeEnd(old, unit)) }
    var startSurah by rememberSaveable(planId) { mutableStateOf(old?.optInt("range_start_surah", 1)?.toString() ?: "1") }
    var startAyah by rememberSaveable(planId) { mutableStateOf(old?.optInt("range_start_ayah", 1)?.toString() ?: "1") }
    var endSurah by rememberSaveable(planId) { mutableStateOf(old?.optInt("range_end_surah", 1)?.toString() ?: "1") }
    var endAyah by rememberSaveable(planId) { mutableStateOf(old?.optInt("range_end_ayah", 7)?.toString() ?: "7") }
    var target by rememberSaveable(planId) { mutableStateOf(storedTarget(old).toString()) }
    var title by rememberSaveable(planId) { mutableStateOf(old?.text("title").orEmpty()) }
    var startDate by rememberSaveable(planId) { mutableStateOf(old?.text("start_date").orEmpty().ifBlank { today() }) }
    var endDate by rememberSaveable(planId) { mutableStateOf(old?.text("end_date").orEmpty().ifBlank { PlanEngine.addDays(today(), 30) }) }
    var catchUp by rememberSaveable(planId) { mutableStateOf(old?.opt("catch_up_weekday")?.toString()?.takeUnless { it == "null" }.orEmpty()) }
    var cap by rememberSaveable(planId) { mutableStateOf(old?.optDouble("max_daily_multiplier", 1.5)?.toString() ?: "1.5") }
    var minimum by rememberSaveable(planId) { mutableStateOf(old?.text("minimum_evaluation").orEmpty().ifBlank { "very_good" }) }
    var reviewTier by rememberSaveable(planId) { mutableStateOf(old?.text("review_tier").orEmpty().takeUnless { it.isBlank() || it == "none" } ?: "both") }
    var near by rememberSaveable(planId) { mutableStateOf(old?.optDouble("near_revision_pages", 7.0)?.toString() ?: "7") }
    var far by rememberSaveable(planId) { mutableStateOf(old?.optDouble("far_revision_pages", 20.0)?.toString() ?: "20") }
    var milestone by rememberSaveable(planId) { mutableStateOf(old?.text("milestone_mode").orEmpty().ifBlank { "juz" }) }
    var delay by rememberSaveable(planId) { mutableStateOf(old?.optDouble("delay_alert_days", 3.0)?.toString() ?: "3") }
    var note by rememberSaveable(planId) { mutableStateOf(old?.text("note").orEmpty()) }
    var weekdays by rememberSaveable(planId) { mutableStateOf(old?.optJSONArray("schedule_weekdays")?.ints()?.joinToString(",") ?: "0,1,2,3,4") }
    var autoExtend by rememberSaveable(planId) { mutableStateOf(old?.optBoolean("auto_extend", true) != false) }
    var qualityGate by rememberSaveable(planId) { mutableStateOf(old?.optBoolean("quality_gate_enabled", true) != false) }
    var milestoneApproval by rememberSaveable(planId) { mutableStateOf(old?.optBoolean("milestone_requires_approval", true) != false) }
    var homePush by rememberSaveable(planId) { mutableStateOf(old?.optBoolean("home_prep_push", true) != false) }
    val students = state.data["students"].orEmpty().filter { it.text("status") == "active" && it.text("halaqa_id") == halaqa }
    val categories = state.data["categories"].orEmpty().filter { it.text("halaqa_id") == halaqa && it.optBoolean("active", true) }
    fun selectedDays(): List<Int> = weekdays.split(',').mapNotNull { it.toIntOrNull() }.distinct().sorted()
    fun toggleDay(day: Int) { val next = selectedDays().toMutableSet().apply { if (!add(day)) remove(day) }; weekdays = next.sorted().joinToString(",") }
    fun buildPlan(): JSONObject {
        val days = selectedDays(); require(days.isNotEmpty()) { "اختر يوم دوام واحداً على الأقل" }
        require(startDate.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) && endDate.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) && endDate >= startDate) { "تحقق من تاريخي البداية والنهاية" }
        val kind = type
        val requested = target.toDoubleOrNull()?.takeIf { it > 0 } ?: error("أدخل هدفاً صحيحاً")
        val range = if (kind == "hifz" && start.isBlank() && end.isBlank()) {
            JSONObject().put("goal_unit", "pages").put("target_units", requested).put("target_pages", requested)
                .put("range_start_page", JSONObject.NULL).put("range_end_page", JSONObject.NULL)
                .put("selected_surahs", JSONArray()).put("selected_juz", JSONArray()).put("selected_rubs", JSONArray())
        } else if (unit == "ayahs") {
            PlanEngine.quranRangeFromSelection(JSONObject().put("goal_unit", "ayahs").put("start_surah", startSurah.toInt()).put("start_ayah", startAyah.toInt()).put("end_surah", endSurah.toInt()).put("end_ayah", endAyah.toInt()))
        } else {
            val a = start.toIntOrNull() ?: error("حدد بداية النطاق")
            val b = end.toIntOrNull() ?: error("حدد نهاية النطاق")
            PlanEngine.quranRangeFromSelection(JSONObject().put("goal_unit", unit).put("start_value", a).put("end_value", b))
        }
        val settings = (old?.optJSONObject("settings") ?: JSONObject()).copyJson()
            .put("algorithm_version", "2.18.2").put("event_driven", true).put("deficit_damping", true)
        if (kind == "hifz" || kind == "sard" || kind == "tathbit") settings.put("requested_target_pages", requested)
        val row = range.copyJson().put("scope_type", scope).put("halaqa_id", halaqa)
            .put("student_id", if (scope == "student") student else JSONObject.NULL)
            .put("category_id", if (scope == "category") category else JSONObject.NULL)
            .put("plan_type", kind).put("review_tier", if (kind == "review") reviewTier else "none")
            .put("title", title.trim().ifBlank { "${planTypeLabels[kind] ?: "خطة"} ${number(requested)} صفحة" })
            .put("start_date", startDate).put("end_date", endDate).put("schedule_weekdays", JSONArray(days))
            .put("catch_up_weekday", catchUp.toIntOrNull() ?: JSONObject.NULL).put("max_daily_multiplier", cap.toDoubleOrNull()?.coerceIn(1.0, 3.0) ?: 1.5)
            .put("auto_extend", autoExtend).put("quality_gate_enabled", qualityGate).put("minimum_evaluation", minimum)
            .put("near_revision_pages", near.toDoubleOrNull()?.coerceIn(0.0, 30.0) ?: 7.0).put("far_revision_pages", far.toDoubleOrNull()?.coerceIn(0.0, 604.0) ?: 20.0)
            .put("milestone_mode", milestone).put("milestone_requires_approval", milestoneApproval).put("delay_alert_days", delay.toDoubleOrNull()?.coerceIn(1.0, 30.0) ?: 3.0)
            .put("home_prep_push", homePush).put("note", note.trim().takeIf { it.isNotBlank() } ?: JSONObject.NULL).put("settings", settings)
            .put("status", old?.text("status").orEmpty().ifBlank { "active" }).put("revision", old?.optInt("revision", 1) ?: 1)
        old?.text("id")?.takeIf { it.isNotBlank() }?.let { row.put("id", it) }
        old?.text("parent_plan_id")?.takeIf { it.isNotBlank() }?.let { row.put("parent_plan_id", it) }
        return row
    }
    FormBody(if (planId.isNullOrBlank()) "خطة ذكية جديدة" else "تعديل الخطة الذكية") {
        Select("نطاق الخطة", scope, linkedMapOf("student" to "طالب", "category" to "فئة", "halaqa" to "الحلقة كاملة")) { scope = it }
        Select("الحلقة", halaqa, state.data["halaqas"].orEmpty().associate { it.text("id") to it.text("name") }) { halaqa = it; student = ""; category = "" }
        if (scope == "student") Select("الطالب", student, students.associate { it.text("id") to it.text("full_name") }) { student = it }
        if (scope == "category") Select("الفئة", category, categories.associate { it.text("id") to it.text("name") }) { category = it }
        Select("نوع الخطة", type, planTypeLabels) { type = it }
        Field("عنوان اختياري", title, { title = it })
        Field("تاريخ البداية YYYY-MM-DD", startDate, { startDate = it }); Field("تاريخ النهاية YYYY-MM-DD", endDate, { endDate = it })
        Select("وحدة النطاق", unit, goalUnitLabels) { unit = it; start = "1"; end = if (it == "pages") "5" else "1" }
        if (unit == "ayahs") {
            Field("السورة من", startSurah, { startSurah = it }, numeric = true); Field("الآية من", startAyah, { startAyah = it }, numeric = true)
            Field("السورة إلى", endSurah, { endSurah = it }, numeric = true); Field("الآية إلى", endAyah, { endAyah = it }, numeric = true)
        } else {
            Field("من", start, { start = it }, numeric = true); Field("إلى", end, { end = it }, numeric = true)
        }
        if (type == "hifz") Field("الهدف المطلوب بالصفحات", target, { target = it }, numeric = true)
        Select("يوم التعويض (اختياري)", catchUp, linkedMapOf("" to "بدون تعويض") + weekdayLabels.entries.associate { it.key.toString() to "تعويض: ${it.value}" }) { catchUp = it }
        Text("أيام الدوام", style = MaterialTheme.typography.labelMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { weekdayLabels.forEach { (day, label) -> FilterChip(selected = day in selectedDays(), onClick = { toggleDay(day) }, label = { Text(label) }) } }
        Field("سقف التعويض (1–3×)", cap, { cap = it }, numeric = true)
        if (type == "review") {
            Select("طبقة المراجعة", reviewTier, linkedMapOf("near" to "قريبة", "far" to "بعيدة", "both" to "كلاهما")) { reviewTier = it }
            Field("المراجعة القريبة بالصفحات", near, { near = it }, numeric = true); Field("المراجعة البعيدة بالصفحات", far, { far = it }, numeric = true)
        }
        Select("الحد الأدنى للتقييم", minimum, linkedMapOf("good" to "جيد", "very_good" to "جيد جداً", "excellent" to "ممتاز")) { minimum = it }
        Select("نمط المعلم", milestone, linkedMapOf("none" to "بدون اختبار", "juz" to "اختبار جزء", "hizb" to "اختبار حزب")) { milestone = it }
        Field("تنبيه التعثر بعد (أيام)", delay, { delay = it }, numeric = true)
        SwitchLine("التمديد التلقائي", autoExtend) { autoExtend = it }; SwitchLine("بوابة الجودة", qualityGate) { qualityGate = it }
        SwitchLine("اعتماد الاختبارات المرحلية", milestoneApproval) { milestoneApproval = it }; SwitchLine("تذكير التحضير المنزلي", homePush) { homePush = it }
        Field("ملاحظة", note, { note = it }, lines = 3)
        Button({ repo.launch { saveSmartPlan(buildPlan()); close() } }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) { Text("حفظ الخطة") }
    }
}

@Composable
private fun SwitchLine(label: String, value: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(label); Switch(checked = value, onCheckedChange = change) }
}

private fun rangeStart(plan: JSONObject?, unit: String): String {
    if (plan == null) return ""
    if (unit == "pages" && plan.isNull("range_start_page")) return ""
    val selected = when (unit) { "juz" -> plan.optJSONArray("selected_juz"); "rub" -> plan.optJSONArray("selected_rubs"); "surah" -> plan.optJSONArray("selected_surahs"); else -> null }
    return selected?.optInt(0)?.takeIf { it > 0 }?.toString() ?: plan.optInt("range_start_page", 1).toString()
}

private fun rangeEnd(plan: JSONObject?, unit: String): String {
    if (plan == null) return ""
    if (unit == "pages" && plan.isNull("range_end_page")) return ""
    val selected = when (unit) { "juz" -> plan.optJSONArray("selected_juz"); "rub" -> plan.optJSONArray("selected_rubs"); "surah" -> plan.optJSONArray("selected_surahs"); else -> null }
    return selected?.let { it.optInt(it.length() - 1) }?.takeIf { it > 0 }?.toString() ?: plan.optInt("range_end_page", 5).toString()
}

private fun JSONArray.ints(): List<Int> = (0 until length()).mapNotNull { optInt(it).takeIf { value -> value in 0..6 } }

private fun storedTarget(plan: JSONObject?): Double {
    val settingValue = plan?.optJSONObject("settings")?.optDouble("requested_target_pages", Double.NaN)
    val fromSettings = if (settingValue == null || settingValue.isNaN() || settingValue.isInfinite()) null else settingValue
    return fromSettings ?: plan?.optDouble("target_pages", 20.0) ?: 20.0
}
