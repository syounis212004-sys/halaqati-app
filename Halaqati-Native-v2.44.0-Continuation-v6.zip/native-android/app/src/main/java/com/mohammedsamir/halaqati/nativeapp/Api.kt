package com.mohammedsamir.halaqati.nativeapp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import javax.net.ssl.HttpsURLConnection
class ApiFailure(val status:Int,message:String):Exception(message)
class Conflict(message:String):Exception(message)
class Api(private val store:SecureStore) {
    private val authLock=Mutex()
    private var session:SessionToken?=null
    val userId get()=session?.userId
    suspend fun restore():Boolean=withContext(Dispatchers.IO) { session=store.read("session")?.let { SessionToken.fromStored(JSONObject(it)) }; session!=null }
    private suspend fun request(path:String,method:String="GET",body:JSONObject?=null,access:String?=null,prefer:String?=null):String=withContext(Dispatchers.IO) {
        require(path.startsWith("/auth/v1/") || path.startsWith("/rest/v1/"))
        val c=URL(BASE+path).openConnection() as HttpsURLConnection
        c.requestMethod=method; c.connectTimeout=12000; c.readTimeout=20000; c.instanceFollowRedirects=false
        c.setRequestProperty("apikey",PUBLIC_KEY); c.setRequestProperty("Accept","application/json")
        if(access!=null) c.setRequestProperty("Authorization","Bearer $access")
        if(prefer!=null) c.setRequestProperty("Prefer",prefer)
        try {
            if(body!=null) { c.doOutput=true; c.setRequestProperty("Content-Type","application/json; charset=utf-8"); c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) } }
            val code=c.responseCode; val raw=(if(code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if(code !in 200..299) { val error=runCatching { JSONObject(raw) }.getOrNull(); throw ApiFailure(code,error?.text("msg")?.ifBlank { error.text("message") }?.ifBlank { error.text("error_description") }?.takeIf { it.isNotBlank() } ?: "رفض الخادم الطلب ($code)") }
            raw
        } finally { c.disconnect() }
    }
    private suspend fun save(s:SessionToken)=withContext(Dispatchers.IO) { store.write("session",s.json().toString()); session=s }
    suspend fun signIn(email:String,password:String,expectedUser:String?=null)=authLock.withLock {
        val fresh=SessionToken.fromAuth(JSONObject(request("/auth/v1/token?grant_type=password","POST",JSONObject().put("email",email.trim()).put("password",password))))
        require(expectedUser==null || fresh.userId==expectedUser) { "استخدم الحساب صاحب التعديلات المحلية" }; save(fresh)
    }
    private suspend fun access(force:Boolean=false):String=authLock.withLock {
        val old=session ?: throw ApiFailure(401,"سجّل الدخول")
        if(!force && old.expires>System.currentTimeMillis()/1000+60) return@withLock old.access
        val fresh=SessionToken.fromAuth(JSONObject(request("/auth/v1/token?grant_type=refresh_token","POST",JSONObject().put("refresh_token",old.refresh))))
        check(fresh.userId==old.userId) { "صاحب جلسة الدخول لا يطابق البيانات" }; save(fresh); fresh.access
    }
    suspend fun authenticated(path:String,method:String="GET",body:JSONObject?=null,prefer:String?=null):String {
        return try { request(path,method,body,access(),prefer) } catch(e:ApiFailure) { if(e.status!=401 || method!="GET") throw e; request(path,method,body,access(true),prefer) }
    }
    suspend fun list(table:String,filters:Map<String,String> = emptyMap(),order:String="id.asc"):List<JSONObject> {
        require(table.matches(Regex("[a-z_]+")))
        return collectPages { offset -> JSONArray(authenticated("/rest/v1/$table?"+query(mapOf("select" to "*","order" to order,"limit" to "200","offset" to "$offset")+filters))).rows() }
    }
    suspend fun rpc(name:String,payload:JSONObject):JSONObject { require(name.matches(Regex("[a-z_]+"))); return JSONObject(authenticated("/rest/v1/rpc/$name","POST",payload)) }
    /** Safe replay: UUID identity, idempotent equality, guarded PATCH, explicit conflicts. */
    suspend fun applyOperation(op:JSONObject):JSONObject {
        require(op.getString("owner")==userId) { "عملية تخص حساباً آخر" }
        val table=op.getString("table"); require(table in MUTABLE_TABLES)
        val rowId=op.getString("row_id"); val identity=mapOf("id" to "eq.$rowId")
        val desired=op.getJSONObject("desired"); val before=op.optJSONObject("before")
        val existing=list(table,identity).singleOrNull()
        if(existing!=null && sameFields(existing,desired)) return existing
        if(before==null) {
            if(existing!=null) throw Conflict("السجل موجود على الخادم بقيم مختلفة؛ راجع العملية قبل المحاولة")
            val raw=authenticated("/rest/v1/$table?on_conflict=id","POST",desired,"resolution=ignore-duplicates,return=representation")
            if(JSONArray(raw).length()==0) {
                val current=list(table,identity).singleOrNull()
                if(current==null || !sameFields(current,desired)) throw Conflict("تعارض عند إنشاء السجل")
            }
        } else {
            if(existing==null) throw Conflict("حُذف السجل من جهاز آخر")
            val changes=changedFields(before,desired)
            if(changes.length()==0) return existing
            val guard=guardedFilters(identity,before,changes)
            val result=JSONArray(authenticated("/rest/v1/$table?"+query(guard),"PATCH",changes,"return=representation"))
            if(result.length()!=1) throw Conflict("تغيرت البيانات على جهاز آخر. بقيت تعديلاتك محفوظة؛ راجعها قبل المتابعة")
        }
        return list(table,identity).singleOrNull() ?: throw Conflict("تعذر تأكيد السجل بعد الإرسال؛ ستُراجع العملية عند المزامنة")
    }
    suspend fun register(email:String,password:String,name:String,phone:String,role:String):Boolean=authLock.withLock {
        require(role in setOf("teacher","guardian","supervisor"))
        val metadata=JSONObject().put("full_name",name.trim()).put("phone",phone.trim()).put("requested_role",role)
        val result=JSONObject(request("/auth/v1/signup","POST",JSONObject().put("email",email.trim()).put("password",password).put("data",metadata)))
        if(result.has("access_token")){save(SessionToken.fromAuth(result));true}else false
    }
    suspend fun resetPassword(email:String) {
        request("/auth/v1/recover?"+query(mapOf("redirect_to" to "$BASE/functions/v1/halaqati-reset/")),"POST",JSONObject().put("email",email.trim()))
    }
    suspend fun updateName(name:String,p:JSONObject):JSONObject {
        require(name.trim().length>=3)
        val prefs=(p.optJSONObject("preferences")?:JSONObject()).copyJson().put("account_name_confirmed",true).put("account_name_updated_at",java.time.Instant.now().toString())
        val rows=JSONArray(authenticated("/rest/v1/profiles?"+query(mapOf("id" to "eq.${userId}")),"PATCH",JSONObject().put("full_name",name.trim().replace(Regex("\\s+")," ")).put("preferences",prefs),"return=representation"))
        check(rows.length()==1) { "لم يُحفظ الاسم" }; return rows.getJSONObject(0)
    }
    suspend fun signOut() {
        try { session?.let { request("/auth/v1/logout?scope=local","POST",access=it.access) } }
        finally { withContext(Dispatchers.IO) { session=null; store.remove("session") } }
    }
    companion object {
        const val BASE="https://xlxzwucqdtggkfwwqibk.supabase.co"
        const val PUBLIC_KEY="sb_publishable_VZGYTedRpXfJdswijXoxig_F0Hva8ks"
        val MUTABLE_TABLES=setOf("students","sessions","attendance_records","student_daily_notes","recitation_entries","announcements","forum_posts","forum_comments","smart_plans","smart_plan_events")
    }
}
