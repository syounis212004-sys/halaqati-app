package com.mohammedsamir.halaqati.nativeapp

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import org.json.JSONObject

/** Vector-only drawing; no WebView, screenshot, HTML renderer or bitmap conversion. */
object NativePdf {
    fun sessionReport(context:Context,state:AppState,sessionId:String):File {
        val session=state.data["sessions"].orEmpty().find { it.text("id")==sessionId } ?: error("الجلسة غير متاحة")
        val ak="attendance_records_$sessionId"; val rk="recitation_entries_$sessionId"
        require(ak in state.data && rk in state.data) { "حمّل الحضور والتسميع قبل التصدير" }
        require(ak !in state.errors && rk !in state.errors) { "لم يكتمل تحميل التقرير؛ أعد التحديث" }
        val attendance=state.data[ak].orEmpty(); val recs=state.data[rk].orEmpty()
        val studentIds=(attendance+recs).map { it.text("student_id") }.toSet()
        val students=state.data["students"].orEmpty().filter { it.text("id") in studentIds }
        require(students.isNotEmpty()) { "لا توجد بيانات مسجلة في الجلسة" }
        val pdf=PdfDocument(); val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        val font=Typeface.create("sans-serif",Typeface.NORMAL)
        val widths=floatArrayOf(48f,52f,52f,52f,67f,244f)
        val headings=listOf("النقاط","السرد","المراجعة","الحفظ","الحضور","الطالب")
        var pageNumber=0; var page:PdfDocument.Page?=null; var y=0f
        fun drawText(text:String,x:Float,top:Float,width:Float,size:Float=11f,bold:Boolean=false) {
            val p=TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(24,42,35); textSize=size; typeface=if(bold) Typeface.create(font,Typeface.BOLD) else font }
            val layout=StaticLayout.Builder.obtain(text,0,text.length,p,width.toInt()).setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL).setIncludePad(false).build()
            val canvas=page!!.canvas; canvas.save(); canvas.translate(x,top); layout.draw(canvas); canvas.restore()
        }
        fun row(values:List<String>,header:Boolean=false) {
            var x=20f
            values.forEachIndexed { index,text ->
                paint.color=if(header) Color.rgb(218,238,226) else Color.WHITE
                page!!.canvas.drawRect(x,y,x+widths[index],y+30,paint)
                paint.color=Color.rgb(210,220,215); paint.style=Paint.Style.STROKE; paint.strokeWidth=.4f
                page!!.canvas.drawRect(x,y,x+widths[index],y+30,paint); paint.style=Paint.Style.FILL
                val measure=TextPaint().apply { textSize=11f; typeface=font }
                val size=if(index==5 && measure.measureText(text)>widths[index]-8) (11f*(widths[index]-8)/measure.measureText(text)).coerceAtLeast(7f) else 11f
                drawText(text,x+4,y+6,widths[index]-8,size,header); x+=widths[index]
            }; y+=30
        }
        fun startPage() {
            page?.let { drawText("${pageNumber}",20f,810f,555f,9f); pdf.finishPage(it) }
            pageNumber++; page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNumber).create())
            drawText("تقرير الجلسة · حلقاتي",20f,22f,555f,20f,true)
            drawText("${session.text("title")} · ${session.text("session_date")}",20f,58f,555f,12f)
            y=87f; row(headings,true)
        }
        try {
            startPage()
            students.forEach { student ->
                if(y+30>790) startPage()
                val r=recs.filter { it.text("student_id")==student.text("id") }
                fun pages(types:Set<String>)=number(r.filter { it.text("activity_type") in types }.sumOf { it.optDouble("pages_count",0.0) })
                val points=r.sumOf { if(it.has("points")) it.optDouble("points",0.0) else scoreV6(it).getDouble("points") }
                val a=attendance.find { it.text("student_id")==student.text("id") }?.text("status")
                row(listOf(number(points),pages(setOf("sard")),pages(setOf("review_near","review_far","tilawah")),pages(setOf("new_hifz")),attendanceNames[a] ?: "غير مسجل",student.text("full_name")))
            }
            drawText("${pageNumber}",20f,810f,555f,9f); pdf.finishPage(page!!); page=null
            val directory=File(context.cacheDir,"exports").apply { mkdirs() }
            val result=File(directory,"Halaqati-session-${session.text("session_date")}.pdf")
            result.outputStream().use { pdf.writeTo(it) }; require(result.length()>0); return result
        } finally { page?.let { pdf.finishPage(it) }; pdf.close() }
    }
    fun share(context:Context,file:File) {
        val uri=FileProvider.getUriForFile(context,"${context.packageName}.files",file)
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("application/pdf").putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),"مشاركة التقرير"))
    }
}
