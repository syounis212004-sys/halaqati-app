package com.mohammedsamir.halaqati.nativeapp

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONObject

@Composable internal fun FormBody(title:String,content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxWidth().heightIn(max=720.dp).imePadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) { Text(title,style=MaterialTheme.typography.headlineSmall);content();Spacer(Modifier.height(20.dp)) }
}
@Composable internal fun Field(label:String,value:String,change:(String)->Unit,numeric:Boolean=false,lines:Int=1) {
    OutlinedTextField(value,change,Modifier.fillMaxWidth(),label={Text(label)},singleLine=lines==1,minLines=lines,keyboardOptions=KeyboardOptions(keyboardType=if(numeric)KeyboardType.Number else KeyboardType.Text))
}
@Composable internal fun Select(label:String,value:String,options:Map<String,String>,change:(String)->Unit) {
    var expanded by remember {mutableStateOf(false)}
    Column {Text(label,style=MaterialTheme.typography.labelMedium);Box{OutlinedButton({expanded=true},Modifier.fillMaxWidth()){Text(options[value]?:if(value.isBlank())"اختر" else "القيمة الحالية")};DropdownMenu(expanded,{expanded=false}){options.forEach{(id,name)->DropdownMenuItem(text={Text(name)},onClick={change(id);expanded=false})}}}}
}
private fun nullable(row:JSONObject,key:String,value:String){row.put(key,value.trim().takeIf{it.isNotEmpty()}?:JSONObject.NULL)}
@Composable fun StudentForm(state:AppState,id:String?,repo:Repository,close:()->Unit){
    val old=state.data["students"].orEmpty().find{it.text("id")==id}
    var raw by rememberSaveable(id){mutableStateOf((old?.copyJson()?:JSONObject().put("halaqa_id",state.data["halaqas"]?.firstOrNull()?.text("id").orEmpty()).put("track_code","general_hifz")).toString())}
    val draft=JSONObject(raw);fun set(k:String,v:String){raw=draft.copyJson().put(k,v).toString()}
    FormBody(if(id==null)"إضافة طالب" else "تعديل الطالب"){
        Field("الاسم الكامل",draft.text("full_name"),{set("full_name",it)})
        Select("الحلقة",draft.text("halaqa_id"),state.data["halaqas"].orEmpty().associate{it.text("id") to it.text("name")}){raw=draft.copyJson().put("halaqa_id",it).put("category_id",JSONObject.NULL).toString()}
        Select("المسار",canonicalTrack(draft.text("track_code")),tracks){set("track_code",it)}
        Select("الفئة",draft.text("category_id"),linkedMapOf("" to "بدون فئة")+state.data["categories"].orEmpty().filter{it.text("halaqa_id")==draft.text("halaqa_id")}.associate{it.text("id") to it.text("name")}){set("category_id",it)}
        Select("الجنس",draft.text("gender"),linkedMapOf("" to "غير محدد","male" to "ذكر","female" to "أنثى")){set("gender",it)}
        listOf("national_id" to "رقم الهوية","date_of_birth" to "الميلاد YYYY-MM-DD","school_grade" to "الصف الدراسي","program_name" to "البرنامج الإضافي","guardian_phone" to "هاتف ولي الأمر","address" to "العنوان","notes" to "الملاحظات").forEach{(k,label)->Field(label,draft.text(k),{set(k,it)},lines=if(k=="notes")3 else 1)}
        Button({repo.launch{
            val row=JSONObject().put("full_name",draft.text("full_name")).put("halaqa_id",draft.text("halaqa_id"))
            listOf("track_code","category_id","gender","national_id","date_of_birth","school_grade","program_name","guardian_phone","address","notes").forEach{nullable(row,it,draft.text(it))}
            if(draft.text("date_of_birth").isNotBlank())java.time.LocalDate.parse(draft.text("date_of_birth"))
            saveStudent(id,row);close()
        }},Modifier.fillMaxWidth(),enabled=!state.busy&&draft.text("full_name").isNotBlank()&&draft.text("halaqa_id").isNotBlank()){Text("حفظ الطالب")}
    }
}
@Composable fun SessionForm(state:AppState,id:String?,repo:Repository,close:()->Unit){
    val old=state.data["sessions"].orEmpty().find{it.text("id")==id}
    var raw by rememberSaveable(id){mutableStateOf((old?.copyJson()?:JSONObject().put("halaqa_id",state.data["halaqas"]?.firstOrNull()?.text("id").orEmpty()).put("session_date",today()).put("session_type","tasmee")).toString())}
    val d=JSONObject(raw);fun set(k:String,v:String){raw=d.copyJson().put(k,v).toString()}
    FormBody(if(id==null)"جلسة جديدة" else "تعديل الجلسة"){
        Select("الحلقة",d.text("halaqa_id"),state.data["halaqas"].orEmpty().associate{it.text("id") to it.text("name")}){set("halaqa_id",it)}
        Field("تاريخ الجلسة YYYY-MM-DD",d.text("session_date"),{set("session_date",it)})
        Select("نوع الجلسة",d.text("session_type"),sessionNames){set("session_type",it)}
        Field("عنوان الجلسة",d.text("title"),{set("title",it)})
        Field("ملاحظات",d.text("notes"),{set("notes",it)},lines=3)
        Button({repo.launch{val row=JSONObject().put("halaqa_id",d.text("halaqa_id")).put("session_date",d.text("session_date")).put("session_type",d.text("session_type"));nullable(row,"title",d.text("title"));nullable(row,"notes",d.text("notes"));saveSession(id,row);close()}},Modifier.fillMaxWidth(),enabled=!state.busy&&d.text("halaqa_id").isNotBlank()){Text("حفظ الجلسة")}
    }
}
@Composable fun RecitationForm(state:AppState,sessionId:String,studentId:String,repo:Repository,close:()->Unit){
    var start by rememberSaveable{mutableStateOf("")};var end by rememberSaveable{mutableStateOf("")};var mistakes by rememberSaveable{mutableStateOf("0")};var prompts by rememberSaveable{mutableStateOf("0")};var activity by rememberSaveable{mutableStateOf("new_hifz")};var note by rememberSaveable{mutableStateOf("")};var plan by rememberSaveable{mutableStateOf("")}
    val a=start.toIntOrNull();val b=end.toIntOrNull();val m=mistakes.toIntOrNull();val p=prompts.toIntOrNull();val valid=a!=null&&b!=null&&a in 1..604&&b in a..604&&m!=null&&m>=0&&p!=null&&p>=0
    FormBody("إضافة تسميع · صفحات كاملة"){
        Text(state.data["students"].orEmpty().find{it.text("id")==studentId}?.text("full_name").orEmpty())
        Select("نوع التسميع",activity,activityNames){activity=it}
        Field("من الصفحة",start,{start=it},numeric=true);Field("إلى الصفحة",end,{end=it},numeric=true)
        Field("الأخطاء",mistakes,{mistakes=it},numeric=true);Field("التنبيهات",prompts,{prompts=it},numeric=true)
        val plans=state.data["plans"].orEmpty().filter{it.text("student_id")==studentId&&it.text("status")=="active"}
        Select("الخطة المرتبطة",plan,linkedMapOf("" to "بدون ربط بخطة")+plans.associate{it.text("id") to it.text("title")}){plan=it}
        Field("ملاحظة المحفّظ",note,{note=it},lines=2)
        if(valid){val score=scoreV6(JSONObject().put("pages_count",b!!-a!!+1).put("mistakes",m).put("prompts",p));Text("${b-a+1} صفحة · ${score.text("points")} نقطة · ${evaluationNames[score.text("evaluation")].orEmpty()}")}
        Button({repo.launch{saveRecitation(sessionId,studentId,a!!,b!!,m!!,p!!,activity,note,plan.takeIf{it.isNotBlank()});close()}},Modifier.fillMaxWidth(),enabled=!state.busy&&valid){Text("حفظ التسميع")}
    }
}
@Composable fun NoteForm(state:AppState,sessionId:String,studentId:String,repo:Repository,close:()->Unit){
    val old=state.data["student_daily_notes_$sessionId"].orEmpty().find{it.text("student_id")==studentId}
    var comment by rememberSaveable{mutableStateOf(old?.text("teacher_comment").orEmpty())};var homework by rememberSaveable{mutableStateOf(old?.text("homework").orEmpty())}
    FormBody("ملاحظة الطالب"){Field("تعليق المحفّظ",comment,{comment=it},lines=3);Field("الواجب",homework,{homework=it},lines=2);Button({repo.launch{saveNote(sessionId,studentId,comment,homework);close()}},Modifier.fillMaxWidth(),enabled=!state.busy){Text("حفظ الملاحظة")}}
}
@Composable fun NameForm(state:AppState,repo:Repository,close:()->Unit){var name by rememberSaveable{mutableStateOf(state.profile?.text("full_name").orEmpty())};FormBody("اسم الحساب"){Field("الاسم الكامل",name,{name=it});Button({repo.launch{updateName(name);close()}},enabled=!state.busy&&name.trim().length>=3){Text("حفظ")}}}
