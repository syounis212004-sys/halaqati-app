package com.mohammedsamir.halaqati.nativeapp
import org.json.*
import org.junit.Test
import org.junit.Assert.*
import kotlinx.coroutines.runBlocking
class DomainTest {
    @Test fun v6MatchesOriginalAcross185Cases(){
        val cases=JSONArray(javaClass.getResource("/v6-original.json")!!.readText());assertEquals(185,cases.length())
        cases.rows().forEachIndexed{i,v->val actual=scoreV6(v.getJSONObject("input"));val expected=v.getJSONObject("expected");expected.keys().forEach{k->if(expected.get(k) is Number)assertEquals("$i $k",expected.getDouble(k),actual.getDouble(k),1e-9)else assertEquals("$i $k",expected.get(k),actual.get(k))}}
    }
    @Test fun serverCapDoesNotTruncatePagination()=runBlocking {
        val offsets=mutableListOf<Int>();val result=collectPages{n->offsets.add(n);when(n){0->listOf(JSONObject("{id:1}"),JSONObject("{id:2}"));2->listOf(JSONObject("{id:3}"));else->emptyList()}}
        assertEquals(listOf(0,2,3),offsets);assertEquals(3,result.size)
    }
    @Test fun ignoredOffsetIsDetected()=runBlocking {try{collectPages{listOf(JSONObject("{id:1}"))};fail()}catch(_:IllegalStateException){}}
    @Test fun patchGuardsChangedValuesAndNulls(){val before=JSONObject("{id:'a',name:'old',notes:null,active:true}");val changed=changedFields(before,JSONObject("{id:'a',name:'new',notes:'x',active:true}"));assertEquals(setOf("name","notes"),changed.keys().asSequence().toSet());assertEquals(mapOf("id" to "eq.a","name" to "eq.old","notes" to "is.null"),guardedFilters(mapOf("id" to "eq.a"),before,changed))}
    @Test fun nestedJsonOrderCannotBreakIdempotency(){assertTrue(sameFields(JSONObject("{settings:{a:1,b:[2,3]},pages:1}"),JSONObject("{pages:1.0,settings:{b:[2,3],a:1}}")));assertFalse(sameFields(JSONObject("{settings:{b:[2,3]}}"),JSONObject("{settings:{b:[3,2]}}")))}
    @Test fun approvalIsIndependentOfNameConfirmation(){assertFalse(isApproved(JSONObject("{active:true,approval_status:'pending',preferences:{account_name_confirmed:true}}")));assertFalse(isApproved(JSONObject("{active:false,approval_status:'approved'}")));assertTrue(isApproved(JSONObject("{active:true,approval_status:'approved'}")));assertFalse(canManage(JSONObject("{active:true,approval_status:'approved',role:'guardian'}")))}
    @Test fun exactlyTwoTracks(){assertEquals(setOf("general_hifz","tathbit"),tracks.keys);assertEquals("general_hifz",canonicalTrack("sard"))}
    @Test fun planScopeMatchesStudentCategoryAndHalaqa(){
        val student=JSONObject("{id:'s1',halaqa_id:'h1',category_id:'c1'}")
        assertTrue(planAppliesToStudent(JSONObject("{scope_type:'student',student_id:'s1',halaqa_id:'h1'}"),student))
        assertTrue(planAppliesToStudent(JSONObject("{scope_type:'category',category_id:'c1',halaqa_id:'h1'}"),student))
        assertTrue(planAppliesToStudent(JSONObject("{scope_type:'halaqa',halaqa_id:'h1'}"),student))
        assertFalse(planAppliesToStudent(JSONObject("{scope_type:'category',category_id:'c2',halaqa_id:'h1'}"),student))
        assertFalse(planAppliesToStudent(JSONObject("{scope_type:'halaqa',halaqa_id:'h2'}"),student))
    }
    @Test fun queryEscapesReservedCharacters(){val q=query(mapOf("full_name" to "eq.أ & ب"));assertFalse(q.contains('&'));assertEquals("full_name=eq.أ & ب",java.net.URLDecoder.decode(q,"UTF-8"))}
}
