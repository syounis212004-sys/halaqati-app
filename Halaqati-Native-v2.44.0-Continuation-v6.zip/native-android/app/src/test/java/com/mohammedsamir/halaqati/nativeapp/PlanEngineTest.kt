package com.mohammedsamir.halaqati.nativeapp

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PlanEngineTest {
    private fun plan() = JSONObject()
        .put("id", "p1").put("plan_type", "hifz").put("scope_type", "student")
        .put("student_id", "s1").put("halaqa_id", "h1").put("status", "active")
        .put("start_date", "2026-09-01").put("end_date", "2026-09-10")
        .put("target_pages", 5).put("target_units", 5).put("schedule_weekdays", JSONArray(listOf(1, 2, 3, 4, 5)))

    @Test fun planDatesHonorsScheduleAndBounds() {
        val dates = PlanEngine.planDates(plan(), "2026-09-02", "2026-09-08")
        assertEquals(listOf("2026-09-02", "2026-09-03", "2026-09-04", "2026-09-07", "2026-09-08"), dates)
    }

    @Test fun quranRangeUsesPinnedMetadata() {
        val range = PlanEngine.quranRangeFromSelection(JSONObject().put("goal_unit", "juz").put("start_value", 1).put("end_value", 1))
        assertEquals(1, range.getJSONArray("selected_juz").getInt(0))
        assertEquals(1, range.optInt("range_start_page")); assertEquals(21, range.optInt("range_end_page"))
        assertTrue(range.optInt("target_units") > 0)
    }

    @Test fun progressNeverInventsAssignmentOutsidePlanRange() {
        val p = plan().put("range_start_page", 30).put("range_end_page", 34).put("target_pages", 5)
        val out = PlanEngine.calculateProgress(JSONObject().put("plan", p).put("studentId", "s1").put("today", "2026-09-02").put("recitations", JSONArray()).put("sessions", JSONArray()).put("events", JSONArray()))
        val assignment = out.getJSONObject("assignment")
        assertTrue(assignment.optInt("startPage") == 30 || assignment.isNull("startPage"))
        assertTrue(assignment.optInt("endPage") <= 34 || assignment.isNull("endPage"))
    }
}
