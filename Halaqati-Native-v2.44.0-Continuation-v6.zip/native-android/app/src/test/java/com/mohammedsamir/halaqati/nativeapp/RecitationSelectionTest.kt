package com.mohammedsamir.halaqati.nativeapp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RecitationSelectionTest {
    @Test fun pageSelectionPreservesDatabaseShape() {
        val value = RecitationSelection.pages(10, 12)
        assertEquals("pages", value.text("input_method"))
        assertEquals(10, value.optInt("start_page")); assertEquals(12, value.optInt("end_page"))
        assertEquals(3, value.optInt("pages_count")); assertEquals("pages", value.getJSONObject("selection_data").text("mode"))
        assertTrue(value.getJSONObject("selection_data").getJSONArray("qcf_line_keys").length() == 0)
    }

    @Test fun ayahSelectionUsesGlobalAyahBounds() {
        val value = RecitationSelection.ayahs(1, 2, 2, 4)
        assertEquals(QuranMetadata.surahAyahCount(1) - 2 + 1 + 4, value.optInt("ayahs_count"))
        assertEquals(1, value.optInt("range_start_surah")); assertEquals(2, value.optInt("range_start_ayah"))
        assertEquals(2, value.optInt("range_end_surah")); assertEquals(4, value.optInt("range_end_ayah"))
    }

    @Test fun surahAndJuzSelectionsAreContiguousAndDeterministic() {
        val surahs = RecitationSelection.surahs(2, 4)
        assertEquals(3, surahs.optInt("surahs_count")); assertEquals(3, surahs.getJSONArray("selected_surahs").length())
        val juz = RecitationSelection.juzs(2, 3)
        assertEquals(2, juz.getJSONObject("selection_data").getJSONArray("selected_juz").length())
        assertEquals("juz", juz.text("input_method"))
    }

    @Test(expected = IllegalArgumentException::class)
    fun invalidPageRangeIsRejected() { RecitationSelection.pages(604, 605) }
}
