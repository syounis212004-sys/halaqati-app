import fs from 'node:fs';import vm from 'node:vm';
const core=fs.readFileSync(new URL('../../src/core/runtime.js',import.meta.url),'utf8');const a=core.indexOf('function recitationLineCountV6'),b=core.indexOf('function decorateRecForOffline',a);if(a<0||b<a)throw Error('V6 missing');
const ctx={Math,Number,Set,Array,String,window:{}};vm.runInNewContext(core.slice(a,b),ctx);const cases=[];
for(const pages_count of [0,1/15,7/15,8/15,1,1.5,2,10,604])for(const mistakes of [0,1,2,7])for(const prompts of [0,1,2,3,5]){const input={pages_count,mistakes,prompts};cases.push({input,expected:ctx.computeRecitationV6(input)});}
for(const size of [1,7,8,15,30]){const keys=Array.from({length:size},(_,i)=>`1:${i+1}`);keys.push(keys[0]);const input={pages_count:size/15,mistakes:0,prompts:1,selection_data:{qcf_line_keys:keys}};cases.push({input,expected:ctx.computeRecitationV6(input)});}
fs.writeFileSync(new URL('../app/src/test/resources/v6-original.json',import.meta.url),JSON.stringify(cases));console.log(`${cases.length} original scoring fixtures`);
