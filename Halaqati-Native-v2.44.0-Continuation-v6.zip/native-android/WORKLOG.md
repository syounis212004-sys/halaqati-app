# Native migration resume checkpoint (v2.44.0)

The original 251 web/PWA files are retained byte-for-byte. The native module is a separate Kotlin + Jetpack Compose preview application and never uses a WebView or a service-role key.

Verified in the preceding workspace before the automatic scratch cleanup:

- `npm run build` for the unchanged web application completed and generated the PWA service worker and Pages fallback.
- `node scripts/v2440-sync-refresh-check.mjs` passed.
- The original JS V6 and dashboard tests passed (10 tests).
- Kotlin debug APK assembly and Android Lint completed successfully at the previous checkpoint; the then-current unit-test task had no source tests.

Native work present in this checkpoint:

- encrypted Android Keystore-backed session/snapshot store;
- Supabase HTTPS REST authentication, pagination, refresh, guarded optimistic PATCH and UUID-idempotent outbox;
- approval/role checks, two-track mapping (`general_hifz` and `tathbit`), Arabic RTL Compose navigation, responsive rail/bottom navigation, forms for students/sessions/attendance/recitation/notes, forum posts/comments, sign-up and password recovery;
- V6 score implementation and the Kotlin smart-plan engine with pinned Quran metadata source;
- vector Android PDF session report with explicit offline/pending data indication and Cairo font resource;
- UX Pilot references for teacher dashboard, recitation session, students, plans, guardian, reports, certificates and notifications.

Still not a production-parity release: the native report/certificate templates do not yet reproduce every original HTML/vector template; notifications/FCM, Google sign-in, guardian linking, import/OCR, backup/restore, all lesson-activity fields, recitation deletion/edit history, and production signing/outbox transfer remain to be integrated. No production Supabase mutations were performed.

Continuation completed after this checkpoint:

- `RecitationSelection.kt` now preserves the web database shape for page, ayah, surah, and juz input modes. It derives page/ayah counts from the pinned Hafs metadata and leaves `qcf_line_keys` empty unless a real line map is available.
- `Repository.saveSelectedRecitation` and `loadPlanActivity` connect the picker and the Kotlin smart-plan engine to the existing `recitation_entries`, `sessions`, and `smart_plan_events` contracts. `smart_plan_events` is now an idempotent outbox table; no schema migration or production write was performed.
- The plans route now has an interactive Compose progress view: student scope selection, calculated completion/pace/health, daily assignment, retry blocking, milestone/catch-up state, refresh, and archive/reactivate controls. The recitation sheet exposes all four range modes and keeps the existing V6 scoring path.
- Plan attachment validation now covers student, category, and halaqa scopes consistently in the picker, repository outbox, and plan detail screen.
- Added a native smart-plan form for create/edit, with the existing range, schedule, review, milestone, quality-gate, and notification fields; the form writes through the guarded `smart_plans` outbox path.
- Added deterministic native tests for Quran selections and smart-plan progress, Android backup/data-extraction exclusions, and `.github/workflows/build-halaqati-native-v2.44.0.yml` for web checks, native unit tests/lint, debug APK, release APK, and AAB.

Verification in this continuation:

- Node syntax checks for the legacy/plans engines passed.
- The original V6/dashboard tests passed (10 tests) and `V2440_SYNC_REFRESH_PASS` passed.
- A fresh Android compile after the continuation edits remains unverified locally because the scratch environment no longer contains Gradle, Android SDK, or `javac`, and the attempted toolchain downloads were rejected by the execution network. The CI workflow is the reproducible build path; no APK is claimed as locally produced here.
- The web source baseline was rechecked after the continuation: all 251 original project files remain byte-for-byte unchanged.
