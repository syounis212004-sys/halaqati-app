@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.ui.components.*
import com.mohammedsamir.halaqati.ui.navigation.AddActionBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.LocalDate

/** One row of the staff dashboard (a teacher or a supervisor) with the figures of the current month. */
private data class StaffRow(
    val id: String,
    val name: String,
    val isSupervisor: Boolean,
    val photo: String?,
    val phone: String,
    val halaqas: List<Pair<String, String>>,
    val sessions: Int,
    val sessionDays: Int,
    val closed: Int,
    val recitations: Int?,
    val lastSession: String?,
    val visitsReceived: Int,
    val visitScore: Double?,
    val visitsMade: Int,
    val halaqasVisited: Int,
    val openActions: Int,
    val frozen: Boolean,
) {
    /** 0..100, or null when there is nothing to compare with yet. */
    fun commitment(monthDays: Int): Int? = if (isSupervisor) {
        if (halaqas.isEmpty()) null else ((halaqasVisited * 100.0) / halaqas.size).toInt().coerceIn(0, 100)
    } else {
        if (monthDays <= 0) null else ((sessionDays * 100.0) / monthDays).toInt().coerceIn(0, 100)
    }
}

private fun commitmentLabel(v: Int?): Pair<String, String> = when {
    v == null -> "لا بيانات" to "neutral"
    v >= 80 -> "ممتاز" to "success"
    v >= 50 -> "جيد" to "warning"
    else -> "يحتاج متابعة" to "danger"
}

/**
 * RC53: "متابعة المحفظين" (supervisor) / "متابعة المحفظين والمشرفين" (administrator).
 * One expandable row per person: commitment, sessions, visits and open action items, with quick alert / visit buttons.
 */
@Composable
fun StaffMonitorScreen(profile: Profile, pending: Int, onRefresh: () -> Unit, navigate: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val isAdmin = profile.role == UserRole.ADMIN
    var board by remember { mutableStateOf<SupBoard?>(null) }
    var rows by remember { mutableStateOf<List<StaffRow>>(emptyList()) }
    var message by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var expanded by remember { mutableStateOf<String?>(null) }
    var alertFor by remember { mutableStateOf<StaffRow?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }

    suspend fun reload() {
        try {
            val result = withContext(Dispatchers.IO) {
                val repo = AppGraph.repo
                val b = loadSupBoard(supervisorOnly = profile.role == com.mohammedsamir.halaqati.model.UserRole.SUPERVISOR)
                val today = LocalDate.now()
                val monthStart = today.withDayOfMonth(1).toString()
                val overview = repo.staffOverview(monthStart, today.toString())?.associateBy { it.optString("id") }.orEmpty()
                val supLinks = repo.table("halaqa_supervisors", "select=halaqa_id,supervisor_id&limit=500", forceRefresh = repo.online()).sRows()
                val hq = repo.table("halaqas", "select=id,name,supervisor_id&active=eq.true&limit=200", forceRefresh = repo.online()).sRows()
                val names = hq.associate { it.optString("id") to it.optString("name", "حلقة") }
                val built = b.staff.filter { isAdmin || it.optString("role") == "teacher" }.map { st ->
                    val id = st.optString("id")
                    val sup = st.optString("role") == "supervisor"
                    val myHalaqas: List<Pair<String, String>> = if (sup) {
                        (supLinks.filter { it.optString("supervisor_id") == id }.map { it.optString("halaqa_id") } +
                            hq.filter { it.optString("supervisor_id") == id }.map { it.optString("id") })
                            .distinct().map { it to (names[it] ?: "حلقة") }
                    } else b.halaqas.filter { id in it.teacherIds }.map { it.id to it.name }
                    val myIds = myHalaqas.map { it.first }.toSet()
                    val received = b.visits.filter { it.optString("halaqa_id") in myIds && it.optString("visit_date") >= monthStart }
                    val made = b.visits.filter { it.optString("supervisor_id") == id && it.optString("visit_date") >= monthStart }
                    val ov = overview[id]
                    StaffRow(
                        id = id,
                        name = st.optString("full_name", "—"),
                        isSupervisor = sup,
                        photo = st.optString("avatar_path").takeIf { it.isNotBlank() && it != "null" },
                        phone = st.optString("phone").takeIf { it != "null" }.orEmpty(),
                        halaqas = myHalaqas,
                        sessions = ov?.optInt("sessions") ?: (b.sessionsByCreator[id] ?: 0),
                        sessionDays = ov?.optInt("session_days") ?: (b.daysByCreator[id] ?: 0),
                        closed = ov?.optInt("closed_sessions") ?: (b.closedByCreator[id] ?: 0),
                        recitations = ov?.optInt("recitations"),
                        lastSession = (ov?.optString("last_session")?.takeIf { it.isNotBlank() && it != "null" }) ?: b.lastSessionByCreator[id],
                        visitsReceived = received.size,
                        visitScore = received.mapNotNull { visitAverage(it) }.takeIf { it.isNotEmpty() }?.average(),
                        visitsMade = made.size,
                        halaqasVisited = made.map { it.optString("halaqa_id") }.filter { it in myIds }.distinct().size,
                        openActions = b.visits.count { it.optString("halaqa_id") in myIds && it.supStr("action_items").isNotBlank() && !it.optBoolean("action_done", false) },
                        frozen = st.optBoolean("frozen", false),
                    )
                }
                b to built
            }
            board = result.first
            rows = result.second
            message = null
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) { message = e.message ?: "تعذر تحميل المتابعة" }
    }
    val syncEpoch by AppGraph.connectivity.syncEpoch.collectAsState()
    LaunchedEffect(syncEpoch) { reload() }
    // The "+" sheet asks for a teacher alert: it just needs this page; the alert is chosen per row.
    val request by AddActionBus.requested.collectAsState()
    LaunchedEffect(request) { if (request == "alert") AddActionBus.consume() }

    val b = board
    val shownRows = rows.filter { (tab == 1) == it.isSupervisor && (query.isBlank() || it.name.contains(query.trim())) }
    val monthDays = b?.monthDays ?: 0

    Column {
        AppTopBar(
            if (isAdmin) "متابعة المحفظين والمشرفين" else "متابعة المحفظين",
            onRefresh = { scope.launch { reload() }; onRefresh() }, pending = pending,
        )
        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        toast?.let { StateNotice(it, kind = "success", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (isAdmin) SegmentedTabs(listOf("المحفظون", "المشرفون"), tab, { tab = it; expanded = null }, Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true, label = { Text("بحث بالاسم") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp),
        )
        if (b == null) { LoadingSkeleton(rows = 4, modifier = Modifier.padding(12.dp)); return@Column }
        LazyColumn(
            state = androidx.compose.foundation.lazy.rememberLazyListState(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                val good = shownRows.count { (it.commitment(monthDays) ?: 0) >= 80 }
                val low = shownRows.count { it.commitment(monthDays)?.let { v -> v < 50 } == true }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SupStat("العدد", shownRows.size.toString(), Modifier.weight(1f))
                    SupStat("ملتزمون", good.toString(), Modifier.weight(1f), accent = MaterialTheme.colorScheme.primary)
                    SupStat("يحتاجون متابعة", low.toString(), Modifier.weight(1f), accent = if (low > 0) MaterialTheme.colorScheme.error else null)
                }
            }
            if (shownRows.isEmpty()) item { EmptyState(if (tab == 1) "لا يوجد مشرفون" else "لا يوجد محفظون") }
            items(shownRows, key = { it.id }) { r ->
                val c = r.commitment(monthDays)
                val (label, kind) = commitmentLabel(c)
                val open = expanded == r.id
                val pair = when (kind) { "success" -> HalaqatiGradients.Emerald; "danger" -> HalaqatiGradients.Red; "warning" -> HalaqatiGradients.Gold; else -> HalaqatiGradients.Slate }
                Surface(
                    Modifier.fillMaxWidth().clickable { expanded = if (open) null else r.id },
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, pair.a),
                ) {
                  Column {
                    Row(
                        Modifier.fillMaxWidth().background(pair.brush()).girih(Color.White, .16f, 40.dp).padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Box(Modifier.size(76.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color.White).padding(3.dp)) { StudentAvatar(r.photo, r.name, 70.dp) }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(r.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(r.halaqas.joinToString("، ") { it.second }.ifBlank { "بلا حلقة" }, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = .95f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(50), color = Color.White.copy(alpha = .24f)) {
                                Text(if (c != null) "$label · $c%" else label, Modifier.padding(horizontal = 12.dp, vertical = 3.dp), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                        if (c != null) RubStar((c / 100f).coerceIn(0f, 1f), starSize = 58.dp, fill = Color.White, track = Color.White.copy(alpha = .22f), outline = Color.White, description = "الالتزام $c%")
                    }
                    Column(Modifier.padding(14.dp)) {
                    if (!r.isSupervisor) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(r.sessions.toString() to "جلسات الشهر", "${r.sessionDays}/$monthDays" to "أيام النشاط", r.closed.toString() to "جلسات مُنهاة").forEach { (v, l) ->
                            Column(Modifier.weight(1f).clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(v, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                Text(l, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                            }
                        }
                    }
                    if (open) {
                        Spacer(Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(Modifier.height(8.dp))
                        if (r.frozen) StatusPill("الحساب مجمّد", kind = "danger")
                        if (!r.isSupervisor) {
                            Text("جلسات الشهر: ${r.sessions} · أيام النشاط: ${r.sessionDays} من $monthDays · جلسات مُنهاة: ${r.closed}", style = MaterialTheme.typography.bodyMedium)
                            Text("التسميعات المسجلة: ${r.recitations?.toString() ?: "—"} · آخر جلسة: ${r.lastSession ?: "—"}", style = MaterialTheme.typography.bodyMedium)
                            Text("زيارات المشرف له هذا الشهر: ${r.visitsReceived}" + (r.visitScore?.let { " · متوسط التقييم ${oneDecimal(it)}/5" } ?: ""), style = MaterialTheme.typography.bodyMedium)
                            if (r.openActions > 0) Text("إجراءات مطلوبة منه لم تُنفّذ: ${r.openActions}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                        } else {
                            Text("حلقات تحت إشرافه: ${r.halaqas.size} · زار منها هذا الشهر: ${r.halaqasVisited}", style = MaterialTheme.typography.bodyMedium)
                            Text("عدد الزيارات المسجلة: ${r.visitsMade} · آخر نشاط: ${r.lastSession ?: "—"}", style = MaterialTheme.typography.bodyMedium)
                        }
                        if (r.phone.isNotBlank()) Text("الهاتف: ${r.phone}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { alertFor = r }, modifier = Modifier.weight(1f).heightIn(min = 44.dp), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("إرسال تنبيه", maxLines = 1) }
                            if (!r.isSupervisor && r.halaqas.isNotEmpty()) OutlinedButton(
                                onClick = { AddActionBus.request("visit:${r.halaqas.first().first}"); navigate("visits") },
                                modifier = Modifier.weight(1f).heightIn(min = 44.dp), contentPadding = PaddingValues(horizontal = 8.dp),
                            ) { Text("تسجيل زيارة", maxLines = 1) }
                            if (isAdmin) OutlinedButton(onClick = { navigate("users") }, modifier = Modifier.weight(1f).heightIn(min = 44.dp), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("الحساب", maxLines = 1) }
                        }
                    }
                    }
                  }
                }
            }
        }
    }
    alertFor?.let { r ->
        SupAlertDialog(
            recipients = listOf(r.id to r.name), halaqaId = r.halaqas.firstOrNull()?.first,
            close = { alertFor = null }, onSent = { toast = "وصل التنبيه إلى ${r.name}" },
        )
    }
}
