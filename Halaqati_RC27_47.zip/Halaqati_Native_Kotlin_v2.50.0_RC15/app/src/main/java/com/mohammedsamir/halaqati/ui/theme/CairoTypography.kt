@file:OptIn(ExperimentalTextApi::class)

package com.mohammedsamir.halaqati.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.mohammedsamir.halaqati.R

/** Cairo is the single application typeface. The variable font is embedded by CI before resource processing. */
/**
 * RC27.2: Cairo is a VARIABLE font (wght axis). Registering the same file for every weight without
 * variation settings made Compose draw every weight at the font's default instance, so "Bold" titles
 * looked regular and text looked weak. Each weight now pins its own wght value (API 26+; older
 * devices keep the default instance because Android cannot vary a font axis there).
 */
/**
 * RC27.11: the screens ask for Bold / ExtraBold / SemiBold in a dozen places, which made the same kind of text look
 * thin on one screen and heavy on the next. All three "strong" requests now draw the SAME refined weight, so a title
 * looks the same everywhere; body text stays at Normal / Medium.
 */
private fun cairo(weight: FontWeight, drawn: Int = weight.weight) = Font(
    R.font.cairo,
    weight,
    variationSettings = FontVariation.Settings(FontVariation.weight(drawn)),
)

val CairoFamily = FontFamily(
    cairo(FontWeight.Light),
    cairo(FontWeight.Normal),
    cairo(FontWeight.Medium),
    cairo(FontWeight.SemiBold, drawn = 640),
    cairo(FontWeight.Bold, drawn = 640),
    cairo(FontWeight.ExtraBold, drawn = 640),
)

/** RC17.1 hierarchy: names/titles are strong, supporting copy is intentionally lighter. */
fun cairoTypography() = Typography(
    displayLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 44.sp, lineHeight = 58.sp),
    displayMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 38.sp, lineHeight = 50.sp),
    displaySmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 44.sp),
    headlineLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 40.sp),
    headlineMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 25.sp, lineHeight = 36.sp),
    headlineSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 24.sp),
    titleSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 18.sp),
    labelSmall = TextStyle(fontFamily = CairoFamily, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
)
