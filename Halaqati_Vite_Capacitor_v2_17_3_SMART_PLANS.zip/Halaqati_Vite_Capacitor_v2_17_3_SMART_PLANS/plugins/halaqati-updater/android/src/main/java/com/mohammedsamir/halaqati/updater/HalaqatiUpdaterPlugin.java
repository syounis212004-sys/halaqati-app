
package com.mohammedsamir.halaqati.updater;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@CapacitorPlugin(name = "HalaqatiUpdater")
public class HalaqatiUpdaterPlugin extends Plugin {

    @PluginMethod
    public void getVersion(PluginCall call) {
        try {
            PackageInfo info = getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), 0);
            JSObject out = new JSObject();
            out.put("versionName", info.versionName == null ? "" : info.versionName);
            long code = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? info.getLongVersionCode() : info.versionCode;
            out.put("versionCode", code);
            boolean canInstall = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || getContext().getPackageManager().canRequestPackageInstalls();
            out.put("canInstallPackages", canInstall);
            call.resolve(out);
        } catch (Exception e) {
            call.reject("تعذر قراءة إصدار التطبيق", e);
        }
    }

    @PluginMethod
    public void openInstallPermissionSettings(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getContext().getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("تعذر فتح إعداد السماح بالتثبيت", e);
        }
    }

    @PluginMethod
    public void downloadAndInstall(PluginCall call) {
        String url = call.getString("url", "");
        String expectedPackage = call.getString("expectedPackage", getContext().getPackageName());
        Integer expectedCode = call.getInt("expectedVersionCode");
        if (url == null || url.trim().isEmpty()) { call.reject("رابط التحديث غير صالح"); return; }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !getContext().getPackageManager().canRequestPackageInstalls()) {
            JSObject out = new JSObject(); out.put("permissionRequired", true); call.resolve(out); return;
        }

        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL u = new URL(url);
                conn = (HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(20000); conn.setReadTimeout(60000); conn.setInstanceFollowRedirects(true);
                conn.connect();
                if (conn.getResponseCode() < 200 || conn.getResponseCode() >= 300) throw new Exception("HTTP " + conn.getResponseCode());
                long total = conn.getContentLengthLong();
                File dir = new File(getContext().getExternalCacheDir() != null ? getContext().getExternalCacheDir() : getContext().getCacheDir(), "updates");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد التحديث");
                File apk = new File(dir, "Halaqati-update.apk");
                long done = 0; int lastPercent = -1;
                try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(apk)) {
                    byte[] buf = new byte[64 * 1024]; int n;
                    while ((n = in.read(buf)) >= 0) {
                        if (n == 0) continue;
                        out.write(buf, 0, n); done += n;
                        int percent = total > 0 ? (int)Math.min(100, (done * 100L) / total) : 0;
                        if (percent != lastPercent) { lastPercent = percent; JSObject ev = new JSObject(); ev.put("percent", percent); notifyListeners("downloadProgress", ev); }
                    }
                    out.flush();
                }

                PackageManager pm = getContext().getPackageManager();
                PackageInfo archive = pm.getPackageArchiveInfo(apk.getAbsolutePath(), 0);
                if (archive == null || archive.packageName == null) throw new Exception("ملف APK غير صالح");
                if (expectedPackage != null && !expectedPackage.equals(archive.packageName)) throw new Exception("حزمة التحديث لا تطابق تطبيق حلقتي");
                long archiveCode = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? archive.getLongVersionCode() : archive.versionCode;
                if (expectedCode != null && expectedCode > 0 && archiveCode != expectedCode.longValue()) throw new Exception("رقم إصدار APK لا يطابق ملف التحديث");

                Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".halaqati.update.provider", apk);
                Intent install = new Intent(Intent.ACTION_VIEW);
                install.setDataAndType(uri, "application/vnd.android.package-archive");
                install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                getActivity().runOnUiThread(() -> {
                    try {
                        getContext().startActivity(install);
                        JSObject result = new JSObject(); result.put("started", true); call.resolve(result);
                    } catch (Exception e) { call.reject("تعذر فتح مثبت Android", e); }
                });
            } catch (Exception e) {
                call.reject("تعذر تنزيل أو التحقق من التحديث: " + e.getMessage(), e);
            } finally { if (conn != null) conn.disconnect(); }
        }).start();
    }
}
