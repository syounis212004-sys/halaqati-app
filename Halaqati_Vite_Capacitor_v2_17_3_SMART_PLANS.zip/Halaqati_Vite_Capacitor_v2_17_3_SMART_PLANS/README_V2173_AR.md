# حلقتي v2.17.3

حزمة مشروع Vite/Capacitor قابلة للبناء على GitHub Actions بنفس مسار إصدارات حلقتي السابقة.
الإصدار يحتوي Web v2.17.3 المعدل، Capacitor 8، إضافة التحديث، رابط OAuth العميق، وملفات التحقق والبناء.

مهم: إصلاح View الإحصائيات الشهرية موجود في `Halaqati-v2.17.3-monthly-stats-fix.sql` ويُشغّل مرة واحدة في Supabase SQL Editor، وليس أثناء بناء APK.
