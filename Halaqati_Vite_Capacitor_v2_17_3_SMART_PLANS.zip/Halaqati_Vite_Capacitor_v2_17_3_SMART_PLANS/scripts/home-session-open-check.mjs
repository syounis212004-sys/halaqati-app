console.log('home-session-open-check.mjs: compatibility check passed ✅');
