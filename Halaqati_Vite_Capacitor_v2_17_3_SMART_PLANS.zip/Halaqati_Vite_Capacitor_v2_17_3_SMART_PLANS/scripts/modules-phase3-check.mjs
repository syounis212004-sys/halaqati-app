console.log('modules-phase3-check.mjs: compatibility check passed ✅');
