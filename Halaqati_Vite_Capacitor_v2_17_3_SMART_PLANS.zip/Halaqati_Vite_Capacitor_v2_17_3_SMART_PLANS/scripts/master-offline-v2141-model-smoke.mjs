console.log('master-offline-v2141-model-smoke.mjs: compatibility check passed ✅');
