
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
const apk=process.argv[2];
if(!apk || !fs.existsSync(apk)) throw new Error('APK path missing');
const out=path.resolve('update-publish');
fs.rmSync(out,{recursive:true,force:true}); fs.mkdirSync(out,{recursive:true});
fs.copyFileSync(apk,path.join(out,'Halaqati-latest.apk'));
const manifest={
  version:'2.17.3', versionName:'2.17.3', versionCode:21703,
  apkUrl:'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
  mandatory:false,
  notes:[
    'إصلاح الإحصائيات الشهرية وحدود التاريخ بالتوقيت المحلي.',
    'إضافة اختيار الشهر في الصفحة الرئيسية.',
    'إضافة رفع الجلسة وإعادة فتحها وتعديل بياناتها والحذف النهائي بعد التأكيد.',
    'تحويل أرقام الآيات العربية والفارسية تلقائياً إلى أرقام إنجليزية.'
  ]
};
fs.writeFileSync(path.join(out,'version.json'),JSON.stringify(manifest,null,2));
const zip=path.resolve('Halaqati-v2.17.3-publish-update.zip');
fs.rmSync(zip,{force:true});
execFileSync('zip',['-q','-9','-r',zip,'version.json','Halaqati-latest.apk'],{cwd:out});
console.log(zip);
