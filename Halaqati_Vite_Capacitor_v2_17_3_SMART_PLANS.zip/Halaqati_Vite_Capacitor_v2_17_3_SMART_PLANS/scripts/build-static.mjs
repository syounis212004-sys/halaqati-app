
import fs from 'node:fs';
import path from 'node:path';

const src = path.resolve('prebuilt-web');
const dst = path.resolve('dist');
if (!fs.existsSync(path.join(src, 'index.html'))) throw new Error('prebuilt-web/index.html missing');
fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true });
for (const file of ['Halaqati-latest.apk', '.nojekyll']) {
  fs.rmSync(path.join(dst, file), { force: true });
}
const index = fs.readFileSync(path.join(dst, 'index.html'), 'utf8');
if (!index.includes('2.17.3')) throw new Error('expected v2.17.3 index');
console.log('Halaqati v2.17.3 static web build copied to dist ✅');
