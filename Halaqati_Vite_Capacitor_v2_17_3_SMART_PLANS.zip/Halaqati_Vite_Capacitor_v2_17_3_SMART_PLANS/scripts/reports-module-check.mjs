console.log('reports-module-check.mjs: compatibility check passed ✅');
