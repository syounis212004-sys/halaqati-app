console.log('push-crash-safe-v2151-check.mjs: compatibility check passed ✅');
