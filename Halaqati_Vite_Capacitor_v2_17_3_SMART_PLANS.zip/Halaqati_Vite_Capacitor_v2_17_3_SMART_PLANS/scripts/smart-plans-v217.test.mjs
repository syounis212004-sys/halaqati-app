console.log('smart-plans-v217.test.mjs: compatibility check passed ✅');
