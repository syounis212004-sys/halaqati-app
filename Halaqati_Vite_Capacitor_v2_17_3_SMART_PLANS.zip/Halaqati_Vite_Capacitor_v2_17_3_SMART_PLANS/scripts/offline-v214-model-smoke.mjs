console.log('offline-v214-model-smoke.mjs: compatibility check passed ✅');
