
import fs from 'node:fs';
const p='android/app/build.gradle';
let s=fs.readFileSync(p,'utf8');
s=s.replace(/versionCode\s+\d+/, 'versionCode 21703');
s=s.replace(/versionName\s+["'][^"']+["']/, 'versionName "2.17.3"');
fs.writeFileSync(p,s);
if (!s.includes('versionCode 21703') || !s.includes('versionName "2.17.3"')) throw new Error('Android version not configured');
console.log('Android version set to 2.17.3 (21703) ✅');
