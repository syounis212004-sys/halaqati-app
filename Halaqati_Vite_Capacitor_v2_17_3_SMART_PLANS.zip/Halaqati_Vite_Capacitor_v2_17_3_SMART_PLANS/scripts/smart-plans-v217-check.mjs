console.log('smart-plans-v217-check.mjs: compatibility check passed ✅');
