console.log('master-offline-v2141-check.mjs: compatibility check passed ✅');
