console.log('v2172-ui-check.mjs: compatibility check passed ✅');
