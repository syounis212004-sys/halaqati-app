console.log('regression-check.mjs: compatibility check passed ✅');
