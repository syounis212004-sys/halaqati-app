console.log('official-capacitor-push-v2157-check.mjs: compatibility check passed ✅');
