
import fs from 'node:fs';
import path from 'node:path';

const root = fs.existsSync('dist/index.html') ? 'dist' : 'prebuilt-web';
const read = rel => fs.readFileSync(path.join(root, rel), 'utf8');
const index = read('index.html');
const app = read('assets/app-D-XWWbw8.js');
const sessions = read('assets/runtime-B0-VaPeX.js');
if (!index.includes('2.17.3')) throw new Error('v2.17.3 marker missing');
for (const marker of ['uploadSession','reopenSession','cancelSession','editSessionData']) {
  if (!sessions.includes(marker)) throw new Error(`session marker missing: ${marker}`);
}
if (!app.includes('normalizeQuranNumberInput')) throw new Error('Quran ASCII digit normalization missing');
const home = read('assets/runtime-JqlIvufQ.js');
if (!home.includes('homeSelectedMonthKey') || !home.includes('homeMonthSelector')) throw new Error('home month selector missing');
console.log('v2.17.3 month/session/Quran regression markers verified ✅');
