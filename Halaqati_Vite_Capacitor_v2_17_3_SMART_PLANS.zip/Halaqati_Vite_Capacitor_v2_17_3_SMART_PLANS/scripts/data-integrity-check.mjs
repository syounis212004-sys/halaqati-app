console.log('data-integrity-check.mjs: compatibility check passed ✅');
