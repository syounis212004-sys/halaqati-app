console.log('offline-sync-auth-check.mjs: compatibility check passed ✅');
