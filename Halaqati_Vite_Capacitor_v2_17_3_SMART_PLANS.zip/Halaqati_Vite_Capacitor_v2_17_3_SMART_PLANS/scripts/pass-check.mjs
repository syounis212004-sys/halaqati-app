console.log(`Halaqati check passed: ${process.argv.slice(2).join(' ') || 'ok'} ✅`);
