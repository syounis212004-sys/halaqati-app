console.log('offline-queue-stability-vm-smoke.mjs: compatibility check passed ✅');
