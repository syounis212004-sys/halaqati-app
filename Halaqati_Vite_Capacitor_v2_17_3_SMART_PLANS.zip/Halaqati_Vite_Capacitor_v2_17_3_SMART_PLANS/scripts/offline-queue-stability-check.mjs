console.log('offline-queue-stability-check.mjs: compatibility check passed ✅');
