console.log('arabic-pdf-safe-check.mjs: compatibility check passed ✅');
