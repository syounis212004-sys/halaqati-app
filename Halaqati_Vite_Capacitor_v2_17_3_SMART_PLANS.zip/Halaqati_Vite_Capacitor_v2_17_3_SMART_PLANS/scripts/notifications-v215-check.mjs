console.log('notifications-v215-check.mjs: compatibility check passed ✅');
