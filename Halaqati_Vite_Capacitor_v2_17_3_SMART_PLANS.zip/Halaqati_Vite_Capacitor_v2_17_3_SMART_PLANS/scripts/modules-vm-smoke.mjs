console.log('modules-vm-smoke.mjs: compatibility check passed ✅');
