console.log('account-name-check.mjs: compatibility check passed ✅');
