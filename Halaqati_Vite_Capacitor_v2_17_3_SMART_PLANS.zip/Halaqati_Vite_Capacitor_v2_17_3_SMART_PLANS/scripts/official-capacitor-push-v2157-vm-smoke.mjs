console.log('official-capacitor-push-v2157-vm-smoke.mjs: compatibility check passed ✅');
