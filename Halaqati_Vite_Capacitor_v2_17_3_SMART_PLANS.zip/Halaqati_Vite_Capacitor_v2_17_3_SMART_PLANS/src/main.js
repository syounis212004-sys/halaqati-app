export const HALAQATI_VERSION='2.17.3';
export const RELEASE_SOURCE='prebuilt-web';
