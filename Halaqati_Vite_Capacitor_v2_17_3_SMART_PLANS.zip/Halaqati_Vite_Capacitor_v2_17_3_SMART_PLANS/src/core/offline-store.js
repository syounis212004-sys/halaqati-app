export const offlineStoreVersion='2.17.3';
