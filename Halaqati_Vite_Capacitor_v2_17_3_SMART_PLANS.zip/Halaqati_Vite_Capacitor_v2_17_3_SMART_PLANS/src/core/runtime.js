export const coreRuntimeVersion='2.17.3';
