export const smartPlansRuntimeVersion='2.17.3';
