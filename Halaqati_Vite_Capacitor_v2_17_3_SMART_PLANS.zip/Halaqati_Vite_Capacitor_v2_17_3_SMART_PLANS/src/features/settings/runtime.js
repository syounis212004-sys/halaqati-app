export const settingsRuntimeVersion='2.17.3';
