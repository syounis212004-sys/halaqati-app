// Official Capacitor PushNotifications path only.
export const pushProvider='@capacitor/push-notifications';
