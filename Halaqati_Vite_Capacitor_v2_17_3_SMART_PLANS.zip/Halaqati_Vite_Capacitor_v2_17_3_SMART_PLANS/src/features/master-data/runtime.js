export const masterDataRuntimeVersion='2.17.3';
