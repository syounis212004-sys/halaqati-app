// Compatibility ownership marker. Runtime release code is in prebuilt-web/assets.
export const legacyRuntimeVersion='2.17.3';
