// Existing halaqati-notify function remains deployed; source marker for release package.
