// Compatibility file for Halaqati source-package workflow.
export default {};
