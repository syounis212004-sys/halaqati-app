/* Halaqati v2.14.1 — startup hooks. Kept last to preserve the original boot timing. */
applySavedTheme();
const recoveryInUrl=location.hash.includes('type=recovery')||location.search.includes('type=recovery');
db.auth.onAuthStateChange((event,session)=>{if(event==='PASSWORD_RECOVERY')setTimeout(()=>showPasswordRecovery(),0)});
(async()=>{if(recoveryInUrl){showPasswordRecovery();return}let session=null;try{let r=await withTimeout(db.auth.getSession(),500,'session timeout');session=r?.data?.session||null}catch(e){}if(session?.user)await boot(session.user);else{let last=readOfflineAuth();if(last){state.user=last;await prepareOfflineStorageForUser(last.id);if(restoreSnapshot()){captureSyncSessionDependencies();state.fastStarted=true;showApp();setTimeout(()=>refreshFromServer({renderAfter:true}),80)}}}})();
setTimeout(()=>ensureQuranLayout(true),900);
setInterval(async()=>{if(state.user&&readOfflineQueue().length&&navigator.onLine&&!state.syncing)await syncOfflineQueue()},20000);
// Service Worker registration moved to src/core/pwa.js in v2.12.

/* ---- migrated from v2.11 legacy runtime ---- */
