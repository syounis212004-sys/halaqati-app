package com.mohammedsamir.halaqati.pdf;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.provider.MediaStore;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "HalaqatiPdf")
public class HalaqatiPdfPlugin extends Plugin {
    private interface Failer { void fail(String message); }
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @PluginMethod
    public void exportPdf(PluginCall call) {
        final String html = call.getString("html", "");
        final String requestedName = call.getString("filename", "halaqati-report.pdf");
        final String orientation = call.getString("orientation", "landscape");
        if (html == null || html.trim().isEmpty()) {
            call.reject("PDF HTML is empty");
            return;
        }
        if (html.length() > 12_000_000) {
            call.reject("PDF HTML is too large");
            return;
        }
        final String filename = safePdfName(requestedName);
        final Activity activity = getActivity();
        if (activity == null) {
            call.reject("Android activity is unavailable");
            return;
        }
        activity.runOnUiThread(() -> startExport(activity, call, html, filename, orientation));
    }

    private void startExport(Activity activity, PluginCall call, String html, String filename, String orientation) {
        final AtomicBoolean terminal = new AtomicBoolean(false);
        final WebView webView = new WebView(activity);
        final Runnable[] timeoutRef = new Runnable[1];
        final int[] pollCount = new int[]{0};

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setLoadsImagesAutomatically(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        webView.setBackgroundColor(0xFFFFFFFF);

        Runnable cleanup = () -> {
            try { webView.stopLoading(); } catch (Throwable ignored) {}
            try { webView.loadUrl("about:blank"); } catch (Throwable ignored) {}
            try { webView.destroy(); } catch (Throwable ignored) {}
        };

        Failer fail = message -> {
            if (!terminal.compareAndSet(false, true)) return;
            if (timeoutRef[0] != null) mainHandler.removeCallbacks(timeoutRef[0]);
            cleanup.run();
            call.reject(message == null ? "تعذر إنشاء PDF" : message);
        };

        timeoutRef[0] = () -> fail.fail("انتهت مهلة تجهيز PDF. حاول مرة أخرى.");
        mainHandler.postDelayed(timeoutRef[0], 25_000L);

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pollReady(view, activity, call, filename, orientation, terminal, timeoutRef, cleanup, fail, pollCount);
            }
        });

        webView.loadDataWithBaseURL("https://halaqati.local/", html, "text/html", "UTF-8", null);
    }

    private void pollReady(WebView webView, Activity activity, PluginCall call, String filename, String orientation,
                           AtomicBoolean terminal, Runnable[] timeoutRef, Runnable cleanup,
                           Failer fail, int[] pollCount) {
        if (terminal.get()) return;
        final String readyJs = "(function(){try{return (!!document.body && document.readyState==='complete' && (!document.fonts || document.fonts.status==='loaded') && Array.prototype.every.call(document.images,function(i){return i.complete;})) ? 'READY' : 'WAIT';}catch(e){return 'WAIT';}})();";
        webView.evaluateJavascript(readyJs, value -> {
            if (terminal.get()) return;
            String v = value == null ? "" : value.replace("\"", "");
            if ("READY".equals(v) || pollCount[0]++ >= 80) {
                beginPrint(webView, activity, call, filename, orientation, terminal, timeoutRef, cleanup, fail);
            } else {
                mainHandler.postDelayed(() -> pollReady(webView, activity, call, filename, orientation, terminal, timeoutRef, cleanup, fail, pollCount), 120L);
            }
        });
    }

    private void beginPrint(WebView webView, Activity activity, PluginCall call, String filename, String orientation,
                            AtomicBoolean terminal, Runnable[] timeoutRef, Runnable cleanup,
                            Failer fail) {
        if (terminal.get()) return;
        if (timeoutRef[0] != null) mainHandler.removeCallbacks(timeoutRef[0]);
        timeoutRef[0] = () -> fail.fail("انتهت مهلة كتابة PDF. حاول مرة أخرى.");
        mainHandler.postDelayed(timeoutRef[0], 30_000L);

        File temp;
        try {
            temp = File.createTempFile("halaqati-vector-", ".pdf", activity.getCacheDir());
        } catch (Exception e) {
            fail.fail("تعذر إنشاء ملف PDF مؤقت: " + e.getMessage());
            return;
        }

        PrintAttributes.MediaSize media = PrintAttributes.MediaSize.ISO_A4;
        if ("landscape".equalsIgnoreCase(orientation)) media = media.asLandscape();
        else media = media.asPortrait();
        PrintAttributes attrs = new PrintAttributes.Builder()
                .setMediaSize(media)
                .setResolution(new PrintAttributes.Resolution("halaqati-vector", "Halaqati Vector", 600, 600))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build();

        PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("Halaqati");
        CancellationSignal cancellation = new CancellationSignal();
        adapter.onStart();
        adapter.onLayout(null, attrs, cancellation, new PrintDocumentAdapter.LayoutResultCallback() {
            @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                if (terminal.get()) return;
                final ParcelFileDescriptor pfd;
                try {
                    pfd = ParcelFileDescriptor.open(temp,
                            ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_READ_WRITE);
                } catch (Exception e) {
                    try { adapter.onFinish(); } catch (Throwable ignored) {}
                    temp.delete();
                    fail.fail("تعذر فتح ملف PDF المؤقت: " + e.getMessage());
                    return;
                }
                adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, pfd, cancellation, new PrintDocumentAdapter.WriteResultCallback() {
                    @Override public void onWriteFinished(PageRange[] pages) {
                        try { pfd.close(); } catch (Exception ignored) {}
                        try { adapter.onFinish(); } catch (Throwable ignored) {}
                        new Thread(() -> {
                            try {
                                Uri uri = persistPdf(activity, temp, filename);
                                temp.delete();
                                activity.runOnUiThread(() -> {
                                    if (!terminal.compareAndSet(false, true)) return;
                                    if (timeoutRef[0] != null) mainHandler.removeCallbacks(timeoutRef[0]);
                                    cleanup.run();
                                    JSObject out = new JSObject();
                                    out.put("saved", true);
                                    out.put("filename", filename);
                                    out.put("uri", uri == null ? "" : uri.toString());
                                    out.put("engine", "chromium-webview-vector");
                                    call.resolve(out);
                                });
                            } catch (Exception e) {
                                temp.delete();
                                activity.runOnUiThread(() -> fail.fail("تعذر حفظ PDF: " + e.getMessage()));
                            }
                        }, "halaqati-pdf-save").start();
                    }
                    @Override public void onWriteFailed(CharSequence error) {
                        try { pfd.close(); } catch (Exception ignored) {}
                        try { adapter.onFinish(); } catch (Throwable ignored) {}
                        temp.delete();
                        fail.fail(error == null ? "فشلت كتابة PDF" : error.toString());
                    }
                    @Override public void onWriteCancelled() {
                        try { pfd.close(); } catch (Exception ignored) {}
                        try { adapter.onFinish(); } catch (Throwable ignored) {}
                        temp.delete();
                        fail.fail("تم إلغاء إنشاء PDF");
                    }
                });
            }
            @Override public void onLayoutFailed(CharSequence error) {
                try { adapter.onFinish(); } catch (Throwable ignored) {}
                temp.delete();
                fail.fail(error == null ? "فشل تخطيط PDF" : error.toString());
            }
            @Override public void onLayoutCancelled() {
                try { adapter.onFinish(); } catch (Throwable ignored) {}
                temp.delete();
                fail.fail("تم إلغاء تخطيط PDF");
            }
        }, new Bundle());
    }

    private Uri persistPdf(Activity activity, File source, String filename) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = activity.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Halaqati");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("تعذر إنشاء ملف في التنزيلات");
            try (InputStream in = new FileInputStream(source); OutputStream out = resolver.openOutputStream(uri, "w")) {
                if (out == null) throw new Exception("تعذر فتح ملف التنزيل");
                copy(in, out);
            } catch (Exception e) {
                resolver.delete(uri, null, null);
                throw e;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Downloads.IS_PENDING, 0);
            resolver.update(uri, done, null, null);
            return uri;
        }
        File base = activity.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if (base == null) base = activity.getFilesDir();
        File dir = new File(base, "Halaqati");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد Halaqati");
        File dest = new File(dir, filename);
        try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(dest)) { copy(in, out); }
        return Uri.fromFile(dest);
    }

    private void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buffer = new byte[64 * 1024];
        int n;
        while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        out.flush();
    }

    private String safePdfName(String value) {
        String s = value == null ? "halaqati-report.pdf" : value.trim();
        s = s.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "_");
        if (!s.toLowerCase().endsWith(".pdf")) s += ".pdf";
        if (s.length() > 120) s = s.substring(0, 116) + ".pdf";
        return s.isEmpty() ? "halaqati-report.pdf" : s;
    }
}
