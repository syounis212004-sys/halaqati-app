from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.29',
    'versionCode':28929,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "بطاقة الترحيب (محفّظ، مشرف، مسؤول) تعرض صورة حساب صاحبها، وفي الرئيسية لولي الأمر بطاقة واحدة تجمع التحية والآية مع بطاقة الابن وصورته",
        "صورة الحساب في رأس القائمة الجانبية بدل الأيقونة العامة",
        "حذف بطاقة النجمة «التسميع اليوم» من الرئيسية",
        "انتقالات الصفحات الإدارية (الحسابات، الهيكل، الفريق، الطلاب، التقارير …) تنزلق بنعومة، وبطاقات الهيكل الإداري تتحرك عند الإضافة والإزالة",
        "يشمل أيضًا إصلاح أرقام حاضر وبانتظارك وأتمّ التسميع، وإزالة العناصر من الجمعية",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
