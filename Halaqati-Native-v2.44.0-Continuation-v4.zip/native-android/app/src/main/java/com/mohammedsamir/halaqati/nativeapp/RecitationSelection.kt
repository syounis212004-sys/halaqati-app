package com.mohammedsamir.halaqati.nativeapp

import org.json.JSONArray
import org.json.JSONObject

/**
 * Native counterpart of the web session range picker.
 *
 * The database contract is deliberately kept identical: the range is stored
 * in the top-level recitation columns and the picker state is stored in
 * selection_data.  QCF line keys are only written when an exact line map is
 * available; this module uses the pinned page/ayah metadata and never invents
 * line coordinates.
 */
object RecitationSelection {
    private fun selected(values: Iterable<Int>) = JSONArray().also { out -> values.distinct().sorted().forEach { value -> out.put(value) } }

    private fun base(mode: String, pages: Any, ayahs: Int, surahs: Int, selection: JSONObject): JSONObject =
        JSONObject()
            .put("input_method", mode)
            .put("start_page", selection.optInt("range_start_page").takeIf { it > 0 } ?: JSONObject.NULL)
            .put("end_page", selection.optInt("range_end_page").takeIf { it > 0 } ?: JSONObject.NULL)
            .put("start_surah", selection.optInt("range_start_surah").takeIf { it > 0 } ?: JSONObject.NULL)
            .put("start_ayah", selection.optInt("range_start_ayah").takeIf { it > 0 } ?: JSONObject.NULL)
            .put("end_surah", selection.optInt("range_end_surah").takeIf { it > 0 } ?: JSONObject.NULL)
            .put("end_ayah", selection.optInt("range_end_ayah").takeIf { it > 0 } ?: JSONObject.NULL)
            .put("pages_count", pages)
            .put("ayahs_count", ayahs)
            .put("surahs_count", surahs)
            .put("selected_surahs", selection.optJSONArray("selected_surahs") ?: JSONArray())
            .put("selection_data", selection.put("mode", mode).put("qcf_line_keys", JSONArray()))

    fun pages(start: Int, end: Int): JSONObject {
        require(start in 1..QuranMetadata.pageCount && end in start..QuranMetadata.pageCount) { "نطاق الصفحات غير صحيح" }
        val first = QuranMetadata.first(start); val last = QuranMetadata.last(end)
        val data = JSONObject().put("range_start_page", start).put("range_end_page", end)
            .put("selected_surahs", JSONArray()).put("selected_juz", JSONArray())
            .put("start_global", QuranMetadata.ayahId(first.first, first.second))
            .put("end_global", QuranMetadata.ayahId(last.first, last.second))
        return base("pages", end - start + 1, data.optInt("end_global") - data.optInt("start_global") + 1, 0, data)
    }

    fun ayahs(startSurah: Int, startAyah: Int, endSurah: Int, endAyah: Int): JSONObject {
        val start = QuranMetadata.ayahId(startSurah, startAyah); val end = QuranMetadata.ayahId(endSurah, endAyah)
        require(end >= start) { "نهاية نطاق الآيات يجب أن تكون بعد بدايته" }
        val startPage = QuranMetadata.page(startSurah, startAyah); val endPage = QuranMetadata.page(endSurah, endAyah)
        val data = JSONObject().put("range_start_page", startPage).put("range_end_page", endPage)
            .put("range_start_surah", startSurah).put("range_start_ayah", startAyah)
            .put("range_end_surah", endSurah).put("range_end_ayah", endAyah)
            .put("start_global", start).put("end_global", end)
            .put("selected_surahs", JSONArray()).put("selected_juz", JSONArray())
        return base("ayahs", ((end - start + 1) / 15.0).coerceAtLeast(.01).let { number(it) }, end - start + 1, if (startSurah == endSurah) 1 else endSurah - startSurah + 1, data)
    }

    fun surahs(start: Int, end: Int): JSONObject {
        require(start in 1..QuranMetadata.surahCount && end in start..QuranMetadata.surahCount) { "نطاق السور غير صحيح" }
        return ayahs(start, 1, end, QuranMetadata.surahAyahCount(end)).also {
            val selection = it.getJSONObject("selection_data").put("mode", "surahs")
            it.put("input_method", "surahs").put("selected_surahs", selected(start..end))
            selection.put("selected_surahs", selected(start..end)).put("selected_juz", JSONArray())
            it.put("selection_data", selection).put("surahs_count", end - start + 1)
        }
    }

    fun juzs(start: Int, end: Int): JSONObject {
        require(start in 1..QuranMetadata.juzCount && end in start..QuranMetadata.juzCount) { "نطاق الأجزاء غير صحيح" }
        val firstPage = QuranMetadata.juzPages(start).first; val lastPage = QuranMetadata.juzPages(end).last
        val result = pages(firstPage, lastPage); val selection = result.getJSONObject("selection_data").put("mode", "juz").put("selected_juz", selected(start..end))
        return result.put("input_method", "juz").put("selection_data", selection).put("selected_juz", selected(start..end))
    }

    fun fromInput(mode: String, values: List<Int>): JSONObject = when (mode) {
        "pages" -> pages(values.getOrNull(0) ?: 1, values.getOrNull(1) ?: values.getOrNull(0) ?: 1)
        "surahs" -> surahs(values.getOrNull(0) ?: 1, values.getOrNull(1) ?: values.getOrNull(0) ?: 1)
        "juz" -> juzs(values.getOrNull(0) ?: 1, values.getOrNull(1) ?: values.getOrNull(0) ?: 1)
        else -> error("استخدم ayahs(startSurah,startAyah,endSurah,endAyah) لنطاق الآيات")
    }

    private fun number(value: Double): Double = kotlin.math.round(value * 100.0) / 100.0
}
