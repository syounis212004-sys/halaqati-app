package com.mohammedsamir.halaqati.nativeapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Assignment
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.PauseCircle
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private val planKinds = linkedMapOf(
    "hifz" to "حفظ جديد", "review" to "مراجعة", "sard" to "سرد", "tathbit" to "تثبيت"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NativePlansScreen(state: AppState, id: String, repo: Repository, open: (String) -> Unit, add: () -> Unit, edit: (String) -> Unit) {
    var status by rememberSaveable { mutableStateOf("active") }
    val plans = state.data["plans"].orEmpty()
    val rows = plans.filter { id.isNotBlank() && it.text("id") == id || id.isBlank() && (status == "all" || it.text("status") == status) }
    if (id.isNotBlank()) {
        PlanDetailScreen(state, rows.firstOrNull(), repo) { edit(id) }
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الخطط الذكية", style = MaterialTheme.typography.headlineSmall)
                    Text("توزيع يومي مبني على أيام الدوام، التقدم الفعلي، والتعويض الآمن.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                linkedMapOf("active" to "نشطة", "archived" to "مؤرشفة", "all" to "الجميع").forEach { (key, label) ->
                    FilterChip(selected = status == key, onClick = { status = key }, label = { Text(label) })
                }
                if (canManage(state.profile)) FilledTonalButton(onClick = add) { Icon(Icons.Outlined.Flag, null); Text("خطة جديدة") }
            }
        }
        if (rows.isEmpty()) item { Text("لا توجد خطط في هذا العرض.", Modifier.padding(28.dp)) }
        items(rows, key = { it.text("id") }) { plan ->
            val student = state.data["students"].orEmpty().find { it.text("id") == plan.text("student_id") }
            Card(onClick = { open(plan.text("id")) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Outlined.Assignment, null, tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f)) {
                            Text(plan.text("title").ifBlank { "خطة ${planKinds[plan.text("plan_type")] ?: "ذكية"}" }, style = MaterialTheme.typography.titleMedium)
                            Text(student?.text("full_name").orEmpty().ifBlank { scopeLabel(plan) }, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(statusNames[plan.text("status")] ?: plan.text("status"), style = MaterialTheme.typography.labelMedium)
                    }
                    Text("${plan.text("start_date")} — ${plan.text("end_date")} · ${planKinds[plan.text("plan_type")] ?: plan.text("plan_type")}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlanDetailScreen(state: AppState, plan: JSONObject?, repo: Repository, edit: () -> Unit) {
    if (plan == null) { Text("الخطة غير متاحة.", Modifier.padding(28.dp)); return }
    val planId = plan.text("id")
    val candidates = state.data["students"].orEmpty().filter { student ->
        student.text("status") == "active" && planAppliesToStudent(plan, student)
    }
    var selectedStudent by rememberSaveable(planId) { mutableStateOf(plan.text("student_id").ifBlank { candidates.firstOrNull()?.text("id").orEmpty() }) }
    if (selectedStudent.isBlank() && candidates.isNotEmpty()) selectedStudent = candidates.first().text("id")
    LaunchedEffect(planId, selectedStudent) {
        if (selectedStudent.isNotBlank()) repo.launch { loadPlanActivity(planId, selectedStudent) }
    }
    val recitations = state.data["plan_recitations_$planId"].orEmpty()
    val sessions = state.data["plan_sessions_$planId"].orEmpty()
    val events = state.data["plan_events_$planId"].orEmpty()
    val progress = runCatching {
        PlanEngine.calculateProgress(JSONObject().put("plan", plan).put("studentId", selectedStudent)
            .put("recitations", recitations.json()).put("sessions", sessions.json()).put("events", events.json()).put("today", today()))
    }.getOrElse { JSONObject().put("error", it.message ?: "تعذر حساب التقدم") }
    val hasError = progress.has("error")
    val percentage = progress.optDouble("percentage", 0.0).coerceIn(0.0, 100.0)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(plan.text("title").ifBlank { "الخطة الذكية" }, style = MaterialTheme.typography.headlineSmall)
                    Text("${planKinds[plan.text("plan_type")] ?: plan.text("plan_type")} · ${scopeLabel(plan)}", style = MaterialTheme.typography.bodyMedium)
                    Text("${plan.text("start_date")} — ${plan.text("end_date")}", style = MaterialTheme.typography.bodySmall)
                    if (canManage(state.profile)) TextButton(onClick = edit) { Text("تعديل إعدادات الخطة") }
                }
            }
        }
        if (plan.text("student_id").isBlank() && candidates.isNotEmpty()) item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                candidates.take(12).forEach { student ->
                    FilterChip(selected = selectedStudent == student.text("id"), onClick = { selectedStudent = student.text("id") }, label = { Text(student.text("full_name")) })
                }
            }
        }
        item {
            if (hasError) PlanNotice(Icons.Outlined.WarningAmber, MaterialTheme.colorScheme.errorContainer, progress.text("error"))
            else {
                Text("${number(progress.optDouble("completed"))} من ${number(progress.optDouble("plan_target", plan.optDouble("target_pages", 0.0)))} صفحة · ${number(percentage)}%", style = MaterialTheme.typography.titleMedium)
                LinearProgressIndicator(progress = { (percentage / 100.0).toFloat() }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        }
        if (!hasError) {
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProgressTile("اليوم", number(progress.optDouble("dailyTarget")), Icons.Outlined.Event, Modifier.weight(1f))
                ProgressTile("المتبقي", number(progress.optDouble("remaining")), Icons.Outlined.Schedule, Modifier.weight(1f))
                ProgressTile("الحالة", progress.text("healthLabel").ifBlank { "—" }, if (progress.text("health") == "red") Icons.Outlined.WarningAmber else Icons.Outlined.CheckCircle, Modifier.weight(1f))
            } }
            item {
                val assignment = progress.optJSONObject("assignment")
                Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("التكليف التالي", style = MaterialTheme.typography.titleMedium)
                        if (assignment == null || assignment.optDouble("pages", 0.0) <= 0.0) Text("لا يوجد تكليف جديد اليوم.")
                        else {
                            Text("${assignmentLabel(assignment.text("kind"))} · ${number(assignment.optDouble("pages"))} صفحة")
                            InfoLine("النطاق", pageRange(assignment))
                            if (assignment.optBoolean("blockedByRetry")) Text("يبدأ التكليف بالتثبيت قبل الحفظ الجديد.", color = MaterialTheme.colorScheme.error)
                            if (assignment.optBoolean("isCatchUp")) Text("يوم تعويض", color = MaterialTheme.colorScheme.primary)
                            val milestone = assignment.optJSONObject("milestone")
                            if (milestone != null && canManage(state.profile) && selectedStudent.isNotBlank()) {
                                FilledTonalButton(onClick = {
                                    repo.launch { savePlanEvent(planId, selectedStudent, "milestone_approved", JSONObject().put("milestone_key", milestone.text("key")).put("approved_at", java.time.Instant.now().toString())) }
                                }) { Icon(Icons.Outlined.CheckCircle, null); Text("اعتماد الاختبار المرحلي") }
                            }
                        }
                    }
                }
            }
            item { FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (canManage(state.profile) && plan.text("status") == "active") FilledTonalButton({ repo.launch { savePlanStatus(planId, "archived") } }) { Icon(Icons.Outlined.PauseCircle, null); Text("أرشفة الخطة") }
                if (canManage(state.profile) && plan.text("status") == "archived") FilledTonalButton({ repo.launch { savePlanStatus(planId, "active") } }) { Icon(Icons.Outlined.Flag, null); Text("إعادة تنشيط") }
                OutlinedButton({ repo.launch { loadPlanActivity(planId, selectedStudent) } }, enabled = !state.busy) { Text("تحديث النشاط") }
            } }
        }
        item { Text("مصدر النشاط: ${recitations.size} تسميع · ${sessions.size} جلسة · ${events.size} حدث خطة", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable private fun PlanNotice(icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, text: String) {
    Surface(shape = RoundedCornerShape(14.dp), color = color) { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null); Text(text) } }
}

@Composable private fun ProgressTile(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Text(value, style = MaterialTheme.typography.titleMedium); Text(label, style = MaterialTheme.typography.labelSmall) } }
}

@Composable private fun InfoLine(label: String, value: String) { if (value.isNotBlank()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value) } }

private fun scopeLabel(plan: JSONObject): String = when (plan.text("scope_type")) { "halaqa" -> "على مستوى الحلقة"; "category" -> "على مستوى الفئة"; else -> "خطة طالب" }
private fun assignmentLabel(kind: String): String = when (kind) { "tathbit" -> "تثبيت"; "test" -> "اختبار"; "review" -> "مراجعة"; "sard" -> "سرد"; else -> "حفظ" }
private fun pageRange(assignment: JSONObject): String { val a = assignment.optInt("startPage"); val b = assignment.optInt("endPage"); return if (a <= 0) "يحدد بعد اعتماد النطاق" else if (a == b || b <= 0) "صفحة $a" else "صفحات $a–$b" }
private fun number(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else "%.2f".format(java.util.Locale.US, value).trimEnd('0').trimEnd('.')
