package com.mohammedsamir.halaqati.nativeapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONObject

@Composable
fun NativeRecitationForm(state: AppState, sessionId: String, studentId: String, repo: Repository, close: () -> Unit) {
    var mode by rememberSaveable { mutableStateOf("pages") }
    var pStart by rememberSaveable { mutableStateOf("") }; var pEnd by rememberSaveable { mutableStateOf("") }
    var sStart by rememberSaveable { mutableStateOf("1") }; var sEnd by rememberSaveable { mutableStateOf("1") }
    var aStartSurah by rememberSaveable { mutableStateOf("1") }; var aStartAyah by rememberSaveable { mutableStateOf("1") }
    var aEndSurah by rememberSaveable { mutableStateOf("1") }; var aEndAyah by rememberSaveable { mutableStateOf("7") }
    var jStart by rememberSaveable { mutableStateOf("1") }; var jEnd by rememberSaveable { mutableStateOf("1") }
    var mistakes by rememberSaveable { mutableStateOf("0") }; var prompts by rememberSaveable { mutableStateOf("0") }
    var activity by rememberSaveable { mutableStateOf("new_hifz") }; var note by rememberSaveable { mutableStateOf("") }; var plan by rememberSaveable { mutableStateOf("") }
    val selection = runCatching {
        when (mode) {
            "pages" -> RecitationSelection.pages(pStart.toInt(), pEnd.toInt())
            "ayahs" -> RecitationSelection.ayahs(aStartSurah.toInt(), aStartAyah.toInt(), aEndSurah.toInt(), aEndAyah.toInt())
            "surahs" -> RecitationSelection.surahs(sStart.toInt(), sEnd.toInt())
            else -> RecitationSelection.juzs(jStart.toInt(), jEnd.toInt())
        }
    }.getOrNull()
    val m = mistakes.toIntOrNull(); val pr = prompts.toIntOrNull()
    val valid = selection != null && m != null && m >= 0 && pr != null && pr >= 0
    val studentName = state.data["students"].orEmpty().find { it.text("id") == studentId }?.text("full_name").orEmpty()
    val student = state.data["students"].orEmpty().find { it.text("id") == studentId }
    val plans = state.data["plans"].orEmpty().filter { it.text("status") == "active" && planAppliesToStudent(it, student) }
    FormBody("إضافة تسميع") {
        Text(studentName)
        Select("طريقة اختيار النطاق", mode, linkedMapOf("pages" to "صفحات", "ayahs" to "آيات", "surahs" to "سور", "juz" to "أجزاء")) { mode = it }
        when (mode) {
            "pages" -> { Field("من الصفحة", pStart, { pStart = it }, numeric = true); Field("إلى الصفحة", pEnd, { pEnd = it }, numeric = true) }
            "ayahs" -> { Field("السورة من (1–114)", aStartSurah, { aStartSurah = it }, numeric = true); Field("الآية من", aStartAyah, { aStartAyah = it }, numeric = true); Field("السورة إلى (1–114)", aEndSurah, { aEndSurah = it }, numeric = true); Field("الآية إلى", aEndAyah, { aEndAyah = it }, numeric = true) }
            "surahs" -> { Field("السورة من (1–114)", sStart, { sStart = it }, numeric = true); Field("السورة إلى", sEnd, { sEnd = it }, numeric = true) }
            else -> { Field("الجزء من (1–30)", jStart, { jStart = it }, numeric = true); Field("الجزء إلى", jEnd, { jEnd = it }, numeric = true) }
        }
        Select("نوع التسميع", activity, activityNames) { activity = it }
        Field("الأخطاء", mistakes, { mistakes = it }, numeric = true); Field("التنبيهات", prompts, { prompts = it }, numeric = true)
        Select("الخطة المرتبطة", plan, linkedMapOf("" to "بدون ربط بخطة") + plans.associate { it.text("id") to it.text("title").ifBlank { "خطة ذكية" } }) { plan = it }
        if (selection != null) {
            val score = scoreV6(JSONObject().put("pages_count", selection.optDouble("pages_count", 0.0)).put("mistakes", m ?: 0).put("prompts", pr ?: 0))
            Text("${number(selection.optDouble("pages_count"))} صفحة تقريباً · ${selection.optInt("ayahs_count")} آية · ${score.text("points")} نقطة · ${evaluationNames[score.text("evaluation")].orEmpty()}")
            Text(selectionSummary(selection), style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
        }
        Field("ملاحظة المحفّظ", note, { note = it }, lines = 2)
        Button({
            val chosen = selection
            if (chosen != null) repo.launch { saveSelectedRecitation(sessionId, studentId, chosen, m ?: 0, pr ?: 0, activity, note, plan.takeIf { it.isNotBlank() }); close() }
        }, Modifier.fillMaxWidth(), enabled = !state.busy && valid) { Text("حفظ التسميع") }
    }
}

private fun selectionSummary(selection: JSONObject): String {
    val mode = selection.optJSONObject("selection_data")?.text("mode") ?: selection.text("input_method")
    return when (mode) {
        "pages" -> "صفحات ${selection.optInt("start_page")}–${selection.optInt("end_page")}"
        "ayahs" -> "آيات ${selection.optInt("start_surah")}:${selection.optInt("start_ayah")} ← ${selection.optInt("end_surah")}:${selection.optInt("end_ayah")}"
        "surahs" -> "سور ${selection.optJSONArray("selected_surahs")?.length() ?: 0}"
        "juz" -> "أجزاء ${selection.optJSONArray("selected_juz")?.length() ?: 0}"
        else -> "نطاق قرآن"
    }
}

private fun number(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else "%.2f".format(java.util.Locale.US, value).trimEnd('0').trimEnd('.')
