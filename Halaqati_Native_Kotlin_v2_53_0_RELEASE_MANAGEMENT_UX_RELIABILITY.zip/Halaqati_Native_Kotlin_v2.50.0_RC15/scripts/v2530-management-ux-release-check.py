from pathlib import Path

root = Path(__file__).resolve().parents[1]
repo = (root / 'app/src/main/java/com/mohammedsamir/halaqati/data/HalaqatiRepository.kt').read_text()
mgmt = (root / 'app/src/main/java/com/mohammedsamir/halaqati/ui/screens/ManagementScreens.kt').read_text()
core = (root / 'app/src/main/java/com/mohammedsamir/halaqati/ui/screens/CoreScreens.kt').read_text()
build = (root / 'app/build.gradle.kts').read_text()
publish = (root / 'scripts/make-update-publish.py').read_text()

def need(cond, msg):
    if not cond:
        raise AssertionError(msg)

need('versionCode = 25300' in build and 'versionName = "2.53.0"' in build, 'v2.53.0 version contract missing')
need('fun writeConfirmed(' in repo and 'fun patchConfirmed(' in repo and 'fun deleteConfirmed(' in repo, 'confirmed management mutations missing')
need('cache.invalidate(owner, "table:$table:")' in repo, 'table cache invalidation missing after confirmed mutation')
need('هذه العملية الإدارية تحتاج اتصالاً بالإنترنت' in repo, 'offline management failure must be explicit')

need('AppGraph.repo.writeConfirmed("halaqas", obj)' in mgmt, 'halaqa create still uses fire-and-forget outbox')
need('AppGraph.repo.writeConfirmed("announcements", obj)' in mgmt, 'announcement publish still uses fire-and-forget outbox')
need('AppGraph.repo.syncNow()' in mgmt and 'forceRefresh = true' in mgmt, 'management screens must flush legacy queued writes then pull authoritative rows')
need('AppGraph.repo.writeConfirmed("student_categories", obj)' in mgmt, 'category create still uses fire-and-forget outbox')
need('AppGraph.repo.deleteConfirmed("student_categories"' in mgmt and 'AppGraph.repo.patchConfirmed("students"' in mgmt, 'category deletion must confirm student unlink + delete')
need('AppGraph.repo.writeConfirmed(\n                                    "halaqa_teachers"' in mgmt, 'teacher assignment still queued without acknowledgement')
need('AppGraph.repo.writeConfirmed(\n                                    "halaqa_supervisors"' in mgmt, 'supervisor assignment still queued without acknowledgement')

need('announcementSaving' in mgmt and 'halaqaSaving' in mgmt, 'duplicate-submit guards missing')
need('جاري النشر' in mgmt and 'جاري الحفظ' in mgmt, 'saving feedback missing')
need('heightIn(max = 500.dp).verticalScroll(rememberScrollState()).imePadding()' in mgmt, 'long management forms are not bounded/scrollable')
need('maxLines = 8' in mgmt and 'heightIn(min = 150.dp, max = 230.dp)' in mgmt, 'announcement body must be height-capped')
need('errorText?.let' in mgmt, 'dialog-local error feedback missing')

need('if (canManage || rows.size > 4)' in core, 'guardian search should not consume viewport for small plan sets')
need('اختر الابن لمشاهدة مقرر اليوم وخطته الفعالة.' in core, 'compact guardian hero missing')
need('Modifier.padding(horizontal = 11.dp, vertical = 9.dp)' in core, 'guardian daily card is not compact')
need('Column(Modifier.padding(horizontal = 7.dp, vertical = 7.dp)' in core, 'plan stat tiles not compacted')

need("'versionName':'2.53.0'" in publish and "'versionCode':25300" in publish, 'publish manifest version mismatch')
need('إصلاح نشر الإعلانات' in publish and 'إصلاح إضافة وتعديل الحلقات' in publish, 'release notes missing reported fixes')

print('v2.53.0 management + guardian UX release gate PASS')
