from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.53.0',
    'versionCode':25300,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    'notes':[
        'إصلاح نشر الإعلانات: النص الطويل أصبح قابلاً للتمرير وزر النشر يبقى ظاهرًا.',
        'إصلاح إضافة وتعديل الحلقات وتعيين الطاقم مع تأكيد الحفظ من الخادم وإظهار الخطأ الحقيقي.',
        'تحسين صفحة خطط الأبناء لتوفير مساحة أكبر للخطة وتقليل الازدحام في أعلى الشاشة.',
        'إصلاح نمط النوافذ الطويلة في الفئات والمنشورات وتفضيلات الإشعارات والزيارات الإشرافية.',
        'تحسين موثوقية عمليات الإدارة ومنع إغلاق النافذة قبل تأكيد Supabase.'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
