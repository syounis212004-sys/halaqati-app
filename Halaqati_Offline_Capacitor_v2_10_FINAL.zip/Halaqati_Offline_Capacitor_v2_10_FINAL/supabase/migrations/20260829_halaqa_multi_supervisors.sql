-- Already applied to project xlxzwucqdtggkfwwqibk on 2026-08-29.
create table if not exists public.halaqa_supervisors (
  halaqa_id uuid not null references public.halaqas(id) on delete cascade,
  supervisor_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  created_by uuid null references public.profiles(id) on delete set null,
  primary key (halaqa_id, supervisor_id)
);
