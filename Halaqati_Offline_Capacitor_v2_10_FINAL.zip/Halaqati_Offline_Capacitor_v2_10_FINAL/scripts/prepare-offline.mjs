import fs from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const source = path.join(root, 'source', 'index.html');
const www = path.join(root, 'www');
const vendor = path.join(www, 'vendor');
const fontsDir = path.join(vendor, 'fonts');
await fs.rm(www, {recursive:true, force:true});
await fs.mkdir(fontsDir, {recursive:true});

let html = await fs.readFile(source, 'utf8');

const files = [
  ['https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2', 'supabase.min.js'],
  ['https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js', 'xlsx.full.min.js'],
  ['https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js', 'html2canvas.min.js'],
  ['https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js', 'jspdf.umd.min.js'],
  ['https://cdn.jsdelivr.net/npm/mammoth@1.8.0/mammoth.browser.min.js', 'mammoth.browser.min.js'],
  ['https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', 'pdf.min.js'],
  ['https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js', 'pdf.worker.min.js'],
  ['https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js', 'tesseract.min.js']
];

async function download(url, out) {
  const r = await fetch(url, {headers:{'user-agent':'Mozilla/5.0'}});
  if (!r.ok) throw new Error(`Download failed ${r.status}: ${url}`);
  const buf = Buffer.from(await r.arrayBuffer());
  await fs.writeFile(out, buf);
  console.log('saved', path.relative(root, out), buf.length);
}

for (const [url, name] of files) {
  await download(url, path.join(vendor, name));
}

const replacements = new Map([
  ['https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2', './vendor/supabase.min.js'],
  ['https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js', './vendor/xlsx.full.min.js'],
  ['https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js', './vendor/html2canvas.min.js'],
  ['https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js', './vendor/jspdf.umd.min.js'],
  ['https://cdn.jsdelivr.net/npm/mammoth@1.8.0/mammoth.browser.min.js', './vendor/mammoth.browser.min.js'],
  ['https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', './vendor/pdf.min.js'],
  ['https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js', './vendor/pdf.worker.min.js'],
  ['https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js', './vendor/tesseract.min.js']
]);
for (const [from,to] of replacements) html = html.split(from).join(to);

// Bundle Cairo font CSS + font files so the UI keeps its Arabic typography offline.
const fontCssUrl = 'https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&display=swap';
try {
  const r = await fetch(fontCssUrl, {headers:{'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36'}});
  if (!r.ok) throw new Error(`font css ${r.status}`);
  let css = await r.text();
  const urls = [...css.matchAll(/url\((https:\/\/[^)]+)\)/g)].map(m=>m[1]);
  const unique = [...new Set(urls)];
  for (let i=0;i<unique.length;i++) {
    const u = unique[i];
    const ext = (new URL(u).pathname.split('.').pop() || 'woff2').split('?')[0];
    const name = `cairo-${i}.${ext}`;
    await download(u, path.join(fontsDir, name));
    css = css.split(u).join(`./fonts/${name}`);
  }
  await fs.writeFile(path.join(vendor,'cairo.css'), css, 'utf8');
  html = html.replace(/<link[^>]+href=["']https:\/\/fonts\.googleapis\.com\/css2\?family=Cairo[^"']*["'][^>]*>/i, '<link rel="stylesheet" href="./vendor/cairo.css">');
  html = html.replace(/<link[^>]+href=["']https:\/\/fonts\.googleapis\.com["'][^>]*>/ig, '');
  html = html.replace(/<link[^>]+href=["']https:\/\/fonts\.gstatic\.com["'][^>]*>/ig, '');
} catch (e) {
  console.warn('Could not bundle Cairo font; system Arabic font will be used offline:', e.message);
  html = html.replace(/<link[^>]+href=["']https:\/\/fonts\.googleapis\.com[^"']*["'][^>]*>/ig, '');
  html = html.replace(/<link[^>]+href=["']https:\/\/fonts\.gstatic\.com[^"']*["'][^>]*>/ig, '');
}


// Bundle Quran page/line metadata so page calculations work from the first cold start offline.
// Source: QCF4 Hafs, Madinah Mushaf 1441 AH. Only compact metadata is bundled (no runtime API call).
const ayahCounts = [7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6];
const prefix=[0]; for(const n of ayahCounts) prefix.push(prefix[prefix.length-1]+n);
const globalAyah=(s,a)=>prefix[s-1]+a;
async function fetchJsonAny(urls){let last;for(const url of urls){try{const r=await fetch(url,{headers:{'user-agent':'Mozilla/5.0'}});if(!r.ok)throw new Error(String(r.status));return await r.json()}catch(e){last=e}}throw last||new Error('all Quran metadata sources failed')}
try{
  const verses=await fetchJsonAny([
    'https://raw.githubusercontent.com/MohamadHajjRabee/quran-qcf4/main/verses.json',
    'https://cdn.jsdelivr.net/gh/MohamadHajjRabee/quran-qcf4@main/verses.json'
  ]);
  const page=new Array(6237).fill(0), first=new Array(6237).fill(0), last=new Array(6237).fill(0);
  for(const [key,v] of Object.entries(verses)){
    const [ss,aa]=key.split(':').map(Number),g=globalAyah(ss,aa),lines=(v.lines||[]).map(x=>Number(x.line)).filter(Boolean);
    page[g]=Number(v.page||0); first[g]=lines.length?Math.min(...lines):0; last[g]=lines.length?Math.max(...lines):first[g];
  }
  if(page.filter(Boolean).length<6200) throw new Error('Quran metadata incomplete');
  const qdata={version:1,source:'QCF4 Hafs · Madinah Mushaf 1441 AH',lineModel:15,page,first,last};
  await fs.writeFile(path.join(vendor,'quran-layout.js'),'window.HALAQATI_QURAN_LAYOUT='+JSON.stringify(qdata)+';\n','utf8');
  html=html.replace('</head>','<script src="./vendor/quran-layout.js"></script>\n</head>');
  console.log('Bundled Quran layout:', page.filter(Boolean).length, 'ayahs');
}catch(e){
  console.warn('Could not bundle QCF4 line metadata; standalone fallback remains available:',e.message);
}

// Copy app icon + local manifest.
await fs.copyFile(path.join(root,'assets','icon-512.png'), path.join(www,'icon-512.png'));
await fs.writeFile(path.join(www,'manifest.webmanifest'), JSON.stringify({
  name:'حلقتي', short_name:'حلقتي', lang:'ar', dir:'rtl', display:'standalone',
  start_url:'./index.html', background_color:'#0d3b2f', theme_color:'#0d3b2f',
  icons:[{src:'./icon-512.png',sizes:'512x512',type:'image/png',purpose:'any maskable'}]
}, null, 2), 'utf8');

await fs.writeFile(path.join(www,'index.html'), html, 'utf8');
console.log('Offline web bundle ready in www/');
