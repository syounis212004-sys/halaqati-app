package com.mohammedsamir.halaqati.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.Assignment
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.ui.theme.cardHairline

private data class Shortcut(val route: String, val label: String, val icon: ImageVector, val hue: Color)

/**
 * RC40: the Home shortcuts grid (Students and Plans left the bottom bar, so they live here one tap away).
 * RC47: every tile has its own soft hue (a tinted squircle behind a rounded icon), enters in sequence and presses in.
 */
@Composable
fun HomeShortcuts(showPlans: Boolean, navigate: (String) -> Unit, showAwards: Boolean = false) {
    val green = Color(0xFF1B7F6B)
    val gold = Color(0xFFB8861B)
    val blue = Color(0xFF2F6FB3)
    val rose = Color(0xFFC2554B)
    val violet = Color(0xFF6B5BB3)
    val items = buildList {
        add(Shortcut("students", "الطلاب", Icons.Rounded.People, green))
        if (showPlans) add(Shortcut("plans", "الخطط", Icons.Rounded.Assignment, gold))
        add(Shortcut("sessions", "الجلسات", Icons.Rounded.CalendarMonth, blue))
        add(Shortcut("reports", "التقارير", Icons.Rounded.Assessment, rose))
        add(Shortcut("rankings", "الترتيب", Icons.Rounded.EmojiEvents, gold))
        add(Shortcut("quran", "المصحف", Icons.Rounded.MenuBook, violet))
        if (showAwards) add(Shortcut("awards", "التكريم", Icons.Rounded.Star, gold))
        if (showAwards) add(Shortcut("support", "الدعم", Icons.Rounded.Favorite, rose))
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("اختصارات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        items.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { item ->
                    Surface(
                        modifier = Modifier.weight(1f).halaqatiEnter().halaqatiPressable { navigate(item.route) },
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surface,
                        shadowElevation = 1.5.dp,
                        border = cardHairline(),
                    ) {
                        Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Surface(shape = RoundedCornerShape(16.dp), color = item.hue.copy(alpha = .14f), modifier = Modifier.size(46.dp)) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(item.icon, contentDescription = null, tint = item.hue, modifier = Modifier.size(26.dp))
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(item.label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 1)
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
