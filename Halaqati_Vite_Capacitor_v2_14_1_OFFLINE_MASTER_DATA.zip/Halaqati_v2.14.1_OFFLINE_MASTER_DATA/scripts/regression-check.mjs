import fs from 'node:fs';
const legacy=fs.readFileSync('src/legacy/app.js','utf8');
const core=fs.readFileSync('src/core/runtime.js','utf8');
const nav=fs.readFileSync('src/core/navigation.js','utf8');
const auth=fs.readFileSync('src/features/auth/runtime.js','utf8');
const students=fs.readFileSync('src/features/students/runtime.js','utf8');
const sessions=fs.readFileSync('src/features/sessions/runtime.js','utf8');
const settings=fs.readFileSync('src/features/settings/runtime.js','utf8');
const reports=fs.readFileSync('src/features/reports/runtime.js','utf8');
const s=[legacy,core,nav,auth,students,sessions,settings,reports].join('\n');
const required=[
  'function settingsPage()', 'function getThemePrefs()', 'function applySavedTheme()',
  'function previewSettings()', 'function setPreset(', 'function saveThemeSettings()',
  'function resetTheme()', 'async function changeMyPassword()',
  'function studentDirectoryRows()', 'async function exportStudentsExcel()',
  'async function exportStudentsWord()', 'window.openStudentsPdfPreview=function()',
  'window.openReportPreview=function()', 'function buildRowSafePdfPages(',
  'function createPdfRenderStage(', 'function canvasLooksBlank(', 'async function renderPdfElement(', 'function collectSafeCanvasCuts(',
  'async function ensureSearchablePdfFont(', 'function collectSearchablePdfTextItems(', 'function addSearchablePdfTextLayer(',
  'window.downloadReportPdfFromPreview=async function()'
];
for(const token of required){if(!s.includes(token)){console.error('MISSING:',token);process.exit(1)}}

const dataStart=legacy.indexOf('function dataPage(){');
const dataEnd=legacy.indexOf('\n',dataStart);
const dataBlock=legacy.slice(dataStart,dataEnd); 
if(dataBlock.includes('exportReportsExcel()')){console.error('Regression: report Excel is back on data page');process.exit(1)}

if(!dataBlock.includes('exportStudentsExcel()')||!dataBlock.includes('exportStudentsWord()')||!dataBlock.includes('openStudentsPdfPreview()')){console.error('Regression: student-only export actions missing');process.exit(1)}
if(!s.includes("paper.dataset.orientation=orientation.value")){console.error('Regression: PDF orientation control is not wired');process.exit(1)}
if(!s.includes("const factor=Number(fontSize.value)/11")){console.error('Regression: PDF font-size control is not wired');process.exit(1)}
if(!s.includes("paper.style.fontFamily=font.value+', sans-serif'")){console.error('Regression: PDF font-family control is not wired');process.exit(1)}
if(!s.includes('paper.style.color=textColor.value')){console.error('Regression: PDF text-color control is not wired');process.exit(1)}
if(!s.includes("el.style.color=accent.value")){console.error('Regression: PDF accent/title color control is not wired');process.exit(1)}
if(!s.includes("paper.style.transform=`scale(${Number(zoom.value)/100})`")){console.error('Regression: PDF zoom control is not wired');process.exit(1)}
if(!s.includes('contenteditable="true"')){console.error('Regression: PDF editable preview is missing');process.exit(1)}

const finalReports=s.lastIndexOf('function reportsPage(){');
const reportBlock=s.slice(finalReports,s.indexOf('\nfunction reportExportRows()',finalReports));
if(!reportBlock.includes('onclick="openReportPreview()"')){console.error('Regression: report PDF does not open built-in preview directly');process.exit(1)}

const paginationStart=s.indexOf('function buildRowSafePdfPages(');
const downloadStart=s.indexOf('window.downloadReportPdfFromPreview=async function()',paginationStart);
const pdfBlock=s.slice(paginationStart,s.indexOf('/* Clicking PDF now opens',downloadStart));
if(!pdfBlock.includes('stage.replaceChildren(element)')){console.error('Regression: PDF page is not moved to visible render stage before capture');process.exit(1)}
if(!pdfBlock.includes("stage.className='hf-pdf-render-stage'")){console.error('Regression: visible PDF render stage missing');process.exit(1)}
if(!pdfBlock.includes("element.style.visibility='visible'")){console.error('Regression: render page visibility is not forced visible');process.exit(1)}
if(!pdfBlock.includes('canvasLooksBlank(canvas)')){console.error('Regression: blank-canvas guard missing');process.exit(1)}
if(!pdfBlock.includes("throw new Error('فشل رسم محتوى التقرير. لم يتم حفظ ملف فارغ. حاول مرة أخرى.')")){console.error('Regression: blank PDF must be rejected, not saved');process.exit(1)}
if(!pdfBlock.includes('collectSafeCanvasCuts(renderPage,canvas)')){console.error('Regression: generic PDF slicing lacks DOM-safe cut boundaries');process.exit(1)}
if(!pdfBlock.includes('if(rowSafe.applied)')){console.error('Regression: row-safe pages are not protected from secondary slicing');process.exit(1)}
if(!pdfBlock.includes('const fit=Math.min(1,boxH/outH)')){console.error('Regression: row-safe page must fit whole page instead of being sliced');process.exit(1)}

// The measurement sandbox may be visibility:hidden, but html2canvas must never capture directly from it.
const directHiddenCapture=/html2canvas\(renderPage/.test(pdfBlock);
if(directHiddenCapture){console.error('Regression: html2canvas is capturing pagination clone directly from hidden sandbox');process.exit(1)}

if(!pdfBlock.includes("renderingMode:'invisible'")){console.error('Regression: searchable invisible PDF text layer missing');process.exit(1)}
if(!pdfBlock.includes('await ensureSearchablePdfFont(pdf)')){console.error('Regression: searchable Arabic font is not embedded before PDF generation');process.exit(1)}
if(!pdfBlock.includes('collectSearchablePdfTextItems(renderPage)')){console.error('Regression: PDF text is not collected from the edited preview DOM');process.exit(1)}
if(!pdfBlock.includes('addSearchablePdfTextLayer(pdf,searchItems')){console.error('Regression: searchable text layer is not applied to PDF pages');process.exit(1)}

if(!core.includes("const APP_VERSION_NAME='2.14.1';")||!core.includes('const APP_VERSION_CODE=21401;')){console.error('Version mismatch');process.exit(1)}
console.log('Regression checks passed across modular Phase 3 runtimes + reports: settings, previews, student exports, high-quality raster PDF, searchable Unicode layer, row-safe pagination, version.');
