# إعداد Push الحقيقي على Android — حلقتي v2.15

مركز الإشعارات داخل التطبيق وقاعدة البيانات وEdge Function جاهزة وتعمل بدون Firebase. لكي يظهر الإشعار في شريط إشعارات Android عندما يكون التطبيق مغلقًا، يلزم إعداد Firebase Cloud Messaging مرة واحدة فقط.

## 1) إنشاء/اختيار مشروع Firebase
1. افتح Firebase Console وسجّل الدخول بحساب Google الخاص بالمشروع.
2. أنشئ مشروعًا أو استخدم مشروعًا موجودًا.
3. أضف Android app بحزمة التطبيق **بالضبط**:
   `com.mohammedsamir.halaqati`
4. نزّل الملف `google-services.json`.

## 2) إضافة google-services.json كـ GitHub Secret
لا ترفع الملف علنًا إلى المستودع.
حوّل الملف إلى Base64، ثم في Repository البناء افتح:
Settings → Secrets and variables → Actions → New repository secret

اسم السر:
`HALAQATI_FIREBASE_GOOGLE_SERVICES_JSON_BASE64`

القيمة: Base64 الكامل لمحتوى `google-services.json`.

الـWorkflow v2.15 يقرأ السر ويضع الملف مؤقتًا في `android/app/google-services.json` أثناء البناء فقط.

## 3) تفعيل Firebase Cloud Messaging API
في Firebase / Google Cloud تأكد أن **Firebase Cloud Messaging API (HTTP v1)** مفعلة للمشروع.

## 4) إنشاء Service Account JSON للإرسال من Supabase
من Firebase / Google Cloud أنشئ Service Account key بصيغة JSON للمشروع. هذا المفتاح لا يوضع داخل APK ولا GitHub العام.

في Supabase Dashboard افتح:
Project Settings → Edge Functions / Secrets

أنشئ Secret بالاسم:
`FIREBASE_SERVICE_ACCOUNT_JSON`

والقيمة تكون **محتوى JSON كاملًا** للخدمة.

Edge Function `halaqati-notify` تستخدم هذا المفتاح من الخادم فقط لإرسال FCM HTTP v1.

## 5) الاختبار
بعد بناء APK وتثبيته:
1. افتح التطبيق وسجّل الدخول.
2. وافق على إذن الإشعارات في Android.
3. الإعدادات → الإشعارات → «تفعيل Push على هذا الجهاز».
4. اضغط «اختبار الإشعار».
5. إذا ظهر إشعار Android بعنوان «اختبار إشعارات حلقتي» فالإعداد كامل.

## ملاحظات أمان
- لا تضع Service Account JSON أو google-services.json في كود JavaScript أو داخل مستودع عام.
- Service Account يبقى في Supabase Secret فقط.
- `google-services.json` يمر للـBuild من GitHub Secret ولا يلزم رفعه كملف عام.
- حتى قبل Firebase، مركز الإشعارات **داخل التطبيق** يعمل، والتفضيلات والسجل والإشعارات اليدوية تعمل؛ الذي ينتظر Firebase فقط هو Push الخارجي في شريط النظام.
