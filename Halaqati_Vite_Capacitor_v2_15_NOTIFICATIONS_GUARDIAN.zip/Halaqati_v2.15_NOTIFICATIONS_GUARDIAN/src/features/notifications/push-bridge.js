import { PushNotifications } from '@capacitor/push-notifications';
window.HalaqatiPushNotifications = PushNotifications;
export { PushNotifications };
