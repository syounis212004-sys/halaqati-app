from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.26',
    'versionCode':28926,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "حضور الشهر في ملف الطالب يُحسب لهذا الشهر فقط (كان يجمع أسابيع من الشهر السابق)",
        "صورة الطالب الحقيقية في ملفه وفي نافذة التفاصيل، وصورة أكبر في قائمة الطلاب وإزالة النجمة منها",
        "الصور تُحمَّل مرة واحدة وتبقى على الجهاز، وتُجلب فقط للطالب الذي تغيّرت صورته؛ وكذلك صور المشرفين والمحفّظين",
        "ملف الطالب يتحدث من الخادم مرة واحدة بعد الثامنة مساءً بتوقيت غزة أو بعد رفع جلسة جديدة",
        "قصّ الصورة إلى مربع تلقائيًا، وخيار شكل الصور (حلقة / دائرة / مربع مدوّر) في الإعدادات",
        "سطر يشرح كيف يُحسب المطلوب والزائد في الخطة الشهرية",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
