import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
const must=(c,m)=>{if(!c)throw new Error(m)};
const mustHave=(t,n,label)=>must(t.includes(n),`${label} missing: ${n}`);

const pkg=JSON.parse(read('package.json'));
const core=read('src/core/runtime.js');
const startup=read('src/core/startup.js');
const legacy=read('src/legacy/app.js');
const vector=read('src/features/reports/vector-pdf-runtime.js');
const java=read('plugins/halaqati-pdf/android/src/main/java/com/mohammedsamir/halaqati/pdf/HalaqatiPdfPlugin.java');

must(pkg.version==='2.40.6','package version must be 2.40.6');
must(core.includes("APP_VERSION_NAME='2.40.6'")&&core.includes('APP_VERSION_CODE=24006'),'app version/code mismatch');

// Root cause fix: native export uses the one already-running Capacitor WebView, not a second
// HTML WebView as the primary path, and it holds the call until Android's PrintJob is final.
for(const token of [
  'useCurrentWebView:true',
  'prepareLivePrintSurface',
  'persistPrintRecoveryState',
  "#reportExportArea{display:none!important;visibility:hidden!important}",
  "#hf-vector-print-root *{visibility:visible!important}",
  'return await p.exportPdf({filename,orientation,useCurrentWebView:true})'
])mustHave(vector,token,'vector runtime');

for(const token of [
  'getBridge().getWebView()',
  'PrintJob',
  'final PrintJob job = printManager.print',
  'pollActivePrintJob',
  'job.isCompleted()',
  'job.isCancelled()',
  'job.isFailed()',
  'chromium-capacitor-webview-public-print-api'
])mustHave(java,token,'Android PDF plugin');

must(!/new\s+PrintDocumentAdapter\.(LayoutResultCallback|WriteResultCallback)/.test(java),'must not instantiate hidden print callbacks');
must(!java.includes('java.lang.reflect'),'must not use reflection');
must(!/html2canvas|new\s+jsPDF|\.addImage\(/.test(vector),'vector report PDF must remain non-raster');

// Session/page recovery after Android print UI/activity recreation.
for(const token of [
  "withTimeout(db.auth.getSession(),primaryTimeout",
  'hfFreshPrintResume',
  'hfRestoreCachedShell',
  'visibilitychange',
  "halaqati_print_resume_v2406"
])mustHave(startup,token,'startup recovery');

mustHave(legacy,"page:state.page||'home'",'snapshot page persistence');
mustHave(legacy,"halaqati_print_resume_v2406",'snapshot print resume recovery');
mustHave(legacy,"'reports'",'snapshot page allowlist');

console.log('HALAQATI_V2406_PDF_ZERO_BYTE_SESSION_FIX_PASS');
console.log('Primary native print: live Capacitor WebView + PrintJob terminal-state tracking ✅');
console.log('Recovery: verified offline identity + cached page + Supabase session retry ✅');
