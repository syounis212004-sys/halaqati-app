package com.mohammedsamir.halaqati.pdf;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Halaqati v2.40.6 Vector PDF — zero-byte / session-safe Android print bridge.
 *
 * Primary path (v2.40.6): print the existing Capacitor WebView after JavaScript stages
 * a print-only report tree in the live document. This avoids allocating a second WebView
 * while Android's print spooler is open, which materially lowers memory pressure on OEM
 * devices and keeps the source document alive until the print job reaches a terminal state.
 *
 * Compatibility path: HTML can still be printed through a dedicated WebView when an older
 * caller does not request useCurrentWebView.
 *
 * Public APIs only:
 * WebView -> createPrintDocumentAdapter() -> PrintManager.print() -> PrintJob state polling.
 * No hidden PrintDocumentAdapter callbacks, no reflection, no raster screenshot pipeline.
 */
@CapacitorPlugin(name = "HalaqatiPdf")
public class HalaqatiPdfPlugin extends Plugin {
    private static final long PAGE_READY_TIMEOUT_MS = 25_000L;
    private static final long PRINT_JOB_POLL_MS = 350L;
    private static final long PRINT_JOB_TIMEOUT_MS = 30L * 60L * 1000L;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Only used by the legacy HTML compatibility path. Never destroy the Capacitor WebView.
    private WebView retainedOwnedPrintView;
    private Runnable pageReadyTimeout;

    private PrintJob activePrintJob;
    private Runnable activePrintPoll;
    private PluginCall activePrintCall;
    private long activePrintStartedAt;
    private boolean activePrintOwnsWebView;

    @PluginMethod
    public void exportPdf(PluginCall call) {
        final String requestedName = call.getString("filename", "halaqati-report.pdf");
        final String orientation = call.getString("orientation", "landscape");
        final boolean useCurrentWebView = Boolean.TRUE.equals(call.getBoolean("useCurrentWebView", false));
        final Activity activity = getActivity();

        if (activity == null) {
            call.reject("Android activity is unavailable");
            return;
        }
        if (hasActivePrintJob()) {
            call.reject("هناك عملية طباعة أو حفظ PDF ما زالت جارية. أنهها أولاً ثم أعد المحاولة.");
            return;
        }

        final String filename = safePdfName(requestedName);
        if (useCurrentWebView) {
            activity.runOnUiThread(() -> printCurrentCapacitorWebView(activity, call, filename, orientation));
            return;
        }

        final String html = call.getString("html", "");
        if (html == null || html.trim().isEmpty()) {
            call.reject("PDF HTML is empty");
            return;
        }
        if (html.length() > 12_000_000) {
            call.reject("PDF HTML is too large");
            return;
        }
        activity.runOnUiThread(() -> prepareOwnedPrintWebView(activity, call, html, filename, orientation));
    }

    /** Print the already-running Capacitor WebView. JS has staged #hf-vector-print-root first. */
    private void printCurrentCapacitorWebView(Activity activity, PluginCall call, String filename, String orientation) {
        final WebView webView;
        try {
            webView = getBridge() == null ? null : getBridge().getWebView();
        } catch (Throwable error) {
            call.reject("تعذر الوصول إلى صفحة التطبيق للطباعة");
            return;
        }
        if (webView == null) {
            call.reject("صفحة التطبيق غير متاحة للطباعة");
            return;
        }

        // The live print surface is prepared by JS before this call. One short RAF-equivalent
        // delay gives WebView a final layout pass before PrintManager snapshots print layout.
        mainHandler.postDelayed(
                () -> openSystemPrintDialog(activity, call, webView, filename, orientation, false),
                120L
        );
    }

    /** Backward-compatible HTML path for callers predating v2.40.6. */
    private void prepareOwnedPrintWebView(Activity activity, PluginCall call, String html, String filename, String orientation) {
        releaseOwnedPrintView();

        final WebView webView = new WebView(activity);
        retainedOwnedPrintView = webView;

        final WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setLoadsImagesAutomatically(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        webView.setBackgroundColor(0xFFFFFFFF);

        final boolean[] launched = new boolean[]{false};
        pageReadyTimeout = () -> {
            if (launched[0]) return;
            releaseOwnedPrintView();
            call.reject("انتهت مهلة تجهيز التقرير للطباعة. حاول مرة أخرى.");
        };
        mainHandler.postDelayed(pageReadyTimeout, PAGE_READY_TIMEOUT_MS);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (launched[0]) return;
                waitForOwnedDocumentReady(activity, call, webView, filename, orientation, launched, 0);
            }
        });

        webView.loadDataWithBaseURL(
                "https://halaqati.local/",
                html,
                "text/html",
                "UTF-8",
                null
        );
    }

    private void waitForOwnedDocumentReady(Activity activity, PluginCall call, WebView webView,
                                           String filename, String orientation, boolean[] launched,
                                           int attempt) {
        if (launched[0] || retainedOwnedPrintView != webView) return;

        final String readyJs =
                "(function(){try{" +
                "var fontsReady=(!document.fonts||document.fonts.status==='loaded');" +
                "var imagesReady=Array.prototype.every.call(document.images,function(i){return i.complete;});" +
                "return (!!document.body&&document.readyState==='complete'&&fontsReady&&imagesReady)?'READY':'WAIT';" +
                "}catch(e){return 'WAIT';}})();";

        try {
            webView.evaluateJavascript(readyJs, value -> {
                if (launched[0] || retainedOwnedPrintView != webView) return;
                final String state = value == null ? "" : value.replace("\"", "");
                if ("READY".equals(state) || attempt >= 100) {
                    launched[0] = true;
                    clearPageReadyTimeout();
                    openSystemPrintDialog(activity, call, webView, filename, orientation, true);
                    return;
                }
                mainHandler.postDelayed(
                        () -> waitForOwnedDocumentReady(activity, call, webView, filename, orientation,
                                launched, attempt + 1),
                        100L
                );
            });
        } catch (Throwable error) {
            mainHandler.postDelayed(() -> {
                if (launched[0] || retainedOwnedPrintView != webView) return;
                launched[0] = true;
                clearPageReadyTimeout();
                openSystemPrintDialog(activity, call, webView, filename, orientation, true);
            }, 500L);
        }
    }

    private void openSystemPrintDialog(Activity activity, PluginCall call, WebView webView,
                                       String filename, String orientation, boolean ownsWebView) {
        final PrintManager printManager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
        if (printManager == null) {
            if (ownsWebView) releaseOwnedPrintView();
            call.reject("خدمة الطباعة غير متاحة على هذا الجهاز");
            return;
        }

        PrintAttributes.MediaSize mediaSize = PrintAttributes.MediaSize.ISO_A4;
        mediaSize = "portrait".equalsIgnoreCase(orientation)
                ? mediaSize.asPortrait()
                : mediaSize.asLandscape();

        final PrintAttributes attributes = new PrintAttributes.Builder()
                .setMediaSize(mediaSize)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build();

        try {
            final PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(filename);
            final PrintJob job = printManager.print(filename, adapter, attributes);
            if (job == null) {
                if (ownsWebView) releaseOwnedPrintView();
                call.reject("تعذر بدء مهمة الطباعة على هذا الجهاز");
                return;
            }

            activePrintJob = job;
            activePrintCall = call;
            activePrintStartedAt = System.currentTimeMillis();
            activePrintOwnsWebView = ownsWebView;
            pollActivePrintJob(filename);
        } catch (Throwable error) {
            if (ownsWebView) releaseOwnedPrintView();
            clearActivePrintState();
            final String message = error.getMessage() == null
                    ? error.getClass().getSimpleName()
                    : error.getMessage();
            call.reject("تعذر فتح شاشة حفظ PDF: " + message);
        }
    }

    /**
     * Keep the JS call and (for legacy HTML only) its source WebView alive until Android's
     * PrintJob actually finishes/cancels/fails. v2.40.5 resolved immediately after opening
     * the dialog, so the app could be recreated while the spooler still needed its source.
     */
    private void pollActivePrintJob(String filename) {
        if (activePrintPoll != null) mainHandler.removeCallbacks(activePrintPoll);
        activePrintPoll = () -> {
            final PrintJob job = activePrintJob;
            final PluginCall call = activePrintCall;
            if (job == null || call == null) return;

            try {
                if (job.isCompleted()) {
                    final JSObject out = new JSObject();
                    out.put("opened", true);
                    out.put("completed", true);
                    out.put("cancelled", false);
                    out.put("printDialog", true);
                    out.put("filename", filename);
                    out.put("engine", activePrintOwnsWebView
                            ? "chromium-dedicated-webview-public-print-api"
                            : "chromium-capacitor-webview-public-print-api");
                    finishActivePrint(true);
                    call.resolve(out);
                    return;
                }
                if (job.isCancelled()) {
                    final JSObject out = new JSObject();
                    out.put("opened", true);
                    out.put("completed", false);
                    out.put("cancelled", true);
                    out.put("printDialog", true);
                    out.put("filename", filename);
                    finishActivePrint(true);
                    call.resolve(out);
                    return;
                }
                if (job.isFailed()) {
                    finishActivePrint(true);
                    call.reject("فشلت مهمة الطباعة/حفظ PDF في خدمة الطباعة على الجهاز");
                    return;
                }
            } catch (Throwable error) {
                finishActivePrint(true);
                call.reject("تعذر متابعة حالة حفظ PDF: " + safeMessage(error));
                return;
            }

            if (System.currentTimeMillis() - activePrintStartedAt >= PRINT_JOB_TIMEOUT_MS) {
                final JSObject out = new JSObject();
                out.put("opened", true);
                out.put("completed", false);
                out.put("cancelled", false);
                out.put("timedOut", true);
                out.put("printDialog", true);
                out.put("filename", filename);
                finishActivePrint(true);
                call.resolve(out);
                return;
            }

            mainHandler.postDelayed(activePrintPoll, PRINT_JOB_POLL_MS);
        };
        mainHandler.postDelayed(activePrintPoll, PRINT_JOB_POLL_MS);
    }

    private boolean hasActivePrintJob() {
        final PrintJob job = activePrintJob;
        if (job == null) return false;
        try {
            if (job.isCompleted() || job.isCancelled() || job.isFailed()) {
                finishActivePrint(true);
                return false;
            }
        } catch (Throwable ignored) {
            // If state cannot be queried, leave the current operation protected.
        }
        return activePrintJob != null;
    }

    private void finishActivePrint(boolean releaseOwnedView) {
        if (activePrintPoll != null) {
            mainHandler.removeCallbacks(activePrintPoll);
            activePrintPoll = null;
        }
        final boolean owned = activePrintOwnsWebView;
        clearActivePrintState();
        if (releaseOwnedView && owned) releaseOwnedPrintView();
    }

    private void clearActivePrintState() {
        activePrintJob = null;
        activePrintCall = null;
        activePrintStartedAt = 0L;
        activePrintOwnsWebView = false;
    }

    private void clearPageReadyTimeout() {
        if (pageReadyTimeout != null) {
            mainHandler.removeCallbacks(pageReadyTimeout);
            pageReadyTimeout = null;
        }
    }

    private void releaseOwnedPrintView() {
        clearPageReadyTimeout();
        final WebView webView = retainedOwnedPrintView;
        retainedOwnedPrintView = null;
        if (webView == null) return;
        try { webView.stopLoading(); } catch (Throwable ignored) {}
        try { webView.loadUrl("about:blank"); } catch (Throwable ignored) {}
        try { webView.destroy(); } catch (Throwable ignored) {}
    }

    private String safeMessage(Throwable error) {
        if (error == null) return "unknown";
        return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
    }

    private String safePdfName(String value) {
        String name = value == null ? "halaqati-report.pdf" : value.trim();
        name = name.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "_");
        if (!name.toLowerCase().endsWith(".pdf")) name += ".pdf";
        if (name.length() > 120) name = name.substring(0, 116) + ".pdf";
        return name.isEmpty() ? "halaqati-report.pdf" : name;
    }

    @Override
    protected void handleOnDestroy() {
        if (activePrintPoll != null) {
            mainHandler.removeCallbacks(activePrintPoll);
            activePrintPoll = null;
        }
        clearPageReadyTimeout();
        releaseOwnedPrintView();
        clearActivePrintState();
        super.handleOnDestroy();
    }
}
