/* Halaqati v2.40.6 — startup/session recovery hooks. Kept last to preserve boot timing. */
applySavedTheme();
const recoveryInUrl=location.hash.includes('type=recovery')||location.search.includes('type=recovery');
db.auth.onAuthStateChange((event,session)=>{if(event==='PASSWORD_RECOVERY')setTimeout(()=>showPasswordRecovery(),0)});

let hfStartupRecoveryBusy=false;

async function hfGetStartupSession(primaryTimeout=3000){
  try{
    let r=await withTimeout(db.auth.getSession(),primaryTimeout,'startup session timeout');
    if(r?.data?.session)return r.data.session;
  }catch(_e){}
  // Android can recreate the WebView just after returning from the print spooler. Give
  // Supabase storage one second chance instead of immediately exposing the login screen.
  try{
    await new Promise(r=>setTimeout(r,120));
    let r=await withTimeout(db.auth.getSession(),1800,'startup session retry timeout');
    return r?.data?.session||null;
  }catch(_e){return null}
}

function hfFreshPrintResume(){
  try{
    let x=readJsonLocal('halaqati_print_resume_v2406',null);
    return !!(x&&Date.now()-Number(x.at||0)<=20*60*1000);
  }catch(_e){return false}
}

async function hfRestoreCachedShell(last,{refreshDelay=180}={}){
  if(!last?.id)return false;
  state.user=last;
  await prepareOfflineStorageForUser(last.id);
  if(!restoreSnapshot())return false;
  captureSyncSessionDependencies();
  state.fastStarted=true;
  showApp();
  // Resolve the real Supabase user in the background, then refresh. This keeps a print-flow
  // activity recreation from flashing or landing on the login page.
  setTimeout(async()=>{
    try{
      let session=await hfGetStartupSession(3500);
      if(session?.user){state.user=session.user;saveOfflineAuth(session.user);state.authNeedsLogin=false}
      if(typeof refreshFromServer==='function')await refreshFromServer({renderAfter:true});
    }catch(_e){}
  },refreshDelay);
  if(typeof cacheRecentSessionRostersForOffline==='function')setTimeout(()=>cacheRecentSessionRostersForOffline(30),1800);
  return true;
}

async function hfStartApplication(){
  if(hfStartupRecoveryBusy)return;
  hfStartupRecoveryBusy=true;
  try{
    if(recoveryInUrl){showPasswordRecovery();return}

    const last=readOfflineAuth();
    // Fast path used only immediately after a native print hand-off. Identity and page were
    // persisted just before opening Android's print UI, so restore them before any network wait.
    if(hfFreshPrintResume()&&last&&await hfRestoreCachedShell(last,{refreshDelay:250}))return;

    const session=await hfGetStartupSession(3000);
    if(session?.user){
      await boot(session.user);
      if(typeof cacheRecentSessionRostersForOffline==='function')setTimeout(()=>cacheRecentSessionRostersForOffline(30),150);
      return;
    }

    // Normal local-first fallback. This is the same trusted offline identity snapshot used by
    // the app elsewhere, but now it is reached after a realistic session-read timeout/retry.
    if(last)await hfRestoreCachedShell(last,{refreshDelay:450});
  }finally{hfStartupRecoveryBusy=false}
}

hfStartApplication();

// If Android resumes the same JS process after the print UI but auth state was temporarily
// cleared by an activity lifecycle edge case, recover the app shell instead of showing login.
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState!=='visible'||state.user||hfStartupRecoveryBusy)return;
  setTimeout(()=>hfStartApplication(),80);
});

setTimeout(()=>ensureQuranLayout(true),900);
setInterval(async()=>{if(state.user&&readOfflineQueue().length&&navigator.onLine&&!state.syncing)await syncOfflineQueue()},20000);
// Service Worker registration moved to src/core/pwa.js in v2.12.

/* ---- migrated from v2.11 legacy runtime ---- */
