package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.ui.components.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class TeamMember(val id: String, val name: String, val role: String, val phone: String, val photo: String?, val active: Boolean, val halaqat: List<String>, val students: Int = 0)

/** RC65: "فريق الجمعية" — the association's staff by level (supervisors above teachers) with each teacher's halaqat. Read-only. */
@Composable
fun TeamScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    var members by remember { mutableStateOf<List<TeamMember>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    val syncEpoch by AppGraph.connectivity.syncEpoch.collectAsState()
    LaunchedEffect(syncEpoch, tick) {
        runCatching {
            withContext(Dispatchers.IO) {
                val repo = AppGraph.repo
                val staff = staffProfiles()
                val halaqas = repo.table("halaqas", "select=id,name&limit=300").sRows().associate { it.optString("id") to it.optString("name") }
                val links = repo.table("halaqa_teachers", "select=halaqa_id,teacher_id&limit=1500").sRows()
                val studentRows = repo.table("students", "select=id,halaqa_id,status&limit=3000", forceRefresh = false).sRows().filter { it.optString("status") == "active" }
                val perHalaqa = studentRows.groupingBy { it.optString("halaqa_id") }.eachCount()
                staff.map { p ->
                    val id = p.optString("id")
                    TeamMember(id, p.supStr("full_name"), p.supStr("role"), p.supStr("phone"), p.supStr("avatar_path").ifBlank { null }, p.optBoolean("active", true),
                        links.filter { it.optString("teacher_id") == id }.mapNotNull { halaqas[it.optString("halaqa_id")] },
                        links.filter { it.optString("teacher_id") == id }.sumOf { perHalaqa[it.optString("halaqa_id")] ?: 0 })
                }
            }
        }.onSuccess { members = it; error = null }.onFailure { error = it.message ?: "تعذر تحميل الفريق" }
        loading = false
    }
    val shown = members.filter { query.isBlank() || it.name.contains(query.trim()) }
    val supervisors = shown.filter { it.role == "supervisor" }
    val teachers = shown.filter { it.role == "teacher" }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("فريق الجمعية", onRefresh = { tick++; onRefresh() }, pending = pending)
        error?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        CompactSearchField(value = query, onValueChange = { query = it }, placeholder = "بحث بالاسم", modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp))
        if (loading && members.isEmpty()) LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp))
        LazyColumn(
            state = rememberLazyListState(), modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { Text("المشرفون (${supervisors.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold) }
            items(supervisors, key = { "sup-" + it.id }) { TeamCard(it) }
            item { Text("المحفّظون (${teachers.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp)) }
            items(teachers, key = { "tch-" + it.id }) { TeamCard(it) }
            if (!loading && shown.isEmpty()) item { EmptyState("لا يوجد أعضاء مطابقون") }
        }
    }
}

@Composable
private fun TeamCard(m: TeamMember) {
    val cs = MaterialTheme.colorScheme
    val context = androidx.compose.ui.platform.LocalContext.current
    val pair = when {
        !m.active -> HalaqatiGradients.Slate
        m.role == "supervisor" -> HalaqatiGradients.Gold
        else -> HalaqatiGradients.Emerald
    }
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp), color = cs.surface, border = BorderStroke(1.5.dp, pair.a)) {
        Column {
            Row(
                Modifier.fillMaxWidth().background(pair.brush()).girih(Color.White, .16f, 40.dp).padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.size(80.dp).clip(CircleShape).background(Color.White).padding(3.dp)) {
                    StudentAvatar(m.photo, m.name, size = 74.dp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(m.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 2)
                    Surface(shape = RoundedCornerShape(50), color = Color.White.copy(alpha = .24f)) {
                        Text(
                            if (!m.active) "مجمَّد" else if (m.role == "supervisor") "مشرف" else "محفّظ",
                            Modifier.padding(horizontal = 12.dp, vertical = 3.dp), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Color.White,
                        )
                    }
                }
            }
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TeamStat(m.halaqat.size.toString(), "حلقات", pair, Modifier.weight(1f))
                    if (m.role != "supervisor") TeamStat(m.students.toString(), "طلاب", HalaqatiGradients.Blue, Modifier.weight(1f))
                }
                if (m.halaqat.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    m.halaqat.forEach { h ->
                        Surface(shape = RoundedCornerShape(50), color = pair.a) {
                            Text(h, Modifier.padding(horizontal = 12.dp, vertical = 4.dp), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                        }
                    }
                } else if (m.role != "supervisor") Text("لم يُسنَد إلى حلقة بعد", style = MaterialTheme.typography.bodyMedium, color = cs.error, fontWeight = FontWeight.Bold)
                if (m.phone.isNotBlank()) {
                    FilledTonalButton(
                        onClick = { runCatching { context.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:" + m.phone)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                    ) { Icon(Icons.Default.Call, null); Spacer(Modifier.width(8.dp)); Text(m.phone, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun TeamStat(value: String, label: String, pair: GradientPair, modifier: Modifier = Modifier) {
    Row(modifier.clip(RoundedCornerShape(16.dp)).background(pair.brush()).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Color.White)
        Text(label, style = MaterialTheme.typography.titleSmall, color = Color.White)
    }
}
