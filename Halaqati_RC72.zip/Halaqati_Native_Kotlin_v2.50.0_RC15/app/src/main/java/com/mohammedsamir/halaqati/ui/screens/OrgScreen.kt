@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.ui.components.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.UUID

/* ============================== data ============================== */

private data class OrgPerson(val id: String, val name: String, val photo: String?)
private data class OrgHalaqa(val id: String, val name: String, val centerId: String?, val teachers: List<OrgPerson>, val supervisors: List<OrgPerson>, val students: Int, val active: Boolean)
private data class OrgCenter(val id: String, val name: String, val kind: String, val manager: OrgPerson?, val halaqat: List<OrgHalaqa>)
private data class OrgData(
    val association: String,
    val centers: List<OrgCenter>,
    val unassigned: List<OrgHalaqa>,
    val centersMissing: Boolean,
    val staff: List<OrgPerson>,
    val teacherCount: Int,
    val supervisorCount: Int,
    val studentCount: Int,
)

private const val NEED_SQL = "لتفعيل المراكز والمساجد شغّل ملف RC67_org.sql في Supabase مرة واحدة."

private fun kindAr(kind: String) = if (kind == "mosque") "مسجد" else "مركز"
private fun kindPair(kind: String) = if (kind == "mosque") HalaqatiGradients.Gold else HalaqatiGradients.Emerald

private fun loadOrg(): OrgData {
    val repo = AppGraph.repo
    val fresh = repo.online()
    val association = runCatching { repo.mySubscription()?.optString("name") }.getOrNull().orEmpty().ifBlank { "الجمعية" }
    val centersResult = runCatching { repo.table("centers", "select=*&order=name.asc&limit=200", forceRefresh = fresh).sRows() }
    val centerRows = centersResult.getOrDefault(emptyList())
    val halaqas = repo.table("halaqas", "select=*&order=name.asc&limit=300", forceRefresh = fresh).sRows()
    val tLinks = repo.table("halaqa_teachers", "select=halaqa_id,teacher_id&limit=1500", forceRefresh = fresh).sRows()
    val sLinks = repo.table("halaqa_supervisors", "select=halaqa_id,supervisor_id&limit=1500", forceRefresh = fresh).sRows()
    val staffRows = staffProfiles()
    val people = staffRows.associate { it.optString("id") to OrgPerson(it.optString("id"), it.supStr("full_name").ifBlank { "—" }, it.supStr("avatar_path").ifBlank { null }) }
    val students = repo.table("students", "select=id,halaqa_id,status&limit=3000", forceRefresh = false).sRows().filter { it.optString("status") == "active" }
    val perHalaqaStudents = students.groupingBy { it.optString("halaqa_id") }.eachCount()
    val orgHalaqat = halaqas.filter { it.optBoolean("active", true) }.map { h ->
        val id = h.optString("id")
        OrgHalaqa(
            id, h.supStr("name").ifBlank { "حلقة" }, h.supStr("center_id").ifBlank { null },
            tLinks.filter { it.optString("halaqa_id") == id }.mapNotNull { people[it.optString("teacher_id")] }.distinctBy { it.id },
            sLinks.filter { it.optString("halaqa_id") == id }.mapNotNull { people[it.optString("supervisor_id")] }.distinctBy { it.id },
            perHalaqaStudents[id] ?: 0, true,
        )
    }
    val centers = centerRows.filter { it.optBoolean("active", true) }.map { c ->
        val id = c.optString("id")
        OrgCenter(id, c.supStr("name").ifBlank { "مركز" }, c.supStr("kind").ifBlank { "center" }, people[c.supStr("manager_id")], orgHalaqat.filter { it.centerId == id })
    }
    val known = centers.map { it.id }.toSet()
    return OrgData(
        association, centers, orgHalaqat.filter { it.centerId == null || it.centerId !in known }, centersResult.isFailure,
        staffRows.map { people.getValue(it.optString("id")) },
        staffRows.count { it.optString("role") == "teacher" }, staffRows.count { it.optString("role") == "supervisor" }, students.size,
    )
}

/* ============================== screen ============================== */

@Composable
fun OrgScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    val isAdmin = profile.role == UserRole.ADMIN
    var data by remember { mutableStateOf<OrgData?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var expanded by remember { mutableStateOf(setOf<String>()) }
    var editing by remember { mutableStateOf<OrgCenter?>(null) }
    var adding by remember { mutableStateOf(false) }
    var moving by remember { mutableStateOf<OrgHalaqa?>(null) }
    var deleting by remember { mutableStateOf<OrgCenter?>(null) }
    val syncEpoch by AppGraph.connectivity.syncEpoch.collectAsState()

    LaunchedEffect(syncEpoch, tick) {
        runCatching { withContext(Dispatchers.IO) { loadOrg() } }
            .onSuccess { data = it; error = null }
            .onFailure { error = it.message ?: "تعذر تحميل الهيكل الإداري" }
    }

    fun act(done: String, block: () -> Unit) {
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { block() } }
                .onSuccess { message = done; tick++; onRefresh() }
                .onFailure { e ->
                    val m = e.message.orEmpty()
                    message = if (m.contains("centers") || m.contains("center_id") || m.contains("42P01") || m.contains("42703") || m.contains("PGRST")) NEED_SQL else (m.ifBlank { "تعذر تنفيذ العملية" })
                }
        }
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar("الهيكل الإداري", onRefresh = { tick++; onRefresh() }, pending = pending)
        error?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        message?.let { StateNotice(it, kind = if (it == NEED_SQL) "warning" else "info", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        val d = data
        if (d == null) { LoadingSkeleton(rows = 4, modifier = Modifier.padding(12.dp)); return@Column }
        LazyColumn(
            state = rememberLazyListState(), modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { OrgHero(d, profile) }
            if (d.centersMissing) item { StateNotice(NEED_SQL, kind = "warning") }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("المراكز والمساجد (${d.centers.size})", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                    if (isAdmin && !d.centersMissing) FilledTonalButton(onClick = { adding = true }, modifier = Modifier.heightIn(min = 48.dp)) {
                        Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("إضافة")
                    }
                }
            }
            if (d.centers.isEmpty() && !d.centersMissing) item { EmptyState("لا توجد مراكز أو مساجد بعد. أضف أول مركز واربط حلقاتك به.") }
            items(d.centers, key = { "c-" + it.id }) { c ->
                OrgCenterCard(c, c.id in expanded, isAdmin, { expanded = if (c.id in expanded) expanded - c.id else expanded + c.id },
                    onEdit = { editing = c }, onDelete = { deleting = c }, onMove = { moving = it })
            }
            if (d.unassigned.isNotEmpty()) item {
                val u = OrgCenter("", "حلقات غير مرتبطة بمركز", "center", null, d.unassigned)
                OrgCenterCard(u, "none" in expanded, isAdmin && !d.centersMissing, { expanded = if ("none" in expanded) expanded - "none" else expanded + "none" },
                    onEdit = null, onDelete = null, onMove = { moving = it }, neutral = true)
            }
        }
    }

    if (adding || editing != null) {
        val d = data
        if (d != null) CenterSheet(
            existing = editing, staff = d.staff, onDismiss = { adding = false; editing = null },
            onSave = { name, kind, manager ->
                val ed = editing
                adding = false; editing = null
                if (ed == null) act("أُضيف $name") {
                    AppGraph.repo.writeConfirmed("centers", JSONObject().put("id", UUID.randomUUID().toString()).put("name", name).put("kind", kind).put("manager_id", manager ?: JSONObject.NULL).put("active", true))
                } else act("حُفظت التعديلات") {
                    AppGraph.repo.patchConfirmed("centers", "id=eq.${ed.id}", JSONObject().put("name", name).put("kind", kind).put("manager_id", manager ?: JSONObject.NULL))
                }
            },
        )
    }
    moving?.let { h ->
        val d = data
        if (d != null) MoveSheet(h, d.centers, onDismiss = { moving = null }) { target ->
            moving = null
            act("نُقلت ${h.name}") { AppGraph.repo.patchConfirmed("halaqas", "id=eq.${h.id}", JSONObject().put("center_id", target ?: JSONObject.NULL)) }
        }
    }
    deleting?.let { c ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف ${c.name}؟") },
            text = { Text("تبقى الحلقات كما هي وتصير «غير مرتبطة بمركز». لا يُحذف أي طالب أو حلقة.") },
            confirmButton = { TextButton(onClick = { deleting = null; act("حُذف ${c.name}") { AppGraph.repo.deleteConfirmed("centers", "id=eq.${c.id}") } }) { Text("حذف", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("تراجع") } },
        )
    }
}

/* ============================== pieces ============================== */

@Composable
private fun OrgHero(d: OrgData, profile: Profile) {
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), color = Color.Transparent) {
        Column(
            Modifier.background(HalaqatiGradients.Deep.brush()).girih(Color.White, .18f, 46.dp).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GradientIcon(Icons.Default.AccountBalance, HalaqatiGradients.Gold, tile = 56.dp, glyph = 30.dp)
                Column(Modifier.weight(1f)) {
                    Text(d.association, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 2)
                    Text("أنت: " + roleLabelArabic(profile.role), style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = .9f))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OrgStat("مراكز", d.centers.size.toString(), Modifier.weight(1f))
                OrgStat("حلقات", (d.centers.sumOf { it.halaqat.size } + d.unassigned.size).toString(), Modifier.weight(1f))
                OrgStat("محفّظون", d.teacherCount.toString(), Modifier.weight(1f))
                OrgStat("مشرفون", d.supervisorCount.toString(), Modifier.weight(1f))
                OrgStat("طلاب", d.studentCount.toString(), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun OrgStat(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(16.dp), color = Color.White.copy(alpha = .16f)) {
        Column(Modifier.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .92f), maxLines = 1)
        }
    }
}

@Composable
private fun PersonChip(p: OrgPerson, supervisor: Boolean) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = RoundedCornerShape(50), color = if (supervisor) HalaqatiGradients.Gold.a else cs.primary) {
        Row(Modifier.padding(start = 4.dp, end = 10.dp, top = 3.dp, bottom = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            StudentAvatar(p.photo, p.name, size = 26.dp)
            Text(p.name, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 130.dp))
        }
    }
}

@Composable
private fun OrgCenterCard(
    c: OrgCenter, open: Boolean, canEdit: Boolean, onToggle: () -> Unit,
    onEdit: (() -> Unit)?, onDelete: (() -> Unit)?, onMove: (OrgHalaqa) -> Unit, neutral: Boolean = false,
) {
    val cs = MaterialTheme.colorScheme
    val pair = if (neutral) HalaqatiGradients.Slate else kindPair(c.kind)
    var menu by remember { mutableStateOf(false) }
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = cs.surface, border = BorderStroke(1.5.dp, pair.a)) {
        Column {
            Row(
                Modifier.fillMaxWidth().background(pair.brush()).girih(Color.White, .16f, 40.dp).clickable(onClick = onToggle).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Surface(shape = CircleShape, color = Color.White.copy(alpha = .22f), modifier = Modifier.size(52.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(if (neutral) Icons.Default.FolderOpen else Icons.Default.AccountBalance, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
                }
                Column(Modifier.weight(1f)) {
                    Text(c.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 2)
                    Text(
                        (if (neutral) "" else kindAr(c.kind) + " · ") + "${c.halaqat.size} حلقات · ${c.halaqat.sumOf { it.students }} طالبًا",
                        style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = .95f),
                    )
                    c.manager?.let { Text((if (c.kind == "mosque") "مسؤول المسجد: " else "مدير المركز: ") + it.name, style = MaterialTheme.typography.labelMedium, color = Color.White) }
                }
                if (canEdit && onEdit != null) Box {
                    IconButton(onClick = { menu = true }, modifier = Modifier.size(48.dp)) { Icon(Icons.Default.MoreVert, "إجراءات", tint = Color.White) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menu = false; onEdit() })
                        if (onDelete != null) DropdownMenuItem(text = { Text("حذف") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menu = false; onDelete() })
                    }
                }
                Icon(if (open) Icons.Default.ExpandLess else Icons.Default.ExpandMore, if (open) "طي" else "فتح", tint = Color.White)
            }
            AnimatedVisibility(visible = open) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (c.halaqat.isEmpty()) Text("لا توجد حلقات هنا بعد.", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    c.halaqat.forEach { h -> OrgHalaqaRow(h, pair, canEdit, onMove) }
                }
            }
        }
    }
}

@Composable
private fun OrgHalaqaRow(h: OrgHalaqa, pair: GradientPair, canMove: Boolean, onMove: (OrgHalaqa) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = RoundedCornerShape(18.dp), color = cs.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradientIcon(Icons.Default.MenuBook, pair, tile = 40.dp, glyph = 22.dp)
                Column(Modifier.weight(1f)) {
                    Text(h.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text("${h.students} طالبًا", style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                }
                if (canMove) TextButton(onClick = { onMove(h) }, modifier = Modifier.heightIn(min = 48.dp)) { Text("نقل") }
            }
            if (h.supervisors.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("المشرف:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                h.supervisors.forEach { PersonChip(it, supervisor = true) }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("المحفّظ:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                if (h.teachers.isEmpty()) Text("لم يُعيَّن بعد", style = MaterialTheme.typography.labelMedium, color = cs.error, fontWeight = FontWeight.Bold)
                h.teachers.forEach { PersonChip(it, supervisor = false) }
            }
        }
    }
}

@Composable
private fun CenterSheet(existing: OrgCenter?, staff: List<OrgPerson>, onDismiss: () -> Unit, onSave: (String, String, String?) -> Unit) {
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var kind by remember { mutableStateOf(existing?.kind ?: "center") }
    var manager by remember { mutableStateOf(existing?.manager?.id.orEmpty()) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(if (existing == null) "إضافة مركز أو مسجد" else "تعديل ${existing.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            OutlinedTextField(name, { name = it.take(80) }, label = { Text("الاسم") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProFilterChip(kind == "center", { kind = "center" }, "مركز", showCheckIcon = false)
                ProFilterChip(kind == "mosque", { kind = "mosque" }, "مسجد", showCheckIcon = false)
            }
            HalaqatiLazySelectField(
                label = if (kind == "mosque") "مسؤول المسجد" else "مدير المركز", selectedKey = manager.ifBlank { null },
                options = staff.map { it.id to it.name }, onSelected = { manager = it }, modifier = Modifier.fillMaxWidth(),
                allowEmpty = true, emptyKey = "", emptyOptionLabel = "بدون", searchable = true,
            )
            Button(enabled = name.trim().length >= 2, onClick = { onSave(name.trim(), kind, manager.ifBlank { null }) }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("حفظ", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun MoveSheet(h: OrgHalaqa, centers: List<OrgCenter>, onDismiss: () -> Unit, onPick: (String?) -> Unit) {
    var target by remember { mutableStateOf(h.centerId.orEmpty()) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("نقل ${h.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            HalaqatiLazySelectField(
                label = "المركز أو المسجد", selectedKey = target.ifBlank { null },
                options = centers.map { it.id to (kindAr(it.kind) + " · " + it.name) }, onSelected = { target = it }, modifier = Modifier.fillMaxWidth(),
                allowEmpty = true, emptyKey = "", emptyOptionLabel = "بدون مركز",
            )
            Button(onClick = { onPick(target.ifBlank { null }) }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("نقل", fontWeight = FontWeight.Bold) }
        }
    }
}

/* ============================== home card ============================== */

/** Shown on the admin / supervisor home: who the association is, what your role in it is, and one tap to the whole tree. */
@Composable
fun OrgSummaryCard(profile: Profile, navigate: (String) -> Unit, modifier: Modifier = Modifier) {
    var name by remember { mutableStateOf("") }
    var halaqat by remember { mutableIntStateOf(0) }
    var staff by remember { mutableIntStateOf(0) }
    LaunchedEffect(profile.id) {
        withContext(Dispatchers.IO) {
            val repo = AppGraph.repo
            name = runCatching { repo.mySubscription()?.optString("name") }.getOrNull().orEmpty()
            halaqat = runCatching { repo.table("halaqas", "select=id,active&limit=300").sRows().count { it.optBoolean("active", true) } }.getOrDefault(0)
            staff = runCatching { staffProfiles().size }.getOrDefault(0)
        }
    }
    Surface(modifier.fillMaxWidth().clickable { navigate("org") }, shape = RoundedCornerShape(24.dp), color = Color.Transparent) {
        Row(
            Modifier.background(HalaqatiGradients.Deep.brush()).girih(Color.White, .16f, 42.dp).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            GradientIcon(Icons.Default.AccountTree, HalaqatiGradients.Gold, tile = 54.dp, glyph = 28.dp)
            Column(Modifier.weight(1f)) {
                Text(name.ifBlank { "الجمعية" }, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(roleLabelArabic(profile.role) + " · $halaqat حلقات · $staff من الكادر", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = .95f))
                Text("الهيكل الإداري: المراكز والمساجد والحلقات", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = .85f))
            }
            Icon(Icons.Default.ChevronLeft, null, tint = Color.White)
        }
    }
}
