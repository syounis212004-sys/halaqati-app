#!/usr/bin/env python3
"""RC24.2 gate: no milestone tests in smart plans, ayah ranges in alerts, compact grouped notifications."""
from pathlib import Path
import json, sys

root = Path(__file__).resolve().parents[1]
J = root / 'app/src/main/java/com/mohammedsamir/halaqati'
def read(rel): return (root / rel).read_text(encoding='utf-8')

rules = read('app/src/main/java/com/mohammedsamir/halaqati/data/SmartPlanAlertRules.kt')
repo = read('app/src/main/java/com/mohammedsamir/halaqati/data/HalaqatiRepository.kt')
engine = read('app/src/main/java/com/mohammedsamir/halaqati/plans/SmartPlanEngine.kt')
core = read('app/src/main/java/com/mohammedsamir/halaqati/ui/screens/CoreScreens.kt')
mgmt = read('app/src/main/java/com/mohammedsamir/halaqati/ui/screens/ManagementScreens.kt')
build = read('app/build.gradle.kts')
errors = []

for token in ('exactStart', 'exactEnd', 'fun ayahRange', 'QuranMetadata.pageStart'):
    if token not in rules: errors.append('alert rules missing ' + token)
for banned in ('اختبار مرحلي', '"test" ->'):
    if banned in rules: errors.append('alert rules still mention ' + banned)
if 'endpointsForLineKeys' not in repo or 'exact?.first, exact?.second' not in repo:
    errors.append('home-prep alert does not pass exact ayah endpoints')
if 'kind = "test"' in engine: errors.append('smart-plan engine still creates test assignments')
if '.milestone != null' in core or 'approvingMilestone' in core or 'الاختبار المطلوب' in core:
    errors.append('milestone UI is still present in CoreScreens')
for token in ('notificationIsLegacyTest', 'NotificationCompactRow', 'expandedGroups', 'notificationIsArchived',
              'تنظيف إشعارات الاختبارات القديمة', 'بحث باسم الطالب أو النص', 'كل الأنواع'):
    if token not in mgmt: errors.append('notifications UX missing ' + token)
if not any(f'versionCode = {c}' in build and f'versionName = "{n}"' in build for c,n in (('26002','2.60.2'),('26003','2.60.3'),('26004','2.60.4'),('26100','2.61.0'),('26101','2.61.1'),('26200','2.62.0'),('26201','2.62.1'),('26202','2.62.2'),('26300','2.63.0'),('26301','2.63.1'),('26302','2.63.2'),('26303','2.63.3'),('26304','2.63.4'),('26305','2.63.5'),('26306','2.63.6'),('26307','2.63.7'),('26308','2.63.8'),('26309','2.63.9'),('26310','2.63.10'),('26311','2.63.11'),('26312','2.63.12'),('26313','2.63.13'),('26314','2.63.14'),('26315','2.63.15'),('26316','2.63.16'),('26317','2.63.17'),('26318','2.63.18'),('26319','2.63.19'))):
    errors.append('version is not 2.60.2/2.60.3')
if json.loads(read('migration/source-contract.json')).get('native_version') not in ('2.60.2','2.60.3','2.60.4','2.61.0','2.61.1','2.62.0','2.62.1','2.62.2','2.63.0','2.63.1','2.63.2','2.63.3','2.63.4','2.63.5','2.63.6','2.63.7','2.63.8','2.63.9','2.63.10','2.63.11','2.63.12','2.63.13','2.63.14','2.63.15','2.63.16','2.63.17','2.63.18','2.63.19'):
    errors.append('source contract native_version is not 2.60.2')
if not (root / 'RELEASE_2_60_2_RC24_2_NOTIFICATIONS_AYAH_RANGES_AR.md').exists():
    errors.append('release note missing')
if errors:
    print('RC24.2 gate FAILED')
    for e in errors: print(' -', e)
    sys.exit(1)
print('RC24.2 notifications / ayah-range / no-milestone gate PASS')
