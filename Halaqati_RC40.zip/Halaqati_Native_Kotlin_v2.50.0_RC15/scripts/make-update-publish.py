from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.76.0',
    'versionCode':27600,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        'إنهاء الجلسة ذكي: عند إنهاء الجلسة يُعتمد الحاضر بلا تسميع «لم يُسمّع»، ويُسجَّل الطالب غير المرصود غائبًا، وتظهر لك النتيجة قبل التأكيد.',
        'شريط سفلي جديد: الرئيسية، الجلسات، زر «＋» ذكي لإضافة جلسة من أي صفحة، الإعلانات والمنتدى، والمزيد. الطلاب والخطط صارت اختصارات في الرئيسية وفي القائمة.',
        'الرئيسية: شبكة اختصارات (الطلاب، الخطط، الجلسات، التقارير، الترتيب، المصحف) والتاريخ الهجري.',
        'صفحة الجلسة أوسع: شريط علوي أنحف، بحث وملخص في سطر، وإزالة التنبيه المكرر للمزامنة، وصفوف طلاب أكثر إحكامًا.',
        'صور الطلاب: إضافة صورة للطالب من نموذج الطالب، وتظهر مصغّرة أمام الاسم بإطار ذهبي، ويمكن إيقافها من الإعدادات.',
        'المراقب: فصل الحفظ والمراجعة والسرد (كنطاق) لكل حلقة ولكل طالب بدل المجموع المختلط.',
        'مظهر أدفأ: خلفية عاجية وحدود ذهبية هادئة، وإزالة سطر «الشرقية — خانيونس» مع بقاء «صُنع بأيدٍ شرقية».',
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
