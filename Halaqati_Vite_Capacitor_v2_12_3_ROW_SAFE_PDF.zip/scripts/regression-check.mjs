import fs from 'node:fs';
const f='src/legacy/app.js';
const s=fs.readFileSync(f,'utf8');
const required=[
  'function settingsPage()', 'function getThemePrefs()', 'function applySavedTheme()',
  'function previewSettings()', 'function setPreset(', 'function saveThemeSettings()',
  'function resetTheme()', 'async function changeMyPassword()',
  'function studentDirectoryRows()', 'async function exportStudentsExcel()',
  'async function exportStudentsWord()', 'window.openStudentsPdfPreview=function()',
  'window.openReportPreview=function()', 'function buildRowSafePdfPages(', 'window.downloadReportPdfFromPreview=async function()'
];
for(const token of required){if(!s.includes(token)){console.error('MISSING:',token);process.exit(1)}}
const dataBlock=s.slice(s.indexOf('function dataPage(){'),s.indexOf('\nfunction settingsPage(){',s.indexOf('function dataPage(){')));
if(dataBlock.includes('exportReportsExcel()')){console.error('Regression: report Excel is back on data page');process.exit(1)}
const finalReports=s.lastIndexOf('function reportsPage(){');
const reportBlock=s.slice(finalReports,s.indexOf('\nfunction reportExportRows()',finalReports));
if(!reportBlock.includes('onclick="openReportPreview()"')){console.error('Regression: report PDF does not open built-in preview directly');process.exit(1)}
if(!s.includes("const APP_VERSION_NAME='2.12.3';")||!s.includes('const APP_VERSION_CODE=21203;')){console.error('Version mismatch');process.exit(1)}
console.log('Regression checks passed: settings, preview, row-safe PDF pagination, exports, version.');
