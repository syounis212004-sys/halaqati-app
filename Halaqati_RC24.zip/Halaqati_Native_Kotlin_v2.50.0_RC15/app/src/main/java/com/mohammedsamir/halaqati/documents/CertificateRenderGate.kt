package com.mohammedsamir.halaqati.documents

import android.webkit.WebView
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

data class CertificateRenderGateResult(
    val ready: Boolean,
    val layoutOk: Boolean,
    val requiredNodesPresent: Boolean,
    val requiredNodesVisible: Boolean,
    val requiredNodesInsidePage: Boolean,
    val noProtectedOverlap: Boolean,
    val invalidSections: List<String>,
    val renderRevision: String,
) {
    val valid: Boolean get() = ready && layoutOk && requiredNodesPresent && requiredNodesVisible && requiredNodesInsidePage && noProtectedOverlap

    fun arabicError(): String {
        if (valid) return ""
        val labels = invalidSections.map { raw ->
            when (raw.substringBefore(':')) {
                "kicker" -> "عنوان شهادة تقدير وإنجاز"
                "title" -> "عنوان الشهادة"
                "student" -> "اسم الطالب"
                "achievement" -> "نص الإنجاز"
                else -> raw
            }
        }.distinct()
        return if (labels.isEmpty()) "معاينة الشهادة غير مكتملة أو خرجت عناصرها عن حدود A4" else "تعذر إصدار الشهادة: راجع ${labels.joinToString("، ")}"
    }

    companion object {
        fun fromJson(obj: JSONObject): CertificateRenderGateResult {
            val invalid = obj.optJSONArray("invalid_sections") ?: JSONArray()
            return CertificateRenderGateResult(
                ready = obj.optBoolean("ready", false),
                layoutOk = obj.optBoolean("layout_ok", false),
                requiredNodesPresent = obj.optBoolean("required_nodes_present", false),
                requiredNodesVisible = obj.optBoolean("required_nodes_visible", false),
                requiredNodesInsidePage = obj.optBoolean("required_nodes_inside_page", false),
                noProtectedOverlap = obj.optBoolean("no_protected_overlap", false),
                invalidSections = (0 until invalid.length()).mapNotNull { invalid.optString(it).takeIf(String::isNotBlank) },
                renderRevision = obj.optString("render_revision", "unknown"),
            )
        }
    }
}

suspend fun evaluateCertificateGate(view: WebView): CertificateRenderGateResult = suspendCancellableCoroutine { cont ->
    view.evaluateJavascript(
        "(function(){try{return JSON.stringify(window.__HALAQATI_CERTIFICATE_GATE__?window.__HALAQATI_CERTIFICATE_GATE__():{ready:false,layout_ok:false,required_nodes_present:false,required_nodes_visible:false,required_nodes_inside_page:false,no_protected_overlap:false,invalid_sections:['gate:missing'],render_revision:'missing'})}catch(e){return JSON.stringify({ready:false,layout_ok:false,required_nodes_present:false,required_nodes_visible:false,required_nodes_inside_page:false,no_protected_overlap:false,invalid_sections:['gate:error'],render_revision:'error'})}})()",
    ) { raw ->
        if (!cont.isActive) return@evaluateJavascript
        val decoded = runCatching { JSONArray("[$raw]").optString(0) }.getOrDefault("")
        val result = runCatching { CertificateRenderGateResult.fromJson(JSONObject(decoded)) }.getOrElse {
            CertificateRenderGateResult(false, false, false, false, false, false, listOf("gate:parse"), "parse-error")
        }
        cont.resume(result)
    }
}
