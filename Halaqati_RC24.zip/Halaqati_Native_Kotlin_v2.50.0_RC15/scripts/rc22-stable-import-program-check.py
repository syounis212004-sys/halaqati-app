from pathlib import Path
root=Path(__file__).resolve().parents[1]
checks={
'app/build.gradle.kts':['versionCode = 25900','versionName = "2.59.0"'],
'migration/20261005_v2580_rc22_program_metadata_import_ux.sql':['program_specialization','program_level','assessment_type','affects_primary_plan'],
'app/src/main/java/com/mohammedsamir/halaqati/ui/screens/ManagementScreens.kt':['program_specialization','program_level','assessment_type','affects_primary_plan','تأهيل محفظين','علاج ضعف القراءة'],
'app/src/main/java/com/mohammedsamir/halaqati/ui/screens/ReportsAndTools.kt':['displayName(context, uri)','zipEntries','name.endsWith(".xlsx")','verticalScroll(rememberScrollState())'],
'app/src/main/java/com/mohammedsamir/halaqati/ui/screens/CoreScreens.kt':['program_specialization','tajweed_applied','intensive_hifz'],
}
count=0
for rel, needles in checks.items():
    text=(root/rel).read_text(encoding='utf-8')
    for n in needles:
        assert n in text, f'{rel}: missing {n}'
        count+=1
print(f'RC22 source gate: {count}/{count} PASS')
