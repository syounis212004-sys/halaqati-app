from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.60.0',
    'versionCode':26000,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    'notes':[
        'إعادة بناء محرك الشهادات لمنع PDF ناقص أو فارغ وإجبار فحص عناصر الشهادة قبل الإصدار.',
        'نقل عبارة شهادة تقدير وإنجاز مباشرة تحت الزخرفة العلوية مع معاينة A4 مطابقة لمسار PDF.',
        'أرقام رسمية جديدة بسلاسل مستقلة قابلة للتخصيص مثل S للسرد وK للختم مع حفظ الأرقام القديمة.',
        'دعم v1/v2/v3 تحت الرقم الرسمي نفسه عند تصحيح النص أو التصميم دون حرق رقم جديد.',
        'أرشيف رسمي قابل للمعاينة والتصحيح والإلغاء وإضافة سجلات تاريخية مع إبقاء PDF والصور محليًا.',
        'الحفاظ على جميع إصلاحات RC23 للطلاب والجلسات والخطط والتزامن.'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
