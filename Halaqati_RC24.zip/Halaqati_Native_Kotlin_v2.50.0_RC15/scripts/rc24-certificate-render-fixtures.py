#!/usr/bin/env python3
from pathlib import Path
import argparse, json, shutil, sys
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
css = (root / 'app/src/main/assets/documents/certificate.css').read_text(encoding='utf-8')

fixtures = [
    dict(key='normal', name='إبراهيم عصمت يوسف البريم', title='إتمام سرد أجزاء من القرآن الكريم', achievement='تقديرًا لإتمامه بحمد الله سرد ثلاثة أجزاء من كتاب الله تعالى', expected=True, number='under_logo'),
    dict(key='long-name', name='عبد الرحمن محمد إسماعيل إبراهيم عبد الكريم أبو عودة الفلسطيني', title='شهادة تقدير وإنجاز', achievement='تقديرًا لتميزه في حفظ كتاب الله تعالى ومواصلته مسيرة الحفظ بإتقان وانضباط', expected=True, number='under_logo'),
    dict(key='long-achievement', name='أحمد حسن وصفي أبو عنزة', title='شهادة تميز في القرآن الكريم', achievement='تقديرًا لما بذله من جهد متميز ومتواصل في حفظ كتاب الله تعالى ومراجعته وإتقان تلاوته، ولما أظهره من انضباط وأخلاق عالية وحرص على حضور الحلقة والمشاركة الفاعلة طوال الفترة المحددة.', expected=True, number='under_logo'),
    dict(key='optional-hidden', name='طالب بدون مقدمة', title='شهادة تقدير', achievement='تقديرًا لتميزه في حفظ كتاب الله تعالى.', expected=True, number='under_logo', intro='', dua=''),
    dict(key='number-top', name='طالب موضع الرقم', title='شهادة تقدير', achievement='تقديرًا لتميزه في حفظ كتاب الله تعالى.', expected=True, number='top'),
    dict(key='number-footer-start', name='طالب موضع الرقم', title='شهادة تقدير', achievement='تقديرًا لتميزه في حفظ كتاب الله تعالى.', expected=True, number='footer_start'),
    dict(key='number-footer-end', name='طالب موضع الرقم', title='شهادة تقدير', achievement='تقديرًا لتميزه في حفظ كتاب الله تعالى.', expected=True, number='footer_end'),
    dict(key='legacy-partial', name='شهادة قديمة', title='بيانات أصلية غير مكتملة', achievement='بيانات التصميم الأصلية غير متوفرة؛ هذه معاينة أرشيفية وليست إعادة اختراع للنص القديم.', expected=True, number='under_logo'),
    dict(key='blank-achievement', name='طالب الاختبار', title='شهادة تقدير وإنجاز', achievement='', expected=False, number='under_logo'),
]


def number_html(position: str):
    code = '<span class="cert-number-label">رقم الشهادة:</span> <span class="cert-number-code">HAL-CERT-2026-S-00001</span>'
    if position == 'under_logo':
        return '', f'<div class="cert-number cert-number-logo">{code}</div>', '', ''
    if position == 'top':
        return f'<div class="cert-number cert-number-top">{code}</div>', '', '', ''
    if position == 'footer_start':
        return '', '', f'<div class="cert-number cert-number-footer cert-number-right">{code}</div>', ''
    if position == 'footer_end':
        return '', '', '', f'<div class="cert-number cert-number-footer">{code}</div>'
    return '', '', '', ''


def html(f):
    top, under, footer_start, footer_end = number_html(f.get('number', 'under_logo'))
    intro = f.get('intro', 'تتشرف الحلقة بمنح هذه الشهادة للطالب')
    dua = f.get('dua', 'سائلين الله تعالى أن يثبته ويرفعه بالقرآن.')
    return f'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>{css}</style></head><body>
 <article class="halaqati-certificate cert-template-emerald" dir="rtl" style="--cert-primary:#0b5f5b;--cert-secondary:#8a4d22;--cert-accent:#b9954a;--cert-paper:#fbf7eb;--cert-ink:#18211e;--cert-title-size:44px;--cert-student-size:38px;--cert-body-size:20px;--cert-logo-size:168px;--cert-border-width:3px;--cert-ornament-opacity:.82;--cert-font:'Cairo',sans-serif;">
 <div class="cert-frame"></div>{top}<header class="cert-head"><div class="cert-logo-slot cert-logo-slot-halaqa"><div class="cert-logo cert-logo-placeholder">شعار</div></div><div class="cert-org"><h3>مركز إبراهيم خليل الرحمن لتحفيظ القرآن الكريم</h3><h4>حلقة معاوية بن أبي سفيان</h4><div class="cert-orn-line"><span></span></div></div><div class="cert-logo-slot cert-logo-slot-center"><div class="cert-logo cert-logo-placeholder">شعار</div>{under}</div></header>
 <div class="cert-kicker">شهادة تقدير وإنجاز</div><h1 class="cert-main-title">{f['title']}</h1><p class="cert-intro" style="{'display:none' if not intro else ''}">{intro}</p><div class="cert-name-box"><strong>{f['name']}</strong></div><p class="cert-achievement">{f['achievement']}</p><p class="cert-dua" style="{'display:none' if not dua else ''}">{dua}</p>
 <div class="cert-dates"><span>28 ربيع الآخر 1448 هـ</span><span>9 أكتوبر 2026م</span></div><div class="cert-signatures"><div class="cert-sign">المحفظ</div><div class="cert-stamp">الختم</div><div class="cert-sign">المشرف</div></div><footer class="cert-footer">{footer_start}<div class="cert-verse">﴿ وَقُلْ رَبِّ زِدْنِي عِلْمًا ﴾</div>{footer_end}</footer></article></body></html>'''


gate_js = '''() => { const page=document.querySelector('.halaqati-certificate'); const P=page.getBoundingClientRect(); const req=[['kicker','.cert-kicker'],['title','.cert-main-title'],['student','.cert-name-box strong'],['achievement','.cert-achievement']]; const prot=[...document.querySelectorAll('.cert-dates,.cert-signatures,.cert-footer')]; let invalid=[]; function visible(e){if(!e)return false;let s=getComputedStyle(e),r=e.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&parseFloat(s.opacity||'1')>0&&r.width>1&&r.height>1} function overlap(a,b){let A=a.getBoundingClientRect(),B=b.getBoundingClientRect();return !(A.bottom+3<=B.top||B.bottom+3<=A.top||A.right<=B.left||B.right<=A.left)}; for(const [k,q] of req){let e=document.querySelector(q);if(!e||!String(e.textContent||'').trim()){invalid.push(k+':missing');continue}if(!visible(e)){invalid.push(k+':hidden');continue}let r=e.getBoundingClientRect();if(r.left<P.left-1||r.right>P.right+1||r.top<P.top-1||r.bottom>P.bottom+1)invalid.push(k+':outside');for(const z of prot){if(visible(z)&&overlap(e,z))invalid.push(k+':overlap')}} let orn=document.querySelector('.cert-orn-line span').getBoundingClientRect(),kick=document.querySelector('.cert-kicker').getBoundingClientRect(); if(kick.top<orn.bottom-4||kick.top-orn.bottom>55)invalid.push('kicker:not-under-ornament'); return {valid:invalid.length===0,invalid,kickerGap:kick.top-orn.bottom}; }'''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--verify', action='store_true')
    ap.add_argument('--out', default='/tmp/rc24-certificate-fixtures')
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    executable = next((shutil.which(x) for x in ('chromium', 'chromium-browser', 'google-chrome', 'google-chrome-stable') if shutil.which(x)), None)
    if not executable:
        print('RC24 certificate fixture gate FAILED: no Chromium/Chrome executable', file=sys.stderr)
        return 2
    results = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, executable_path=executable, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width':1122, 'height':794})
        for f in fixtures:
            page.set_content(html(f), wait_until='load')
            result = page.evaluate(gate_js)
            result.update({'fixture': f['key'], 'expected_valid': f['expected']})
            results.append(result)
            page.screenshot(path=str(out / f"{f['key']}.png"))
            if f['key'] == 'normal':
                page.pdf(path=str(out / 'normal.pdf'), format='A4', landscape=True, print_background=True, margin={'top':'0','right':'0','bottom':'0','left':'0'})
        browser.close()
    (out / 'results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    bad = [r for r in results if bool(r['valid']) != bool(r['expected_valid'])]
    print(json.dumps(results, ensure_ascii=False, indent=2))
    if bad:
        print('RC24 certificate fixture gate FAILED', file=sys.stderr)
        return 1
    print('RC24 certificate fixture gate PASS')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
