from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.30',
    'versionCode':28930,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "رئيسية المانح: بطاقة ترحيب أعمق بآية بخط أغمق وأكبر، وملخص الحلقة للشهر الحالي حتى اليوم مع مقارنة بالشهر الماضي وحلقة حضور ومنحنى آخر 6 أشهر",
        "المكرَّمون بصورهم الحقيقية، ومستويات ذهبي وفضي وبرونزي، وقسم «كيف احتُسب التكريم»، ومفتاح لمسؤول النظام لإظهار صور المكرَّمين للمانحين",
        "بطاقة الابن لولي الأمر أُعيد تصميمها: صورة كبيرة وحالة اليوم ومقرر اليوم في لوحة واضحة",
        "الصور في قائمة الترتيب وبطاقات الملاحظة والتأخر وقائمة إنهاء الطور وصور المانحين في المحادثات",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
