package com.mohammedsamir.halaqati.pdf;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Halaqati v2.40.3 Vector PDF — Android Public API implementation.
 *
 * Intentionally uses only the official public printing surface:
 * WebView -> createPrintDocumentAdapter() -> PrintManager.print().
 * No hidden PrintDocumentAdapter callbacks, no reflection, no direct raster rendering.
 */
@CapacitorPlugin(name = "HalaqatiPdf")
public class HalaqatiPdfPlugin extends Plugin {
    private static final long PRINT_VIEW_RETENTION_MS = 10 * 60 * 1000L;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private WebView retainedPrintView;
    private Runnable retainedCleanup;

    @PluginMethod
    public void exportPdf(PluginCall call) {
        final String html = call.getString("html", "");
        final String requestedName = call.getString("filename", "halaqati-report.pdf");
        final String orientation = call.getString("orientation", "landscape");

        if (html == null || html.trim().isEmpty()) {
            call.reject("PDF HTML is empty");
            return;
        }
        if (html.length() > 12_000_000) {
            call.reject("PDF HTML is too large");
            return;
        }

        final Activity activity = getActivity();
        if (activity == null) {
            call.reject("Android activity is unavailable");
            return;
        }

        final String filename = safePdfName(requestedName);
        activity.runOnUiThread(() -> preparePrint(activity, call, html, filename, orientation));
    }

    private void preparePrint(Activity activity, PluginCall call, String html, String filename, String orientation) {
        releaseRetainedPrintView();

        final WebView webView = new WebView(activity);
        retainedPrintView = webView;

        final WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setLoadsImagesAutomatically(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        webView.setBackgroundColor(0xFFFFFFFF);

        final boolean[] launched = new boolean[]{false};
        final Runnable[] pageTimeout = new Runnable[1];

        pageTimeout[0] = () -> {
            if (launched[0]) return;
            releaseRetainedPrintView();
            call.reject("انتهت مهلة تجهيز التقرير للطباعة. حاول مرة أخرى.");
        };
        mainHandler.postDelayed(pageTimeout[0], 25_000L);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (launched[0]) return;
                // Give embedded Cairo/font-face resources and layout a short stable window.
                mainHandler.postDelayed(() -> {
                    if (launched[0] || retainedPrintView != webView) return;
                    launched[0] = true;
                    mainHandler.removeCallbacks(pageTimeout[0]);
                    openSystemPrintDialog(activity, call, webView, filename, orientation);
                }, 700L);
            }
        });

        webView.loadDataWithBaseURL(
                "https://halaqati.local/",
                html,
                "text/html",
                "UTF-8",
                null
        );
    }

    private void openSystemPrintDialog(Activity activity, PluginCall call, WebView webView,
                                       String filename, String orientation) {
        final PrintManager printManager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
        if (printManager == null) {
            releaseRetainedPrintView();
            call.reject("خدمة الطباعة غير متاحة على هذا الجهاز");
            return;
        }

        PrintAttributes.MediaSize mediaSize = PrintAttributes.MediaSize.ISO_A4;
        mediaSize = "portrait".equalsIgnoreCase(orientation)
                ? mediaSize.asPortrait()
                : mediaSize.asLandscape();

        final PrintAttributes attributes = new PrintAttributes.Builder()
                .setMediaSize(mediaSize)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build();

        try {
            final PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(filename);
            printManager.print(filename, adapter, attributes);

            retainUntilPrintFlowEnds(webView);

            final JSObject out = new JSObject();
            out.put("opened", true);
            out.put("saved", false);
            out.put("printDialog", true);
            out.put("filename", filename);
            out.put("engine", "chromium-webview-public-print-api");
            call.resolve(out);
        } catch (Throwable error) {
            releaseRetainedPrintView();
            final String message = error.getMessage() == null
                    ? error.getClass().getSimpleName()
                    : error.getMessage();
            call.reject("تعذر فتح شاشة حفظ PDF: " + message);
        }
    }

    private void retainUntilPrintFlowEnds(WebView webView) {
        if (retainedCleanup != null) {
            mainHandler.removeCallbacks(retainedCleanup);
        }
        retainedCleanup = () -> {
            if (retainedPrintView == webView) {
                releaseRetainedPrintView();
            }
        };
        mainHandler.postDelayed(retainedCleanup, PRINT_VIEW_RETENTION_MS);
    }

    private void releaseRetainedPrintView() {
        if (retainedCleanup != null) {
            mainHandler.removeCallbacks(retainedCleanup);
            retainedCleanup = null;
        }
        final WebView webView = retainedPrintView;
        retainedPrintView = null;
        if (webView == null) return;
        try { webView.stopLoading(); } catch (Throwable ignored) {}
        try { webView.loadUrl("about:blank"); } catch (Throwable ignored) {}
        try { webView.destroy(); } catch (Throwable ignored) {}
    }

    private String safePdfName(String value) {
        String name = value == null ? "halaqati-report.pdf" : value.trim();
        name = name.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "_");
        if (!name.toLowerCase().endsWith(".pdf")) name += ".pdf";
        if (name.length() > 120) name = name.substring(0, 116) + ".pdf";
        return name.isEmpty() ? "halaqati-report.pdf" : name;
    }
}
