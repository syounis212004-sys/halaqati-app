import fs from 'node:fs';
import path from 'node:path';

const cwd = process.cwd();
const apkArg = process.argv[2];
if (!apkArg) {
  console.error('Usage: node scripts/make-update-publish.mjs <signed-apk>');
  process.exit(1);
}

const apkPath = path.resolve(cwd, apkArg);
if (!fs.existsSync(apkPath) || fs.statSync(apkPath).size === 0) {
  console.error(`Signed APK not found or empty: ${apkPath}`);
  process.exit(1);
}

const pkg = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf8'));
const versionName = String(pkg.version || '1.0.0');
const [major=0, minor=0, patch=0] = versionName.split('.').map(x => Number.parseInt(x, 10) || 0);
const versionCode = major * 10000 + minor * 100 + patch;

const outDir = path.join(cwd, 'update-publish');
fs.mkdirSync(outDir, { recursive: true });

const latestApk = path.join(outDir, 'Halaqati-latest.apk');
fs.copyFileSync(apkPath, latestApk);

const apkUrl = 'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk';
const manifest = {
  versionName,
  versionCode,
  apkUrl,
  mandatory: false,
  notes: [
    'إضافة يوم معين وفترة وشهر معين إلى إحصائيات ومنافسة أولياء الأمور وترتيب الأبناء.',
    'إتاحة الرجوع لأي تاريخ أو شهر سابق مع احتساب الترتيب الحقيقي من بيانات Supabase للفترة المختارة.',
    'مشاركة نفس الفترة المختارة بين صفحتي المنافسة والترتيب، مع فلتر اختياري للابن عند وجود أكثر من طالب.',
    'تحسين رسائل عدم وجود النتائج وإظهار أن البيانات المعروضة مخزنة محلياً عند العمل دون إنترنت.',
    'الحفاظ على خصوصية أولياء الأمور: لا تُكشف ملفات أو تقارير الطلاب الآخرين، ويُستخدم الخادم للحساب فقط.'
  ],
  publishedAt: new Date().toISOString()
};

fs.writeFileSync(
  path.join(outDir, 'version.json'),
  JSON.stringify(manifest, null, 2) + '\n',
  'utf8'
);

console.log(`Update package prepared for v${versionName} (${versionCode})`);
console.log(`APK: ${latestApk}`);
console.log(`Manifest: ${path.join(outDir, 'version.json')}`);
