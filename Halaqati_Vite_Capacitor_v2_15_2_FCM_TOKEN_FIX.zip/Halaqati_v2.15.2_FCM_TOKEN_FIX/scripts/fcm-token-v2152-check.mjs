import fs from 'node:fs';
const r=fs.readFileSync('src/features/notifications/runtime.js','utf8');
const c=JSON.parse(fs.readFileSync('capacitor.config.json','utf8'));
function ok(v,m){if(!v)throw new Error(m)}
ok(r.includes('waitForPushRegistration'),'FCM wait/retry missing');
ok(r.includes('لم يصل رمز FCM من Firebase بعد محاولتين'),'FCM timeout diagnostics missing');
ok(r.includes('registrationError'),'registrationError listener missing');
ok(r.includes('state.pushState?.registered'),'test push guard missing');
ok(c.plugins?.PushNotifications?.presentationOptions?.includes('alert'),'foreground alert presentation missing');
ok(c.plugins?.PushNotifications?.presentationOptions?.includes('sound'),'foreground sound presentation missing');
console.log('FCM_TOKEN_V2152_CHECK_PASS');
