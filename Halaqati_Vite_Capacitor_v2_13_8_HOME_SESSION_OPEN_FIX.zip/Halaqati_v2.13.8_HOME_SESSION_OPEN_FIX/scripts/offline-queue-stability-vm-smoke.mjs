import fs from 'node:fs';
import vm from 'node:vm';
function fakeElement(){return {value:'',textContent:'',innerHTML:'',open:false,dataset:{},style:{},classList:{add(){},remove(){},contains(){return false}},addEventListener(){},showModal(){this.open=true},close(){this.open=false}}}
const els=new Map();
const document={querySelector(s){if(!els.has(s))els.set(s,fakeElement());return els.get(s)},querySelectorAll(){return []},addEventListener(){},visibilityState:'visible'};
const store=new Map(),calls=[];
const USER='11111111-1111-4111-8111-111111111111';
const H='44444444-4444-4444-8444-444444444444';
const DELETED='22222222-2222-4222-8222-222222222222';
const LOCAL='offline-se-123';
const NEW='33333333-3333-4333-8333-333333333333';
let created=false;
function qb(table){
  const st={op:'idle',payload:null,eqs:{},ids:null};
  const q={
    select(){if(st.op==='idle')st.op='select';return q},eq(k,v){st.eqs[k]=v;return q},in(k,v){st.ids=v;return q},
    maybeSingle:async()=>{if(table==='sessions'&&st.eqs.id===NEW&&created)return {data:{id:NEW,halaqa_id:H},error:null};return {data:null,error:null}},
    insert(p){st.op='insert';st.payload=p;return q},upsert(p){st.op='upsert';st.payload=p;return q},update(p){st.op='update';st.payload=p;return q},delete(){st.op='delete';return q},
    single:async()=>{if(table==='sessions'&&st.op==='insert'){created=true;calls.push(['session-insert',st.payload]);return {data:{id:NEW,...st.payload},error:null}};return {data:null,error:null}},
    then(resolve){
      if(table==='sessions'&&st.op==='select'&&st.ids){calls.push(['session-batch-check',st.ids]);return Promise.resolve({data:[],error:null}).then(resolve)}
      if(st.op==='upsert'){calls.push([table+'-upsert',st.payload]);return Promise.resolve({data:[st.payload],error:null}).then(resolve)}
      return Promise.resolve({data:[],error:null}).then(resolve)
    }
  };return q
}
const db={auth:{getSession:async()=>({data:{session:{user:{id:USER,email:'a@b.c'},access_token:'x',expires_at:Math.floor(Date.now()/1000)+3600}},error:null}),getUser:async()=>({data:{user:{id:USER,email:'a@b.c'}},error:null}),refreshSession:async()=>({data:{session:{user:{id:USER,email:'a@b.c'},access_token:'x',expires_at:Math.floor(Date.now()/1000)+3600}},error:null})},from:qb};
const context={console,document,navigator:{onLine:true},localStorage:{getItem:k=>store.get(k)??null,setItem:(k,v)=>store.set(k,String(v)),removeItem:k=>store.delete(k)},fetch:async()=>({ok:true}),setTimeout(){return 1},clearTimeout(){},confirm(){return true},AbortController,Date,Promise,JSON,Math,Number,String,Array,Object,Map,Set,RegExp,Error,Intl};context.window=context;context.window.supabase={createClient(){return db}};vm.createContext(context);
vm.runInContext(fs.readFileSync('src/core/runtime.js','utf8'),context,{timeout:5000});
vm.runInContext(`state.user={id:'${USER}',email:'a@b.c'};state.profile={role:'admin',active:true,approval_status:'approved'};state.networkVerified=true;state.offline=false;state.sessions=[];`,context);
// 1) Old pending writes for a session the user already deleted must be pruned, not recreated.
vm.runInContext(`writeOfflineQueue([
 {type:'attendance',key:'att:${DELETED}:s1',payload:{session_id:'${DELETED}',student_id:'s1',status:'present',recorded_by:'${USER}'}},
 {type:'behavior',key:'beh:${DELETED}:s1',payload:{session_id:'${DELETED}',student_id:'s1',behavior:'normal',created_by:'${USER}'}}
]);`,context);
await vm.runInContext(`pruneDeletedSessionOfflineData({silent:true})`,context);
let len=vm.runInContext('readOfflineQueue().length',context);
if(len!==0){console.error('orphan queue was not pruned',len);process.exit(1)}
if(calls.some(x=>x[0]==='session-insert')){console.error('deleted session was recreated unexpectedly');process.exit(1)}
// 2) A real local offline session must get a parent session operation automatically before child writes.
vm.runInContext(`state.sessions=[{id:'${LOCAL}',_offline:true,halaqa_id:'${H}',session_date:'2026-08-29',session_type:'tasmee',status:'open',created_by:'${USER}'}];state.sessionRoster={attendance:[],notes:[],recitations:[]};writeOfflineQueue([]);prepareSessionForOfflineWork('${LOCAL}');`,context);
let types=vm.runInContext('readOfflineQueue().map(x=>x.type)',context);
if(types.length!==1||types[0]!=='session'){console.error('local parent session was not auto-queued',types);process.exit(1)}
vm.runInContext(`enqueueOffline({type:'attendance',key:'att:${LOCAL}:s1',payload:{session_id:'${LOCAL}',student_id:'s1',status:'present',recorded_by:'${USER}'}})`,context);
await vm.runInContext(`syncOfflineQueue({refreshAfter:false})`,context);
len=vm.runInContext('readOfflineQueue().length',context);
if(len!==0){console.error('valid offline queue not fully synced',len);process.exit(1)}
if(!created||!calls.some(x=>x[0]==='attendance_records-upsert'&&x[1].session_id===NEW)){console.error('child operation was not mapped to created session',calls);process.exit(1)}
console.log('OFFLINE_QUEUE_STABILITY_VM_PASS');
