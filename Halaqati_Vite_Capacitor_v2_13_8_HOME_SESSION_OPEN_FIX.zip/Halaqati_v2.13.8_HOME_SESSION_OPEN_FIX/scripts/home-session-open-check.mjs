import fs from 'node:fs';
const s=fs.readFileSync('src/features/sessions/runtime.js','utf8');
const expected="async function openSessionRoster(id){state.page='sessions';state.sessionView=id;prepareSessionForOfflineWork(id);await loadSessionRosterData(id);render()}";
if(!s.includes(expected)){console.error('HOME_SESSION_OPEN_CHECK_FAIL: openSessionRoster must switch to sessions page before rendering');process.exit(1);}
console.log('HOME_SESSION_OPEN_CHECK_PASS');
