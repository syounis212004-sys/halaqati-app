import fs from 'node:fs';
import vm from 'node:vm';

function fakeElement(){
  return {
    value:'', textContent:'', innerHTML:'', dataset:{}, style:{}, checked:false,
    classList:{add(){},remove(){},toggle(){},contains(){return false}},
    addEventListener(){}, removeEventListener(){}, appendChild(){}, prepend(){},
    querySelector(){return fakeElement()}, querySelectorAll(){return []},
    reset(){}, showModal(){}, close(){}, setAttribute(){}, removeAttribute(){},
  };
}
const elements=new Map();
const document={
  querySelector(sel){if(!elements.has(sel))elements.set(sel,fakeElement());return elements.get(sel)},
  querySelectorAll(){return []},
  getElementById(id){return this.querySelector('#'+id)},
  addEventListener(){}, createElement(){return fakeElement()}, body:fakeElement(), documentElement:fakeElement(), visibilityState:'visible'
};
const q={
  select(){return q}, eq(){return q}, order(){return q}, limit(){return q}, gte(){return q}, lte(){return q}, in(){return q}, is(){return q},
  insert(){return q}, update(){return q}, upsert(){return q}, delete(){return q}, single(){return Promise.resolve({data:null,error:null})},
  then(resolve){return Promise.resolve({data:[],error:null}).then(resolve)}
};
const db={
  auth:{
    signInWithPassword:async()=>({data:{},error:null}), signInWithOAuth:async()=>({data:{},error:null}), signUp:async()=>({data:{},error:null}),
    resetPasswordForEmail:async()=>({error:null}), updateUser:async()=>({error:null}), getUser:async()=>({data:{user:null}}), getSession:async()=>({data:{session:null}}),
    onAuthStateChange:()=>({data:{subscription:{unsubscribe(){}}}}), signOut:async()=>({error:null})
  },
  from(){return Object.create(q)}, storage:{from(){return {createSignedUrl:async()=>({data:null,error:null})}}}
};
const store=new Map();
const context={
  console, document, navigator:{onLine:true}, location:{protocol:'https:',origin:'https://example.test',pathname:'/',hash:'',search:'',reload(){}}, history:{replaceState(){}},
  localStorage:{getItem:k=>store.get(k)??null,setItem:(k,v)=>store.set(k,String(v)),removeItem:k=>store.delete(k)},
  setTimeout(){return 1}, clearTimeout(){}, setInterval(){return 1}, clearInterval(){}, fetch:async()=>({ok:true,json:async()=>({})}), confirm:()=>true,
  URL, URLSearchParams, Date, Promise, Map, Set, JSON, Math, Number, String, Array, Object, RegExp, Error, Intl,
};
context.window=context;
context.window.addEventListener=()=>{};
context.window.open=()=>{};
context.window.supabase={createClient(){return db}};
context.globalThis=context;
vm.createContext(context);
const files=[
  'src/core/runtime.js','src/core/navigation.js','src/features/auth/runtime.js','src/features/students/runtime.js',
  'src/features/sessions/runtime.js','src/features/settings/runtime.js','src/legacy/app.js'
];
for(const file of files){
  try{vm.runInContext(fs.readFileSync(file,'utf8'),context,{filename:file,timeout:3000})}
  catch(e){console.error('VM runtime failure in',file,e);process.exit(1)}
}
const names=['boot','loginWithGoogle','studentsPage','openStudent','sessionsPage','openSessionRoster','settingsPage','render','navItems','changeMyPassword'];
for(const name of names){
  const type=vm.runInContext(`typeof ${name}`,context);
  if(type!=='function'){console.error('VM missing function',name,type);process.exit(1)}
}
const version=vm.runInContext('APP_VERSION_NAME+":"+APP_VERSION_CODE',context);
if(version!=='2.13.6:21306'){console.error('VM version mismatch',version);process.exit(1)}
console.log('PHASE3_VM_RUNTIME_SMOKE_PASS');
