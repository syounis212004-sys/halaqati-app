from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.55.0',
    'versionCode':25500,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    'notes':[
        'إصلاح جذري لدورة الشهر: زر بدء الشهر أصبح Create + Repair ويتحقق من كل طالب بدل تخطي الخطط الموجودة.',
        'الحفظ فردي لكل طالب من 1 إلى 22 حسب هدفه السابق، والسرد موحد 25 صفحة من 23 حتى نهاية الشهر.',
        'إصلاح ظهور مرحلة السرد قبل موعدها عند بقاء حالة حفظ قديمة مكتملة من الشهر السابق.',
        'إعادة تصميم صفحة الخطط بنظام بطاقات قابلة للطي حتى تظهر عدة خطط في الشاشة بدل استهلاك نصف الصفحة لكل طالب.',
        'إضافة نظام متابعة لوني: أزرق متقدم، أخضر على المسار، أصفر يحتاج انتباه، أحمر يحتاج متابعة عند تأخر يتجاوز 25%.',
        'تسجيل حالة الخطة يوميًا وإرسال تنبيه لولي الأمر بعد يومي حفظ أحمر متتاليين مع منع تكرار الإشعار المزعج.',
        'إضافة ملخص سريع لحالات الطلاب وأدوات الإدارة في قائمة واحدة مدمجة بدل أزرار كبيرة متفرقة.'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
