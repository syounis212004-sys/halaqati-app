import fs from 'node:fs/promises';
import path from 'node:path';
const pkg=JSON.parse(await fs.readFile('package.json','utf8'));
const [major,minor,patch]=pkg.version.split('.').map(Number);
const versionCode=major*10000+minor*100+patch;
await fs.rm('update-publish',{recursive:true,force:true});
await fs.mkdir('update-publish',{recursive:true});
await fs.copyFile(process.argv[2]||'Halaqati-signed.apk','update-publish/Halaqati-latest.apk');
const manifest={
  versionCode,
  versionName:pkg.version,
  apkUrl:'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
  mandatory:false,
  minSupportedVersionCode:20800,
  publishedAt:new Date().toISOString(),
  notes:['إصلاح خطأ تثبيت التحديث: Files still open','إغلاق ملف APK قبل تنفيذ PackageInstaller.commit','الإبقاء على إصلاح عرض وتعديل وحذف الخطط الشهرية']
};
await fs.writeFile('update-publish/version.json',JSON.stringify(manifest,null,2),'utf8');
console.log(JSON.stringify(manifest,null,2));
