package com.mohammedsamir.halaqati.updater;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name = "HalaqatiUpdater")
public class HalaqatiUpdaterPlugin extends Plugin {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @PluginMethod
    public void getVersion(PluginCall call) {
        try {
            PackageInfo info = getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), 0);
            JSObject out = new JSObject();
            out.put("versionName", info.versionName == null ? "" : info.versionName);
            out.put("versionCode", longVersionCode(info));
            out.put("packageName", getContext().getPackageName());
            out.put("canInstallPackages", Build.VERSION.SDK_INT < 26 || getContext().getPackageManager().canRequestPackageInstalls());
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Could not read app version: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void checkUpdate(PluginCall call) {
        String manifestUrl = call.getString("url", "");
        if (manifestUrl == null || manifestUrl.trim().isEmpty()) {
            call.reject("Missing update manifest URL");
            return;
        }
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                conn = open(manifestUrl);
                String text = readAll(conn.getInputStream());
                JSONObject j = new JSONObject(text);
                JSObject out = JSObject.fromJSONObject(j);
                call.resolve(out);
            } catch (Exception e) {
                call.reject("Update check failed: " + e.getMessage(), e);
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    @PluginMethod
    public void openInstallPermissionSettings(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT < 26 || getContext().getPackageManager().canRequestPackageInstalls()) {
                JSObject out = new JSObject(); out.put("alreadyAllowed", true); call.resolve(out); return;
            }
            Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getContext().getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            JSObject out = new JSObject(); out.put("opened", true); call.resolve(out);
        } catch (Exception e) {
            call.reject("Could not open install settings: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void downloadAndInstall(PluginCall call) {
        String apkUrl = call.getString("url", "");
        String expectedPackage = call.getString("expectedPackage", getContext().getPackageName());
        Integer expectedVersion = call.getInt("expectedVersionCode");
        if (apkUrl == null || apkUrl.trim().isEmpty()) { call.reject("Missing APK URL"); return; }

        if (Build.VERSION.SDK_INT >= 26 && !getContext().getPackageManager().canRequestPackageInstalls()) {
            JSObject out = new JSObject(); out.put("permissionRequired", true); call.resolve(out); return;
        }

        executor.execute(() -> {
            File apk = new File(getContext().getCacheDir(), "halaqati-update.apk");
            try {
                download(apkUrl, apk);
                PackageInfo archive = verifyArchive(apk, expectedPackage, expectedVersion == null ? 0 : expectedVersion.longValue());
                commitInstall(apk, archive);
                JSObject out = new JSObject();
                out.put("started", true);
                out.put("versionCode", longVersionCode(archive));
                out.put("versionName", archive.versionName == null ? "" : archive.versionName);
                call.resolve(out);
            } catch (Exception e) {
                call.reject("Update install failed: " + e.getMessage(), e);
            }
        });
    }

    private HttpURLConnection open(String u) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(u).openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(30000);
        conn.setRequestProperty("User-Agent", "Halaqati-Android-Updater/1.0");
        int code = conn.getResponseCode();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
        return conn;
    }

    private String readAll(InputStream in) throws Exception {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder(); String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        }
    }

    private void download(String url, File out) throws Exception {
        HttpURLConnection conn = open(url);
        long total = conn.getContentLengthLong();
        long read = 0;
        try (InputStream in = new BufferedInputStream(conn.getInputStream()); FileOutputStream fos = new FileOutputStream(out)) {
            byte[] buf = new byte[64 * 1024]; int n;
            while ((n = in.read(buf)) > 0) {
                fos.write(buf, 0, n); read += n;
                JSObject ev = new JSObject();
                ev.put("bytes", read); ev.put("total", total);
                ev.put("percent", total > 0 ? Math.min(100.0, read * 100.0 / total) : 0);
                notifyListeners("downloadProgress", ev);
            }
            fos.flush();
        } finally { conn.disconnect(); }
        if (!out.isFile() || out.length() < 1024) throw new Exception("Downloaded APK is empty");
    }

    private PackageInfo verifyArchive(File apk, String expectedPackage, long expectedVersion) throws Exception {
        PackageManager pm = getContext().getPackageManager();
        int flags = Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
        PackageInfo archive = pm.getPackageArchiveInfo(apk.getAbsolutePath(), flags);
        if (archive == null) throw new Exception("Downloaded file is not a valid APK");
        if (!expectedPackage.equals(archive.packageName)) throw new Exception("APK package name does not match Halaqati");
        long av = longVersionCode(archive);
        if (expectedVersion > 0 && av != expectedVersion) throw new Exception("APK version does not match update manifest");
        PackageInfo current = pm.getPackageInfo(getContext().getPackageName(), flags);
        if (av <= longVersionCode(current)) throw new Exception("Downloaded APK is not newer than installed version");
        if (!sameSigner(current, archive)) throw new Exception("APK signature does not match the installed Halaqati app");
        return archive;
    }

    private boolean sameSigner(PackageInfo a, PackageInfo b) throws Exception {
        Set<String> aa = certificateDigests(a); Set<String> bb = certificateDigests(b);
        if (aa.isEmpty() || bb.isEmpty()) return false;
        for (String x : aa) if (bb.contains(x)) return true;
        return false;
    }

    private Set<String> certificateDigests(PackageInfo info) throws Exception {
        Signature[] sigs;
        if (Build.VERSION.SDK_INT >= 28 && info.signingInfo != null) {
            sigs = info.signingInfo.hasMultipleSigners() ? info.signingInfo.getApkContentsSigners() : info.signingInfo.getSigningCertificateHistory();
        } else {
            //noinspection deprecation
            sigs = info.signatures;
        }
        Set<String> out = new HashSet<>();
        if (sigs == null) return out;
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        for (Signature s : sigs) {
            byte[] d = md.digest(s.toByteArray());
            StringBuilder hex = new StringBuilder();
            for (byte x : d) hex.append(String.format("%02X", x));
            out.add(hex.toString());
        }
        return out;
    }

    private void commitInstall(File apk, PackageInfo archive) throws Exception {
        PackageInstaller installer = getContext().getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        params.setAppPackageName(getContext().getPackageName());
        if (Build.VERSION.SDK_INT >= 31) {
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_REQUIRED);
        }

        int sessionId = installer.createSession(params);
        boolean committed = false;

        try (PackageInstaller.Session session = installer.openSession(sessionId)) {
            // IMPORTANT: PackageInstaller refuses commit() while a file opened
            // with session.openWrite() is still open. Close both streams first.
            try (InputStream in = new FileInputStream(apk);
                 OutputStream out = session.openWrite("base.apk", 0, apk.length())) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                out.flush();
                session.fsync(out);
            }

            Intent statusIntent = new Intent(getContext(), UpdateInstallReceiver.class);
            statusIntent.setAction("com.mohammedsamir.halaqati.UPDATE_INSTALL_STATUS." + sessionId);

            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) {
                flags |= PendingIntent.FLAG_MUTABLE;
            }

            PendingIntent pending = PendingIntent.getBroadcast(
                getContext(),
                sessionId,
                statusIntent,
                flags
            );

            session.commit(pending.getIntentSender());
            committed = true;
        } finally {
            if (!committed) {
                try {
                    installer.abandonSession(sessionId);
                } catch (Exception ignored) {}
            }
        }
    }

    private long longVersionCode(PackageInfo info) {
        if (Build.VERSION.SDK_INT >= 28) return info.getLongVersionCode();
        //noinspection deprecation
        return info.versionCode;
    }

    @Override
    protected void handleOnDestroy() {
        executor.shutdownNow();
    }
}
