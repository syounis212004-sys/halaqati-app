# حلقتي v2.8.2 — إصلاح التحديث التلقائي

سبب الخطأ:
كان `PackageInstaller.commit()` يُستدعى قبل إغلاق OutputStream الناتج من `session.openWrite()`،
لذلك Android كان يرفض التثبيت برسالة: `Files still open`.

الإصلاح:
- كتابة APK ثم `fsync`.
- إغلاق InputStream وOutputStream بالكامل.
- تنفيذ `session.commit()` بعد إغلاق الملفات.
- abandonSession عند حدوث فشل قبل commit.

ملاحظة:
للانتقال من v2.8.0/v2.8.1 إلى v2.8.2 ثبّت v2.8.2 يدويًا مرة واحدة من Artifact الموقّع.
من v2.8.2 فصاعدًا يفترض أن يعمل زر «تنزيل وتثبيت التحديث» داخل التطبيق.
