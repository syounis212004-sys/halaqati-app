from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.9',
    'versionCode':28909,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "أصلحنا تغيير اسم الحساب: يظهر الاسم الجديد فورًا في الرأس والترحيب دون إعادة تسجيل الدخول.",
        "اسم الدور يظهر بالعربية (محفّظ، مشرف…) بدل TEACHER.",
        "تحديد الإشعار كمقروء يثبت فورًا ولا يعود غير مقروء.",
        "كل التواريخ والأوقات بتوقيت غزة، بنظام 12 ساعة وأرقام لاتينية.",
        "أسماء مرشحات الإشعارات واضحة (محادثة، كفالة، تنبيه النظام…).",
        "ألوان أقوى: أخضر زمردي عميق وأحمر واضح مع شارات حالة صلبة بدل الألوان الباهتة.",
        "يشمل كل ما في الإصدارات السابقة: محادثات المانحين وظهور المشرف الجديد.",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
