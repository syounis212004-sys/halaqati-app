#!/usr/bin/env python3
"""Static gate for the Halaqati motion identity (RC27.12+): Lottie files, runtime recolor names, wiring, dependency."""
import json, re, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]
errors = []
raw = root / 'app/src/main/res/raw'
for n in ('splash', 'loading', 'success', 'empty'):
    p = raw / f'halaqati_{n}.json'
    if not p.exists():
        errors.append(f'missing {p.name}'); continue
    try:
        d = json.loads(p.read_text(encoding='utf-8'))
    except Exception as e:
        errors.append(f'{p.name} invalid JSON: {e}'); continue
    for k in ('v', 'fr', 'ip', 'op', 'w', 'h', 'layers'):
        if k not in d: errors.append(f'{p.name} missing {k}')
    if d.get('op', 0) <= d.get('ip', 0): errors.append(f'{p.name} op <= ip')
    if not re.fullmatch(r'[a-z0-9_]+', p.stem): errors.append(f'{p.name} bad resource name')
    text = p.read_text(encoding='utf-8')
    if n == 'splash':
        if '"BrandLeaf"' not in text: errors.append('splash lost the logo leaf layer')
    elif '"Primary"' not in text: errors.append(f'{p.name} has no Primary recolor target')
    if n != 'splash' and '"Accent"' not in text: errors.append(f'{p.name} has no Accent recolor target')
    if n == 'success' and '"OnPrimary"' not in text: errors.append('success has no OnPrimary target')
res = root / 'app/src/main/res'
for rel in ('drawable/ic_launcher_foreground.xml', 'drawable/ic_launcher_background.xml', 'drawable/ic_launcher_monochrome.xml',
            'drawable/ic_stat_halaqati.xml', 'drawable-nodpi/launcher_legacy.png', 'mipmap-anydpi-v26/ic_launcher.xml',
            'mipmap-anydpi-v26/ic_launcher_round.xml'):
    if not (res / rel).exists(): errors.append(f'icon resource missing: {rel}')
for dpi in ('mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'):
    for n in ('ic_launcher.png', 'ic_launcher_round.png'):
        if not (res / f'mipmap-{dpi}' / n).exists(): errors.append(f'legacy icon missing: mipmap-{dpi}/{n}')
if (res / 'mipmap-anydpi-v26/ic_launcher.xml').exists() and '<monochrome' not in (res / 'mipmap-anydpi-v26/ic_launcher.xml').read_text(encoding='utf-8'):
    errors.append('adaptive icon has no monochrome layer (themed icons)')
if (res / 'drawable/ic_launcher_foreground.xml').exists() and 'launcher_legacy' in (res / 'drawable/ic_launcher_foreground.xml').read_text(encoding='utf-8'):
    errors.append('adaptive foreground still wraps the old PNG')
for rel in ('drawable/ic_launcher_foreground.xml', 'drawable/ic_launcher_monochrome.xml', 'drawable/ic_stat_halaqati.xml'):
    f = res / rel
    if f.exists():
        import xml.dom.minidom
        try: xml.dom.minidom.parse(str(f))
        except Exception as e: errors.append(f'{rel} is not valid XML: {e}')
kt = (root / 'app/src/main/java/com/mohammedsamir/halaqati/ui/components/HalaqatiMotion.kt').read_text(encoding='utf-8')
for tok in ('R.raw.halaqati_splash', 'R.raw.halaqati_loading', 'R.raw.halaqati_success', 'R.raw.halaqati_empty',
            'LocalReducedMotion', 'delay(3200L)', 'derivedStateOf', 'HalaqatiMotionEvents'):
    if tok not in kt: errors.append(f'HalaqatiMotion.kt missing {tok}')
NEW = ('ambient', 'role_teacher', 'role_admin', 'role_supervisor', 'role_student', 'role_guardian', 'milestone', 'sync',
       'empty_people', 'empty_bell', 'empty_search', 'empty_doc', 'trophy', 'offline', 'welcome')
for n in NEW:
    p2 = raw / f'halaqati_{n}.json'
    if not p2.exists(): errors.append(f'missing {p2.name}'); continue
    try: d2 = json.loads(p2.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'{p2.name} invalid JSON: {e}'); continue
    if d2.get('op', 0) <= d2.get('ip', 0) or not d2.get('layers'): errors.append(f'{p2.name} malformed')
    tx = p2.read_text(encoding='utf-8')
    if '"Primary"' not in tx or '"Accent"' not in tx: errors.append(f'{p2.name} lacks recolor names')
    if '"Brand' in tx: errors.append(f'{p2.name} uses fixed brand colors (must follow the theme)')
    if f'R.raw.halaqati_{n}' not in kt: errors.append(f'HalaqatiMotion.kt does not reference halaqati_{n}')
for tok in ('HalaqatiRoleArt', 'HalaqatiAmbient', 'HalaqatiMoment', 'fun milestone', 'fun saved', 'fun welcome', 'onBand'):
    if tok not in kt: errors.append(f'HalaqatiMotion.kt missing {tok}')
ui = root / 'app/src/main/java/com/mohammedsamir/halaqati/ui'
kit = ui / 'components/HalaqatiMotionKit.kt'
if not kit.exists(): errors.append('HalaqatiMotionKit.kt missing')
else:
    ktx = kit.read_text(encoding='utf-8')
    for tok in ('fun Modifier.halaqatiEnter', 'fun animatedCountText', 'fun Modifier.halaqatiPressable', 'fun Modifier.halaqatiRing', 'fun Modifier.halaqatiSpin', 'LocalReducedMotion'):
        if tok not in ktx: errors.append(f'HalaqatiMotionKit.kt missing {tok}')
for rel, toks in {'components/Components.kt': ('HalaqatiAmbient', 'animatedCountText', 'emptyAnimationFor', 'halaqatiEnter'),
                  'components/GoldenShell.kt': ('HalaqatiRoleArt', 'HalaqatiAmbient', 'drawerGroupOf', 'quickDestinations', 'halaqatiPressable'), 'screens/AuthScreens.kt': ('HalaqatiRoleArt', 'HalaqatiAmbient'),
                  'screens/SyncCenterScreen.kt': ('HalaqatiAnimation.Sync',), 'screens/DashboardScreen.kt': ('role = p.role',)}.items():
    s = (ui / rel).read_text(encoding='utf-8')
    for tok in toks:
        if tok not in s: errors.append(f'{rel} not wired: {tok}')
if 'Surface(' in kt: errors.append('success host must not use Surface (it consumes touches)')
gr = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')
if 'com.airbnb.android:lottie-compose:' not in gr: errors.append('lottie-compose dependency missing')
main = (root / 'app/src/main/java/com/mohammedsamir/halaqati/MainActivity.kt').read_text(encoding='utf-8')
for tok in ('HalaqatiLaunchSplash', 'HalaqatiSuccessHost'):
    if tok not in main: errors.append(f'MainActivity missing {tok}')
nav = ui / 'components/HalaqatiNavMotion.kt'
if not nav.exists(): errors.append('HalaqatiNavMotion.kt missing')
else:
    nt = nav.read_text(encoding='utf-8')
    for tok in ('navEnter', 'navExit', 'navPopEnter', 'navPopExit', 'SlideDirection.Up', 'SlideDirection.Down', 'reduced'):
        if tok not in nt: errors.append(f'HalaqatiNavMotion.kt missing {tok}')
app = (ui / 'HalaqatiApp.kt').read_text(encoding='utf-8')
for tok in ('navEnter(', 'navExit(', 'navPopEnter(', 'navPopExit(', 'HalaqatiMotionEvents.welcome()'):
    if tok not in app: errors.append(f'HalaqatiApp.kt missing {tok}')
if 'enableOnBackInvokedCallback' not in (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8'): errors.append('predictive back not enabled in manifest')
if errors:
    print('Motion gate FAILED'); [print(' -', e) for e in errors]; sys.exit(1)
print('Motion gate passed')
