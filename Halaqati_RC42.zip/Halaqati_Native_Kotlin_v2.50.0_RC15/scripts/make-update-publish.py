from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.78.0',
    'versionCode':27800,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        'سجل التسميعات صار جدولًا: صف لكل طالب وأعمدة للأيام (6–7 أيام في الصفحة)، وفي كل خانة ما سمّعه الطالب ذلك اليوم، وعمود إجمالي في آخر صفحة، ويصدَّر كذلك إلى Excel وWord.',
        'زر «＋» يفتح قائمة إضافة سريعة فوق الصفحة (جلسة جديدة، جلسة اليوم، طالب، إعلان، تحفيظ سريع) دون أي تنقّل، فلا تتكرر الصفحة وأنت داخل جلسة.',
        'الشعارات: كل حساب يرى شعار مركزه وشعار حلقته التي رفعها بنفسه في التقارير والشهادات، ولا يظهر شعار المدير لغيره.',
        'المراقب: إصلاح دالة فصل الحفظ والمراجعة والسرد التي كانت تفشل بصمت، وصفحة تفاصيل لكل طالب (آخر التسميعات والحضور)، ورسالة واضحة عند أي فشل.',
        'صفحة «المتابعة والمقارنة» مستقلة بتبويبين، وبطاقاتها تحتفظ بآخر نتيجة فلا تعيد التحميل في كل مرة.',
        'تحديث المظهر: عناوين الشاشات بخط أميري الكلاسيكي، وخط ذهبي رفيع تحت الشريط العلوي وفوق الشريط السفلي، وحدود أدفأ في الوضع الداكن.',
        'الرئيسية أخف: صارت اللوحة المختصرة هي الافتراضية، والمسافات أضيق لتظهر الاختصارات والبطاقات في شاشة واحدة.',
        'مساحة أوسع: شريط علوي أنحف بسطر واحد للعنوان، وبطاقات الطلاب أكثر إحكامًا.',
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
