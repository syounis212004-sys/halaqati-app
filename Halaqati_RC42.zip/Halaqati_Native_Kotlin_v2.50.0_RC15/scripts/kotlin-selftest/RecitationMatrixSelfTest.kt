import com.mohammedsamir.halaqati.documents.RecitationMatrix as M

fun main() {
    val e = listOf(
        M.Entry("a", "أحمد", "2026-10-04", "hifz", "سورة الأحزاب: 51 → 73", 3.0),
        M.Entry("a", "أحمد", "2026-10-04", "review", "سورة النجم: 1 → 20", 2.0),
        M.Entry("a", "أحمد", "2026-10-05", "sard", "x", 10.0, 100, 110),
        M.Entry("a", "أحمد", "2026-10-06", "sard", "x", 10.0, 105, 115),
        M.Entry("b", "بلال", "2026-10-05", "hifz", "سورة ق: 1 → 18", 1.0),
    )
    val m = M.build(e)
    check(m.days == listOf("2026-10-04", "2026-10-05", "2026-10-06")) { m.days }
    check(m.rows.map { it.name } == listOf("أحمد", "بلال"))
    check(m.rows[0].cells["2026-10-04"]!!.size == 2) { "two kinds in one day -> two lines" }
    check(m.rows[0].cells["2026-10-04"]!![0] == "ح الأحزاب: 51 → 73 (3)") { m.rows[0].cells["2026-10-04"]!![0] }
    // total: hifz 3 + review 2 + sard span 100..115 = 16 (the overlap is not counted twice)
    check(m.rows[0].total == 21.0) { m.rows[0].total }
    check(M.blocks(m.days, 2) == listOf(listOf("2026-10-04", "2026-10-05"), listOf("2026-10-06")))
    check(M.blocks(emptyList(), 7).isEmpty())
    check(M.weekdayAr("2026-10-04") == "الأحد") { M.weekdayAr("2026-10-04") }
    println("RecitationMatrix self-tests passed")
}
