package com.mohammedsamir.halaqati.documents

/** RC42: the logos bundled in the app belong to the centre's administrator. Every other account shows only logos it uploaded itself. */
object LogoPolicy {
    @Volatile var builtIn: Boolean = false
}
