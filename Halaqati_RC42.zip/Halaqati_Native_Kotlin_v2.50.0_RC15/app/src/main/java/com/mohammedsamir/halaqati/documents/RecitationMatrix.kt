package com.mohammedsamir.halaqati.documents

import java.time.DayOfWeek
import java.time.LocalDate
import kotlin.math.max
import kotlin.math.min

/**
 * RC42: the recitation log as a grid. One row per student, one column per session day; each cell lists what the student
 * recited that day (one line per kind: ح حفظ · م مراجعة · س سرد · ث تثبيت · ل تلاوة · ا اختبار). Days are split into blocks of
 * [daysPerPage] columns; every block repeats the full student list. The total column follows the app-wide rule: sard is a
 * span (highest end page - lowest start page + 1), everything else adds up pages.
 */
object RecitationMatrix {
    data class Entry(
        val studentId: String,
        val studentName: String,
        val date: String,
        val kind: String,
        val range: String,
        val pages: Double,
        val startPage: Int? = null,
        val endPage: Int? = null,
    )

    data class Row(val studentId: String, val name: String, val cells: Map<String, List<String>>, val total: Double)
    data class Matrix(val days: List<String>, val rows: List<Row>)

    fun kindOf(activityType: String): String = when (activityType) {
        "new_hifz", "hifz" -> "hifz"
        "review_near", "review_far", "review" -> "review"
        else -> activityType
    }

    fun letter(kind: String): String = when (kind) {
        "hifz" -> "ح"; "review" -> "م"; "sard" -> "س"; "tathbit" -> "ث"; "tilawah" -> "ل"; "test" -> "ا"; else -> "•"
    }

    fun shortRange(range: String): String = range.replace("سورة ", "").trim()

    fun weekdayAr(date: String): String = runCatching {
        when (LocalDate.parse(date).dayOfWeek) {
            DayOfWeek.SATURDAY -> "السبت"; DayOfWeek.SUNDAY -> "الأحد"; DayOfWeek.MONDAY -> "الاثنين"
            DayOfWeek.TUESDAY -> "الثلاثاء"; DayOfWeek.WEDNESDAY -> "الأربعاء"; DayOfWeek.THURSDAY -> "الخميس"
            DayOfWeek.FRIDAY -> "الجمعة"
        }
    }.getOrDefault("")

    private fun fmt(v: Double): String =
        if (kotlin.math.abs(v - kotlin.math.round(v)) < .0001) kotlin.math.round(v).toInt().toString()
        else String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

    fun total(entries: List<Entry>): Double {
        val sard = entries.filter { it.kind == "sard" }
        val sardPages = if (sard.any { it.startPage != null && it.endPage != null }) {
            val starts = sard.mapNotNull { it.startPage ?: it.endPage }
            val ends = sard.mapNotNull { it.endPage ?: it.startPage }
            max(0, (ends.maxOrNull() ?: 0) - (starts.minOrNull() ?: 0) + 1).toDouble()
        } else sard.sumOf { it.pages }
        return entries.filter { it.kind != "sard" }.sumOf { it.pages } + sardPages
    }

    fun build(entries: List<Entry>): Matrix {
        val days = entries.map { it.date }.filter { it.isNotBlank() }.distinct().sorted()
        val rows = entries.groupBy { it.studentId }.map { (id, list) ->
            val cells = list.groupBy { it.date }.mapValues { (_, dayEntries) ->
                dayEntries.map { e ->
                    val pages = if (e.pages > 0.0) " (${fmt(e.pages)})" else ""
                    "${letter(e.kind)} ${shortRange(e.range)}$pages"
                }
            }
            Row(id, list.first().studentName, cells, total(list))
        }.sortedBy { it.name }
        return Matrix(days, rows)
    }

    fun blocks(days: List<String>, daysPerPage: Int): List<List<String>> =
        if (days.isEmpty()) emptyList() else days.chunked(max(1, min(daysPerPage, days.size.coerceAtLeast(1))))
}
