@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.ui.components.AppTopBar
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.theme.cardHairline
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** RC46: the donor ("المانح") home — honour roll per month and category, plus the existing statistics view. */
@Composable
fun DonorHomeScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("المكرَّمون") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("الإحصاءات") })
        }
        if (tab == 0) DonorAwardsTab(pending, onRefresh) else ObserverScreen(profile, pending, onRefresh, embedded = true)
    }
}

@Composable
private fun DonorAwardsTab(pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var months by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var month by remember { mutableStateOf<String?>(null) }
    var scopeKind by remember { mutableStateOf("halaqa") }
    var data by remember { mutableStateOf<JSONObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    fun loadMonths() {
        scope.launch {
            loading = true; error = null
            runCatching { withContext(Dispatchers.IO) { AppGraph.repo.awardMonths() } }
                .onSuccess { list ->
                    months = list
                    month = month?.takeIf { m -> list.any { it.optString("month").take(7) == m } } ?: list.firstOrNull()?.optString("month")?.take(7)
                    if (list.isEmpty()) data = null
                }
                .onFailure { error = it.message ?: "تعذر التحميل" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { loadMonths() }
    LaunchedEffect(month, scopeKind) {
        val m = month ?: return@LaunchedEffect
        loading = true
        runCatching { withContext(Dispatchers.IO) { AppGraph.repo.donorAwards("$m-01", scopeKind) } }
            .onSuccess { data = it; error = null }
            .onFailure { error = it.message ?: "تعذر التحميل"; data = null }
        loading = false
    }

    val groups = data?.optJSONArray("groups")?.awardObjects().orEmpty()
    val tathbit = data?.optJSONArray("tathbit")?.awardObjects().orEmpty()
    fun open(intent: Intent) = runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = "المانح", onRefresh = { loadMonths(); onRefresh() }, pending = pending)
        LazyColumn(
            state = androidx.compose.foundation.lazy.rememberLazyListState(),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), border = cardHairline(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("شكرًا لدعمك 🌿", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("هؤلاء أبناؤك الذين بذلوا وجدّوا هذا الشهر. نسأل الله أن يجعل لك مثل أجرهم.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
            error?.let { item { StateNotice(it, "warning") } }
            if (months.isNotEmpty()) item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(months) { row ->
                        val key = row.optString("month").take(7)
                        ProFilterChip(month == key, { month = key }, awardMonthLabel(key))
                    }
                }
            }
            if (months.isNotEmpty()) item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(scopeKind == "halaqa", { scopeKind = "halaqa" }, "حسب الحلقة")
                    ProFilterChip(scopeKind == "category", { scopeKind = "category" }, "حسب الفئة")
                }
            }
            if (loading && data == null) item { LoadingSkeleton(rows = 3) }
            if (!loading && months.isEmpty() && error == null) item { EmptyState("لم يُعتمد تكريم أي شهر بعد. سيصلك إشعار عند اعتماد المدير.") }
            items(groups) { g ->
                val winners = g.optJSONArray("winners")?.awardObjects().orEmpty()
                val title = listOf(g.optString("halaqa_name").takeIf { it.isNotBlank() && it != "null" }, g.optString("category_name")).filterNotNull().joinToString(" · ")
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), border = cardHairline(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(title, fontWeight = FontWeight.Bold)
                        if (winners.isEmpty()) Text("لم يستوفِ أحد شروط التكريم في هذه المجموعة هذا الشهر.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        winners.forEach { w -> DonorWinnerRow(w, ::open) }
                    }
                }
            }
            if (tathbit.isNotEmpty()) item {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), border = cardHairline(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("مجتهدون في التثبيت", fontWeight = FontWeight.Bold)
                        tathbit.forEach { t -> DonorWinnerRow(t.put("score", JSONObject.NULL), ::open, tathbit = true) }
                    }
                }
            }
        }
    }
}

@Composable
private fun DonorWinnerRow(w: JSONObject, open: (Intent) -> Unit, tathbit: Boolean = false) {
    val rank = w.optInt("rank")
    val phone = w.optString("phone").takeIf { it.isNotBlank() && it != "null" }
    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .5f),
        border = if (tathbit) null else BorderStroke(1.dp, medalColor(rank).copy(alpha = .5f))) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (tathbit) "📖" else medalLabel(rank), style = MaterialTheme.typography.titleLarge)
                Column(Modifier.weight(1f)) {
                    Text(w.optString("name"), fontWeight = FontWeight.SemiBold)
                    Text(
                        if (tathbit) "${w.optString("halaqa_name")} · ${awardNum(w.optDouble("pct"))}٪ من خطة التثبيت"
                        else "${awardNum(w.optDouble("score"))} / 100 · ${awardNum(w.optDouble("pages"))} صفحة · ${w.optString("halaqa_name")}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (phone != null) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { open(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) }) { Text("اتصال بولي الأمر") }
                OutlinedButton(onClick = { open(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + phone.filter { it.isDigit() }))) }) { Text("واتساب") }
            }
        }
    }
}
