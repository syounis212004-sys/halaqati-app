from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.82.0',
    'versionCode':28200,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        'التكريم الشهري (للمدير): درجة من ١٠٠ (حفظ ٤٠ · سرد ٣٠ · حضور ١٠ · سلوك ١٠ · جودة ١٠) تُحسب فجر اليوم الأول من الشهر لكل حلقة أو لكل فئة، بشروط (حفظ فوق ٩٠٪، سرد ١٠٠٪، غياب بلا عذر لا يزيد على جلستين). تراجعها وتستبعد من تشاء بسبب، ثم تعتمد الشهر.',
        'واجهة المانح الجديدة: أشهر معتمدة، وأفضل ٣ طلاب في كل فئة بأسمائهم الكاملة، ومجتهدو التثبيت. رقم ولي الأمر لا يظهر إلا بإذن المدير لكل طالب.',
        'زر «إصدار شهادة» بجانب الفائز الأول يعبّئ استوديو الشهادات تلقائيًا (نوع الترتيب، الشهر، الفئة).',
        'ولي الأمر يرى نفس أرقام المحفّظ: هدف المرحلة الحالية (حفظ أو سرد) والمنجز فيها يأتيان من نفس محرّك الخطة المعروض في صفحة الخطط، فلا يختلف رقمه عن رقم المحفّظ.',
        'مقرر اليوم موحّد: المقرر المكتوب (من آية إلى آية) و«مطلوب اليوم» و«هذا الأسبوع» كلها تأتي الآن من خطة الطالب نفسها، ولم يعد الهدف الأسبوعي المسجّل على الطالب يرفع مقرر الحفظ فوق خطته.',
        'تحت «مطلوب اليوم» سطر يشرح الرقم: أساسي + استدراك.',
        'التقارير: سجل التسميعات بتصميم جديد (أسهم صحيحة الاتجاه، نطاق فقط، ألوان للأنواع، «غ» للغياب و«ع» بعذر، عمود إجمالي لا يُقصّ، وصفحات متصلة بلا فراغات)، وملخص أسبوعي جديد، وتقرير أولياء الأمور بالالتزام وأيام الغياب.',
        'إنهاء السرد لعدة طلاب دفعة واحدة من شاشة مراحل الخطة، وبدء الشهر يعرض الشهر المختار (الحالي أو القادم) وتظهر رسالة الخطأ داخل النافذة.',
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
