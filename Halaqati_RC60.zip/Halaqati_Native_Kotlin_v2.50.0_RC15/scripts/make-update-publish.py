from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.7',
    'versionCode':28907,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "محادثات المانحين: قائمة للمدير بكل المحادثات مع عدّاد غير المقروء، وبدء محادثة جديدة مع أي مانح، وزر «محادثة مع المدير» عند المانح.",
        "الضغط على إشعار رسالة المانح (داخل التطبيق أو من إشعار الجوال) يفتح المحادثة مباشرة، وتصل رسالتك كإشعار فوري للطرف الآخر.",
        "يشمل كل ما في الإصدارات السابقة. يحتاج تشغيل ملف RC54_chat.sql على قاعدة البيانات.",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
