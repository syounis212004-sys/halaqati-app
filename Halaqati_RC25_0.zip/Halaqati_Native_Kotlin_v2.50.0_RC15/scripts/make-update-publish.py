from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.61.0',
    'versionCode':26100,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    'notes':[
        'تنظيم المؤسسة: شريط حلقة حالية قابل للتبديل، ونظرة عامة على الحلقات للمشرف والمدير.',
        'الجلسات والخطط مجمّعة حسب الحلقة ثم الشهر (الحالي والسابق مفتوحان والأقدم مطويّ).',
        'الطلاب مجمّعون حسب الحلقة، وإصلاح ذاتي للجلسة المحذوفة، وشاشة استرجاع الجلسات المحذوفة للمدير.',
        'يلزم تنفيذ ملف SQL الخاص بالنسخة مرة واحدة (بعد ملف 2.60.4).'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
