import './styles/app.css';
import coreRuntimeUrl from './core/runtime.js?url';
import navigationRuntimeUrl from './core/navigation.js?url';
import authRuntimeUrl from './features/auth/runtime.js?url';
import studentsRuntimeUrl from './features/students/runtime.js?url';
import sessionsRuntimeUrl from './features/sessions/runtime.js?url';
import settingsRuntimeUrl from './features/settings/runtime.js?url';
import legacyUrl from './legacy/app.js?url';
import startupRuntimeUrl from './core/startup.js?url';
import reportsRuntimeUrl from './features/reports/runtime.js?url';
import { loadClassicScript } from './core/script-loader.js';
import './core/lazy-libs.js';
import { installReportLazyLoading } from './features/reports/lazy.js';
import { installImportLazyLoading } from './features/import/lazy.js';
import { registerHalaqatiPwa } from './core/pwa.js';
const base = import.meta.env.BASE_URL;

async function boot() {
  // Only true boot dependencies are loaded before the legacy runtime.
  await loadClassicScript(`${base}core/supabase-2.min.js`, { id: 'halaqati-core-supabase' });
  // Quran layout metadata is optional; the legacy runtime already has a fallback.
  try { await loadClassicScript(`${base}core/quran-layout.js`, { id: 'halaqati-core-quran-layout' }); } catch (e) { console.warn(e); }

  // Phase 3: load the classic-compatible modules in dependency order. They share the
  // same global lexical environment as the old single file, preserving existing behavior.
  await loadClassicScript(coreRuntimeUrl, { id: 'halaqati-core-runtime' });
  await loadClassicScript(navigationRuntimeUrl, { id: 'halaqati-navigation-runtime' });
  await loadClassicScript(authRuntimeUrl, { id: 'halaqati-auth-runtime' });
  await loadClassicScript(studentsRuntimeUrl, { id: 'halaqati-students-runtime' });
  await loadClassicScript(sessionsRuntimeUrl, { id: 'halaqati-sessions-runtime' });
  await loadClassicScript(settingsRuntimeUrl, { id: 'halaqati-settings-runtime' });
  await loadClassicScript(legacyUrl, { id: 'halaqati-legacy-runtime' });
  // Reports/PDF engine remains isolated and unchanged from the Arabic-safe v2.13.2 path.
  await loadClassicScript(reportsRuntimeUrl, { id: 'halaqati-reports-runtime' });
  // Startup stays last so every function/override is present before auth restoration begins.
  await loadClassicScript(startupRuntimeUrl, { id: 'halaqati-startup-runtime' });
  installReportLazyLoading();
  installImportLazyLoading();
  registerHalaqatiPwa();

  window.dispatchEvent(new CustomEvent('halaqati:ready', { detail: { version: '2.13.9', architecture: 'vite-phase3-offline-sync-recovery-arabic-hq-safe' } }));
}

boot().catch((error) => {
  console.error('Halaqati startup failed', error);
  const box = document.createElement('div');
  box.dir = 'rtl';
  box.style.cssText = 'margin:20px;padding:16px;border:1px solid #e4b8b8;border-radius:14px;background:#fff0f0;color:#8c3333;font-family:Tahoma,Arial,sans-serif';
  box.textContent = 'تعذر تشغيل حلقتي. أعد تحميل الصفحة. التفاصيل: ' + (error?.message || error);
  document.body.prepend(box);
});
