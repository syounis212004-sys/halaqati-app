# حلقتي v2.6.1 — إصلاح تصدير APK

المشكلة:
- HTML كان يطبع PDF بشكل صحيح.
- داخل APK قد لا يتم الوصول إلى custom print plugin من window.Capacitor.Plugins مباشرة.
- ملفات Word القديمة كانت HTML بامتداد .doc وليست DOCX حقيقية.
- عند عدم الوصول إلى Filesystem/Share كان WebView يرجع لتنزيل Blob، وهذا غير موثوق على Android.

الإصلاح:
1. إنشاء native plugin proxy عبر Capacitor.registerPlugin عند الحاجة.
2. PDF داخل APK يستخدم HalaqatiPrint مباشرة ويفتح Android Print Preview.
3. Word أصبح DOCX حقيقي (Office Open XML ZIP)، وليس HTML باسم .doc.
4. Excel يُنشأ كبايتات XLSX فعلية ثم يحوّل Base64 دون تحويلات نصية.
5. الحفظ/المشاركة داخل APK تستخدم Filesystem Cache + Share files[].
6. أسماء الملفات داخل Android أصبحت ASCII لتجنب مشاكل بعض تطبيقات Word/Excel مع URI أو أسماء الملفات العربية.
7. JSZip يُضمّن Offline داخل APK.
8. HTML يحتفظ بنفس وظائف التصدير: DOCX/XLSX تنزيلات حقيقية وPDF عبر نافذة الطباعة.

لا تغيير على Google Login أو Supabase أو بيانات المستخدمين.
