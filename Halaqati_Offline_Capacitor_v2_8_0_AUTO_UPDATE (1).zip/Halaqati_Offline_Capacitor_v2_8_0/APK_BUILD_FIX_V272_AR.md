# حلقتي v2.7.2 — إصلاح فشل بناء APK

سبب الخطأ:
الإصدار السابق كان يستدعي:
PrintDocumentAdapter.LayoutResultCallback
و
PrintDocumentAdapter.WriteResultCallback
مباشرة.

منشئات هذه callbacks ليست public في Android SDK، لذلك Gradle أوقف البناء برسالة:
"cannot be accessed from outside package".

الإصلاح:
- حذف الاعتماد على LayoutResultCallback وWriteResultCallback بالكامل.
- إنشاء PDF باستخدام android.graphics.pdf.PdfDocument (API public).
- تقسيم محتوى WebView إلى صفحات A4.
- التحقق من أن حجم الملف الناتج أكبر من 512 بايت.
- الإبقاء على HTML/PWA وGoogle Login كما في v2.7.1 بدون تغيير.
