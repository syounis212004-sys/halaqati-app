# Backend v2.7
تم نشر Edge Function باسم `halaqati-admin-users` مع JWT verification.
الحذف النهائي للحساب يتم على الخادم باستخدام Supabase Auth Admin، ولا يتم وضع service role key داخل HTML أو APK.
