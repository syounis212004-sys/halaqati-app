# حلقتي v2.7.1 — إصلاح تسجيل Google للويب/PWA

السبب:
Supabase Edge Functions ليست استضافة HTML. عند إرجاع OAuth إلى دالة `halaqati-app`
كان HTML يظهر كنص، لذلك ظهرت الصفحة السوداء والنص المشوّه.

الإصلاح:
- APK بقي يستخدم `com.mohammedsamir.halaqati://auth/callback` بدون تغيير.
- نسخة الويب/PWA تستخدم عنوان الصفحة المنشورة نفسها عبر HTTPS كـ redirectTo.
- منع تسجيل Google من ملف `file://` المحلي لأنه لا يمكن أن يكون OAuth callback آمن.
- بعد نجاح Google على الويب يتم تنظيف token fragment من شريط العنوان.
- أضيفت بيانات PWA/iOS المطلوبة.

مهم:
بعد نشر PWA أضف رابطها في Supabase:
Authentication > URL Configuration > Redirect URLs.
لا تغيّر Google Cloud callback؛ يبقى Supabase `/auth/v1/callback`.
