-- Already applied to the connected Supabase project.
create unique index if not exists halaqa_teachers_one_halaqa_per_teacher on public.halaqa_teachers(teacher_id);

drop policy if exists sessions_delete on public.sessions;
create policy sessions_delete on public.sessions for delete to authenticated
using (is_admin() or is_halaqa_supervisor(halaqa_id) or (is_halaqa_teacher(halaqa_id) and created_by = auth.uid()));
