import fs from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const source = path.join(root, 'source', 'index.html');
const www = path.join(root, 'www');
const vendor = path.join(www, 'vendor');
const fontsDir = path.join(vendor, 'fonts');
await fs.rm(www, {recursive:true, force:true});
await fs.mkdir(fontsDir, {recursive:true});

let html = await fs.readFile(source, 'utf8');

const files = [
  ['https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2', 'supabase.min.js'],
  ['https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js', 'xlsx.full.min.js'],
  ['https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js', 'jszip.min.js'],
  ['https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js', 'html2canvas.min.js'],
  ['https://cdn.jsdelivr.net/npm/jspdf@2.5.2/dist/jspdf.umd.min.js', 'jspdf.umd.min.js'],
  ['https://cdn.jsdelivr.net/npm/mammoth@1.8.0/mammoth.browser.min.js', 'mammoth.browser.min.js'],
  ['https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', 'pdf.min.js'],
  ['https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js', 'pdf.worker.min.js'],
  ['https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js', 'tesseract.min.js']
];

async function download(url, out) {
  const r = await fetch(url, {headers:{'user-agent':'Mozilla/5.0'}});
  if (!r.ok) throw new Error(`Download failed ${r.status}: ${url}`);
  const buf = Buffer.from(await r.arrayBuffer());
  await fs.writeFile(out, buf);
  console.log('saved', path.relative(root, out), buf.length);
}

for (const [url, name] of files) {
  await download(url, path.join(vendor, name));
}

const replacements = new Map([
  ['https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2', './vendor/supabase.min.js'],
  ['https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js', './vendor/xlsx.full.min.js'],
  ['https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js', './vendor/jszip.min.js'],
  ['https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js', './vendor/html2canvas.min.js'],
  ['https://cdn.jsdelivr.net/npm/jspdf@2.5.2/dist/jspdf.umd.min.js', './vendor/jspdf.umd.min.js'],
  ['https://cdn.jsdelivr.net/npm/mammoth@1.8.0/mammoth.browser.min.js', './vendor/mammoth.browser.min.js'],
  ['https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', './vendor/pdf.min.js'],
  ['https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js', './vendor/pdf.worker.min.js'],
  ['https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js', './vendor/tesseract.min.js']
]);
for (const [from,to] of replacements) html = html.split(from).join(to);

// Bundle Cairo font CSS + font files so the UI keeps its Arabic typography offline.
const fontCssUrl = 'https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&display=swap';
try {
  const r = await fetch(fontCssUrl, {headers:{'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36'}});
  if (!r.ok) throw new Error(`font css ${r.status}`);
  let css = await r.text();
  const urls = [...css.matchAll(/url\((https:\/\/[^)]+)\)/g)].map(m=>m[1]);
  const unique = [...new Set(urls)];
  for (let i=0;i<unique.length;i++) {
    const u = unique[i];
    const ext = (new URL(u).pathname.split('.').pop() || 'woff2').split('?')[0];
    const name = `cairo-${i}.${ext}`;
    await download(u, path.join(fontsDir, name));
    css = css.split(u).join(`./fonts/${name}`);
  }
  await fs.writeFile(path.join(vendor,'cairo.css'), css, 'utf8');
  html = html.replace(/<link[^>]+href=["']https:\/\/fonts\.googleapis\.com\/css2\?family=Cairo[^"']*["'][^>]*>/i, '<link rel="stylesheet" href="./vendor/cairo.css">');
  html = html.replace(/<link[^>]+href=["']https:\/\/fonts\.googleapis\.com["'][^>]*>/ig, '');
  html = html.replace(/<link[^>]+href=["']https:\/\/fonts\.gstatic\.com["'][^>]*>/ig, '');
} catch (e) {
  console.warn('Could not bundle Cairo font; system Arabic font will be used offline:', e.message);
  html = html.replace(/<link[^>]+href=["']https:\/\/fonts\.googleapis\.com[^"']*["'][^>]*>/ig, '');
  html = html.replace(/<link[^>]+href=["']https:\/\/fonts\.gstatic\.com[^"']*["'][^>]*>/ig, '');
}

// Copy app icon + local manifest.
await fs.copyFile(path.join(root,'assets','icon-512.png'), path.join(www,'icon-512.png'));
await fs.writeFile(path.join(www,'manifest.webmanifest'), JSON.stringify({
  name:'حلقتي', short_name:'حلقتي', lang:'ar', dir:'rtl', display:'standalone',
  start_url:'./index.html', background_color:'#0d3b2f', theme_color:'#0d3b2f',
  icons:[{src:'./icon-512.png',sizes:'512x512',type:'image/png',purpose:'any maskable'}]
}, null, 2), 'utf8');

await fs.writeFile(path.join(www,'index.html'), html, 'utf8');
console.log('Offline web bundle ready in www/');
