# حلقتي 2.8.0 — نظام تحديث APK من داخل التطبيق

## كيف يعمل
- التطبيق يفحص: https://syounis212004-sys.github.io/halaqati-web/version.json
- إذا versionCode في version.json أكبر من النسخة المثبتة، يظهر تحديث جديد.
- زر تنزيل وتثبيت ينزّل: https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk
- قبل التثبيت يتم التحقق من اسم الحزمة ورقم الإصدار وتوقيع APK.
- Android يطلب موافقة المستخدم النهائية على التثبيت؛ لا يوجد تثبيت صامت لتطبيق عادي.

## مهم جداً: التوقيع الثابت
كل APK مستقبلي يجب أن يُوقّع بنفس keystore. Workflow الجديد يبني Release APK موقّعاً من GitHub Secrets.
لا تضع ملف keystore أو كلمات مروره داخل المستودع.

## ملفات التحديث التي يعطيها GitHub Actions
Artifact باسم Halaqati-v2.8.0-publish-update يحتوي:
- Halaqati-latest.apk
- version.json
ارفع الملفين إلى جذر مستودع halaqati-web العام.

## الانتقال من نسخ Debug القديمة
نسخ GitHub Actions القديمة كانت Debug وقد تكون موقعة بمفتاح مختلف في كل تشغيل. لذلك أول تثبيت للنسخة المستقرة الموقعة 2.8.0 قد يحتاج حذف APK القديم بعد التأكد من مزامنة أي بيانات Offline. بعد تثبيت 2.8.0 الموقعة، التحديثات اللاحقة تعمل فوقها بدون حذف البيانات، بشرط الحفاظ على نفس keystore.
