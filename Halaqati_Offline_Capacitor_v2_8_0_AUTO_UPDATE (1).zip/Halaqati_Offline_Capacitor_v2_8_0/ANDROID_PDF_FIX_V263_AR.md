# حلقتي v2.6.3 — إصلاح PDF داخل APK

سبب المشكلة: WebView الخاص بالطباعة كان منفصلاً عن واجهة Android، وعلى بعض الأجهزة لا يصل إلى حالة الرسم النهائي، لذلك تبقى رسالة جاري تجهيز PDF ولا يصل الكود إلى PrintManager.print().

الإصلاح: ربط WebView مؤقتاً بالـActivity خارج الشاشة، إعطاؤه layout حقيقياً، الانتظار حتى onPageFinished وVisualStateCallback، ثم فتح Android Print Framework وإبقاء WebView حياً أثناء عملية الطباعة.
