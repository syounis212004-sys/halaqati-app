package com.mohammedsamir.halaqati.print;

import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "HalaqatiPrint")
public class HalaqatiPrintPlugin extends Plugin {

    private WebView activePrintView;
    private FrameLayout printHost;

    private void cleanupPrintView() {
        getActivity().runOnUiThread(() -> {
            try {
                if (activePrintView != null) {
                    ViewGroup parent = (ViewGroup) activePrintView.getParent();
                    if (parent != null) parent.removeView(activePrintView);
                    activePrintView.stopLoading();
                    activePrintView.destroy();
                }
            } catch (Exception ignored) {}
            activePrintView = null;

            try {
                if (printHost != null) {
                    ViewGroup parent = (ViewGroup) printHost.getParent();
                    if (parent != null) parent.removeView(printHost);
                }
            } catch (Exception ignored) {}
            printHost = null;
        });
    }

    private void prepareWebView(String html, ReadyCallback callback) {
        cleanupPrintView();

        getActivity().runOnUiThread(() -> {
            try {
                FrameLayout decor = (FrameLayout) getActivity()
                    .getWindow()
                    .getDecorView()
                    .findViewById(android.R.id.content);

                printHost = new FrameLayout(getActivity());
                printHost.setBackgroundColor(Color.TRANSPARENT);
                printHost.setAlpha(0.01f);
                printHost.setTranslationX(-6000f);

                // Fixed rendering width gives predictable A4 pagination.
                FrameLayout.LayoutParams hostParams =
                    new FrameLayout.LayoutParams(1400, 2000);
                decor.addView(printHost, hostParams);

                activePrintView = new WebView(getActivity());
                activePrintView.setBackgroundColor(Color.WHITE);
                activePrintView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);

                printHost.addView(
                    activePrintView,
                    new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                );

                WebSettings settings = activePrintView.getSettings();
                settings.setJavaScriptEnabled(false);
                settings.setLoadsImagesAutomatically(true);
                settings.setBlockNetworkImage(false);
                settings.setBlockNetworkLoads(false);
                settings.setDefaultTextEncodingName("UTF-8");
                settings.setUseWideViewPort(true);
                settings.setLoadWithOverviewMode(false);
                settings.setSupportZoom(false);

                activePrintView.setWebViewClient(new WebViewClient() {
                    private boolean ready = false;

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        if (ready) return;
                        ready = true;

                        Runnable signal = () ->
                            view.postDelayed(() -> callback.onReady(view), 1600);

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            view.postVisualStateCallback(
                                707L,
                                new WebView.VisualStateCallback() {
                                    @Override
                                    public void onComplete(long requestId) {
                                        signal.run();
                                    }
                                }
                            );
                        } else {
                            signal.run();
                        }
                    }
                });

                activePrintView.loadDataWithBaseURL(
                    "https://appassets.androidplatform.net/",
                    html,
                    "text/html",
                    "UTF-8",
                    null
                );

            } catch (Exception e) {
                callback.onError(e);
            }
        });
    }

    @PluginMethod
    public void createPdf(PluginCall call) {
        final String html = call.getString("html", "");
        final String jobName = call.getString("jobName", "Halaqati Report");
        final String orientation = call.getString("orientation", "portrait");

        if (html == null || html.trim().isEmpty()) {
            call.reject("Empty report HTML");
            return;
        }

        final AtomicBoolean terminal = new AtomicBoolean(false);
        final Handler handler = new Handler(Looper.getMainLooper());

        // Safety timeout for very large reports.
        handler.postDelayed(() -> {
            if (terminal.compareAndSet(false, true)) {
                cleanupPrintView();
                call.reject("PDF generation timed out");
            }
        }, 180000);

        prepareWebView(html, new ReadyCallback() {
            @Override
            public void onReady(WebView view) {
                getActivity().runOnUiThread(() -> {
                    PdfDocument document = null;
                    FileOutputStream output = null;

                    try {
                        int pageWidth;
                        int pageHeight;

                        // A4 at 72 points/inch.
                        if ("landscape".equalsIgnoreCase(orientation)) {
                            pageWidth = 842;
                            pageHeight = 595;
                        } else {
                            pageWidth = 595;
                            pageHeight = 842;
                        }

                        int viewWidth = Math.max(1, view.getWidth());
                        float webScale = view.getScale();
                        if (webScale <= 0f) webScale = 1f;

                        int contentHeight = Math.max(
                            view.getHeight(),
                            Math.round(view.getContentHeight() * webScale)
                        );

                        float drawScale = (float) pageWidth / (float) viewWidth;
                        int sourcePageHeight = Math.max(
                            1,
                            (int) Math.floor(pageHeight / drawScale)
                        );

                        int pageCount = Math.max(
                            1,
                            (int) Math.ceil((double) contentHeight / sourcePageHeight)
                        );

                        // Prevent runaway documents caused by a broken layout.
                        if (pageCount > 250) {
                            throw new IOException("Report is too long to export safely");
                        }

                        document = new PdfDocument();

                        int originalScrollY = view.getScrollY();

                        for (int i = 0; i < pageCount; i++) {
                            int y = i * sourcePageHeight;
                            view.scrollTo(0, y);
                            view.invalidate();

                            PdfDocument.PageInfo pageInfo =
                                new PdfDocument.PageInfo.Builder(
                                    pageWidth,
                                    pageHeight,
                                    i + 1
                                ).create();

                            PdfDocument.Page page = document.startPage(pageInfo);

                            page.getCanvas().drawColor(Color.WHITE);
                            page.getCanvas().save();
                            page.getCanvas().scale(drawScale, drawScale);

                            // WebView.draw() renders the currently scrolled viewport.
                            view.draw(page.getCanvas());

                            page.getCanvas().restore();
                            document.finishPage(page);
                        }

                        view.scrollTo(0, originalScrollY);

                        File dir = new File(
                            getActivity().getCacheDir(),
                            "halaqati_exports"
                        );

                        if (!dir.exists() && !dir.mkdirs()) {
                            throw new IOException(
                                "Could not create export directory"
                            );
                        }

                        String safe =
                            "Halaqati_Report_" +
                            System.currentTimeMillis() +
                            ".pdf";

                        File out = new File(dir, safe);
                        output = new FileOutputStream(out);
                        document.writeTo(output);
                        output.flush();
                        output.close();
                        output = null;

                        document.close();
                        document = null;

                        long size = out.length();

                        if (size <= 512) {
                            throw new IOException(
                                "Generated PDF is empty or incomplete"
                            );
                        }

                        if (terminal.compareAndSet(false, true)) {
                            JSObject result = new JSObject();
                            result.put("uri", Uri.fromFile(out).toString());
                            result.put("size", size);
                            result.put("name", safe);
                            result.put("pages", pageCount);

                            call.resolve(result);

                            view.postDelayed(
                                () -> cleanupPrintView(),
                                1500
                            );
                        }

                    } catch (Exception e) {
                        try {
                            if (output != null) output.close();
                        } catch (Exception ignored) {}

                        try {
                            if (document != null) document.close();
                        } catch (Exception ignored) {}

                        if (terminal.compareAndSet(false, true)) {
                            cleanupPrintView();
                            call.reject(
                                "PDF generation failed: " +
                                e.getMessage(),
                                e
                            );
                        }
                    }
                });
            }

            @Override
            public void onError(Exception e) {
                if (terminal.compareAndSet(false, true)) {
                    cleanupPrintView();
                    call.reject(
                        "PDF WebView failed: " +
                        e.getMessage(),
                        e
                    );
                }
            }
        });
    }

    @PluginMethod
    public void printHtml(PluginCall call) {
        createPdf(call);
    }

    private interface ReadyCallback {
        void onReady(WebView view);
        void onError(Exception e);
    }

    @Override
    protected void handleOnDestroy() {
        cleanupPrintView();
    }
}
