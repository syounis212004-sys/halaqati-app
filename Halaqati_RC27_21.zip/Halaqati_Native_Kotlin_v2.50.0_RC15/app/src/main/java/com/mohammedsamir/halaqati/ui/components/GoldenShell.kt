package com.mohammedsamir.halaqati.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.R
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.ui.navigation.AppDestination
import com.mohammedsamir.halaqati.ui.navigation.RoleNavigationPolicy

private val GoldenGreen = Color(0xFF0A4A3F)
private val GoldenGreen2 = Color(com.mohammedsamir.halaqati.ui.theme.HalaqatiPalette.DEFAULT_PRIMARY)
private val GoldenGreen3 = Color(com.mohammedsamir.halaqati.ui.theme.HalaqatiPalette.DEFAULT_ACCENT)
private val GoldenMint = Color(0xFFE1F0EA)
private val GoldenLine = Color(0xFFD9E4DD)
private val GoldenMuted = Color(0xFF42564D)


data class GoldenShellActions(
    val roleLabel: String,
    val online: Boolean,
    val pending: Int,
    val openDrawer: () -> Unit,
    val openNotifications: () -> Unit,
    val openSyncCenter: () -> Unit,
)

val LocalGoldenShellActions = staticCompositionLocalOf<GoldenShellActions?> { null }

@DrawableRes
private fun goldenIconRes(key: String): Int = when (key) {
    "home" -> R.drawable.ic_gm_home
    "notifications" -> R.drawable.ic_gm_notifications
    "group", "halaqas" -> R.drawable.ic_gm_halaqas
    "forum", "community" -> R.drawable.ic_gm_community
    "event", "sessions" -> R.drawable.ic_gm_sessions
    "person", "students" -> R.drawable.ic_gm_students
    "timeline", "plans" -> R.drawable.ic_gm_plans
    "award", "certificates" -> R.drawable.ic_gm_certificates
    "report", "reports" -> R.drawable.ic_gm_reports
    "book", "quran" -> R.drawable.ic_gm_quran
    "leaderboard", "ranking", "rankings" -> R.drawable.ic_gm_ranking
    "competition" -> R.drawable.ic_gm_competition
    "importexport", "data" -> R.drawable.ic_gm_data
    "supervisor", "supervision" -> R.drawable.ic_gm_supervision
    "users" -> R.drawable.ic_gm_users
    "profile" -> R.drawable.ic_gm_profile
    "settings" -> R.drawable.ic_gm_settings
    "more" -> R.drawable.ic_gm_more
    else -> R.drawable.ic_gm_more
}

@Composable
fun GoldenNavIcon(
    key: String,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    Icon(
        painter = painterResource(goldenIconRes(key)),
        contentDescription = contentDescription,
        modifier = modifier,
        tint = tint,
    )
}

@Composable
fun GoldenBottomBar(
    role: UserRole,
    currentRoute: String,
    drawerOpen: Boolean,
    onNavigate: (AppDestination) -> Unit,
    onMore: () -> Unit,
    mode: com.mohammedsamir.halaqati.plans.WorkMode = com.mohammedsamir.halaqati.plans.WorkMode.REGULAR,
) {
    val items = RoleNavigationPolicy.bottom(role, mode)
    val coreRoutes = items.filterNot { it == AppDestination.More }.map { it.route }.toSet()
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = .98f),
        tonalElevation = 0.dp,
        shadowElevation = 0.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                // RC17: system inset is added OUTSIDE the bar height, so labels are never clipped
                // on gesture or 3-button navigation.
                .navigationBarsPadding()
                .height(68.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEach { destination ->
                val isMore = destination == AppDestination.More
                val selected = if (isMore) {
                    drawerOpen || currentRoute !in coreRoutes
                } else {
                    currentRoute == destination.route ||
                        (currentRoute == AppDestination.SessionToday.route && destination == AppDestination.Sessions)
                }
                val tint by animateColorAsState(
                    targetValue = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    animationSpec = tween(com.mohammedsamir.halaqati.ui.theme.motionMillis(180)),
                    label = "bottom-nav-tint",
                )
                val selectedBackground by animateColorAsState(
                    targetValue = if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
                    animationSpec = tween(com.mohammedsamir.halaqati.ui.theme.motionMillis(180)),
                    label = "bottom-nav-background",
                )
                val iconSize by animateDpAsState(
                    targetValue = if (selected) 24.dp else 22.dp,
                    animationSpec = if (com.mohammedsamir.halaqati.ui.theme.LocalReducedMotion.current) tween(0)
                    else spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
                    label = "bottom-nav-icon",
                )
                Box(
                    modifier = Modifier.weight(1f).fillMaxHeight().padding(horizontal = 4.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(17.dp))
                            .background(selectedBackground)
                            .clickable { if (isMore) onMore() else onNavigate(destination) }
                            .heightIn(min = 56.dp)
                            .padding(horizontal = 6.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                                                GoldenNavIcon(
                            key = destination.iconKey,
                            contentDescription = destination.label,
                            tint = tint,
                            modifier = Modifier.size(iconSize),
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            destination.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = tint,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

/** RC27.17: the drawer groups its pages under four small headings instead of one long flat list. */
private fun drawerGroupOf(destination: AppDestination): Int = when (destination) {
    AppDestination.Home, AppDestination.Sessions, AppDestination.SessionToday, AppDestination.Students,
    AppDestination.Plans, AppDestination.Halaqas -> 0
    AppDestination.Rankings, AppDestination.GuardianCompetition, AppDestination.GuardianAchievements,
    AppDestination.Certificates, AppDestination.Reports, AppDestination.Supervision, AppDestination.GuardianProfile -> 1
    AppDestination.Community, AppDestination.Quran, AppDestination.ImportExport -> 2
    else -> 3
}

private val DRAWER_GROUP_TITLES = listOf("الأساسي", "المتابعة والإنجاز", "التواصل والأدوات", "الإدارة")
private val DrawerGold = Color(0xFFEBC66F)

@Composable
fun GoldenDrawerContent(
    profile: Profile,
    currentRoute: String,
    onNavigate: (AppDestination) -> Unit,
    onClose: () -> Unit,
    onLogout: () -> Unit,
) {
    val drawerMode by com.mohammedsamir.halaqati.data.WorkModeHolder.state.collectAsState()
    val drawerEntries = remember(profile.role, drawerMode.mode) { RoleNavigationPolicy.drawerItems(profile.role, drawerMode.mode) }
    val chrome = LocalGoldenShellActions.current
    // Notifications, sync and settings move to the quick tiles; everything else is grouped under headings.
    val quickDestinations = listOf(AppDestination.Notifications, AppDestination.SyncCenter, AppDestination.Settings)
        .filter { RoleNavigationPolicy.canOpen(profile.role, it) }
    val grouped = remember(drawerEntries) {
        drawerEntries.filterNot { it.destination in setOf(AppDestination.Notifications, AppDestination.SyncCenter, AppDestination.Settings) }
            .groupBy { drawerGroupOf(it.destination) }
            .toSortedMap()
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface),
    ) {
        // ---- Header: the primary band of the app, with the slow Eastern pattern and the art of the account type.
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
        ) {
            Box(Modifier.fillMaxWidth()) {
                HalaqatiAmbient(
                    modifier = Modifier.align(Alignment.BottomStart).offset(x = (-60).dp, y = 60.dp).size(200.dp),
                    onBand = true,
                    strength = 0.16f,
                )
                Column(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(start = 18.dp, end = 12.dp, top = 12.dp, bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "حلقتي",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .9f),
                            modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = onClose, modifier = Modifier.size(44.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق القائمة", tint = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Box(
                            Modifier
                                .size(76.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = .13f)),
                            contentAlignment = Alignment.Center,
                        ) {
                            HalaqatiRoleArt(profile.role, size = 68.dp, onBand = true)
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                profile.fullName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = .16f))
                                    .padding(horizontal = 10.dp, vertical = 3.dp),
                            ) {
                                Text(
                                    roleTitle(profile.role),
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Box(
                                    Modifier
                                        .size(8.dp)
                                        .clip(androidx.compose.foundation.shape.CircleShape)
                                        .background(if (chrome?.online != false) Color(0xFF7BE0A4) else DrawerGold),
                                )
                                Text(
                                    if (chrome?.online != false) "الحساب متصل" else "دون اتصال — العمل محفوظ محليًا",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .85f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
                // A thin gold line along the bottom edge of the band, like the gold of the logo.
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 18.dp)
                        .width(64.dp)
                        .height(3.dp)
                        .clip(RoundedCornerShape(50))
                        .background(DrawerGold),
                )
            }
        }

        // The body owns the scroll. The footer stays reachable at all times, fixing the
        // clipped/non-scrollable drawer regression in the first native migration.
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            if (quickDestinations.isNotEmpty()) item(key = "quick-tiles") {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    quickDestinations.forEach { destination ->
                        val badge = when (destination) {
                            AppDestination.Notifications -> if ((chrome?.pending ?: 0) > 0) chrome!!.pending else 0
                            AppDestination.SyncCenter -> chrome?.pending ?: 0
                            else -> 0
                        }
                        val label = when (destination) {
                            AppDestination.Notifications -> "الإشعارات"
                            AppDestination.SyncCenter -> if (chrome?.online == false) "دون اتصال" else "المزامنة"
                            else -> "الإعدادات"
                        }
                        val active = currentRoute == destination.route
                        Surface(
                            modifier = Modifier.weight(1f).halaqatiPressable { onNavigate(destination) },
                            shape = RoundedCornerShape(18.dp),
                            color = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        ) {
                            Column(
                                Modifier.fillMaxWidth().padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                BadgedBox(badge = { if (badge > 0) Badge { Text(badge.coerceAtMost(99).toString()) } }) {
                                    when (destination) {
                                        AppDestination.SyncCenter -> Icon(
                                            if (chrome?.online == false) Icons.Default.CloudOff
                                            else Icons.Default.Sync,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(24.dp).halaqatiSpin(chrome?.online != false && (chrome?.pending ?: 0) > 0),
                                        )
                                        else -> GoldenNavIcon(
                                            destination.iconKey,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(24.dp),
                                        )
                                    }
                                }
                                Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            grouped.forEach { (group, entries) ->
                item(key = "title-$group") {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Box(Modifier.size(6.dp).clip(androidx.compose.foundation.shape.CircleShape).background(MaterialTheme.colorScheme.tertiary))
                        Text(
                            DRAWER_GROUP_TITLES[group],
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.SemiBold,
                        )
                        HorizontalDivider(Modifier.weight(1f), color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }
                items(entries, key = { it.destination.route }) { item ->
                    val active = currentRoute == item.destination.route ||
                        (currentRoute == AppDestination.SessionToday.route && item.destination == AppDestination.Sessions)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (active) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            .halaqatiPressable { onNavigate(item.destination) }
                            .heightIn(min = 52.dp)
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center,
                        ) {
                            GoldenNavIcon(
                                item.destination.iconKey,
                                contentDescription = null,
                                tint = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                        Text(
                            item.label,
                            color = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (active) Box(
                            Modifier
                                .size(width = 4.dp, height = 22.dp)
                                .clip(RoundedCornerShape(50))
                                .background(MaterialTheme.colorScheme.tertiary),
                        )
                    }
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            TextButton(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("تسجيل الخروج", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Text("صُنع بأيدٍ شرقية", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
            Text("الشرقية — خانيونس", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
            Text(
                "Designed by : Dr. Mohammed Samir Abu Younis",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

fun roleTitle(role: UserRole): String = when (role) {
    UserRole.ADMIN -> "مسؤول النظام والحلقات"
    UserRole.SUPERVISOR -> "مشرف الحلقات"
    UserRole.TEACHER -> "محفّظ الحلقة"
    UserRole.GUARDIAN -> "ولي الأمر"
    else -> "المستخدم"
}
