from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.57.0',
    'versionCode':25700,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    'notes':[
        'إعادة تصميم القائمة الجانبية لتتبع هوية التطبيق وإزالة تداخل زر الإغلاق والزخرفة القديمة.',
        'اختيار يوم/شهر/فترة في التقارير عبر نوافذ تاريخ حقيقية بدل حقول التاريخ اليدوية.',
        'إصلاح تخطيط تقارير A4 لكل طالب: الأسماء الطويلة أفقية ومعلومات الطالب أوضح في الوضع الأفقي.',
        'محرك خطوط فعلي ومتسق للتقارير والشهادات مع تطبيق حجم الخط على كامل المستند.',
        'إصلاح جلسات تعدد الحلقات ومنع الطلاب غير المرتبطين بحلقة من الظهور في جلسات أخرى.',
        'تحويل الفلاتر والإجراءات المخفية أفقيًا إلى شبكات متجاوبة وقوائم اختيار قابلة للبحث.',
        'إدارة الحلقات أصبحت تعتمد الأرشفة والاستعادة افتراضيًا مع إبقاء الحذف النهائي ضمن الخيارات المتقدمة.',
        'الحفاظ على إصلاحات RC19 وRC19.1 لعزل خطط وتسميعات كل شهر عن الشهر السابق.'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
