from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.10',
    'versionCode':28910,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "غرفة العمليات بتصميم جديد: صورة المحفّظ كبيرة مع اسمه ولون حالة الجلسة وزخرفة، وإحصاءات الحضور والغياب بأيقونات.",
        "المتابعة والمقارنة: مربعات ثابتة تظهر كلها فورًا (غياب متكرر، لم يسمّعوا، بلا ولي أمر، حلقات بلا جلسة، حلقات بلا محفّظ، بلا خطة) والتفاصيل في ورقة سفلية.",
        "الخطط الذكية: البطاقة المغلقة تعرض اسم الطالب وإنجازه ومقرر اليوم فقط، وشريط بحث واحد مع أيقونة تصفية وأيقونة إدارة، وفلتر الحلقة والحالة داخل ورقة التصفية.",
        "يشمل كل ما في الإصدارات السابقة: الثبات وألوان أقوى ومحادثات المانحين.",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
