from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.52.0',
    'versionCode':25200,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    'notes':[
        'استعادة تصميم الشهادات وهويتها البصرية القريبة من v2.44.',
        'إرجاع القوالب والخطوط والألوان والشعارات والتوقيعات والختم مع معاينة A4 محسنة.',
        'إعادة تصميم واجهة التحديثات مع نسبة تنزيل وتثبيت مباشر بعد الاكتمال.',
        'Supabase يحتفظ ببيانات الأرشيف والأرقام فقط؛ ملفات PDF والصور تبقى محلية.'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
