package com.mohammedsamir.halaqati.ui.components

import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

/**
 * RC27.10: a person's name always sits on ONE line. The text shrinks step by step until it fits the width it is given
 * (never below [minSp]); only an extremely long name is cut with an ellipsis. Never wraps to a second line.
 * [maxLines] and [overflow] are accepted only so it can replace Text(...) calls without other edits.
 */
@Composable
fun OneLineName(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    fontWeight: FontWeight? = null,
    color: Color = Color.Unspecified,
    textAlign: TextAlign? = null,
    minSp: Float = 11f,
    @Suppress("UNUSED_PARAMETER") maxLines: Int = 1,
    @Suppress("UNUSED_PARAMETER") overflow: TextOverflow = TextOverflow.Ellipsis,
) {
    val baseSize: TextUnit = if (style.fontSize == TextUnit.Unspecified) 16.sp else style.fontSize
    var scale by remember(text, baseSize) { mutableFloatStateOf(1f) }
    val minScale = (minSp / baseSize.value).coerceIn(0.5f, 1f)
    Text(
        text = text,
        modifier = modifier,
        style = style.copy(fontSize = baseSize * scale),
        fontWeight = fontWeight,
        color = color,
        textAlign = textAlign,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Ellipsis,
        onTextLayout = { result ->
            if (result.hasVisualOverflow && scale > minScale) scale = (scale * 0.92f).coerceAtLeast(minScale)
        },
    )
}
