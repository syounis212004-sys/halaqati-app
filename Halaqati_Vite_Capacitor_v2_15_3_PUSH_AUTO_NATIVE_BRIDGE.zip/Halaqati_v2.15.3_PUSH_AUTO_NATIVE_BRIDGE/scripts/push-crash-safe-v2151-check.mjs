import fs from 'node:fs';
function need(cond,msg){if(!cond){console.error('PUSH_CRASH_SAFE_CHECK_FAIL:',msg);process.exit(1)}}
const bridge=fs.readFileSync('src/features/notifications/push-bridge.js','utf8');
const runtime=fs.readFileSync('src/features/notifications/runtime.js','utf8');
const main=fs.readFileSync('src/main.js','utf8');
need(!/^\s*import\s+\{\s*PushNotifications\s*\}\s+from\s+['\"]@capacitor\/push-notifications['\"]/m.test(bridge),'PushNotifications must not be statically imported at startup');
need(bridge.includes("import('@capacitor/push-notifications')"),'Push plugin must be lazy-loaded');
need(bridge.includes('VITE_HALAQATI_FIREBASE_CONFIGURED'),'build-time Firebase guard is missing');
need(runtime.includes('function pushBuildConfigured()'),'runtime Firebase guard is missing');
need(runtime.includes("permission:'unconfigured'"),'unconfigured safe state is missing');
need(runtime.includes("if(perm.receive==='prompt'||perm.receive==='prompt-with-rationale')perm=await withPushTimeout(p.requestPermissions()"),'automatic permission request must remain timeout-contained');
need(runtime.includes('enablePushNotifications(false).catch'),'background Push initialization must be error-contained');
need(main.includes("version: '2.15.3'"),'main version is not v2.15.3');
console.log('PUSH_CRASH_SAFE_CHECK_PASS');
