import fs from 'node:fs';
import vm from 'node:vm';
const code=fs.readFileSync('src/features/notifications/runtime.js','utf8');
const calls=[];
const toasts=[];
const never=new Promise(()=>{});
const pushPlugin={
  checkPermissions: async()=>({receive:'granted'}),
  requestPermissions: async()=>({receive:'granted'}),
  addListener: async()=>({remove(){}}),
  createChannel: async()=>({}),
  register: ()=>never,
};
const nativeBridge={
  diagnostics: async()=>({ok:true,projectId:'halaqti-test',applicationId:'1:test:android',autoInitEnabled:true}),
  getToken: async()=>({token:'FAKE_FCM_TOKEN_1234567890'}),
};
const ctx={
  console,
  setTimeout,clearTimeout,setInterval,clearInterval,
  Promise,Date,Math,JSON,String,Number,Array,Set,Map,Object,
  navigator:{onLine:true},
  document:{visibilityState:'visible'},
  window:{
    HalaqatiPushConfigured:true,
    HalaqatiPushNotifications:pushPlugin,
    HalaqatiPushLoadError:'',
    Capacitor:{getPlatform:()=> 'android',Plugins:{HalaqatiPushBridge:nativeBridge}},
    addEventListener(){},
  },
  state:{
    user:{id:'user-1'},profile:{role:'admin'},page:'home',pushState:{},
    notificationPreferences:{push_enabled:true},students:[],notifications:[],notificationUnread:0,
  },
  APP_VERSION_NAME:'2.15.3',
  isNativeHalaqati:()=>true,
  ensureServerAuthSession:async()=>true,
  db:{
    functions:{invoke:async(_name,{body})=>{calls.push(body);if(body.action==='register_device')return {data:{ok:true,device:{id:'dev-1'}},error:null};if(body.action==='test_push')return {data:{ok:true,push_configured:true,push_sent:1},error:null};return {data:{ok:true},error:null}}},
    from:()=>({select(){return this},eq(){return this},neq(){return this},order(){return this},limit:async()=>({data:[],error:null}),maybeSingle:async()=>({data:null,error:null}),upsert:async()=>({error:null}),update(){return this},is:async()=>({error:null})}),
  },
  toast:(m)=>toasts.push(String(m)),
  render(){},
  $:()=>null,
  esc:s=>String(s??''),
  fmt:s=>String(s??''),
  go(){},studentProfile(){},cacheSnapshot(){},
  attAr:{},behAr:{},
};
ctx.globalThis=ctx;
vm.createContext(ctx);
vm.runInContext(code,ctx,{filename:'notifications-runtime.js'});
const ok=await ctx.enablePushNotifications(true);
if(!ok)throw new Error('automatic native bridge activation returned false');
if(!ctx.state.pushState?.registered)throw new Error('device was not marked registered');
if(ctx.state.pushState?.tokenLast4!=='7890')throw new Error('token state was not persisted');
if(!calls.some(x=>x.action==='register_device'&&x.push_token==='FAKE_FCM_TOKEN_1234567890'))throw new Error('server register_device was not called with direct token');
// Critical regression: PushNotifications.register() never resolves in this test, yet activation above must finish.
await ctx.sendTestPush();
if(!calls.some(x=>x.action==='test_push'))throw new Error('test push was not sent after automatic activation');
console.log('PUSH_AUTO_V2153_VM_PASS');
