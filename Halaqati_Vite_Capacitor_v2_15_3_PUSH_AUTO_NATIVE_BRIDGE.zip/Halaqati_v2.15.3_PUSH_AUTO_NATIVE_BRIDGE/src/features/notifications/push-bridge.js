/* Halaqati v2.15.3 — crash-safe lazy PushNotifications bridge.
   IMPORTANT: never import/initialize the native PushNotifications plugin unless
   this APK was actually built with a validated google-services.json. */
const firebaseConfigured = String(import.meta.env.VITE_HALAQATI_FIREBASE_CONFIGURED || 'false').toLowerCase() === 'true';
let loadPromise = null;

window.HalaqatiPushConfigured = firebaseConfigured;
window.HalaqatiPushNotifications = null;
window.HalaqatiPushLoadError = '';

window.loadHalaqatiPushPlugin = async function loadHalaqatiPushPlugin(){
  if(!firebaseConfigured) return null;
  if(window.HalaqatiPushNotifications) return window.HalaqatiPushNotifications;
  if(loadPromise) return loadPromise;
  loadPromise = import('@capacitor/push-notifications')
    .then(mod => {
      const plugin = mod?.PushNotifications || null;
      window.HalaqatiPushNotifications = plugin;
      return plugin;
    })
    .catch(err => {
      window.HalaqatiPushLoadError = String(err?.message || err || 'Push plugin load failed');
      console.warn('PushNotifications lazy load failed', err);
      loadPromise = null;
      return null;
    });
  return loadPromise;
};
