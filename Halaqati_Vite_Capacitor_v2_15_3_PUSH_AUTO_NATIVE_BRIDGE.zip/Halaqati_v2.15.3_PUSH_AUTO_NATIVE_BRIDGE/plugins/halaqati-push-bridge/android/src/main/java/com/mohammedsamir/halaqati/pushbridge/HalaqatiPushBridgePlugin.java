package com.mohammedsamir.halaqati.pushbridge;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;

@CapacitorPlugin(name = "HalaqatiPushBridge")
public class HalaqatiPushBridgePlugin extends Plugin {

    private FirebaseApp ensureFirebase() {
        try {
            return FirebaseApp.getInstance();
        } catch (IllegalStateException ignored) {
            FirebaseApp initialized = FirebaseApp.initializeApp(getContext());
            if (initialized == null) {
                throw new IllegalStateException("FirebaseApp initialization returned null. Check google-services.json.");
            }
            return initialized;
        }
    }

    @PluginMethod
    public void diagnostics(PluginCall call) {
        try {
            FirebaseApp app = ensureFirebase();
            FirebaseOptions options = app.getOptions();
            JSObject out = new JSObject();
            out.put("ok", true);
            out.put("packageName", getContext().getPackageName());
            out.put("projectId", options.getProjectId());
            out.put("applicationId", options.getApplicationId());
            out.put("senderId", options.getGcmSenderId());
            out.put("autoInitEnabled", FirebaseMessaging.getInstance().isAutoInitEnabled());
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Firebase diagnostics failed: " + String.valueOf(e.getMessage()), e);
        }
    }

    @PluginMethod
    public void getToken(PluginCall call) {
        try {
            ensureFirebase();
            FirebaseMessaging messaging = FirebaseMessaging.getInstance();
            messaging.setAutoInitEnabled(true);
            messaging.getToken().addOnCompleteListener(task -> {
                if (!task.isSuccessful()) {
                    Exception ex = task.getException();
                    call.reject("FCM token failed: " + (ex != null ? ex.getMessage() : "unknown error"), ex);
                    return;
                }
                String token = task.getResult();
                if (token == null || token.trim().isEmpty()) {
                    call.reject("FCM returned an empty token");
                    return;
                }
                JSObject out = new JSObject();
                out.put("token", token);
                out.put("last4", token.length() > 4 ? token.substring(token.length() - 4) : token);
                call.resolve(out);
            });
        } catch (Exception e) {
            call.reject("FCM token bridge failed: " + String.valueOf(e.getMessage()), e);
        }
    }
}
