from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.15',
    'versionCode':28915,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "هوية «نجمة الربع» والنقش الهندسي الإسلامي: نجمة تمتلئ بنسبة حقيقية، وشريط زخرفي دقيق من النجوم الثمانية أسفل كل شريط علوي، ونقش خفيف على بطاقات الترحيب والعناوين وشاشة الدخول وبطاقة ولي الأمر.",
        "الرئيسية: بطاقة «التسميع اليوم» بالنجمة، واختصارات موحّدة اللون (دوائر زمردية بأيقونات بيضاء) تظهر حسب صلاحية الدور وفيها الاختبارات والشهادات والمتابعة والفريق.",
        "الطالب: نجمة بنسبة الخطة بدل شريط التقدم، وإخفاء شارة «نشط» لتقليل التكرار.",
        "الإشعارات: أيقونة حسب النوع داخل دائرة صلبة، زمردية لغير المقروء.",
        "الآيات والأحاديث بخط النسخ.",
        "الاختبارات: النجمة بدل الدائرة.",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
