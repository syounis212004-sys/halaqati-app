import fs from 'node:fs';
import assert from 'node:assert/strict';
const read=p=>fs.readFileSync(p,'utf8');
const pkg=JSON.parse(read('package.json'));
const core=read('src/core/runtime.js');
const reports=read('src/features/reports/runtime.js');
assert.equal(pkg.version,'2.40.1');
assert.ok(core.includes("APP_VERSION_NAME='2.40.1'")&&core.includes('APP_VERSION_CODE=24001'));
assert.ok(reports.includes("#reportPreviewPaper .pro-table-wrap{width:100%!important;min-width:0!important;max-width:100%!important"),'PDF table wrapper must stay inside page width');
assert.ok(reports.includes('table-layout:fixed!important'),'PDF tables must use fixed layout for deterministic A4 containment');
assert.ok(!reports.includes('.pro-table-wrap{width:max-content!important'),'max-content table wrapper must not return');
assert.ok(reports.includes("colgroup.dataset.hfAutofit='1'")&&reports.includes('pdfColumnWeights(table,head,kinds)'),'dynamic PDF colgroup auto-fit is required');
assert.ok(reports.includes("cell.style.whiteSpace='nowrap'")&&reports.includes('shrinkPdfNameCells(table)'),'student names must remain single-line with safe shrink-to-fit');
assert.ok(reports.includes('width:renderWidth,height:Math.max(1,element.scrollHeight)'),'html2canvas must capture explicit fitted page bounds');
assert.ok(reports.includes("const PDF_PNG_COMPRESSION='NONE'"),'HQ report PDF must not use FAST image compression');
assert.ok(reports.includes("toDataURL('image/png')")&&reports.includes("addImage(canvas.toDataURL('image/png'),'PNG'"),'report PDF must remain lossless PNG');
for(const file of [
  'plugins/halaqati-updater/android/src/main/java/com/mohammedsamir/halaqati/updater/HalaqatiUpdaterPlugin.java',
  'plugins/halaqati-updater/android/src/main/java/com/mohammedsamir/halaqati/updater/HalaqatiUpdateFileProvider.java',
  'plugins/halaqati-deeplink/android/src/main/java/com/mohammedsamir/halaqati/deeplink/HalaqatiDeepLinkPlugin.java'
]) assert.ok(fs.existsSync(file)&&fs.statSync(file).size>100,`native plugin missing: ${file}`);
console.log('HALAQATI_V2401_PDF_AUTOFIT_CHECK_PASS');
