package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Student
import com.mohammedsamir.halaqati.ui.components.StateNotice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * RC27.44: fast fill of the national id + birth date that guardian linking needs.
 * Lists the active students that still miss one of them; one row saves through the normal offline-safe student patch.
 */
@Composable
fun StudentIdentitySection(modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var missing by remember { mutableStateOf<List<Student>>(emptyList()) }
    var expanded by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }

    suspend fun reload() {
        missing = withContext(Dispatchers.IO) {
            runCatching { AppGraph.repo.students() }.getOrDefault(emptyList())
                .filter { it.status == "active" && (it.nationalId.isNullOrBlank() || it.dateOfBirth.isNullOrBlank()) }
                .sortedBy { it.fullName }
        }
    }
    LaunchedEffect(Unit) { reload() }
    if (missing.isEmpty()) return

    ElevatedCard(modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("بيانات هوية الطلاب (${missing.size} ناقصة)", fontWeight = FontWeight.Bold)
                    Text(
                        "ربط أولياء الأمور برقم الهوية وتاريخ الميلاد يحتاج هذه البيانات.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "إخفاء" else "تعبئة") }
            }
            note?.let { StateNotice(it, "success") }
            if (expanded) {
                missing.take(30).forEach { st ->
                    key(st.id) {
                        var nid by remember { mutableStateOf(st.nationalId.orEmpty()) }
                        var dob by remember { mutableStateOf(st.dateOfBirth.orEmpty()) }
                        var err by remember { mutableStateOf<String?>(null) }
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            HorizontalDivider()
                            Text(st.fullName, style = MaterialTheme.typography.titleSmall)
                            OutlinedTextField(nid, { nid = it; err = null }, label = { Text("رقم الهوية") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(dob, { dob = it; err = null }, label = { Text("تاريخ الميلاد (yyyy-MM-dd)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            err?.let { StateNotice(it, "error") }
                            Button(
                                onClick = {
                                    val digits = nid.trim()
                                    val date = normalizeBirthDate(dob)
                                    when {
                                        digits.count { it.isDigit() } < 5 -> err = "رقم الهوية غير صالح"
                                        date == null -> err = "تاريخ الميلاد غير صحيح"
                                        else -> scope.launch {
                                            withContext(Dispatchers.IO) {
                                                AppGraph.repo.patch(
                                                    "students", "id=eq.${st.id}",
                                                    JSONObject().put("national_id", digits).put("date_of_birth", date),
                                                    dedupe = "student-identity:${st.id}",
                                                )
                                            }
                                            note = "تم حفظ بيانات ${st.fullName}"
                                            reload()
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            ) { Text("حفظ") }
                        }
                    }
                }
                if (missing.size > 30) Text("يظهر أول 30 طالبًا، وتتجدد القائمة بعد الحفظ.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
