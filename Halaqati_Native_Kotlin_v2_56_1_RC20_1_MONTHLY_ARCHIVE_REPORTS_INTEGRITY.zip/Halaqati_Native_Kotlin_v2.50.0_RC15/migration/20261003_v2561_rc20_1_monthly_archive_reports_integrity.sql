-- RC20.1 / v2.56.1 — Monthly archive + report integrity
-- Additive/idempotent migration. No tables, historical rows, or existing features are removed.
begin;

-- Root fix: manually archived finished plans remain eligible for immutable monthly snapshots.
-- Archived duplicate plans are ignored when an authoritative sibling exists for the same scope/period.
create or replace function public.rc18_archive_finished_plans(p_as_of date default current_date)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  p record;
  s record;
  v_month_start date := date_trunc('month', p_as_of)::date;
  v_period date;
  v_hifz numeric;
  v_sard numeric;
  v_tathbit numeric;
  v_target numeric;
  v_sard_target numeric;
  v_present integer;
  v_absent integer;
  v_quality numeric;
  v_first jsonb;
  v_last jsonb;
  v_count integer := 0;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;

  for p in
    select sp.*
      from public.smart_plans sp
     where coalesce(sp.legacy, false) = false
       and sp.end_date < v_month_start
       and sp.status in ('active','paused','completed','archived')
       and (
         sp.status <> 'archived'
         or not exists(
           select 1 from public.smart_plans live
            where live.id<>sp.id and coalesce(live.legacy,false)=false and live.status<>'archived'
              and live.scope_type=sp.scope_type and live.halaqa_id=sp.halaqa_id and live.plan_type=sp.plan_type
              and live.student_id is not distinct from sp.student_id
              and live.category_id is not distinct from sp.category_id
              and live.start_date=sp.start_date and live.end_date=sp.end_date
         )
       )
       and (
         public.is_admin()
         or exists(select 1 from public.halaqa_teachers ht where ht.halaqa_id=sp.halaqa_id and ht.teacher_id=auth.uid())
         or exists(select 1 from public.halaqa_supervisors hs where hs.halaqa_id=sp.halaqa_id and hs.supervisor_id=auth.uid())
       )
  loop
    v_period := coalesce(p.period_month, date_trunc('month', p.start_date)::date);

    for s in
      select st.* from public.students st
       where st.halaqa_id=p.halaqa_id and (
         (p.scope_type='student' and st.id=p.student_id)
         or (p.scope_type='category' and st.category_id=p.category_id)
         or (p.scope_type='halaqa')
       ) and (
         st.status='active'
         or p.scope_type='student'
         or exists(
           select 1 from public.recitation_entries er
           join public.sessions es on es.id=er.session_id and es.status<>'cancelled'
           where er.student_id=st.id and es.session_date between p.start_date and p.end_date
         )
         or exists(
           select 1 from public.attendance_records ea
           join public.sessions es2 on es2.id=ea.session_id and es2.status<>'cancelled'
           where ea.student_id=st.id and es2.session_date between p.start_date and p.end_date
         )
       )
    loop
      with rec as (
        select r.*, se.session_date
          from public.recitation_entries r
          join public.sessions se on se.id=r.session_id and se.status<>'cancelled'
         where r.student_id=s.id
           and se.session_date between p.start_date and p.end_date
           and lower(coalesce(r.evaluation::text,'')) not in ('repeat','weak','إعادة','ضعيف')
           and (
             r.plan_id=p.id
             or exists(select 1 from public.smart_plan_phases ph where ph.id=r.phase_id and ph.plan_id=p.id)
             or (r.plan_id is null and r.phase_id is null)
           )
      )
      select
        coalesce(sum(pages_count) filter(where activity_type::text='new_hifz'),0),
        coalesce(sum(pages_count) filter(where activity_type::text='sard'),0),
        coalesce(sum(pages_count) filter(where activity_type::text in ('tathbit','review_far')),0),
        round(avg(safety_percentage) filter(where safety_percentage is not null),1),
        (select jsonb_build_object('date',session_date,'start_surah',start_surah,'start_ayah',start_ayah,'end_surah',end_surah,'end_ayah',end_ayah,'pages',pages_count)
           from rec order by session_date,created_at limit 1),
        (select jsonb_build_object('date',session_date,'start_surah',start_surah,'start_ayah',start_ayah,'end_surah',end_surah,'end_ayah',end_ayah,'pages',pages_count)
           from rec order by session_date desc,created_at desc limit 1)
      into v_hifz,v_sard,v_tathbit,v_quality,v_first,v_last
      from rec;

      select coalesce(sum(coalesce(ps.target_pages_override,ps.frozen_target_pages,ph.target_pages,
                  case when ph.goal_mode='juz' then ph.target_units*20 else null end,0)) filter(where ph.phase_type='hifz'),0),
             coalesce(sum(coalesce(ps.target_pages_override,ps.frozen_target_pages,ph.target_pages,
                  case when ph.goal_mode='juz' then ph.target_units*20 else null end,0)) filter(where ph.phase_type='sard'),0)
        into v_target,v_sard_target
        from public.smart_plan_phases ph
        left join public.smart_plan_phase_states ps on ps.phase_id=ph.id and ps.student_id=s.id
       where ph.plan_id=p.id;

      if p.plan_type='tathbit' then
        v_target := coalesce(nullif(v_target,0),p.target_pages,0);
      else
        v_target := coalesce(nullif(v_target,0),p.target_pages,0);
      end if;

      select count(*) filter(where ar.status::text in ('present','late')),
             count(*) filter(where ar.status::text='absent')
        into v_present,v_absent
        from public.attendance_records ar
        join public.sessions se on se.id=ar.session_id and se.status<>'cancelled'
       where ar.student_id=s.id and se.session_date between p.start_date and p.end_date;

      insert into public.smart_plan_month_archives(
        student_id,halaqa_id,source_plan_id,period_month,plan_type,plan_title,
        target_pages,done_pages,sard_target_pages,sard_done_pages,
        attendance_present,attendance_absent,quality_percent,start_anchor,end_anchor,snapshot,created_by
      ) values (
        s.id,p.halaqa_id,p.id,v_period,p.plan_type,p.title,
        coalesce(v_target,0),case when p.plan_type='tathbit' then coalesce(v_tathbit,0) else coalesce(v_hifz,0) end,
        coalesce(v_sard_target,0),coalesce(v_sard,0),
        coalesce(v_present,0),coalesce(v_absent,0),v_quality,v_first,v_last,
        jsonb_build_object(
          'scope_type',p.scope_type,'category_id',p.category_id,'student_id',p.student_id,
          'start_date',p.start_date,'end_date',p.end_date,'status',p.status,
          'activities',case when p.plan_type='tathbit' then jsonb_build_array(
             jsonb_build_object('key','tathbit','target_pages',coalesce(v_target,0),'done_pages',coalesce(v_tathbit,0))
          ) else jsonb_build_array(
             jsonb_build_object('key','hifz','target_pages',coalesce(v_target,0),'done_pages',coalesce(v_hifz,0)),
             jsonb_build_object('key','sard','target_pages',coalesce(v_sard_target,0),'done_pages',coalesce(v_sard,0))
          ) end
        ),auth.uid()
      )
      on conflict(student_id,source_plan_id,period_month) do update set
        target_pages=excluded.target_pages,done_pages=excluded.done_pages,
        sard_target_pages=excluded.sard_target_pages,sard_done_pages=excluded.sard_done_pages,
        attendance_present=excluded.attendance_present,attendance_absent=excluded.attendance_absent,
        quality_percent=excluded.quality_percent,start_anchor=excluded.start_anchor,end_anchor=excluded.end_anchor,
        snapshot=excluded.snapshot,archived_at=now();
      v_count := v_count + 1;
    end loop;

    update public.smart_plans
       set status='completed', period_month=v_period, frozen_at=coalesce(frozen_at,now()),
           frozen_summary=coalesce(frozen_summary,'{}'::jsonb) || jsonb_build_object('rc18_archived',true,'archived_at',now()),
           updated_at=now(), revision=revision+1
     where id=p.id and status<>'archived';

    update public.smart_plan_phases
       set status='completed', completed_at=coalesce(completed_at,now()), updated_at=now(), revision=revision+1
     where plan_id=p.id and status='active' and end_date < v_month_start;
  end loop;

  return jsonb_build_object('archived_rows',v_count,'through',v_month_start-1);
end;
$$;


revoke all on function public.rc18_archive_finished_plans(date) from public, anon;
grant execute on function public.rc18_archive_finished_plans(date) to authenticated;

-- Future-safe manual archive. A finished prior-month plan is snapshotted before the status is
-- changed to archived, so the UI action can no longer make the month disappear from history.
create or replace function public.rc201_archive_plan_with_snapshot(p_plan_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_plan public.smart_plans%rowtype;
  v_archive jsonb := '{}'::jsonb;
  v_snapshot_rows integer := 0;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  select sp.* into v_plan
    from public.smart_plans sp
   where sp.id=p_plan_id
     and (
       public.is_admin()
       or exists(select 1 from public.halaqa_teachers ht where ht.halaqa_id=sp.halaqa_id and ht.teacher_id=auth.uid())
       or exists(select 1 from public.halaqa_supervisors hs where hs.halaqa_id=sp.halaqa_id and hs.supervisor_id=auth.uid())
     );
  if not found then raise exception 'plan access denied'; end if;

  -- rc18_archive_finished_plans is idempotent (ON CONFLICT updates the immutable month row),
  -- and now also understands plans that were already marked archived by older clients.
  v_archive := public.rc18_archive_finished_plans(current_date);

  update public.smart_plans
     set status='archived', updated_at=now(), revision=revision+1
   where id=p_plan_id;

  select count(*) into v_snapshot_rows
    from public.smart_plan_month_archives a
   where a.source_plan_id=p_plan_id;

  return jsonb_build_object(
    'plan_id',p_plan_id,
    'status','archived',
    'snapshot_rows',v_snapshot_rows,
    'archive_pass',coalesce(v_archive,'{}'::jsonb)
  );
end;
$$;
revoke all on function public.rc201_archive_plan_with_snapshot(uuid) from public, anon;
grant execute on function public.rc201_archive_plan_with_snapshot(uuid) to authenticated;

-- Idempotent on-demand repair used when opening a student's month history. It also backfills
-- September 2026 (and any other finished month) if the old client archived the plan too early.
create or replace function public.rc201_repair_student_month_archives(p_student_id uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_archive jsonb;
  v_rows integer := 0;
begin
  if auth.uid() is null then raise exception 'authentication required'; end if;
  if not public.rc18_can_view_student(p_student_id) then raise exception 'student access denied'; end if;

  -- Guardians may read history but never trigger cross-plan maintenance. Staff run the expensive
  -- idempotent repair only when this student actually has a finished plan missing its snapshot.
  if public.rc18_can_manage_student(p_student_id) and exists(
    select 1
      from public.smart_plans sp
      join public.students st on st.id=p_student_id and st.halaqa_id=sp.halaqa_id
     where coalesce(sp.legacy,false)=false
       and sp.end_date < date_trunc('month',current_date)::date
       and sp.status in ('active','paused','completed','archived')
       and (
         (sp.scope_type='student' and sp.student_id=st.id)
         or (sp.scope_type='category' and sp.category_id=st.category_id)
         or sp.scope_type='halaqa'
       )
       and not exists(
         select 1 from public.smart_plan_month_archives a
          where a.student_id=st.id and a.source_plan_id=sp.id
            and a.period_month=coalesce(sp.period_month,date_trunc('month',sp.start_date)::date)
       )
  ) then
    v_archive := public.rc18_archive_finished_plans(current_date);
  end if;
  select count(*) into v_rows from public.smart_plan_month_archives where student_id=p_student_id;
  return jsonb_build_object('student_id',p_student_id,'history_rows',v_rows,'archive_pass',coalesce(v_archive,'{}'::jsonb));
end;
$$;
revoke all on function public.rc201_repair_student_month_archives(uuid) from public, anon;
grant execute on function public.rc201_repair_student_month_archives(uuid) to authenticated;

commit;
