#!/usr/bin/env python3
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
errors=[]
def read(rel):
    p=root/rel
    if not p.exists(): errors.append(f'missing {rel}'); return ''
    return p.read_text(encoding='utf-8',errors='ignore')
def need(c,m):
    if not c: errors.append(m)

build=read('app/build.gradle.kts')
repo=read('app/src/main/java/com/mohammedsamir/halaqati/data/HalaqatiRepository.kt')
renderer=read('app/src/main/java/com/mohammedsamir/halaqati/documents/ReportHtmlRenderer.kt')
layout=read('app/src/main/java/com/mohammedsamir/halaqati/documents/RecitationMatrixLayout.kt')
exports=read('app/src/main/java/com/mohammedsamir/halaqati/ui/screens/NativeReportExport.kt')
controls=read('app/src/main/java/com/mohammedsamir/halaqati/ui/screens/ReportStudioControls.kt')
core=read('app/src/main/java/com/mohammedsamir/halaqati/ui/screens/CoreScreens.kt')
mig=read('migration/20261003_v2561_rc20_1_monthly_archive_reports_integrity.sql')
contract=json.loads(read('migration/source-contract.json') or '{}')

need('versionCode = 25601' in build and 'versionName = "2.56.1"' in build,'v2.56.1 version')
need(contract.get('native_version')=='2.56.1','source contract v2.56.1')
need("sp.status in ('active','paused','completed','archived')" in mig,'archive repair accepts manually archived plans')
need('rc201_repair_student_month_archives' in mig,'student archive backfill rpc')
need('rc18_can_manage_student(p_student_id)' in mig,'archive repair runs expensive backfill only for authorized staff')
need('rc201_archive_plan_with_snapshot' in mig,'future manual archive snapshots before status change')
need('rc201_archive_plan_with_snapshot' in repo,'manual archive uses snapshot-safe rpc')
need("st.status='active'" in mig and 'recitation_entries' in mig and 'attendance_records' in mig,'historical student eligibility preserves withdrawn students with evidence')
need('rc201_repair_student_month_archives' in repo,'history invokes archive backfill before read')
need('throw IllegalStateException("تعذر تحميل أرشيف الخطط' in repo,'archive history does not silently swallow online rpc failure')
need('start_surah,start_ayah,end_surah,end_ayah,start_page,end_page' in repo,'report summary loads exact Quran anchors')
for key in ['hifz_start_anchor','hifz_end_anchor','sard_start_anchor','sard_end_anchor']:
    need(key in repo,f'report summary emits {key}')
    need(key in renderer,f'report renderer uses {key}')
    need(key in exports,f'flat exports use {key}')
need('RecitationMatrixLayout.pages' in renderer,'PDF/preview recitations use deterministic matrix pagination')
need('RecitationMatrixLayout.pages' in exports,'Excel/Word/image/share recitations use matrix data')
need('maxDays = if (landscape) 7 else 4' in layout,'matrix day column limits')
need('maxStudentsPerPage' in layout,'matrix student batching')
need('"hifz_start" to "بداية الحفظ"' in controls and '"sard_end" to "نهاية السرد"' in controls,'halaqa report exposes new anchor columns')
need('تم إصلاح أرشيف' in core or 'أرشيف' in core,'monthly rollover reports archive result')

if errors:
    print('RC20.1 Monthly Archive + Reports gate FAILED')
    for e in errors: print(' -',e)
    sys.exit(1)
print('RC20.1 Monthly Archive + Reports gate PASS')
