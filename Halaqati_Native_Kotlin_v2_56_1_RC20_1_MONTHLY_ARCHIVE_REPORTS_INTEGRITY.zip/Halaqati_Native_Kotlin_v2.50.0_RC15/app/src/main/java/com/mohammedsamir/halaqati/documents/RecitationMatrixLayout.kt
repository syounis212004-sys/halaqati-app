package com.mohammedsamir.halaqati.documents

/**
 * Deterministic pagination model for recitation reports.
 * It keeps student names on every page, limits day columns by page orientation,
 * and batches long rosters so PDF/preview output never relies on browser overflow.
 */
object RecitationMatrixLayout {
    data class Entry(
        val studentId: String,
        val studentName: String,
        val date: String,
        val text: String,
    )

    data class Cell(val date: String, val lines: List<String>)
    data class StudentRow(val studentId: String, val studentName: String, val cells: List<Cell>)
    data class Page(val days: List<String>, val students: List<StudentRow>)

    fun pages(
        entries: List<Entry>,
        landscape: Boolean,
        maxStudentsPerPage: Int = if (landscape) 12 else 16,
    ): List<Page> {
        if (entries.isEmpty()) return emptyList()
        require(maxStudentsPerPage > 0) { "maxStudentsPerPage must be positive" }
        val maxDays = if (landscape) 7 else 4
        val days = entries.map { it.date }.filter { it.isNotBlank() }.distinct().sorted()
        if (days.isEmpty()) return emptyList()

        val students = entries
            .filter { it.studentId.isNotBlank() || it.studentName.isNotBlank() }
            .groupBy { it.studentId.ifBlank { "name:${it.studentName}" } }
            .map { (id, studentEntries) ->
                Triple(id, studentEntries.first().studentName.ifBlank { "طالب" }, studentEntries)
            }
            .sortedBy { it.second }

        return days.chunked(maxDays).flatMap { dayChunk ->
            students.chunked(maxStudentsPerPage).map { studentChunk ->
                Page(
                    days = dayChunk,
                    students = studentChunk.map { (id, name, studentEntries) ->
                        StudentRow(
                            studentId = id,
                            studentName = name,
                            cells = dayChunk.map { day ->
                                Cell(
                                    date = day,
                                    lines = studentEntries
                                        .filter { it.date == day }
                                        .map { it.text }
                                        .filter { it.isNotBlank() },
                                )
                            },
                        )
                    },
                )
            }
        }
    }
}
