package com.mohammedsamir.halaqati.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.mohammedsamir.halaqati.R
import com.mohammedsamir.halaqati.documents.RecitationMatrixLayout
import com.mohammedsamir.halaqati.quran.QuranMetadata
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.OutputStreamWriter
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Golden-master compatible report exports: Excel, Word, image and shareable text. */
object NativeReportExport {
    data class Table(val headers: List<String>, val rows: List<List<String>>)

    fun table(source: List<JSONObject>, details: Boolean, landscape: Boolean = true): Table {
        return if (details) recitationMatrixTable(source, landscape) else {
            val headers = listOf(
                "#", "الطالب", "الفئة", "المسار",
                "بداية الحفظ", "نهاية الحفظ", "الحفظ", "التثبيت", "المراجعة",
                "بداية السرد", "نهاية السرد", "السرد", "الحضور", "الغياب", "النقاط",
            )
            val rows = source.mapIndexed { index, row ->
                listOf(
                    (index + 1).toString(),
                    row.optString("student_name", "طالب"),
                    row.optString("category_name"),
                    if (row.optString("track_code") == "tathbit") "التثبيت" else "الحفظ العام",
                    anchorLabel(row.optJSONObject("hifz_start_anchor")),
                    anchorLabel(row.optJSONObject("hifz_end_anchor")),
                    clean(row.optDouble("hifz_pages", 0.0)),
                    clean(row.optDouble("tathbit_pages", 0.0)),
                    clean(row.optDouble("review_pages", 0.0)),
                    anchorLabel(row.optJSONObject("sard_start_anchor")),
                    anchorLabel(row.optJSONObject("sard_end_anchor")),
                    clean(row.optDouble("sard_pages", 0.0)),
                    (row.optInt("present", 0) + row.optInt("late", 0)).toString(),
                    row.optInt("absent", 0).toString(),
                    clean(row.optDouble("points", 0.0)),
                )
            }
            Table(headers, rows)
        }
    }

    private fun recitationMatrixTable(source: List<JSONObject>, landscape: Boolean): Table {
        val entries = source.mapNotNull { row ->
            val student = row.optJSONObject("students")
            val session = row.optJSONObject("sessions")
            val date = session?.optString("session_date").orEmpty().ifBlank { row.optString("session_date") }
            if (date.isBlank()) return@mapNotNull null
            val studentName = student?.optString("full_name").orEmpty().ifBlank { row.optString("student_name", "طالب") }
            val studentId = row.optString("student_id").ifBlank { "name:$studentName" }
            RecitationMatrixLayout.Entry(
                studentId = studentId,
                studentName = studentName,
                date = date,
                text = "${activityLabel(row.optString("activity_type"))} · ${recitationRange(row)} · ${clean(row.optDouble("pages_count",0.0))}ص",
            )
        }
        val pages = RecitationMatrixLayout.pages(entries, landscape = landscape)
        val daySlots = if (landscape) 7 else 4
        val headers = listOf("الطالب") + (1..daySlots).map { "اليوم $it" }
        val rows = mutableListOf<List<String>>()
        pages.forEachIndexed { index, page ->
            rows += listOf("الأيام ${index + 1}/${pages.size}") + page.days.map(::shortDate) + List(daySlots - page.days.size) { "" }
            page.students.forEach { student ->
                rows += listOf(student.studentName) + student.cells.map { cell -> cell.lines.joinToString(" | ").ifBlank { "—" } } + List(daySlots - page.days.size) { "" }
            }
        }
        return Table(headers, rows)
    }

    fun exportXlsx(context: Context, uri: Uri, table: Table, sheetName: String = "تقرير حلقتي") {
        context.contentResolver.openOutputStream(uri)?.use { raw ->
            ZipOutputStream(BufferedOutputStream(raw)).use { zip ->
                fun entry(name: String, content: String) {
                    zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry()
                }
                entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
                entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
                entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${xml(sheetName.take(31))}" sheetId="1" r:id="rId1"/></sheets></workbook>""")
                entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
                val all = listOf(table.headers) + table.rows
                val sheetRows = all.mapIndexed { r, cells ->
                    val cellXml = cells.mapIndexed { c, value ->
                        val ref = "${columnName(c + 1)}${r + 1}"
                        "<c r=\"$ref\" t=\"inlineStr\"><is><t>${xml(value)}</t></is></c>"
                    }.joinToString("")
                    "<row r=\"${r + 1}\">$cellXml</row>"
                }.joinToString("")
                val firstColumnWidth = if (table.headers.firstOrNull() == "الطالب") 24 else 6
                entry("xl/worksheets/sheet1.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0" rightToLeft="1"/></sheetViews><cols><col min="1" max="1" width="$firstColumnWidth" customWidth="1"/><col min="2" max="20" width="18" customWidth="1"/></cols><sheetData>$sheetRows</sheetData></worksheet>""")
            }
        } ?: error("تعذر فتح ملف Excel للحفظ")
    }

    fun exportWord(context: Context, uri: Uri, table: Table, title: String, subtitle: String) {
        val head = table.headers.joinToString("") { "<th>${html(it)}</th>" }
        val body = table.rows.joinToString("") { row -> row.joinToString("", "<tr>", "</tr>") { "<td>${html(it)}</td>" } }
        val doc = """<!doctype html><html dir="rtl"><head><meta charset="UTF-8"><style>body{font-family:Cairo,Tahoma,Arial,sans-serif;direction:rtl;color:#18231f;padding:24px}h1{text-align:center;color:#0d3b2f;margin-bottom:4px}p{text-align:center;color:#65716b}table{width:100%;border-collapse:collapse;font-size:9.5pt}th{background:#0d3b2f;color:#fff;padding:7px;border:1px solid #d7e0dc}td{padding:6px;border:1px solid #d7e0dc;text-align:center}tr:nth-child(even){background:#f3f8f5}</style></head><body><h1>${html(title)}</h1><p>${html(subtitle)}</p><table><thead><tr>$head</tr></thead><tbody>$body</tbody></table></body></html>"""
        context.contentResolver.openOutputStream(uri)?.use { stream ->
            OutputStreamWriter(stream, Charsets.UTF_8).use { it.write('\ufeff'.toString()); it.write(doc) }
        } ?: error("تعذر فتح ملف Word للحفظ")
    }

    fun exportPng(context: Context, uri: Uri, table: Table, title: String, subtitle: String) {
        val width = 1600
        val rowHeight = 58
        val height = (250 + table.rows.size.coerceAtMost(120) * rowHeight).coerceAtLeast(500)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        val typeface = ResourcesCompat.getFont(context, R.font.cairo)
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 48f; color = 0xFF0D3B2F.toInt(); this.typeface = typeface }
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 25f; color = 0xFF65716B.toInt(); this.typeface = typeface }
        val rowPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 25f; color = 0xFF18231F.toInt(); this.typeface = typeface }
        var y = 48f
        fun drawRtl(text: String, paint: TextPaint, top: Float, w: Int = width - 120): Int {
            val l = StaticLayout.Builder.obtain(text, 0, text.length, paint, w).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setIncludePad(false).build()
            canvas.save(); canvas.translate(60f, top); l.draw(canvas); canvas.restore(); return l.height
        }
        y += drawRtl(title, titlePaint, y) + 10
        y += drawRtl(subtitle, subPaint, y) + 22
        val headerLine = table.headers.joinToString("  |  ")
        y += drawRtl(headerLine, rowPaint, y) + 10
        canvas.drawLine(60f, y, width - 60f, y, Paint().apply { color = 0xFF2F8B69.toInt(); strokeWidth = 3f }); y += 12
        table.rows.take(120).forEach { row ->
            val line = row.joinToString("  |  ")
            y += drawRtl(line, rowPaint, y) + 8
            canvas.drawLine(60f, y, width - 60f, y, Paint().apply { color = 0xFFE4EBE7.toInt(); strokeWidth = 1f }); y += 8
        }
        context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 96, it) } ?: error("تعذر فتح ملف الصورة للحفظ")
        bitmap.recycle()
    }

    fun shareText(context: Context, table: Table, title: String, subtitle: String) {
        val body = buildString {
            appendLine(title)
            appendLine(subtitle)
            table.rows.take(20).forEach { row -> appendLine(row.joinToString(" · ")) }
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, body)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة تقرير حلقتي"))
    }

    private fun recitationRange(r: JSONObject): String {
        val ss=nullableInt(r,"start_surah"); val sa=nullableInt(r,"start_ayah"); val es=nullableInt(r,"end_surah"); val ea=nullableInt(r,"end_ayah")
        if(ss!=null&&sa!=null){
            val endS=es?:ss; val endA=ea?:sa
            return when {
                endS==ss && endA==sa -> "سورة ${surahName(ss)}: $sa"
                endS==ss -> "سورة ${surahName(ss)}: $sa → $endA"
                else -> "${surahName(ss)} $sa → ${surahName(endS)} $endA"
            }
        }
        val surahs=r.optJSONArray("selected_surahs") ?: r.optJSONObject("selection_data")?.optJSONArray("selected_surahs")
        if(surahs!=null&&surahs.length()>0)return (0 until surahs.length()).joinToString("، "){surahName(surahs.optInt(it))}
        val juz=r.optJSONObject("selection_data")?.optJSONArray("selected_juz")
        if(juz!=null&&juz.length()>0)return "الأجزاء "+(0 until juz.length()).joinToString("، "){juz.optInt(it).toString()}
        val sp=nullableInt(r,"start_page"); val ep=nullableInt(r,"end_page")
        if(sp!=null||ep!=null){ val x=sp?:ep!!; val y=ep?:x; return if(x==y)"صفحة $x" else "صفحات $x–$y" }
        return "—"
    }
    private fun anchorLabel(anchor: JSONObject?): String {
        if (anchor == null) return "—"
        val surah = anchor.optInt("surah").takeIf { anchor.has("surah") && !anchor.isNull("surah") && it in 1..114 }
        val ayah = anchor.optInt("ayah").takeIf { anchor.has("ayah") && !anchor.isNull("ayah") && it > 0 }
        val page = anchor.optInt("page").takeIf { anchor.has("page") && !anchor.isNull("page") && it in 1..604 }
        return when {
            surah != null && ayah != null -> "${surahName(surah)} $ayah"
            surah != null -> surahName(surah)
            page != null -> "صفحة $page"
            else -> "—"
        }
    }
    private fun shortDate(value: String): String = runCatching {
        val p=value.split('-'); "${p[2]}/${p[1]}"
    }.getOrDefault(value)
    private fun surahName(n: Int): String = runCatching { QuranMetadata.surahName(n) }.getOrDefault("سورة $n")
    private fun nullableInt(o: JSONObject,key: String): Int? = if(!o.has(key)||o.isNull(key)) null else o.optInt(key).takeIf{it>0}

    private fun activityLabel(v: String) = when (v) {
        "new_hifz", "hifz" -> "حفظ"
        "review_near" -> "مراجعة قريبة"
        "review_far" -> "مراجعة بعيدة"
        "sard" -> "سرد"
        "test" -> "اختبار"
        else -> v.ifBlank { "—" }
    }
    private fun evaluationLabel(v: String) = when (v) {
        "excellent" -> "ممتاز"
        "very_good" -> "جيد جدًا"
        "good" -> "جيد"
        "repeat" -> "إعادة"
        else -> v.ifBlank { "—" }
    }
    private fun clean(v: Double) = if (kotlin.math.abs(v - v.toInt()) < .0001) v.toInt().toString() else "%.2f".format(v)
    private fun columnName(index: Int): String { var n=index; val out=StringBuilder(); while(n>0){ n--; out.append(('A'.code+n%26).toChar()); n/=26 }; return out.reverse().toString() }
    private fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun html(s: String) = xml(s).replace("'", "&#39;")
}
