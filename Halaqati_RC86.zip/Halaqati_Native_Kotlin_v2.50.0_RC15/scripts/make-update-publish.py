from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.33',
    'versionCode':28933,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "الدعم والمانحون يعمل دون إنترنت: القوائم تُحمَّل مرة واحدة وتبقى على الجهاز، وتتجدد بزر التحديث أو بعد أي تعديل",
        "بطاقة المانح صغيرة بصف واحد مع شارة متدرجة بزخرفة هندسية، فيظهر عدد أكبر من المانحين في الشاشة",
        "إدارة الحلقات: بطاقة جديدة بتدرج لوني وموجات وزخرفة هندسية، وصورة شعار الحلقة ظاهرة مع زر واضح لإضافتها أو تغييرها (وفي نافذة التعديل)",
        "لا يظهر نص null في وصف الحلقة، وأسماء تخصص البرنامج ومستواه بالعربية",
        "المحفّظ يعمل في حلقة عادية واحدة: عند إضافته لحلقة أخرى يظهر تأكيد النقل، ويبقى في برامجه",
        "المشرف لا يرى المشرفين الآخرين في فريق الجمعية، ورسالة فصل الحلقة عن الجمعية توضح أنها تصير مستقلة",
        "تنبيه على بطاقة البرنامج قبل أسبوع من انتهائه وبعده، دون إغلاق تلقائي",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
