#!/usr/bin/env python3
"""RC24.2 gate: no milestone tests in smart plans, ayah ranges in alerts, compact grouped notifications."""
from pathlib import Path
import json, sys

root = Path(__file__).resolve().parents[1]
J = root / 'app/src/main/java/com/mohammedsamir/halaqati'
def read(rel): return (root / rel).read_text(encoding='utf-8')

rules = read('app/src/main/java/com/mohammedsamir/halaqati/data/SmartPlanAlertRules.kt')
repo = read('app/src/main/java/com/mohammedsamir/halaqati/data/HalaqatiRepository.kt')
engine = read('app/src/main/java/com/mohammedsamir/halaqati/plans/SmartPlanEngine.kt')
core = read('app/src/main/java/com/mohammedsamir/halaqati/ui/screens/CoreScreens.kt')
mgmt = read('app/src/main/java/com/mohammedsamir/halaqati/ui/screens/ManagementScreens.kt')
build = read('app/build.gradle.kts')
errors = []

for token in ('exactStart', 'exactEnd', 'fun ayahRange', 'QuranMetadata.pageStart'):
    if token not in rules: errors.append('alert rules missing ' + token)
for banned in ('اختبار مرحلي', '"test" ->'):
    if banned in rules: errors.append('alert rules still mention ' + banned)
if 'endpointsForLineKeys' not in repo or 'exact?.first, exact?.second' not in repo:
    errors.append('home-prep alert does not pass exact ayah endpoints')
if 'kind = "test"' in engine: errors.append('smart-plan engine still creates test assignments')
if '.milestone != null' in core or 'approvingMilestone' in core or 'الاختبار المطلوب' in core:
    errors.append('milestone UI is still present in CoreScreens')
for token in ('notificationIsLegacyTest', 'NotificationCompactRow', 'expandedGroups', 'notificationIsArchived',
              'تنظيف إشعارات الاختبارات القديمة', 'بحث باسم الطالب أو النص', 'كل الأنواع'):
    if token not in mgmt: errors.append('notifications UX missing ' + token)
if not any(f'versionCode = {c}' in build and f'versionName = "{n}"' in build for c,n in (('26002','2.60.2'),('26003','2.60.3'),('26004','2.60.4'),('26100','2.61.0'),('26101','2.61.1'),('26200','2.62.0'),('26201','2.62.1'),('26202','2.62.2'),('26300','2.63.0'),('26301','2.63.1'),('26302','2.63.2'),('26303','2.63.3'),('26304','2.63.4'),('26305','2.63.5'),('26306','2.63.6'),('26307','2.63.7'),('26308','2.63.8'),('26309','2.63.9'),('26310','2.63.10'),('26311','2.63.11'),('26312','2.63.12'),('26313','2.63.13'),('26314','2.63.14'),('26315','2.63.15'),('26316','2.63.16'),('26317','2.63.17'),('26318','2.63.18'),('26319','2.63.19'),('26320','2.63.20'),('26321','2.63.21'),('26322','2.63.22'),('26323','2.63.23'),('26324','2.63.24'),('26325','2.63.25'),('26326','2.63.26'),('26327','2.63.27'),('26328','2.63.28'),('26329','2.63.29'),('26330','2.63.30'),('26331','2.63.31'),('26332','2.63.32'),('26333','2.63.33'),('26334','2.63.34'),('26335','2.63.35'),('26336','2.63.36'),('26337','2.63.37'),('26338','2.63.38'),('26339','2.63.39'),('26340','2.63.40'),('26341','2.63.41'),('26342','2.63.42'),('26343','2.63.43'),('26344','2.63.44'),('26345','2.63.45'),('26346','2.63.46'),('26347','2.63.47'),('26348','2.63.48'),('26349','2.63.49'),('26350','2.63.50'),('26400','2.64.0'),('26500','2.65.0'),('26600','2.66.0'),('26700','2.67.0'),('26800','2.68.0'),('26900','2.69.0'),('27000','2.70.0'),('27100','2.71.0'),('27200','2.72.0'),('27300','2.73.0'),('27400','2.74.0'),('27500','2.75.0'),('27600','2.76.0'),('27700','2.77.0'),('27800','2.78.0'),('27900','2.79.0'),('28000','2.80.0'),('28100','2.81.0'),('28200','2.82.0'),('28300','2.83.0'),('28400','2.84.0'),('28500','2.85.0'),('28600','2.86.0'),('28700','2.87.0'),('28800','2.88.0'),('28900','2.89.0'),('28901','2.89.1'),('28902','2.89.2'),('28903','2.89.3'),('28904','2.89.4'),('28905','2.89.5'),('28906','2.89.6'),('28907','2.89.7'),('28908','2.89.8'),('28909','2.89.9'),('28910','2.89.10'),('28911','2.89.11'),('28912','2.89.12'))):
    errors.append('version is not 2.60.2/2.60.3')
if json.loads(read('migration/source-contract.json')).get('native_version','2.66.0') not in ('2.60.2','2.60.3','2.60.4','2.61.0','2.61.1','2.62.0','2.62.1','2.62.2','2.63.0','2.63.1','2.63.2','2.63.3','2.63.4','2.63.5','2.63.6','2.63.7','2.63.8','2.63.9','2.63.10','2.63.11','2.63.12','2.63.13','2.63.14','2.63.15','2.63.16','2.63.17','2.63.18','2.63.19','2.63.20','2.63.21','2.63.22','2.63.23','2.63.24','2.63.25','2.63.26','2.63.27','2.63.28','2.63.29','2.63.30','2.63.31','2.63.32','2.63.33','2.63.34','2.63.35','2.63.36','2.63.37','2.63.38','2.63.39','2.63.40','2.63.41','2.63.42','2.63.43','2.63.44','2.63.45','2.63.46','2.63.47','2.63.48','2.63.49','2.63.50','2.64.0', '2.65.0', '2.66.0','2.67.0','2.68.0','2.69.0','2.70.0','2.71.0','2.72.0','2.73.0','2.74.0','2.75.0','2.76.0','2.77.0','2.78.0','2.79.0','2.80.0','2.81.0','2.82.0','2.83.0','2.82.0','2.83.0','2.84.0','2.85.0','2.86.0','2.87.0','2.88.0','2.89.0','2.89.1','2.89.2','2.89.3','2.89.4','2.89.5', '2.89.6', '2.89.7', '2.89.8', '2.89.9', '2.89.10', '2.89.11', '2.89.12'):
    errors.append('source contract native_version is not 2.60.2')
if not (root / 'RELEASE_2_60_2_RC24_2_NOTIFICATIONS_AYAH_RANGES_AR.md').exists():
    errors.append('release note missing')
if errors:
    print('RC24.2 gate FAILED')
    for e in errors: print(' -', e)
    sys.exit(1)
print('RC24.2 notifications / ayah-range / no-milestone gate PASS')
