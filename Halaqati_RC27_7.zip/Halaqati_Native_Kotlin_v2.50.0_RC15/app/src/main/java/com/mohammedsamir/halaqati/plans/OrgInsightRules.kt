package com.mohammedsamir.halaqati.plans

/**
 * RC27 pure rules for two home cards:
 *  - repeated absence (consecutive absent sessions, newest first), with a ready guardian message;
 *  - halaqa comparison for a month (attendance, pages, quality).
 */
object OrgInsightRules {
    data class Attendance(val studentId: String, val date: String, val status: String, val sessionCancelled: Boolean = false)
    data class Streak(val studentId: String, val count: Int, val lastAbsentDate: String)

    /**
     * Consecutive "absent" from the most recent session backwards. "excused" neither counts nor breaks the
     * streak; "present" (or late) breaks it; cancelled sessions are ignored.
     */
    fun absenceStreaks(records: List<Attendance>, minStreak: Int = 3): List<Streak> =
        records.filter { !it.sessionCancelled }
            .groupBy { it.studentId }
            .mapNotNull { (id, rows) ->
                var count = 0
                var last: String? = null
                for (r in rows.sortedByDescending { it.date }) {
                    when (r.status) {
                        "absent" -> { count++; if (last == null) last = r.date }
                        "excused" -> Unit
                        else -> break
                    }
                }
                if (count >= minStreak && last != null) Streak(id, count, last) else null
            }
            .sortedWith(compareByDescending<Streak> { it.count }.thenByDescending { it.lastAbsentDate })

    fun guardianMessage(studentName: String, count: Int, halaqaName: String? = null): String =
        "السلام عليكم ورحمة الله وبركاته، نودّ الاطمئنان على الطالب $studentName، فقد غاب عن $count جلسات متتالية" +
            (if (!halaqaName.isNullOrBlank()) " في $halaqaName" else "") +
            ". نرجو إفادتنا بالسبب وحرصكم على انتظامه. جزاكم الله خيرًا."

    data class HalaqaSession(val halaqaId: String, val date: String, val cancelled: Boolean)
    data class HalaqaAttendance(val halaqaId: String, val status: String)
    data class HalaqaRecitation(val halaqaId: String, val activityType: String, val pages: Double, val evaluation: String)
    data class HalaqaStats(
        val halaqaId: String,
        val students: Int,
        val sessions: Int,
        val attendancePercent: Int?,   // present / (present + absent); excused excluded
        val hifzPages: Double,
        val reviewPages: Double,
        val pagesPerStudent: Double,
        val qualityPercent: Int?,      // recitations not repeat/weak
    )

    private val POOR = setOf("repeat", "weak", "إعادة", "ضعيف")
    private val REVIEW = setOf("review_near", "review_far", "tathbit", "sard")

    fun compare(
        halaqaIds: List<String>,
        activeStudentsByHalaqa: Map<String, Int>,
        sessions: List<HalaqaSession>,
        attendance: List<HalaqaAttendance>,
        recitations: List<HalaqaRecitation>,
    ): List<HalaqaStats> = halaqaIds.map { id ->
        val att = attendance.filter { it.halaqaId == id }
        val present = att.count { it.status == "present" || it.status == "late" }
        val absent = att.count { it.status == "absent" }
        val rec = recitations.filter { it.halaqaId == id }
        val hifz = rec.filter { it.activityType == "new_hifz" }.sumOf { it.pages }
        val review = rec.filter { it.activityType in REVIEW }.sumOf { it.pages }
        val students = activeStudentsByHalaqa[id] ?: 0
        HalaqaStats(
            halaqaId = id,
            students = students,
            sessions = sessions.count { it.halaqaId == id && !it.cancelled },
            attendancePercent = if (present + absent > 0) Math.round(present * 100.0 / (present + absent)).toInt() else null,
            hifzPages = hifz,
            reviewPages = review,
            pagesPerStudent = if (students > 0) (hifz + review) / students else 0.0,
            qualityPercent = if (rec.isNotEmpty()) Math.round(rec.count { it.evaluation.lowercase() !in POOR } * 100.0 / rec.size).toInt() else null,
        )
    }.sortedByDescending { it.pagesPerStudent }
}
