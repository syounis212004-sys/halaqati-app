package com.mohammedsamir.halaqati.ui.theme

import kotlin.math.pow

/**
 * RC27 palette as plain ARGB ints (no Compose) so contrast can be verified by a self-test.
 * Every text/background pair below is checked to WCAG AA (>= 4.5:1) in HalaqatiPaletteSelfTest.
 */
object HalaqatiPalette {
    const val DEFAULT_PRIMARY = 0xFF0B5D4F.toInt()
    const val DEFAULT_ACCENT = 0xFF1B7F6B.toInt()

    /** Colors shipped before RC27; an install still using exactly this pair moves to the new defaults. */
    const val OLD_DEFAULT_PRIMARY = 0xFF155643.toInt()
    const val OLD_DEFAULT_ACCENT = 0xFF2F8B69.toInt()

    data class Roles(
        val primary: Int, val onPrimary: Int, val primaryContainer: Int, val onPrimaryContainer: Int,
        val secondary: Int, val onSecondary: Int, val secondaryContainer: Int, val onSecondaryContainer: Int,
        val tertiary: Int, val onTertiary: Int, val tertiaryContainer: Int, val onTertiaryContainer: Int,
        val background: Int, val onBackground: Int, val surface: Int, val onSurface: Int,
        val surfaceVariant: Int, val onSurfaceVariant: Int, val outline: Int, val outlineVariant: Int,
        val error: Int, val onError: Int, val errorContainer: Int, val onErrorContainer: Int,
    )

    /** Semantic status pair (background, text). Each status keeps its own hue so states read at a glance. */
    data class Status(val bg: Int, val fg: Int)
    data class StatusSet(val success: Status, val warning: Status, val danger: Status, val info: Status, val neutral: Status) {
        fun of(kind: String): Status = when (kind) {
            "success" -> success
            "warning" -> warning
            "error", "danger" -> danger
            "neutral" -> neutral
            else -> info
        }
    }

    val LIGHT = Roles(
        primary = DEFAULT_PRIMARY, onPrimary = 0xFFFFFFFF.toInt(),
        primaryContainer = 0xFFD3EEE3.toInt(), onPrimaryContainer = 0xFF04392F.toInt(),
        secondary = DEFAULT_ACCENT, onSecondary = 0xFFFFFFFF.toInt(),
        secondaryContainer = 0xFFE1F0EA.toInt(), onSecondaryContainer = 0xFF0A4A3D.toInt(),
        tertiary = 0xFF7A5200.toInt(), onTertiary = 0xFFFFFFFF.toInt(),
        tertiaryContainer = 0xFFFAEDCB.toInt(), onTertiaryContainer = 0xFF4A3000.toInt(),
        background = 0xFFF5F7F4.toInt(), onBackground = 0xFF12261F.toInt(),
        surface = 0xFFFFFFFF.toInt(), onSurface = 0xFF12261F.toInt(),
        surfaceVariant = 0xFFE6EFE9.toInt(), onSurfaceVariant = 0xFF42564D.toInt(),
        outline = 0xFF72877D.toInt(), outlineVariant = 0xFFD9E4DD.toInt(),
        error = 0xFFB3261E.toInt(), onError = 0xFFFFFFFF.toInt(),
        errorContainer = 0xFFFBDFDC.toInt(), onErrorContainer = 0xFF65100B.toInt(),
    )

    val DARK = Roles(
        primary = 0xFF8FDDBF.toInt(), onPrimary = 0xFF04281F.toInt(),
        primaryContainer = 0xFF1F4A3E.toInt(), onPrimaryContainer = 0xFFDDF8EC.toInt(),
        secondary = 0xFF9ED9C3.toInt(), onSecondary = 0xFF06291F.toInt(),
        secondaryContainer = 0xFF28493E.toInt(), onSecondaryContainer = 0xFFDDF8EC.toInt(),
        tertiary = 0xFFEBC66F.toInt(), onTertiary = 0xFF3A2800.toInt(),
        tertiaryContainer = 0xFF4A3908.toInt(), onTertiaryContainer = 0xFFF8E7B8.toInt(),
        background = 0xFF0E1714.toInt(), onBackground = 0xFFE9F3EE.toInt(),
        surface = 0xFF16221D.toInt(), onSurface = 0xFFE9F3EE.toInt(),
        surfaceVariant = 0xFF22332C.toInt(), onSurfaceVariant = 0xFFC3D4CB.toInt(),
        outline = 0xFF7F9A8E.toInt(), outlineVariant = 0xFF35493F.toInt(),
        error = 0xFFFFB4AB.toInt(), onError = 0xFF4A0B07.toInt(),
        errorContainer = 0xFF6B1D18.toInt(), onErrorContainer = 0xFFFFDAD6.toInt(),
    )

    val STATUS_LIGHT = StatusSet(
        success = Status(0xFFDCF2E3.toInt(), 0xFF0E5A2C.toInt()),
        warning = Status(0xFFFFEEBF.toInt(), 0xFF6A4600.toInt()),
        danger = Status(0xFFFCDFDC.toInt(), 0xFF8A1912.toInt()),
        info = Status(0xFFDBEAF9.toInt(), 0xFF0B4A8F.toInt()),
        neutral = Status(0xFFE8ECE9.toInt(), 0xFF3E4944.toInt()),
    )

    val STATUS_DARK = StatusSet(
        success = Status(0xFF17402A.toInt(), 0xFFA9E8BF.toInt()),
        warning = Status(0xFF4A390C.toInt(), 0xFFF5D97A.toInt()),
        danger = Status(0xFF5A1B17.toInt(), 0xFFFFC2BA.toInt()),
        info = Status(0xFF163A5C.toInt(), 0xFFB3D4FF.toInt()),
        neutral = Status(0xFF2A3430.toInt(), 0xFFCAD6D0.toInt()),
    )

    private fun channel(v: Int): Double {
        val c = v / 255.0
        return if (c <= 0.03928) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4)
    }

    fun luminance(argb: Int): Double =
        0.2126 * channel((argb shr 16) and 0xFF) + 0.7152 * channel((argb shr 8) and 0xFF) + 0.0722 * channel(argb and 0xFF)

    /** WCAG 2.x contrast ratio, 1.0 .. 21.0. */
    fun contrast(a: Int, b: Int): Double {
        val la = luminance(a)
        val lb = luminance(b)
        return (maxOf(la, lb) + 0.05) / (minOf(la, lb) + 0.05)
    }

    /** Every (name, text, background) pair that must stay readable. */
    fun textPairs(): List<Triple<String, Int, Int>> = buildList {
        for ((mode, r) in listOf("light" to LIGHT, "dark" to DARK)) {
            add(Triple("$mode onBackground/background", r.onBackground, r.background))
            add(Triple("$mode onSurface/surface", r.onSurface, r.surface))
            add(Triple("$mode onSurfaceVariant/surface", r.onSurfaceVariant, r.surface))
            add(Triple("$mode onSurfaceVariant/background", r.onSurfaceVariant, r.background))
            add(Triple("$mode onSurfaceVariant/surfaceVariant", r.onSurfaceVariant, r.surfaceVariant))
            add(Triple("$mode onSurface/surfaceVariant", r.onSurface, r.surfaceVariant))
            add(Triple("$mode primary/surface", r.primary, r.surface))
            add(Triple("$mode primary/background", r.primary, r.background))
            add(Triple("$mode onPrimary/primary", r.onPrimary, r.primary))
            add(Triple("$mode onSecondary/secondary", r.onSecondary, r.secondary))
            add(Triple("$mode secondary/surface", r.secondary, r.surface))
            add(Triple("$mode onTertiary/tertiary", r.onTertiary, r.tertiary))
            add(Triple("$mode tertiary/surface", r.tertiary, r.surface))
            add(Triple("$mode onPrimaryContainer/primaryContainer", r.onPrimaryContainer, r.primaryContainer))
            add(Triple("$mode onSecondaryContainer/secondaryContainer", r.onSecondaryContainer, r.secondaryContainer))
            add(Triple("$mode onTertiaryContainer/tertiaryContainer", r.onTertiaryContainer, r.tertiaryContainer))
            add(Triple("$mode onError/error", r.onError, r.error))
            add(Triple("$mode error/surface", r.error, r.surface))
            add(Triple("$mode onErrorContainer/errorContainer", r.onErrorContainer, r.errorContainer))
        }
        for ((mode, set) in listOf("light" to STATUS_LIGHT, "dark" to STATUS_DARK)) {
            for ((name, s) in listOf("success" to set.success, "warning" to set.warning, "danger" to set.danger, "info" to set.info, "neutral" to set.neutral)) {
                add(Triple("$mode status $name", s.fg, s.bg))
            }
        }
    }
}
