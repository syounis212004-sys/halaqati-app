package com.mohammedsamir.halaqati.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.ThemeMode
import com.mohammedsamir.halaqati.data.UiDensity
import com.mohammedsamir.halaqati.data.UiPreferences

/**
 * RC17 Design Package tokens.
 * Geometry mirrors the supplied Halaqati prototype: 8pt rhythm, 20dp page gutters,
 * 16dp actions, 20-24dp cards and a minimum 48dp touch target.
 */
object HalaqatiUiTokens {
    val TouchTarget = 48.dp
    val ActionHeight = 52.dp
    val RadiusSmall = 12.dp
    val RadiusMedium = 16.dp
    val RadiusMetric = 20.dp
    val RadiusLarge = 22.dp
    val RadiusCard = 24.dp
    val RadiusHero = 26.dp
    val ScreenHorizontal = 14.dp
    val SpaceXs = 4.dp
    val SpaceSm = 8.dp
    val SpaceMd = 12.dp
    val SpaceLg = 16.dp
    val SpaceXl = 24.dp
}

/** Fixed semantic accents from the approved redesign. Primary/accent can still be user-customized. */
// RC16 parity anchors retained for regression tooling only: 0xFF0D3B2F / 0xFF52645D
object HalaqatiDesignColors {
    val DefaultPrimary = Color(HalaqatiPalette.DEFAULT_PRIMARY)
    val DefaultAccent = Color(HalaqatiPalette.DEFAULT_ACCENT)
    val Ink = Color(0xFF163C32)
    val Background = Color(0xFFF7F8F3)
    val Soft = Color(0xFFEAF1E9)
    val Border = Color(0xFFD8E3DA)
    val Gold = Color(0xFF86621F)
    val GoldSoft = Color(0xFFF5EDD9)
    val Hero = Color(0xFF103E32)
}

data class HalaqatiSpacing(val xs: Dp, val sm: Dp, val md: Dp, val lg: Dp, val xl: Dp)
val LocalHalaqatiSpacing = staticCompositionLocalOf { HalaqatiSpacing(4.dp, 8.dp, 12.dp, 16.dp, 24.dp) }

private fun spacing(density: UiDensity) = when (density) {
    UiDensity.COMFORTABLE -> HalaqatiSpacing(6.dp, 10.dp, 14.dp, 18.dp, 28.dp)
    UiDensity.BALANCED -> HalaqatiSpacing(4.dp, 8.dp, 12.dp, 16.dp, 24.dp)
    UiDensity.COMPACT -> HalaqatiSpacing(3.dp, 6.dp, 9.dp, 12.dp, 18.dp)
}

private fun c(argb: Int) = Color(argb)

private val HalaqatiLight = HalaqatiPalette.LIGHT.let { r ->
    lightColorScheme(
        primary = c(r.primary), onPrimary = c(r.onPrimary),
        primaryContainer = c(r.primaryContainer), onPrimaryContainer = c(r.onPrimaryContainer),
        secondary = c(r.secondary), onSecondary = c(r.onSecondary),
        secondaryContainer = c(r.secondaryContainer), onSecondaryContainer = c(r.onSecondaryContainer),
        tertiary = c(r.tertiary), onTertiary = c(r.onTertiary),
        tertiaryContainer = c(r.tertiaryContainer), onTertiaryContainer = c(r.onTertiaryContainer),
        background = c(r.background), onBackground = c(r.onBackground),
        surface = c(r.surface), onSurface = c(r.onSurface),
        surfaceVariant = c(r.surfaceVariant), onSurfaceVariant = c(r.onSurfaceVariant),
        outline = c(r.outline), outlineVariant = c(r.outlineVariant),
        error = c(r.error), onError = c(r.onError),
        errorContainer = c(r.errorContainer), onErrorContainer = c(r.onErrorContainer),
    )
}

private val HalaqatiDark = HalaqatiPalette.DARK.let { r ->
    darkColorScheme(
        primary = c(r.primary), onPrimary = c(r.onPrimary),
        primaryContainer = c(r.primaryContainer), onPrimaryContainer = c(r.onPrimaryContainer),
        secondary = c(r.secondary), onSecondary = c(r.onSecondary),
        secondaryContainer = c(r.secondaryContainer), onSecondaryContainer = c(r.onSecondaryContainer),
        tertiary = c(r.tertiary), onTertiary = c(r.onTertiary),
        tertiaryContainer = c(r.tertiaryContainer), onTertiaryContainer = c(r.onTertiaryContainer),
        background = c(r.background), onBackground = c(r.onBackground),
        surface = c(r.surface), onSurface = c(r.onSurface),
        surfaceVariant = c(r.surfaceVariant), onSurfaceVariant = c(r.onSurfaceVariant),
        outline = c(r.outline), outlineVariant = c(r.outlineVariant),
        error = c(r.error), onError = c(r.onError),
        errorContainer = c(r.errorContainer), onErrorContainer = c(r.onErrorContainer),
    )
}

/** Semantic status colors (success / warning / danger / info / neutral) for the current light or dark scheme. */
@Composable
fun statusColors(kind: String): Pair<Color, Color> {
    val dark = MaterialTheme.colorScheme.background.luminance() < .5f
    val s = (if (dark) HalaqatiPalette.STATUS_DARK else HalaqatiPalette.STATUS_LIGHT).of(kind)
    return Color(s.bg) to Color(s.fg)
}

private val HalaqatiShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(HalaqatiUiTokens.RadiusSmall),
    medium = RoundedCornerShape(HalaqatiUiTokens.RadiusMedium),
    large = RoundedCornerShape(HalaqatiUiTokens.RadiusLarge),
    extraLarge = RoundedCornerShape(HalaqatiUiTokens.RadiusHero),
)

private fun readableOn(color: Color) = if (color.luminance() > .45f) Color(0xFF10201F) else Color.White

private fun blend(from: Color, to: Color, amount: Float): Color {
    val t = amount.coerceIn(0f, 1f)
    return Color(
        red = from.red + (to.red - from.red) * t,
        green = from.green + (to.green - from.green) * t,
        blue = from.blue + (to.blue - from.blue) * t,
        alpha = 1f,
    )
}

/** Preserve the selected hue in dark mode while lifting low-luminance accents to readable contrast. */
private fun darkReadableAccent(color: Color): Color =
    if (color.luminance() >= .34f) color else blend(color, Color.White, .55f)

@Composable
fun HalaqatiTheme(preferences: UiPreferences = UiPreferences.defaults(), content: @Composable () -> Unit) {
    val dark = when (preferences.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val selectedPrimary = Color(preferences.primaryArgb)
    val selectedAccent = Color(preferences.accentArgb)
    val primary = if (dark) darkReadableAccent(selectedPrimary) else selectedPrimary
    val accent = if (dark) darkReadableAccent(selectedAccent) else selectedAccent
    val base = if (dark) HalaqatiDark else HalaqatiLight
    val scheme = base.copy(
        primary = primary,
        onPrimary = readableOn(primary),
        secondary = accent,
        onSecondary = readableOn(accent),
        // Hero/container colors stay distinct from the page background in both modes.
        primaryContainer = if (dark) blend(selectedPrimary, Color.White, .16f) else base.primaryContainer,
        onPrimaryContainer = if (dark) Color(0xFFF0FFF7) else base.onPrimaryContainer,
    )
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalHalaqatiSpacing provides spacing(preferences.density),
    ) {
        MaterialTheme(
            colorScheme = scheme,
            typography = cairoTypography(),
            shapes = HalaqatiShapes,
            content = content,
        )
    }
}
