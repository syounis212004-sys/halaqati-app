# تقارير حلقتي v2.4

الجديد:
- تقرير يوم محدد.
- تقرير فترة من تاريخ إلى تاريخ.
- تقرير شهر محدد.
- جلب التقارير التاريخية من Supabase.
- تصدير PDF حقيقي.
- تصدير Excel.
- تصدير Word.
- تصدير PNG.
- في Android يتم تجهيز الملف وفتح نافذة الحفظ/المشاركة عبر Capacitor Filesystem + Share.

لا يحتاج هذا التحديث أي تغيير جديد في Google OAuth.
يبقى Deep Link:
com.mohammedsamir.halaqati://auth/callback
