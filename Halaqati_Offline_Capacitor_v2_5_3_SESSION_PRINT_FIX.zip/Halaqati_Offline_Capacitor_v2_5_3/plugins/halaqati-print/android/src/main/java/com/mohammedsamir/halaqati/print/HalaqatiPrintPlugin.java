package com.mohammedsamir.halaqati.print;

import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

@CapacitorPlugin(name = "HalaqatiPrint")
public class HalaqatiPrintPlugin extends Plugin {

    @PluginMethod
    public void printHtml(PluginCall call) {
        final String html = call.getString("html", "");
        final String jobName = call.getString("jobName", "Halaqati Report");
        final String orientation = call.getString("orientation", "portrait");

        if (html == null || html.trim().isEmpty()) {
            call.reject("Empty report HTML");
            return;
        }

        getActivity().runOnUiThread(() -> {
            try {
                final WebView printView = new WebView(getActivity());
                printView.getSettings().setJavaScriptEnabled(false);
                printView.getSettings().setLoadsImagesAutomatically(true);

                printView.setWebViewClient(new WebViewClient() {
                    private boolean printed = false;

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        if (printed) return;
                        printed = true;

                        view.postDelayed(() -> {
                            try {
                                PrintManager manager =
                                    (PrintManager) getActivity().getSystemService(Context.PRINT_SERVICE);

                                PrintDocumentAdapter adapter =
                                    printView.createPrintDocumentAdapter(jobName);

                                PrintAttributes.MediaSize media =
                                    "landscape".equalsIgnoreCase(orientation)
                                        ? PrintAttributes.MediaSize.ISO_A4.asLandscape()
                                        : PrintAttributes.MediaSize.ISO_A4.asPortrait();

                                PrintAttributes attrs = new PrintAttributes.Builder()
                                    .setMediaSize(media)
                                    .setResolution(new PrintAttributes.Resolution(
                                        "halaqati_pdf", "Halaqati PDF", 600, 600))
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build();

                                manager.print(jobName, adapter, attrs);
                                call.resolve(new JSObject());
                            } catch (Exception ex) {
                                call.reject("Print failed: " + ex.getMessage(), ex);
                            }
                        }, 1000);
                    }
                });

                printView.loadDataWithBaseURL(
                    "https://localhost/",
                    html,
                    "text/html",
                    "UTF-8",
                    null
                );
            } catch (Exception ex) {
                call.reject("Print setup failed: " + ex.getMessage(), ex);
            }
        });
    }
}
