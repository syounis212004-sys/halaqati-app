# إصلاح بناء Android في v2.5.1

سبب فشل v2.5:
إضافة الطباعة الأصلية كانت تعتمد على Capacitor Android بدون إضافة AndroidX AppCompat مباشرة،
فأثناء Gradle compile ظهر:
`class file for androidx.appcompat.app.AppCompatActivity not found`

الإصلاح:
- إضافة androidx.appcompat إلى halaqati-print.
- توحيد Java 21 مع Capacitor 8.
- استخدام minSdk الخاص بالمشروع مع fallback 24.

لا يوجد تغيير في Google Login أو Deep Link أو قاعدة البيانات.
