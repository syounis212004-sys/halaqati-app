package com.mohammedsamir.halaqati.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.R
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.ui.navigation.AppDestination
import com.mohammedsamir.halaqati.ui.navigation.RoleNavigationPolicy

private val GoldenGreen = Color(0xFF0A4A3F)
private val GoldenGreen2 = Color(com.mohammedsamir.halaqati.ui.theme.HalaqatiPalette.DEFAULT_PRIMARY)
private val GoldenGreen3 = Color(com.mohammedsamir.halaqati.ui.theme.HalaqatiPalette.DEFAULT_ACCENT)
private val GoldenMint = Color(0xFFE1F0EA)
private val GoldenLine = Color(0xFFD9E4DD)
private val GoldenMuted = Color(0xFF42564D)


data class GoldenShellActions(
    val roleLabel: String,
    val online: Boolean,
    val pending: Int,
    val openDrawer: () -> Unit,
    val openNotifications: () -> Unit,
    val openSyncCenter: () -> Unit,
)

val LocalGoldenShellActions = staticCompositionLocalOf<GoldenShellActions?> { null }

@DrawableRes
private fun goldenIconRes(key: String): Int = when (key) {
    "home" -> R.drawable.ic_gm_home
    "notifications" -> R.drawable.ic_gm_notifications
    "group", "halaqas" -> R.drawable.ic_gm_halaqas
    "forum", "community" -> R.drawable.ic_gm_community
    "event", "sessions" -> R.drawable.ic_gm_sessions
    "person", "students" -> R.drawable.ic_gm_students
    "timeline", "plans" -> R.drawable.ic_gm_plans
    "award", "certificates" -> R.drawable.ic_gm_certificates
    "report", "reports" -> R.drawable.ic_gm_reports
    "book", "quran" -> R.drawable.ic_gm_quran
    "leaderboard", "ranking", "rankings" -> R.drawable.ic_gm_ranking
    "competition" -> R.drawable.ic_gm_competition
    "importexport", "data" -> R.drawable.ic_gm_data
    "supervisor", "supervision" -> R.drawable.ic_gm_supervision
    "users" -> R.drawable.ic_gm_users
    "profile" -> R.drawable.ic_gm_profile
    "settings" -> R.drawable.ic_gm_settings
    "more" -> R.drawable.ic_gm_more
    else -> R.drawable.ic_gm_more
}

@Composable
fun GoldenNavIcon(
    key: String,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
) {
    Icon(
        painter = painterResource(goldenIconRes(key)),
        contentDescription = contentDescription,
        modifier = modifier,
        tint = tint,
    )
}

@Composable
fun GoldenBottomBar(
    role: UserRole,
    currentRoute: String,
    drawerOpen: Boolean,
    onNavigate: (AppDestination) -> Unit,
    onMore: () -> Unit,
    mode: com.mohammedsamir.halaqati.plans.WorkMode = com.mohammedsamir.halaqati.plans.WorkMode.REGULAR,
) {
    val items = RoleNavigationPolicy.bottom(role, mode)
    val coreRoutes = items.filterNot { it == AppDestination.More }.map { it.route }.toSet()
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = .98f),
        tonalElevation = 0.dp,
        shadowElevation = 0.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                // RC17: system inset is added OUTSIDE the bar height, so labels are never clipped
                // on gesture or 3-button navigation.
                .navigationBarsPadding()
                .height(68.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEach { destination ->
                val isMore = destination == AppDestination.More
                val selected = if (isMore) {
                    drawerOpen || currentRoute !in coreRoutes
                } else {
                    currentRoute == destination.route ||
                        (currentRoute == AppDestination.SessionToday.route && destination == AppDestination.Sessions)
                }
                val tint by animateColorAsState(
                    targetValue = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    animationSpec = tween(com.mohammedsamir.halaqati.ui.theme.motionMillis(180)),
                    label = "bottom-nav-tint",
                )
                val selectedBackground by animateColorAsState(
                    targetValue = if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
                    animationSpec = tween(com.mohammedsamir.halaqati.ui.theme.motionMillis(180)),
                    label = "bottom-nav-background",
                )
                val iconSize by animateDpAsState(
                    targetValue = if (selected) 24.dp else 22.dp,
                    animationSpec = if (com.mohammedsamir.halaqati.ui.theme.LocalReducedMotion.current) tween(0)
                    else spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
                    label = "bottom-nav-icon",
                )
                Box(
                    modifier = Modifier.weight(1f).fillMaxHeight().padding(horizontal = 4.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(17.dp))
                            .background(selectedBackground)
                            .clickable { if (isMore) onMore() else onNavigate(destination) }
                            .heightIn(min = 56.dp)
                            .padding(horizontal = 6.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                                                GoldenNavIcon(
                            key = destination.iconKey,
                            contentDescription = destination.label,
                            tint = tint,
                            modifier = Modifier.size(iconSize),
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            destination.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = tint,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

/**
 * RC27.21: the side menu is a calm "more hub" (the pattern Material and NN/g recommend when there are too many pages for the
 * bottom bar): a slim account row, then pages as a 3-column grid of icon tiles under five short headings, then one footer.
 * No pattern or art is drawn behind text, and every tile is a big touch target.
 */
private fun drawerGroupOf(destination: AppDestination): Int = when (destination) {
    AppDestination.Home, AppDestination.Sessions, AppDestination.SessionToday, AppDestination.Students,
    AppDestination.Plans, AppDestination.Halaqas -> 0
    AppDestination.Rankings, AppDestination.GuardianCompetition, AppDestination.GuardianAchievements,
    AppDestination.Certificates, AppDestination.Reports, AppDestination.Supervision, AppDestination.GuardianProfile -> 1
    AppDestination.Community, AppDestination.Quran, AppDestination.ImportExport -> 2
    AppDestination.Notifications, AppDestination.SyncCenter, AppDestination.Settings -> 4
    else -> 3
}

private val DRAWER_GROUP_TITLES = listOf("الأساسي", "المتابعة والإنجاز", "التواصل والأدوات", "الإدارة", "الحساب والنظام")
private val DrawerOnline = Color(0xFF2E9E5B)
private val DrawerOffline = Color(0xFFB7791F)

@Composable
fun GoldenDrawerContent(
    profile: Profile,
    currentRoute: String,
    onNavigate: (AppDestination) -> Unit,
    onClose: () -> Unit,
    onLogout: () -> Unit,
) {
    val drawerMode by com.mohammedsamir.halaqati.data.WorkModeHolder.state.collectAsState()
    val drawerEntries = remember(profile.role, drawerMode.mode) { RoleNavigationPolicy.drawerItems(profile.role, drawerMode.mode) }
    val chrome = LocalGoldenShellActions.current
    val online = chrome?.online != false
    val grouped = remember(drawerEntries) {
        drawerEntries.groupBy { drawerGroupOf(it.destination) }.toSortedMap()
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface),
    ) {
        // ---- Account row: plain primary band, art of the account type, name, role, connection. Nothing behind the text.
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(start = 16.dp, end = 6.dp, top = 12.dp, bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = .13f)),
                    contentAlignment = Alignment.Center,
                ) {
                    HalaqatiRoleArt(profile.role, size = 50.dp, onBand = true)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        profile.fullName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            roleTitle(profile.role),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .9f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        Box(
                            Modifier
                                .size(8.dp)
                                .clip(androidx.compose.foundation.shape.CircleShape)
                                .background(if (online) DrawerOnline else DrawerOffline),
                        )
                        Text(
                            if (online) "متصل" else "دون اتصال",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .85f),
                            maxLines = 1,
                        )
                    }
                }
                IconButton(onClick = onClose, modifier = Modifier.size(44.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق القائمة", tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }

        // The body owns the scroll; the footer stays reachable at all times.
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            grouped.forEach { (group, entries) ->
                item(key = "title-$group") {
                    Text(
                        DRAWER_GROUP_TITLES[group],
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(start = 4.dp, top = 12.dp, bottom = 2.dp),
                    )
                }
                items(entries.chunked(3), key = { row -> "row-" + row.first().destination.route }) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { entry ->
                            val destination = entry.destination
                            val active = currentRoute == destination.route ||
                                (currentRoute == AppDestination.SessionToday.route && destination == AppDestination.Sessions)
                            val badge = when (destination) {
                                AppDestination.Notifications, AppDestination.SyncCenter -> chrome?.pending ?: 0
                                else -> 0
                            }
                            val syncing = destination == AppDestination.SyncCenter && online && (chrome?.pending ?: 0) > 0
                            DrawerTile(
                                label = if (destination == AppDestination.SyncCenter && !online) "دون اتصال" else entry.label,
                                iconKey = destination.iconKey,
                                active = active,
                                badge = badge,
                                spinning = syncing,
                                offline = destination == AppDestination.SyncCenter && !online,
                                onClick = { onNavigate(destination) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            TextButton(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("تسجيل الخروج", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            Text(
                "صُنع بأيدٍ شرقية · الشرقية — خانيونس",
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                "Designed by : Dr. Mohammed Samir Abu Younis",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

@Composable
private fun DrawerTile(
    label: String,
    iconKey: String,
    active: Boolean,
    badge: Int,
    spinning: Boolean,
    offline: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.halaqatiPressable { onClick() },
        shape = RoundedCornerShape(18.dp),
        color = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f),
    ) {
        Column(
            Modifier.fillMaxWidth().heightIn(min = 96.dp).padding(horizontal = 6.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
        ) {
            BadgedBox(badge = { if (badge > 0) Badge { Text(badge.coerceAtMost(99).toString()) } }) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center,
                ) {
                    val tint = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary
                    when {
                        offline -> Icon(Icons.Default.CloudOff, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
                        iconKey == "sync" -> Icon(Icons.Default.Sync, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp).halaqatiSpin(spinning))
                        else -> GoldenNavIcon(iconKey, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
                    }
                }
            }
            Text(
                label,
                color = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

fun roleTitle(role: UserRole): String = when (role) {
    UserRole.ADMIN -> "مسؤول النظام والحلقات"
    UserRole.SUPERVISOR -> "مشرف الحلقات"
    UserRole.TEACHER -> "محفّظ الحلقة"
    UserRole.GUARDIAN -> "ولي الأمر"
    else -> "المستخدم"
}
