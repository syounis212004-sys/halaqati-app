package com.mohammedsamir.halaqati.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.plans.OrgInsightRules
import com.mohammedsamir.halaqati.ui.theme.statusColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.time.LocalDate

/** Insight data is live: refetch at most every 5 minutes (repo.table would otherwise serve its cache forever). */
private object InsightFreshness {
    private val last = HashMap<String, Long>()
    @Synchronized fun dueFor(key: String): Boolean {
        val now = System.currentTimeMillis()
        val due = now - (last[key] ?: 0L) > 5 * 60_000L
        if (due) last[key] = now
        return due
    }
}

private fun JSONArray.objs() = (0 until length()).mapNotNull { optJSONObject(it) }

private fun openGuardianMessage(context: Context, phone: String?, message: String) {
    val clean = phone?.filter { it.isDigit() || it == '+' }.orEmpty()
    val intent = if (clean.isNotBlank()) {
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$clean")).putExtra("sms_body", message)
    } else {
        Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, message), "إرسال رسالة لولي الأمر")
    }
    runCatching { context.startActivity(intent) }
}

/** RC27 home card: students absent from 3+ consecutive sessions, with a ready guardian message. */
@Composable
fun AbsenceStreakCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var rows by remember { mutableStateOf<List<Triple<String, Int, String?>>>(emptyList()) } // name, streak, phone
    var halaqaOf by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        runCatching {
            withContext(Dispatchers.IO) {
                if (!AppGraph.repo.online()) return@withContext emptyList<Triple<String, Int, String?>>() to emptyMap<String, String>()
                val from = LocalDate.now().minusDays(60).toString()
                val arr = AppGraph.repo.table(
                    "attendance_records",
                    "select=student_id,status,sessions!inner(session_date,status)&sessions.session_date=gte.$from&limit=5000",
                    forceRefresh = InsightFreshness.dueFor("absence"),
                )
                val att = arr.objs().mapNotNull { o ->
                    val s = o.optJSONObject("sessions") ?: return@mapNotNull null
                    OrgInsightRules.Attendance(o.optString("student_id"), s.optString("session_date"), o.optString("status"), s.optString("status") == "cancelled")
                }
                val students = AppGraph.repo.students(forceRefresh = false).filter { it.status == "active" }.associateBy { it.id }
                val halaqas = AppGraph.repo.table("halaqas", "select=id,name&limit=200").objs().associate { it.optString("id") to it.optString("name") }
                val streaks = OrgInsightRules.absenceStreaks(att).filter { it.studentId in students }
                streaks.map { st -> Triple(students.getValue(st.studentId).fullName, st.count, students.getValue(st.studentId).guardianPhone) } to
                    streaks.associate { st -> students.getValue(st.studentId).fullName to (halaqas[students.getValue(st.studentId).halaqaId].orEmpty()) }
            }
        }.onSuccess { (r, h) -> rows = r; halaqaOf = h }
    }
    if (rows.isEmpty()) return
    InsightCardShell(
        kind = "error",
        icon = Icons.Default.EventBusy,
        title = "غياب متكرر",
        summary = if (expanded) "غابوا 3 جلسات متتالية فأكثر" else rows.take(4).joinToString("، ") { it.first } + if (rows.size > 4) " …" else "",
        count = rows.size,
        expanded = expanded,
        onClick = { expanded = !expanded },
        modifier = modifier,
    ) {
        if (expanded) {
            rows.take(15).forEach { (name, count, phone) ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(name, fontWeight = FontWeight.SemiBold)
                        Text("غاب $count جلسات متتالية", style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { openGuardianMessage(context, phone, OrgInsightRules.guardianMessage(name, count, halaqaOf[name])) }) {
                        Text("رسالة للولي")
                    }
                }
            }
        }
    }
}

/** RC27 home card (admin/supervisor): this month's halaqas side by side. */
@Composable
fun HalaqaComparisonCard(modifier: Modifier = Modifier) {
    var stats by remember { mutableStateOf<List<OrgInsightRules.HalaqaStats>>(emptyList()) }
    var names by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var expanded by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        runCatching {
            withContext(Dispatchers.IO) {
                if (!AppGraph.repo.online()) return@withContext emptyList<OrgInsightRules.HalaqaStats>() to emptyMap<String, String>()
                val from = LocalDate.now().withDayOfMonth(1).toString()
                val fresh = InsightFreshness.dueFor("compare")
                val halaqas = AppGraph.repo.table("halaqas", "select=id,name,active&order=name.asc&limit=200").objs().filter { it.optBoolean("active", true) }
                if (halaqas.size < 2) return@withContext emptyList<OrgInsightRules.HalaqaStats>() to emptyMap<String, String>()
                val sessions = AppGraph.repo.table("sessions", "select=id,halaqa_id,session_date,status&session_date=gte.$from&limit=2000", forceRefresh = fresh).objs().map {
                    OrgInsightRules.HalaqaSession(it.optString("halaqa_id"), it.optString("session_date"), it.optString("status") == "cancelled")
                }
                val att = AppGraph.repo.table(
                    "attendance_records",
                    "select=status,sessions!inner(session_date,halaqa_id,status)&sessions.session_date=gte.$from&limit=5000",
                    forceRefresh = fresh,
                ).objs().mapNotNull { o ->
                    val s = o.optJSONObject("sessions") ?: return@mapNotNull null
                    if (s.optString("status") == "cancelled") null else OrgInsightRules.HalaqaAttendance(s.optString("halaqa_id"), o.optString("status"))
                }
                val rec = AppGraph.repo.table(
                    "recitation_entries",
                    "select=activity_type,pages_count,evaluation,sessions!inner(session_date,halaqa_id,status)&sessions.session_date=gte.$from&limit=5000",
                    forceRefresh = fresh,
                ).objs().mapNotNull { o ->
                    val s = o.optJSONObject("sessions") ?: return@mapNotNull null
                    if (s.optString("status") == "cancelled") null
                    else OrgInsightRules.HalaqaRecitation(s.optString("halaqa_id"), o.optString("activity_type"), o.optDouble("pages_count", 0.0), o.optString("evaluation"))
                }
                val students = AppGraph.repo.students(forceRefresh = false).filter { it.status == "active" }.groupBy { it.halaqaId.orEmpty() }.mapValues { it.value.size }
                OrgInsightRules.compare(halaqas.map { it.optString("id") }, students, sessions, att, rec) to
                    halaqas.associate { it.optString("id") to it.optString("name") }
            }
        }.onSuccess { (s, n) -> stats = s; names = n }
    }
    if (stats.isEmpty()) return
    InsightCardShell(
        kind = "neutral",
        icon = Icons.Default.Leaderboard,
        title = "مقارنة الحلقات هذا الشهر",
        summary = "${stats.size} حلقات · الحضور والجودة والإنجاز",
        expanded = expanded,
        onClick = { expanded = !expanded },
        modifier = modifier,
    ) {
        if (expanded) {
            // Ranked list: halaqas with data first (best attendance on top); a halaqa with no sessions yet is one quiet line.
            val ranked = stats.sortedWith(compareByDescending<OrgInsightRules.HalaqaStats> { it.sessions > 0 }.thenByDescending { it.attendancePercent ?: -1 })
            ranked.forEachIndexed { index, st ->
                if (index > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .7f))
                CompareRow(index + 1, names[st.halaqaId].orEmpty().ifBlank { "حلقة" }, st)
            }
        }
    }
}

@Composable
private fun CompareRow(rank: Int, name: String, st: OrgInsightRules.HalaqaStats) {
    val hasData = st.sessions > 0
    var open by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(enabled = hasData) { open = !open }.padding(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(30.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = if (hasData) .14f else .06f)),
                contentAlignment = Alignment.Center,
            ) {
                Text(rank.toString(), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (hasData) "${st.students} طالبًا · ${st.sessions} جلسات" else "${st.students} طالبًا · لا جلسات هذا الشهر بعد",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (hasData) {
            InsightMeter("الحضور", st.attendancePercent?.let { "$it٪" } ?: "—", st.attendancePercent?.let { it / 100f })
            InsightMeter("جودة التسميع", st.qualityPercent?.let { "$it٪" } ?: "—", st.qualityPercent?.let { it / 100f })
            if (open) {
                Text(
                    "صفحات/طالب %.1f".format(st.pagesPerStudent),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    "حفظ %.0f ص · مراجعة وتثبيت وسرد %.0f ص".format(st.hifzPages, st.reviewPages),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                Text("اضغط لعرض الصفحات", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .7f))
            }
        }
    }
}
