import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
const pkg=JSON.parse(read('package.json'));
const legacy=read('src/legacy/app.js'),core=read('src/core/runtime.js'),nav=read('src/core/navigation.js'),auth=read('src/features/auth/runtime.js'),students=read('src/features/students/runtime.js'),sessions=read('src/features/sessions/runtime.js'),settings=read('src/features/settings/runtime.js'),reports=read('src/features/reports/runtime.js'),vector=read('src/features/reports/vector-pdf-runtime.js'),main=read('src/main.js');
const s=[legacy,core,nav,auth,students,sessions,settings,reports,vector].join('\n');
const required=['function settingsPage()','function getThemePrefs()','function applySavedTheme()','function studentDirectoryRows()','async function exportStudentsExcel()','async function exportStudentsWord()','window.openStudentsPdfPreview=function()','window.openReportPreview=function()','applyAutoFitPdfTables','window.downloadReportPdfFromPreview=async function()'];
for(const token of required){if(!s.includes(token)){console.error('MISSING:',token);process.exit(1)}}
if(pkg.version!=='2.40.4'||!core.includes("const APP_VERSION_NAME='2.40.4';")||!core.includes('const APP_VERSION_CODE=24004;')){console.error('Version mismatch');process.exit(1)}
if(!main.includes('halaqati-vector-pdf-runtime')){console.error('Vector PDF runtime not loaded');process.exit(1)}
for(const token of ['HalaqatiPdf','@page','table-header-group','break-inside:avoid','buildVectorHtml'])if(!vector.includes(token)){console.error('Vector PDF regression:',token);process.exit(1)}
if(/html2canvas|new\s+jsPDF|\.addImage\(/.test(vector)){console.error('Raster PDF code leaked into v2.40.4 final export layer');process.exit(1)}
if(!reports.includes("paper.dataset.orientation=orientation.value")||!reports.includes("paper.style.fontFamily=font.value+', sans-serif'")||!reports.includes('paper.style.color=textColor.value')||!reports.includes('el.style.color=accent.value')||!reports.includes('contenteditable="true"')){console.error('PDF preview controls regression');process.exit(1)}
const dataStart=legacy.indexOf('function dataPage(){'),dataEnd=legacy.indexOf('\n',dataStart),dataBlock=legacy.slice(dataStart,dataEnd);
if(dataBlock.includes('exportReportsExcel()')||!dataBlock.includes('exportStudentsExcel()')||!dataBlock.includes('exportStudentsWord()')||!dataBlock.includes('openStudentsPdfPreview()')){console.error('Student export actions regression');process.exit(1)}
console.log('Regression checks passed: legacy features + preview controls + Auto-fit + v2.40.4 Chromium vector PDF.');
