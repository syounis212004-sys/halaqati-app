/* Halaqati Vector PDF Engine — v2.13.1
 * High-quality vector renderer for report pages.
 * - Uses the preview DOM as the single source of truth for sizes/colors/layout.
 * - Draws text, table cells, borders and fills as PDF vectors.
 * - Falls back safely to the legacy 300-DPI raster renderer when a page contains
 *   unsupported rich media or when the selected preview font is not Cairo.
 */
(function(){
  'use strict';

  const ENGINE_VERSION='2.13.1-vector-hq';
  const FONT_REGULAR='./core/fonts/cairo-pdf-regular.ttf';
  const FONT_BOLD='./core/fonts/cairo-pdf-bold.ttf';
  const FONT_FAMILY='HalaqatiCairo';
  const fontCache=new Map();

  function clamp(n,min,max){return Math.max(min,Math.min(max,n))}
  function normText(v){return String(v??'').replace(/[\u200e\u200f\ufeff]/g,'').replace(/\s+/g,' ').trim()}
  function hasArabic(s){return /[\u0600-\u06ff\u0750-\u077f\u08a0-\u08ff]/.test(String(s||''))}
  function bytesToBase64(bytes){let out='';const size=0x8000;for(let i=0;i<bytes.length;i+=size)out+=String.fromCharCode(...bytes.subarray(i,Math.min(bytes.length,i+size)));return btoa(out)}

  async function fetchFont(url){
    if(!fontCache.has(url)){
      fontCache.set(url,(async()=>{
        const r=await fetch(url,{cache:'force-cache'});
        if(!r.ok)throw new Error('تعذر تحميل خط PDF المتجهي');
        const bytes=new Uint8Array(await r.arrayBuffer());
        if(bytes.length<50000)throw new Error('ملف خط PDF المتجهي غير صالح');
        return bytesToBase64(bytes);
      })());
    }
    return fontCache.get(url);
  }

  async function ensureFonts(pdf){
    const [regular,bold]=await Promise.all([fetchFont(FONT_REGULAR),fetchFont(FONT_BOLD)]);
    try{pdf.addFileToVFS('HalaqatiCairo-Regular.ttf',regular)}catch(_e){}
    try{pdf.addFont('HalaqatiCairo-Regular.ttf',FONT_FAMILY,'normal')}catch(_e){}
    try{pdf.addFileToVFS('HalaqatiCairo-Bold.ttf',bold)}catch(_e){}
    try{pdf.addFont('HalaqatiCairo-Bold.ttf',FONT_FAMILY,'bold')}catch(_e){}
    pdf.setFont(FONT_FAMILY,'normal');
    try{pdf.setLanguage?.('ar')}catch(_e){}
    try{pdf.viewerPreferences?.({Direction:'R2L',PrintScaling:'None'})}catch(_e){}
    return FONT_FAMILY;
  }

  function parseCssColor(value){
    const v=String(value||'').trim().toLowerCase();
    if(!v||v==='transparent'||v==='rgba(0, 0, 0, 0)'||v==='rgba(0,0,0,0)')return null;
    let m=v.match(/^#([0-9a-f]{3})$/i);if(m){return m[1].split('').map(x=>parseInt(x+x,16))}
    m=v.match(/^#([0-9a-f]{6})$/i);if(m){return [parseInt(m[1].slice(0,2),16),parseInt(m[1].slice(2,4),16),parseInt(m[1].slice(4,6),16)]}
    m=v.match(/^rgba?\(\s*([\d.]+)[, ]+\s*([\d.]+)[, ]+\s*([\d.]+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/i);
    if(m){if(m[4]!==undefined&&Number(m[4])<.03)return null;return [clamp(Math.round(Number(m[1])),0,255),clamp(Math.round(Number(m[2])),0,255),clamp(Math.round(Number(m[3])),0,255)]}
    return null;
  }

  function borderInfo(style,side){
    const cap=side[0].toUpperCase()+side.slice(1);
    const width=parseFloat(style[`border${cap}Width`]||'0')||0;
    const type=style[`border${cap}Style`];
    const color=parseCssColor(style[`border${cap}Color`]);
    return width>0&&type!=='none'&&color?{width,color}:null;
  }

  function pxBox(rect,root){return {x:rect.left-root.left,y:rect.top-root.top,w:rect.width,h:rect.height}}
  function mapBox(box,map){return {x:map.x+box.x*map.scale,y:map.y+box.y*map.scale,w:box.w*map.scale,h:box.h*map.scale}}
  function sameish(a,b,eps=.15){return Math.abs(a-b)<=eps}

  function drawElementBox(pdf,el,root,map){
    const style=getComputedStyle(el);
    if(style.display==='none'||style.visibility==='hidden'||Number(style.opacity||1)===0)return;
    const r=el.getBoundingClientRect();
    if(r.width<.5||r.height<.5)return;
    const b=mapBox(pxBox(r,root),map);
    if(b.x>map.pageRight||b.y>map.pageBottom||b.x+b.w<map.pageLeft||b.y+b.h<map.pageTop)return;
    const bg=parseCssColor(style.backgroundColor);
    const radiusPx=Math.max(parseFloat(style.borderTopLeftRadius)||0,parseFloat(style.borderTopRightRadius)||0,parseFloat(style.borderBottomRightRadius)||0,parseFloat(style.borderBottomLeftRadius)||0);
    const rad=Math.min(b.w/2,b.h/2,radiusPx*map.scale);
    if(bg){pdf.setFillColor(...bg);if(rad>.15)pdf.roundedRect(b.x,b.y,b.w,b.h,rad,rad,'F');else pdf.rect(b.x,b.y,b.w,b.h,'F')}

    const top=borderInfo(style,'top'),right=borderInfo(style,'right'),bottom=borderInfo(style,'bottom'),left=borderInfo(style,'left');
    const all=top&&right&&bottom&&left&&top.color.join(',')===right.color.join(',')&&top.color.join(',')===bottom.color.join(',')&&top.color.join(',')===left.color.join(',')&&sameish(top.width,right.width)&&sameish(top.width,bottom.width)&&sameish(top.width,left.width);
    if(all){pdf.setDrawColor(...top.color);pdf.setLineWidth(Math.max(.05,top.width*map.scale));if(rad>.15)pdf.roundedRect(b.x,b.y,b.w,b.h,rad,rad,'S');else pdf.rect(b.x,b.y,b.w,b.h,'S');return}
    const side=(info,x1,y1,x2,y2)=>{if(!info)return;pdf.setDrawColor(...info.color);pdf.setLineWidth(Math.max(.05,info.width*map.scale));pdf.line(x1,y1,x2,y2)};
    side(top,b.x,b.y,b.x+b.w,b.y);side(right,b.x+b.w,b.y,b.x+b.w,b.y+b.h);side(bottom,b.x,b.y+b.h,b.x+b.w,b.y+b.h);side(left,b.x,b.y,b.x,b.y+b.h);
  }

  function isTextVisible(el){
    const s=getComputedStyle(el);return s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)!==0&&parseFloat(s.fontSize||'0')>0;
  }

  function fontStyleFor(el){
    const s=getComputedStyle(el);const n=parseInt(s.fontWeight,10);return Number.isFinite(n)&&n>=600||/bold/i.test(s.fontWeight)||el.matches?.('b,strong,th')?'bold':'normal';
  }

  function textColorFor(el){return parseCssColor(getComputedStyle(el).color)||[24,35,31]}
  function textAlignFor(el,text){
    const s=getComputedStyle(el),a=s.textAlign;
    if(a==='center')return 'center';if(a==='right'||a==='end')return 'right';if(a==='left'||a==='start')return 'left';
    return s.direction==='rtl'||hasArabic(text)?'right':'left';
  }

  function setPdfTextStyle(pdf,el,map){
    const s=getComputedStyle(el);const px=parseFloat(s.fontSize)||11;const pt=clamp(px*map.scale*(72/25.4),4,48);
    pdf.setFont(FONT_FAMILY,fontStyleFor(el));pdf.setFontSize(pt);pdf.setTextColor(...textColorFor(el));
    const lh=parseFloat(s.lineHeight);pdf.setLineHeightFactor(Number.isFinite(lh)&&lh>0?clamp(lh/px,1,1.7):1.22);
    return {pt,px};
  }

  function fitLines(pdf,text,maxW,maxH,basePt){
    let pt=basePt,lines=[text];
    for(let i=0;i<7;i++){
      pdf.setFontSize(pt);
      try{lines=pdf.splitTextToSize(text,Math.max(1,maxW))||[text]}catch(_e){lines=[text]}
      const lineH=(pt*1.22)*(25.4/72),need=lineH*Math.max(1,lines.length);
      if(need<=maxH+.15)return {pt,lines,lineH};
      pt=Math.max(4,pt*.90);
    }
    const lineH=(pt*1.15)*(25.4/72);return {pt,lines,lineH};
  }

  function drawTableCellText(pdf,cell,root,map){
    const text=normText(cell.textContent);if(!text||!isTextVisible(cell))return 0;
    const r=cell.getBoundingClientRect();if(r.width<1||r.height<1)return 0;
    const b=mapBox(pxBox(r,root),map);const s=getComputedStyle(cell);
    const pl=(parseFloat(s.paddingLeft)||0)*map.scale,pr=(parseFloat(s.paddingRight)||0)*map.scale,ptop=(parseFloat(s.paddingTop)||0)*map.scale,pbot=(parseFloat(s.paddingBottom)||0)*map.scale;
    const inner={x:b.x+pl,y:b.y+ptop,w:Math.max(1,b.w-pl-pr),h:Math.max(1,b.h-ptop-pbot)};
    const base=setPdfTextStyle(pdf,cell,map).pt;
    const bold=cell.querySelector('b,strong');if(bold)pdf.setFont(FONT_FAMILY,'bold');
    const fitted=fitLines(pdf,text,inner.w,inner.h,base);pdf.setFontSize(fitted.pt);
    const align=textAlignFor(cell,text);let x=align==='right'?inner.x+inner.w:align==='center'?inner.x+inner.w/2:inner.x;
    const totalH=fitted.lineH*Math.max(1,fitted.lines.length),startY=inner.y+Math.max(0,(inner.h-totalH)/2)+fitted.lineH*.78;
    try{pdf.text(fitted.lines,x,startY,{align,baseline:'alphabetic'});return 1}catch(e){console.warn('vector table text skipped',e);return 0}
  }

  function textNodeRect(node){
    try{const range=document.createRange();range.selectNodeContents(node);const r=range.getBoundingClientRect();range.detach?.();return r}catch(_e){return null}
  }

  function drawTextNode(pdf,node,root,map){
    const text=normText(node.nodeValue);const el=node.parentElement;if(!text||!el||!isTextVisible(el)||el.closest('td,th'))return 0;
    const r=textNodeRect(node);if(!r||r.width<.5||r.height<.5)return 0;
    const b=mapBox(pxBox(r,root),map);const base=setPdfTextStyle(pdf,el,map).pt;
    const align=textAlignFor(el,text);let x=align==='right'?b.x+b.w:align==='center'?b.x+b.w/2:b.x;
    // Range geometry already reflects browser alignment. Keep wrapping conservative.
    const fitted=fitLines(pdf,text,Math.max(1,b.w),Math.max(1,b.h*1.35),base);pdf.setFontSize(fitted.pt);
    let y=b.y+Math.min(b.h*.80,(fitted.pt*(25.4/72))*.95);
    try{pdf.text(fitted.lines,x,y,{align,baseline:'alphabetic'});return 1}catch(e){console.warn('vector text skipped',e);return 0}
  }

  function drawAllBoxes(pdf,element,root,map){
    const nodes=[element,...element.querySelectorAll('*')];
    for(const el of nodes){
      if(el.nodeType!==1||el.matches('script,style,link,meta,img,canvas,svg,video,audio'))continue;
      const s=getComputedStyle(el);const hasBg=!!parseCssColor(s.backgroundColor);const hasBorder=['top','right','bottom','left'].some(side=>borderInfo(s,side));
      if(hasBg||hasBorder)drawElementBox(pdf,el,root,map);
    }
  }

  function drawAllText(pdf,element,root,map){
    let count=0;
    for(const cell of element.querySelectorAll('th,td'))count+=drawTableCellText(pdf,cell,root,map);
    const walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT,{acceptNode(node){return normText(node.nodeValue)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}});
    let node;while((node=walker.nextNode()))count+=drawTextNode(pdf,node,root,map);
    return count;
  }

  function pageHasUnsupportedRichMedia(element){return !!element.querySelector('img,canvas,svg,video,audio,iframe')}

  async function waitForPaint(){try{if(document.fonts?.ready)await document.fonts.ready}catch(_e){}await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))}

  async function renderPage(pdf,element,opts={}){
    const {pageW,pageH,margin=7,stage}=opts;
    if(!stage)throw new Error('Vector render stage is missing');
    stage.replaceChildren(element);element.style.visibility='visible';element.style.opacity='1';element.style.display='block';element.style.transform='none';stage.style.width=Math.max(1,element.scrollWidth)+'px';
    await waitForPaint();
    if(pageHasUnsupportedRichMedia(element))return {ok:false,reason:'rich-media'};
    const root=element.getBoundingClientRect();if(root.width<10||root.height<10)return {ok:false,reason:'empty-layout'};
    const boxW=pageW-margin*2,boxH=pageH-margin*2,scale=Math.min(boxW/root.width,boxH/root.height);
    const outW=root.width*scale,outH=root.height*scale;
    const map={scale,x:margin+(boxW-outW)/2,y:margin,pageLeft:margin,pageTop:margin,pageRight:margin+boxW,pageBottom:margin+boxH};
    pdf.setFillColor(255,255,255);pdf.rect(0,0,pageW,pageH,'F');
    drawAllBoxes(pdf,element,root,map);
    const textCount=drawAllText(pdf,element,root,map);
    if(textCount===0&&normText(element.textContent))return {ok:false,reason:'no-text-rendered'};
    return {ok:true,textCount,scale,outW,outH};
  }

  async function renderDocument({pdf,pages,stage,pageW,pageH,margin=7,onProgress}){
    await ensureFonts(pdf);
    let rendered=0;
    for(let i=0;i<pages.length;i++){
      if(i>0)pdf.addPage('a4',pageW>pageH?'landscape':'portrait');
      onProgress?.(i+1,pages.length);
      const result=await renderPage(pdf,pages[i],{pageW,pageH,margin,stage});
      if(!result.ok)return {ok:false,index:i,reason:result.reason,rendered};
      rendered++;
      stage.replaceChildren();
      await new Promise(r=>setTimeout(r,0));
    }
    return {ok:true,rendered};
  }

  window.HalaqatiVectorPdf={version:ENGINE_VERSION,ensureFonts,renderPage,renderDocument,pageHasUnsupportedRichMedia};
  console.info('Halaqati vector PDF engine loaded',ENGINE_VERSION);
})();
