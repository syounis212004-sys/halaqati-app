import fs from 'node:fs';

const engine=fs.readFileSync('src/features/reports/vector-engine.js','utf8');
const runtime=fs.readFileSync('src/features/reports/runtime.js','utf8');
const main=fs.readFileSync('src/main.js','utf8');
const vendor=fs.readFileSync('scripts/fetch-vendor.mjs','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const legacy=fs.readFileSync('src/legacy/app.js','utf8');

function ok(v,msg){if(!v){console.error('VECTOR_PDF_CHECK_FAIL:',msg);process.exit(1)}console.log('OK:',msg)}

ok(pkg.version==='2.13.1','package version is 2.13.1');
ok(legacy.includes("const APP_VERSION_NAME='2.13.1';")&&legacy.includes('const APP_VERSION_CODE=21301;'),'legacy version matches 2.13.1');
ok(engine.includes("const ENGINE_VERSION='2.13.1-vector-hq'"),'vector engine sentinel exists');
ok(engine.includes("const FONT_FAMILY='HalaqatiCairo'"),'embedded Cairo vector family configured');
ok(engine.includes('drawAllBoxes(pdf,element,root,map)'),'vector shapes renderer exists');
ok(engine.includes('drawAllText(pdf,element,root,map)'),'vector text renderer exists');
ok(engine.includes("element.querySelectorAll('th,td')"),'table cells are rendered as real PDF text');
ok(engine.includes("pageHasUnsupportedRichMedia"),'rich-media safety detector exists');
ok(runtime.includes('async function downloadVectorPdfFromPreview()'),'vector exporter is connected');
ok(runtime.includes('async function downloadRasterPdfFromPreview()'),'proven 300-DPI compatibility exporter is preserved');
ok(runtime.includes("return font==='Cairo'&&!!window.HalaqatiVectorPdf?.renderPage"),'Cairo preview uses vector engine without changing other font behavior');
ok(runtime.includes("say('تم التحويل تلقائياً إلى وضع الجودة العالية المتوافق لضمان سلامة التقرير')"),'automatic safe fallback is present');
ok(runtime.includes("const result=await window.HalaqatiVectorPdf.renderPage"),'edited preview DOM is sent to vector engine');
ok(main.includes("import vectorPdfEngineUrl from './features/reports/vector-engine.js?url'"),'main imports isolated vector engine');
const vectorPos=main.indexOf("loadClassicScript(vectorPdfEngineUrl");
const runtimePos=main.indexOf("loadClassicScript(reportsRuntimeUrl");
ok(vectorPos>=0&&runtimePos>vectorPos,'vector engine loads before reports runtime');
ok(vendor.includes('cairo-pdf-regular.ttf')&&vendor.includes('Cairo-Regular.ttf'),'static Cairo regular font bundled');
ok(vendor.includes('cairo-pdf-bold.ttf')&&vendor.includes('Cairo-Bold.ttf'),'static Cairo bold font bundled');
console.log('VECTOR_PDF_CHECK_PASS');
