import fs from 'node:fs';
import assert from 'node:assert/strict';
const read=p=>fs.readFileSync(p,'utf8');
const pkg=JSON.parse(read('package.json'));
const core=read('src/core/runtime.js');
const reports=read('src/features/reports/runtime.js');
assert.equal(pkg.version,'2.40.2');
assert.ok(core.includes("APP_VERSION_NAME='2.40.2'")&&core.includes('APP_VERSION_CODE=24002'));
assert.ok(reports.includes("const PDF_TARGET_DPI=300")&&reports.includes('PDF_PRINT_SCALE=PDF_TARGET_DPI/PDF_CSS_DPI'),'300-DPI output must remain');
assert.ok(reports.includes("const PDF_PNG_COMPRESSION='NONE'"),'lossless PNG pipeline must remain');
assert.ok(reports.includes('PDF_NATIVE_TILE_MAX_PIXELS=1_500_000')&&reports.includes('pdfTilePixelBudget()'),'native PDF tile memory budget is required');
assert.ok(reports.includes('addPdfSegmentTiled')&&reports.includes('renderPdfTile'),'PDF must render in bounded tiles instead of one giant Android canvas');
assert.ok(reports.includes("canvas.toBlob")&&reports.includes("new Uint8Array(buffer)")&&reports.includes("pdf.addImage(pngBytes,'PNG'"),'PNG tiles must avoid data-URL/base64 expansion');
assert.ok(reports.includes("const pdf=new jsPDF({orientation,unit:'mm',format:'a4',compress:false"),'PDF stream compression must not create extra transient mobile memory');
assert.ok(reports.includes("pdf.output('arraybuffer')")&&reports.includes("fs.appendFile")&&reports.includes('chunkSize=192*1024'),'native file save must stream base64 chunks instead of one giant data URL');
const fn=reports.slice(reports.indexOf('window.downloadReportPdfFromPreview=async function(){'),reports.indexOf('/* Clicking PDF now opens'));
assert.ok(fn.includes('addElementMemorySafePages'),'download path must use memory-safe renderer');
assert.ok(!fn.includes("toDataURL('image/png')"),'download path must not create full-page PNG data URLs');
assert.ok(!fn.includes('blobToBase64'),'download path must not duplicate the whole PDF through FileReader base64');
for(const file of [
  'plugins/halaqati-updater/android/src/main/java/com/mohammedsamir/halaqati/updater/HalaqatiUpdaterPlugin.java',
  'plugins/halaqati-updater/android/src/main/java/com/mohammedsamir/halaqati/updater/HalaqatiUpdateFileProvider.java',
  'plugins/halaqati-deeplink/android/src/main/java/com/mohammedsamir/halaqati/deeplink/HalaqatiDeepLinkPlugin.java'
]) assert.ok(fs.existsSync(file)&&fs.statSync(file).size>100,`native plugin missing: ${file}`);
console.log('HALAQATI_V2402_PDF_STABILITY_CHECK_PASS');
