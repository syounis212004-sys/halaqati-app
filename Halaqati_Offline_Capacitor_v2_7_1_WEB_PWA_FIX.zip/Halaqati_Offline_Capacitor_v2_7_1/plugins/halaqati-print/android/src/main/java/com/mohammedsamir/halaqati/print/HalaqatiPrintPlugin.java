package com.mohammedsamir.halaqati.print;

import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "HalaqatiPrint")
public class HalaqatiPrintPlugin extends Plugin {
    private WebView activePrintView;
    private FrameLayout printHost;

    private void cleanupPrintView() {
        getActivity().runOnUiThread(() -> {
            try {
                if (activePrintView != null) {
                    ViewGroup parent = (ViewGroup) activePrintView.getParent();
                    if (parent != null) parent.removeView(activePrintView);
                    activePrintView.stopLoading();
                    activePrintView.destroy();
                }
            } catch (Exception ignored) {}
            activePrintView = null;
            try {
                if (printHost != null) {
                    ViewGroup parent = (ViewGroup) printHost.getParent();
                    if (parent != null) parent.removeView(printHost);
                }
            } catch (Exception ignored) {}
            printHost = null;
        });
    }

    private PrintAttributes attributesFor(String orientation) {
        PrintAttributes.MediaSize media = "landscape".equalsIgnoreCase(orientation)
            ? PrintAttributes.MediaSize.ISO_A4.asLandscape()
            : PrintAttributes.MediaSize.ISO_A4.asPortrait();
        return new PrintAttributes.Builder()
            .setMediaSize(media)
            .setResolution(new PrintAttributes.Resolution("halaqati_pdf", "Halaqati PDF", 600, 600))
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build();
    }

    private void prepareWebView(String html, ReadyCallback callback) {
        cleanupPrintView();
        getActivity().runOnUiThread(() -> {
            try {
                FrameLayout decor = (FrameLayout) getActivity().getWindow().getDecorView().findViewById(android.R.id.content);
                printHost = new FrameLayout(getActivity());
                printHost.setBackgroundColor(Color.TRANSPARENT);
                printHost.setAlpha(0.01f);
                printHost.setTranslationX(-6000f);
                FrameLayout.LayoutParams hostParams = new FrameLayout.LayoutParams(1600, 2300);
                decor.addView(printHost, hostParams);

                activePrintView = new WebView(getActivity());
                activePrintView.setBackgroundColor(Color.WHITE);
                activePrintView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                printHost.addView(activePrintView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                WebSettings settings = activePrintView.getSettings();
                settings.setJavaScriptEnabled(false);
                settings.setLoadsImagesAutomatically(true);
                settings.setBlockNetworkImage(false);
                settings.setBlockNetworkLoads(false);
                settings.setDefaultTextEncodingName("UTF-8");
                settings.setUseWideViewPort(true);
                settings.setLoadWithOverviewMode(false);
                settings.setSupportZoom(false);

                activePrintView.setWebViewClient(new WebViewClient() {
                    private boolean ready = false;
                    @Override public void onPageFinished(WebView view, String url) {
                        if (ready) return;
                        ready = true;
                        Runnable signal = () -> view.postDelayed(() -> callback.onReady(view), 1600);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            view.postVisualStateCallback(707L, new WebView.VisualStateCallback() {
                                @Override public void onComplete(long requestId) { signal.run(); }
                            });
                        } else signal.run();
                    }
                });
                activePrintView.loadDataWithBaseURL("https://appassets.androidplatform.net/", html, "text/html", "UTF-8", null);
            } catch (Exception e) { callback.onError(e); }
        });
    }

    @PluginMethod
    public void createPdf(PluginCall call) {
        final String html = call.getString("html", "");
        final String jobName = call.getString("jobName", "Halaqati Report");
        final String orientation = call.getString("orientation", "portrait");
        if (html == null || html.trim().isEmpty()) { call.reject("Empty report HTML"); return; }

        final AtomicBoolean terminal = new AtomicBoolean(false);
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(() -> {
            if (terminal.compareAndSet(false, true)) {
                cleanupPrintView();
                call.reject("PDF generation timed out. Try again with fewer images or after reconnecting to the internet.");
            }
        }, 120000);

        prepareWebView(html, new ReadyCallback() {
            @Override public void onReady(WebView view) {
                try {
                    PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(jobName);
                    PrintAttributes attrs = attributesFor(orientation);
                    CancellationSignal layoutSignal = new CancellationSignal();
                    adapter.onStart();
                    adapter.onLayout(null, attrs, layoutSignal, new PrintDocumentAdapter.LayoutResultCallback() {
                        @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                            try {
                                File dir = new File(getActivity().getCacheDir(), "halaqati_exports");
                                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create export directory");
                                String safe = "Halaqati_Report_" + System.currentTimeMillis() + ".pdf";
                                File out = new File(dir, safe);
                                ParcelFileDescriptor pfd = ParcelFileDescriptor.open(out, ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_READ_WRITE);
                                CancellationSignal writeSignal = new CancellationSignal();
                                adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, pfd, writeSignal, new PrintDocumentAdapter.WriteResultCallback() {
                                    private void closeFd() { try { pfd.close(); } catch (Exception ignored) {} }
                                    @Override public void onWriteFinished(PageRange[] pages) {
                                        closeFd();adapter.onFinish();
                                        long size = out.length();
                                        if (size <= 0) {
                                            if (terminal.compareAndSet(false,true)) { cleanupPrintView();call.reject("Generated PDF is empty"); }
                                            return;
                                        }
                                        if (terminal.compareAndSet(false,true)) {
                                            JSObject result = new JSObject();
                                            result.put("uri", Uri.fromFile(out).toString());
                                            result.put("size", size);
                                            result.put("name", safe);
                                            call.resolve(result);
                                            view.postDelayed(() -> cleanupPrintView(), 1500);
                                        }
                                    }
                                    @Override public void onWriteFailed(CharSequence error) { closeFd();adapter.onFinish();if (terminal.compareAndSet(false,true)){cleanupPrintView();call.reject("PDF write failed: "+String.valueOf(error));} }
                                    @Override public void onWriteCancelled() { closeFd();adapter.onFinish();if (terminal.compareAndSet(false,true)){cleanupPrintView();call.reject("PDF generation cancelled");} }
                                });
                            } catch (Exception e) { adapter.onFinish();if (terminal.compareAndSet(false,true)){cleanupPrintView();call.reject("PDF file setup failed: "+e.getMessage(),e);} }
                        }
                        @Override public void onLayoutFailed(CharSequence error) { adapter.onFinish();if (terminal.compareAndSet(false,true)){cleanupPrintView();call.reject("PDF layout failed: "+String.valueOf(error));} }
                        @Override public void onLayoutCancelled() { adapter.onFinish();if (terminal.compareAndSet(false,true)){cleanupPrintView();call.reject("PDF layout cancelled");} }
                    }, new Bundle());
                } catch (Exception e) { if (terminal.compareAndSet(false,true)){cleanupPrintView();call.reject("PDF generation failed: "+e.getMessage(),e);} }
            }
            @Override public void onError(Exception e) { if (terminal.compareAndSet(false,true)){cleanupPrintView();call.reject("PDF WebView failed: "+e.getMessage(),e);} }
        });
    }

    @PluginMethod
    public void printHtml(PluginCall call) { createPdf(call); }

    private interface ReadyCallback { void onReady(WebView view); void onError(Exception e); }

    @Override protected void handleOnDestroy() { cleanupPrintView(); }
}
