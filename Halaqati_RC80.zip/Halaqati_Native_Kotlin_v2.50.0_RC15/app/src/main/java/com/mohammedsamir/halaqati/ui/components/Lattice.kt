package com.mohammedsamir.halaqati.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

private fun starPath(r: Float): Path = Path().apply {
    for (i in 0 until 16) {
        val ang = Math.toRadians(i * 22.5 - 90.0)
        val rad = if (i % 2 == 0) r else r * 0.765f
        val x = (rad * cos(ang)).toFloat()
        val y = (rad * sin(ang)).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

/**
 * RC67: a faint tiling of eight-pointed stars (the geometric lattice of Islamic ornament) drawn behind a band.
 * It only paints; it never carries information, so it stays at a low alpha and never reduces text contrast below 4.5:1
 * (callers use it on the solid emerald band, where white text sits at >= 7:1).
 */
fun Modifier.latticeOverlay(color: Color = Color.White, alpha: Float = .09f, cell: Dp = 30.dp): Modifier = this.clipToBounds().drawBehind {
    val c = cell.toPx()
    val star = starPath(c * 0.36f)
    val stroke = Stroke(width = 1.dp.toPx())
    var row = 0
    var y = 0f
    while (y <= size.height + c) {
        val shift = if (row % 2 == 0) 0f else c / 2f
        var x = -c + shift
        while (x <= size.width + c) {
            translate(x, y) { drawPath(star, color.copy(alpha = alpha), style = stroke) }
            x += c
        }
        y += c / 2f
        row++
    }
}

/** A thin lattice strip that closes the top bar of every page. */
@Composable
fun LatticeStrip(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(9.dp).latticeOverlay(MaterialTheme.colorScheme.primary, alpha = .5f, cell = 12.dp))
        HorizontalDivider(Modifier.align(androidx.compose.ui.Alignment.BottomStart), thickness = 1.dp, color = MaterialTheme.colorScheme.primary.copy(alpha = .25f))
    }
}
