package com.mohammedsamir.halaqati.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/**
 * RC75: the top of the teacher / admin home. One rich emerald card instead of a plain white note plus a grey button:
 * the day's message with its icon, the numbers that matter (present, waiting), and one clear start button.
 * While data is loading the button says so (it never claims "day off"), and a day off is shown in plain words.
 */
@Composable
fun TodayHeroCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    loaded: Boolean,
    offDay: Boolean,
    waitingForSession: Boolean,
    present: Int,
    waiting: Int,
    onStart: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), color = Color.Transparent) {
        Column(
            Modifier.background(HalaqatiGradients.Deep.brush()).girih(Color.White, .16f, 44.dp).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                GradientIcon(icon, HalaqatiGradients.Gold, tile = 56.dp, glyph = 30.dp)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = .95f), maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
            if (loaded && !offDay) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeroNumber("حاضر اليوم", present.toString(), Modifier.weight(1f))
                HeroNumber("بانتظارك", waiting.toString(), Modifier.weight(1f))
            }
            Button(
                onClick = onStart,
                enabled = loaded && !offDay,
                modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White, contentColor = Color(0xFF0B6E4F),
                    disabledContainerColor = Color.White.copy(alpha = .92f), disabledContentColor = Color(0xFF42564D),
                ),
            ) {
                if (!loaded) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.5.dp, color = Color(0xFF42564D))
                else Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(
                    when {
                        !loaded -> "جارٍ تجهيز بيانات اليوم…"
                        offDay -> "اليوم إجازة"
                        waitingForSession -> "ابدأ جلسة اليوم"
                        else -> "فتح جلسة اليوم"
                    },
                    fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium,
                )
            }
        }
    }
}

@Composable
private fun HeroNumber(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(16.dp), color = Color.White.copy(alpha = .16f)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(label, style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = .95f))
        }
    }
}
