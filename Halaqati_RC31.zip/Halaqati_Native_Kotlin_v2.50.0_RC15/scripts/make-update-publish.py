from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.67.0',
    'versionCode':26700,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        'المزامنة: تظهر الآن رسالة واضحة إذا بقي أي تسجيل ولم يصل الخادم أكثر من 3 دقائق، والتطبيق يعيد المحاولة تلقائيًا كل 15 دقيقة، ولا يتوقف الإرسال بسبب عملية واحدة عالقة. وتقرير المشكلة يتضمن حالة المزامنة.',
        'الألوان والخطوط والوضع الداكن: سلّم ألوان كامل للوضعين، نص مقروء على كل الخلفيات، وأي لون أساسي تختاره يُضبط تلقائيًا ليبقى واضحًا. وجودة التسميع في مقارنة الفئات والحلقات صارت متوسط نسبة السلامة بدل 100٪ دائمًا.',
        'زر «إرسال تقرير مشكلة» في الإعدادات يجهّز تقريرًا قصيرًا (الإصدار والجهاز) لترسله لمسؤول النظام. والتحديث صار اختياريًا بشكل افتراضي إلا في الإصدارات الحرجة.',
        'مركز الإشعارات: المدير والمشرف يرسلون إشعارًا لكل الحلقات أو حلقة أو فئة أو طالب محدد (لأولياء الأمور أو المعلمين أو الجميع) مع تأكيد بعدد المستلمين، وتبويب "المُرسَل" يبيّن قرأه كم من كم وأسماء من قرأ ومن لم يقرأ. بدون استعلام دوري وبحمل خفيف على Supabase. يحتاج تشغيل ملف SQL الجديد ونشر نسخة محدّثة من دالة halaqati-notify.',
        'إصلاح خطأ بناء في تحديث 2.63.47 (استيراد ناقص في حقل تاريخ الميلاد). يحتوي كل ميزات 2.63.47: تقويم تاريخ الميلاد، قائمة الهوية القابلة للتمرير، اللصق من Excel، شارة ناقص بيانات.',
        'تاريخ الميلاد يُختار من تقويم منبثق بدل الكتابة، قائمة تعبئة هوية الطلاب صارت قابلة للتمرير مع بحث وصف مضغوط لكل طالب، ولصق قائمة هويات من Excel، وشارة "ناقص بيانات" على بطاقة الطالب.',
        'إشعارات push لنتائج الاعتماد (قبول/رفض الحساب أو الربط). تحتاج نشر نسخة محدّثة من دالة halaqati-notify في Supabase، وبدونها يعمل التطبيق كالمعتاد.',
        'اختبارات وحدة جديدة (تصنيف أخطاء المزامنة، تاريخ ميلاد ولي الأمر، ملخص الأسبوع) وملف فحص أمان للقراءة فقط. لا تغيير في سلوك التطبيق.',
        'تعبئة سريعة لهوية وتاريخ ميلاد الطلاب من شاشة طلبات الاعتماد، وملخص آخر 7 أيام لولي الأمر مع مشاركة، وإصلاح أرشيف الشهادات الذي كان يظهر فارغًا عند فشل التحديث.'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
