import './styles/app.css';
import legacyUrl from './legacy/app.js?url';
import reportsRuntimeUrl from './features/reports/runtime.js?url';
import { loadClassicScript } from './core/script-loader.js';
import './core/lazy-libs.js';
import { installReportLazyLoading } from './features/reports/lazy.js';
import { installImportLazyLoading } from './features/import/lazy.js';
import { registerHalaqatiPwa } from './core/pwa.js';

const base = import.meta.env.BASE_URL;

async function boot() {
  // Only true boot dependencies are loaded before the legacy runtime.
  await loadClassicScript(`${base}core/supabase-2.min.js`, { id: 'halaqati-core-supabase' });
  // Quran layout metadata is optional; the legacy runtime already has a fallback.
  try { await loadClassicScript(`${base}core/quran-layout.js`, { id: 'halaqati-core-quran-layout' }); } catch (e) { console.warn(e); }

  await loadClassicScript(legacyUrl, { id: 'halaqati-legacy-runtime' });
  // v2.13.2: reports/PDF engine stays isolated from the legacy runtime.
  // Arabic PDF visuals intentionally use the browser renderer (html2canvas) at 300 DPI.
  // This preserves correct Arabic shaping/spacing while the invisible Unicode layer keeps search/copy/select.
  await loadClassicScript(reportsRuntimeUrl, { id: 'halaqati-reports-runtime' });
  installReportLazyLoading();
  installImportLazyLoading();
  registerHalaqatiPwa();

  window.dispatchEvent(new CustomEvent('halaqati:ready', { detail: { version: '2.13.2', architecture: 'vite-reports-arabic-hq-safe' } }));
}

boot().catch((error) => {
  console.error('Halaqati startup failed', error);
  const box = document.createElement('div');
  box.dir = 'rtl';
  box.style.cssText = 'margin:20px;padding:16px;border:1px solid #e4b8b8;border-radius:14px;background:#fff0f0;color:#8c3333;font-family:Tahoma,Arial,sans-serif';
  box.textContent = 'تعذر تشغيل حلقتي. أعد تحميل الصفحة. التفاصيل: ' + (error?.message || error);
  document.body.prepend(box);
});
