package com.mohammedsamir.halaqati.print;

import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

@CapacitorPlugin(name = "HalaqatiPrint")
public class HalaqatiPrintPlugin extends Plugin {
    @PluginMethod
    public void print(PluginCall call) {
        final String jobName = call.getString("jobName", "Halaqati Report");
        getActivity().runOnUiThread(() -> {
            try {
                PrintManager manager = (PrintManager) getActivity().getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter = getBridge().getWebView().createPrintDocumentAdapter(jobName);
                PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("halaqati", "Halaqati", 600, 600))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();
                manager.print(jobName, adapter, attrs);
                call.resolve(new JSObject());
            } catch (Exception ex) {
                call.reject("Print failed: " + ex.getMessage(), ex);
            }
        });
    }
}
