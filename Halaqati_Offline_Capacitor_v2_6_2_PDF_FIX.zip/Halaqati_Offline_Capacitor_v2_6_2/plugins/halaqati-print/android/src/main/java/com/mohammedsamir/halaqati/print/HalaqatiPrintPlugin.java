package com.mohammedsamir.halaqati.print;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

@CapacitorPlugin(name = "HalaqatiPrint")
public class HalaqatiPrintPlugin extends Plugin {

    @PluginMethod
    public void printHtml(PluginCall call) {
        final String html = call.getString("html", "");
        final String jobName = call.getString("jobName", "Halaqati Report");
        final String orientation = call.getString("orientation", "portrait");

        if (html == null || html.trim().isEmpty()) {
            call.reject("Empty report HTML");
            return;
        }

        getActivity().runOnUiThread(() -> {
            try {
                final WebView printView = new WebView(getActivity());
                printView.setBackgroundColor(Color.WHITE);
                printView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);

                WebSettings settings = printView.getSettings();
                settings.setJavaScriptEnabled(false);
                settings.setLoadsImagesAutomatically(true);
                settings.setBlockNetworkImage(false);
                settings.setBlockNetworkLoads(false);
                settings.setDefaultTextEncodingName("UTF-8");
                settings.setLoadWithOverviewMode(false);
                settings.setUseWideViewPort(true);

                printView.setWebViewClient(new WebViewClient() {
                    private boolean scheduled = false;

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        if (scheduled) return;
                        scheduled = true;

                        Runnable printAction = () -> view.postDelayed(() -> {
                            try {
                                PrintManager manager =
                                    (PrintManager) getActivity().getSystemService(Context.PRINT_SERVICE);

                                PrintDocumentAdapter adapter =
                                    printView.createPrintDocumentAdapter(jobName);

                                PrintAttributes.MediaSize media =
                                    "landscape".equalsIgnoreCase(orientation)
                                        ? PrintAttributes.MediaSize.ISO_A4.asLandscape()
                                        : PrintAttributes.MediaSize.ISO_A4.asPortrait();

                                PrintAttributes attrs = new PrintAttributes.Builder()
                                    .setMediaSize(media)
                                    .setResolution(new PrintAttributes.Resolution(
                                        "halaqati_pdf", "Halaqati PDF", 600, 600))
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build();

                                manager.print(jobName, adapter, attrs);
                                call.resolve(new JSObject());
                            } catch (Exception ex) {
                                call.reject("Print failed: " + ex.getMessage(), ex);
                            }
                        }, 1200);

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            view.postVisualStateCallback(1L, new WebView.VisualStateCallback() {
                                @Override
                                public void onComplete(long requestId) {
                                    printAction.run();
                                }
                            });
                        } else {
                            printAction.run();
                        }
                    }
                });

                printView.loadDataWithBaseURL(
                    "https://appassets.androidplatform.net/",
                    html,
                    "text/html",
                    "UTF-8",
                    null
                );
            } catch (Exception ex) {
                call.reject("Print setup failed: " + ex.getMessage(), ex);
            }
        });
    }
}
