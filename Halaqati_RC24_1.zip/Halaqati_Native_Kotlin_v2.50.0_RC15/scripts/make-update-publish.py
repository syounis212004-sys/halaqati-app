from pathlib import Path
import json, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.60.1',
    'versionCode':26001,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    'notes':[
        'إعادة ترتيب الشهادة على مناطق ثابتة (الرأس ثم المحتوى ثم التواريخ ثم التواقيع ثم الآية) بلا تداخل.',
        'فحص A4 صار يعيد ضبط الخطوط تلقائيًا ولا يعتمد على توقيت التحميل، ويذكر العنصر المشكلة بالاسم.',
        'إصلاح فشل الفحص عند ترك المقدمة أو الدعاء فارغين.',
        'أرشيف مضغوط بفلاتر وفرز وصفوف قابلة للتوسيع، مع إخفاء وحذف من الجهاز وحذف نهائي للمدير.',
        'رأس أصغر ومعاينة أكبر وزر إصلاح التنسيق.',
        'الحفاظ على كل ميزات RC24 وأرقام الشهادات الرسمية.'
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
