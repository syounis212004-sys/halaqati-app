#!/usr/bin/env python3
from pathlib import Path
import json,sys,re
root=Path(__file__).resolve().parents[1]
errors=[]
def read(rel):
    p=root/rel
    if not p.exists(): errors.append('missing '+rel); return ''
    return p.read_text(encoding='utf-8',errors='ignore')
core=read('app/src/main/java/com/mohammedsamir/halaqati/model/CertificateCore.kt')+read('app/src/main/java/com/mohammedsamir/halaqati/model/CertificateRules.kt')
renderer=read('app/src/main/java/com/mohammedsamir/halaqati/documents/CertificateHtmlRenderer.kt')
css=read('app/src/main/assets/documents/certificate.css')
fit_js=read('app/src/main/assets/documents/certificate-fit.js')
repo=read('app/src/main/java/com/mohammedsamir/halaqati/data/HalaqatiRepository.kt')
ui=read('app/src/main/java/com/mohammedsamir/halaqati/ui/screens/ReportsAndTools.kt')
vector=read('app/src/main/java/com/mohammedsamir/halaqati/documents/VectorDocumentRenderer.kt')
release_note=read('RELEASE_2_60_0_RC24_CERTIFICATE_ARCHIVE_RENDERING_CORE_AR.md')
migration=read('migration/20261009_v2600_rc24_certificate_archive_rendering_core.sql')
contract=json.loads(read('migration/source-contract.json') or '{}')
checks=[
 ('halaqati_certificate_render_v2',core),
 ('CertificateRevisionRow',core),('CertificateSeriesRow',core),
 ('cert-kicker',renderer),('cert-main-title',renderer),('cert-name-box',renderer),('cert-achievement',renderer),
 ('certificate-fit.js',renderer),
 ('__HALAQATI_CERTIFICATE_GATE__',fit_js),('render_revision',fit_js),
 ('margin:6px auto 0',css),
 ('rc24_issue_certificate',repo),('rc24_create_certificate_revision',repo),('rc24_void_certificate',repo),('rc24_import_legacy_certificate',repo),
 ('archive_v4',ui),('certificateId',ui),('revisionNo',ui),
 ('إنشاء نسخة مصححة',ui),('إلغاء رسمي',ui),('إضافة سجل أرشيف قديم',ui),('رموز الشهادات',ui),
 ('requireCertificateGateIfNeeded',vector),
 ('metadata_only_no_pdf_no_assets',migration),('legacy_partial',migration),
 ('لا تُرفع إلى Supabase',release_note),('v1/v2/v3',release_note),
]
for token,text in checks:
    if token not in text: errors.append('missing RC24 marker: '+token)
if 'byNumber' in ui[ui.find('object NativeCertificate'):ui.find('fun exportArchiveIndex')]: errors.append('local archive still dedupes by number only')
for t in ['certificate_series','certificate_revisions','certificate_number_counters']:
    if t not in contract.get('tables',[]): errors.append('source contract missing table '+t)
for r in ['rc24_issue_certificate','rc24_create_certificate_revision','rc24_void_certificate','rc24_import_legacy_certificate','rc24_next_certificate_number']:
    if r not in contract.get('rpc',[]): errors.append('source contract missing rpc '+r)
if '2.60.1' != contract.get('native_version'): errors.append('native version not 2.60.1')
if errors:
    print('RC24 certificate archive/rendering gate FAILED')
    [print(' -',e) for e in errors]; sys.exit(1)
print('RC24 certificate archive/rendering gate PASS')
