#!/usr/bin/env python3
"""RC24.1 — Certificate Layout & Archive UX Hotfix: static contract."""
from pathlib import Path
import json, sys
root = Path(__file__).resolve().parents[1]
errors = []


def read(rel):
    p = root / rel
    if not p.exists():
        errors.append('missing ' + rel)
        return ''
    return p.read_text(encoding='utf-8', errors='ignore')


css = read('app/src/main/assets/documents/certificate.css')
fit = read('app/src/main/assets/documents/certificate-fit.js')
renderer = read('app/src/main/java/com/mohammedsamir/halaqati/documents/CertificateHtmlRenderer.kt')
gate = read('app/src/main/java/com/mohammedsamir/halaqati/documents/CertificateRenderGate.kt')
vector = read('app/src/main/java/com/mohammedsamir/halaqati/documents/VectorDocumentRenderer.kt')
preview = read('app/src/main/java/com/mohammedsamir/halaqati/documents/HtmlDocumentPreview.kt')
ui = read('app/src/main/java/com/mohammedsamir/halaqati/ui/screens/ReportsAndTools.kt')
repo = read('app/src/main/java/com/mohammedsamir/halaqati/data/HalaqatiRepository.kt')
build = read('app/build.gradle.kts')
note = read('RELEASE_2_60_1_RC24_1_CERTIFICATE_LAYOUT_ARCHIVE_UX_AR.md')
contract = json.loads(read('migration/source-contract.json') or '{}')

checks = [
    # fixed zones, no flow/absolute mix for the body
    ('.cert-main{', css), ('.cert-body{', css), ('--cert-main-bottom', css), ('.cert-head{', css),
    ('.cert-signatures{', css), ('.cert-dates{', css), ('.cert-footer{', css),
    # fit script: idempotent, scale independent, self-running gate
    ('function layout()', fit), ('function scale()', fit), ('var st = layout();', fit),
    ('__HALAQATI_CERTIFICATE_GATE__', fit), ("'rc24.1'", fit), ('function reset()', fit),
    # renderer
    ('documents/certificate-fit.js', renderer), ('class="cert-main"', renderer), ('class="cert-body"', renderer),
    ('draft.intro.isBlank()', renderer), ('draft.dua.isBlank()', renderer),
    # gate error quality + race-free evaluation
    ('suspend fun awaitCertificateGate', gate), ('"overflow" ->', gate),
    ('awaitCertificateGate(view)', vector), ('awaitCertificateGate(view)', preview),
    # archive UX
    ('CertificateArchiveRow(', ui), ('CertificateActionButton(', ui), ('fun deleteLocalArchive', ui), ('fun setHidden', ui),
    ('حذف نهائي', ui), ('إخفاء من القائمة', ui), ('حذف من هذا الجهاز', ui), ('إصلاح التنسيق وفحص A4', ui),
    ('"voided" to "ملغاة', ui), ('"legacy" to "قديمة', ui), ('"hidden" to "مخفية', ui),
    ('fun deleteCertificate', repo), ('removeJsonArrayCacheRow', repo),
    ('versionCode = 26001', build), ('versionName = "2.60.1"', build),
    ('2.60.1', note), ('digest_search_path', note),
]
for token, text in checks:
    if token not in text:
        errors.append('missing RC24.1 marker: ' + token)
# regressions we explicitly fixed
if 'protectedTop-8' in renderer or 'safeLogo>174' in renderer:
    errors.append('old measuring script still embedded in the renderer')
if 'position:absolute;top:0;width:220px' in css:
    errors.append('old absolute logo slots are back')
if 'CertificateStudioHeader(\n            version = BuildConfig.VERSION_NAME,\n            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),' in ui:
    errors.append('pinned (non-scrolling) certificate header is back')
if contract.get('native_version') != '2.60.1':
    errors.append('source contract native_version is not 2.60.1')
if errors:
    print('RC24.1 certificate layout/archive gate FAILED')
    for e in errors:
        print(' -', e)
    sys.exit(1)
print('RC24.1 certificate layout/archive gate PASS')
