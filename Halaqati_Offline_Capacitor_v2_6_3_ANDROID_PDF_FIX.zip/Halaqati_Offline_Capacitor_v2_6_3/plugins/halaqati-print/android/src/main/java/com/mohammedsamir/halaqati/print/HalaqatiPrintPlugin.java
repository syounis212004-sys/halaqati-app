package com.mohammedsamir.halaqati.print;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.PluginMethod;

@CapacitorPlugin(name = "HalaqatiPrint")
public class HalaqatiPrintPlugin extends Plugin {
    private WebView activePrintView;
    private FrameLayout printHost;

    private void cleanupPrintView() {
        try {
            if (activePrintView != null) {
                ViewGroup parent = (ViewGroup) activePrintView.getParent();
                if (parent != null) parent.removeView(activePrintView);
                activePrintView.stopLoading();
                activePrintView.destroy();
            }
        } catch (Exception ignored) {}
        activePrintView = null;
        try {
            if (printHost != null) {
                ViewGroup parent = (ViewGroup) printHost.getParent();
                if (parent != null) parent.removeView(printHost);
            }
        } catch (Exception ignored) {}
        printHost = null;
    }

    @PluginMethod
    public void printHtml(PluginCall call) {
        final String html = call.getString("html", "");
        final String jobName = call.getString("jobName", "Halaqati Report");
        final String orientation = call.getString("orientation", "portrait");
        if (html == null || html.trim().isEmpty()) { call.reject("Empty report HTML"); return; }

        getActivity().runOnUiThread(() -> {
            try {
                cleanupPrintView();
                FrameLayout decor=(FrameLayout)getActivity().getWindow().getDecorView().findViewById(android.R.id.content);
                printHost=new FrameLayout(getActivity());
                printHost.setBackgroundColor(Color.TRANSPARENT);
                printHost.setAlpha(0.01f);
                printHost.setTranslationX(-5000f);
                printHost.setTranslationY(0f);
                decor.addView(printHost,new FrameLayout.LayoutParams(1400,2000));

                activePrintView=new WebView(getActivity());
                activePrintView.setBackgroundColor(Color.WHITE);
                activePrintView.setLayerType(View.LAYER_TYPE_SOFTWARE,null);
                printHost.addView(activePrintView,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));

                WebSettings settings=activePrintView.getSettings();
                settings.setJavaScriptEnabled(false);
                settings.setLoadsImagesAutomatically(true);
                settings.setBlockNetworkImage(false);
                settings.setBlockNetworkLoads(false);
                settings.setDefaultTextEncodingName("UTF-8");
                settings.setLoadWithOverviewMode(false);
                settings.setUseWideViewPort(true);
                settings.setSupportZoom(false);

                activePrintView.setWebViewClient(new WebViewClient(){
                    private boolean scheduled=false;
                    @Override public void onPageFinished(WebView view,String url){
                        if(scheduled)return; scheduled=true;
                        final boolean[] printTriggered = { false };
                        Runnable beginPrint=()->{
                            if (printTriggered[0]) return;
                            printTriggered[0] = true;
                            view.postDelayed(()->{
                                try{
                                    PrintManager manager=(PrintManager)getActivity().getSystemService(Context.PRINT_SERVICE);
                                    PrintDocumentAdapter adapter=activePrintView.createPrintDocumentAdapter(jobName);
                                    PrintAttributes.MediaSize media="landscape".equalsIgnoreCase(orientation)?PrintAttributes.MediaSize.ISO_A4.asLandscape():PrintAttributes.MediaSize.ISO_A4.asPortrait();
                                    PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(media).setResolution(new PrintAttributes.Resolution("halaqati_pdf","Halaqati PDF",600,600)).setColorMode(PrintAttributes.COLOR_MODE_COLOR).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
                                    manager.print(jobName,adapter,attrs);
                                    JSObject result=new JSObject(); result.put("opened",true); call.resolve(result);
                                    activePrintView.postDelayed(()->cleanupPrintView(),120000);
                                }catch(Exception ex){cleanupPrintView();call.reject("Print failed: "+ex.getMessage(),ex);}
                            },900);
                        };
                        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
                            view.postVisualStateCallback(100L,new WebView.VisualStateCallback(){@Override public void onComplete(long requestId){beginPrint.run();}});
                            // Fallback for devices where VisualStateCallback never arrives.
                            view.postDelayed(beginPrint,3500);
                        }else beginPrint.run();
                    }
                });

                activePrintView.loadDataWithBaseURL("https://appassets.androidplatform.net/",html,"text/html","UTF-8",null);
            }catch(Exception ex){cleanupPrintView();call.reject("Print setup failed: "+ex.getMessage(),ex);}
        });
    }

    @Override protected void handleOnDestroy(){cleanupPrintView();}
}
