@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.ui.components.*
import com.mohammedsamir.halaqati.ui.navigation.AddActionBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.UUID

/* ============================== small shared pieces ============================== */

internal fun supDaysSince(date: String?): Int? =
    if (date.isNullOrBlank()) null else runCatching { ChronoUnit.DAYS.between(LocalDate.parse(date.take(10)), LocalDate.now()).toInt() }.getOrNull()

@Composable
internal fun SupStat(label: String, value: String, modifier: Modifier = Modifier, accent: Color? = null) {
    BorderedCard(modifier = modifier, accent = accent, padding = 10.dp) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
    }
}

@Composable
internal fun SupSectionTitle(text: String, modifier: Modifier = Modifier, trailing: (@Composable () -> Unit)? = null) {
    Row(modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing?.invoke()
    }
}

private val ALERT_TEMPLATES = listOf(
    "لم تبدأ الجلسة" to "لم تُفتح جلسة اليوم في حلقتك حتى الآن. نرجو فتحها وتسجيل الحضور.",
    "تأخر التسميع" to "لاحظنا تأخر التسميع في حلقتك. نرجو متابعة الطلاب وتسجيل الإنجاز.",
    "تذكير بالتقارير" to "نرجو استكمال الخطط والتقارير المطلوبة هذا الأسبوع.",
    "شكر وتقدير" to "بارك الله فيك على التزامك وجهدك مع الطلاب.",
)

/** A private alert from the supervisor / administrator to one teacher (or supervisor). Needs a connection. */
@Composable
internal fun SupAlertDialog(
    recipients: List<Pair<String, String>>,
    halaqaId: String?,
    presetTitle: String = "",
    presetBody: String = "",
    close: () -> Unit,
    onSent: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var recipientId by remember { mutableStateOf(recipients.firstOrNull()?.first.orEmpty()) }
    var title by remember { mutableStateOf(presetTitle) }
    var body by remember { mutableStateOf(presetBody) }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { if (!sending) close() },
        title = { Text("تنبيه محفّظ") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (recipients.size > 1) {
                    HalaqatiLazySelectField(
                        label = "المستلم", selectedKey = recipientId, options = recipients,
                        onSelected = { recipientId = it }, modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    Text(recipients.firstOrNull()?.second ?: "لا يوجد مستلم", fontWeight = FontWeight.Bold)
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ALERT_TEMPLATES.forEach { (t, b) ->
                        ProFilterChip(selected = title == t, onClick = { title = t; body = b }, label = t, showCheckIcon = false)
                    }
                }
                OutlinedTextField(title, { if (it.length <= 80) title = it }, label = { Text("العنوان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(body, { if (it.length <= 500) body = it }, label = { Text("النص") }, minLines = 3, maxLines = 6, modifier = Modifier.fillMaxWidth())
                error?.let { StateNotice(it, kind = "error") }
                Text("يصل التنبيه داخل التطبيق ويحتاج اتصالًا بالإنترنت.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(
                enabled = !sending && recipientId.isNotBlank() && title.isNotBlank() && body.isNotBlank(),
                modifier = Modifier.heightIn(min = 48.dp),
                onClick = {
                    scope.launch {
                        sending = true; error = null
                        try {
                            val r = withContext(Dispatchers.IO) { AppGraph.repo.alertStaff(recipientId, title.trim(), body.trim(), halaqaId) }
                            if (r.optBoolean("ok", false)) { onSent(); close() } else error = r.optString("error", "تعذر الإرسال")
                        } catch (e: kotlinx.coroutines.CancellationException) {
                            throw e
                        } catch (e: Exception) { error = e.message ?: "تعذر الإرسال. تحقق من الاتصال وأن تحديث الخادم مطبّق." }
                        finally { sending = false }
                    }
                },
            ) { Text(if (sending) "جارٍ الإرسال…" else "إرسال") }
        },
        dismissButton = { TextButton(onClick = close, enabled = !sending, modifier = Modifier.heightIn(min = 48.dp)) { Text("إلغاء") } },
    )
}

/* ============================== a halaqa card (operations view) ============================== */

@Composable
internal fun SupHalaqaCard(
    h: SupHalaqa,
    detailed: Boolean,
    onAlert: () -> Unit,
    onVisit: () -> Unit,
    onOpen: (() -> Unit)? = null,
) {
    val cs = MaterialTheme.colorScheme
    val accent = when (h.state) {
        TeacherDayState.NOT_STARTED -> cs.error
        TeacherDayState.IN_PROGRESS -> cs.tertiary
        TeacherDayState.CLOSED -> cs.primary
    }
    val kind = when (h.state) { TeacherDayState.NOT_STARTED -> "danger"; TeacherDayState.IN_PROGRESS -> "warning"; TeacherDayState.CLOSED -> "success" }
    BorderedCard(accent = accent, onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(h.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(h.teacherLine, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            StatusPill(h.stateLabel, kind = kind)
        }
        Spacer(Modifier.height(8.dp))
        if (h.students > 0) {
            LinearProgressIndicator(progress = { h.recitedPercent / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = accent, trackColor = cs.surfaceVariant)
            Spacer(Modifier.height(4.dp))
        }
        Text(
            "سُمّع ${h.recited} من ${h.students} · حضور ${h.present} · غياب ${h.absent}" + if (h.excused > 0) " · بعذر ${h.excused}" else "",
            style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
        )
        if (detailed) {
            val last = h.lastVisitDate
            val days = supDaysSince(last)
            Text(
                "جلسات الشهر ${h.monthSessions} · " + if (last == null) "لم تُزر بعد" else "آخر زيارة قبل ${days ?: 0} يومًا" + (h.lastVisitScore?.let { " (${oneDecimal(it)}/5)" } ?: ""),
                style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onAlert, enabled = h.teacherIds.isNotEmpty(), modifier = Modifier.weight(1f).heightIn(min = 44.dp), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("تنبيه المحفّظ", maxLines = 1) }
            OutlinedButton(onClick = onVisit, modifier = Modifier.weight(1f).heightIn(min = 44.dp), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("زيارة", maxLines = 1) }
        }
    }
}

/* ============================== home: the operations room ============================== */

@Composable
fun SupervisorHomeScreen(profile: Profile, pending: Int, onRefresh: () -> Unit, navigate: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var board by remember { mutableStateOf<SupBoard?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var alertFor by remember { mutableStateOf<SupHalaqa?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }

    suspend fun reload() {
        try {
            board = withContext(Dispatchers.IO) { loadSupBoard() }
            message = null
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) { message = e.message ?: "تعذر تحميل لوحة اليوم" }
    }
    val syncEpoch by AppGraph.connectivity.syncEpoch.collectAsState()
    LaunchedEffect(syncEpoch) { reload() }

    val b = board
    val started = b?.halaqas?.count { it.state != TeacherDayState.NOT_STARTED } ?: 0
    val total = b?.halaqas?.size ?: 0
    val notStarted = b?.halaqas?.filter { it.state == TeacherDayState.NOT_STARTED }.orEmpty()
    val staleVisits = b?.halaqas?.filter { (supDaysSince(it.lastVisitDate) ?: 999) > 14 }.orEmpty()
    val openActions = b?.visits?.count { it.optString("action_items").isNotBlank() && !it.optBoolean("action_done", false) } ?: 0
    val weekVisits = b?.visits?.count { (supDaysSince(it.optString("visit_date")) ?: 999) <= 7 } ?: 0

    Column {
        AppTopBar("غرفة العمليات", onRefresh = { scope.launch { reload() }; onRefresh() }, pending = pending, kicker = "أهلًا ${profile.fullName}")
        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        toast?.let { StateNotice(it, kind = "success", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (b == null) { LoadingSkeleton(rows = 4, modifier = Modifier.padding(12.dp)); return@Column }
        LazyColumn(
            state = androidx.compose.foundation.lazy.rememberLazyListState(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { RoleWelcomeCard(profile.role) }
            item {
                Text(
                    if (total == 0) "لا توجد حلقات مسندة إليك بعد" else "$started من $total حلقات بدأت اليوم" + if (notStarted.isNotEmpty()) " · ${notStarted.size} لم تبدأ" else " · الجميع بدأ",
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SupStat("حلقات بدأت", "$started/$total", Modifier.weight(1f), accent = MaterialTheme.colorScheme.primary)
                    SupStat("زياراتي هذا الأسبوع", weekVisits.toString(), Modifier.weight(1f))
                    SupStat("إجراءات مفتوحة", openActions.toString(), Modifier.weight(1f), accent = if (openActions > 0) MaterialTheme.colorScheme.tertiary else null)
                }
            }
            if (notStarted.isNotEmpty() || staleVisits.isNotEmpty()) item {
                BorderedCard(accent = MaterialTheme.colorScheme.error) {
                    Text("يحتاج تدخلك", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    notStarted.take(5).forEach { h ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("• ${h.teacherLine} لم يبدأ جلسة ${h.name}", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            TextButton(onClick = { alertFor = h }, enabled = h.teacherIds.isNotEmpty(), modifier = Modifier.heightIn(min = 40.dp)) { Text("تنبيه") }
                        }
                    }
                    staleVisits.take(3).forEach { h ->
                        Text("• ${h.name}: " + (supDaysSince(h.lastVisitDate)?.let { "لم تُزر منذ $it يومًا" } ?: "لم تُزر بعد"), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }
            item { SupSectionTitle("حلقات اليوم") }
            if (b.halaqas.isEmpty()) item { EmptyState("لا توجد حلقات لعرضها") }
            items(b.halaqas, key = { it.id }) { h ->
                SupHalaqaCard(
                    h, detailed = false,
                    onAlert = { alertFor = h },
                    onVisit = { AddActionBus.request("visit:${h.id}"); navigate("visits") },
                    onOpen = { navigate("halaqas") },
                )
            }
            item {
                OutlinedButton(onClick = { navigate("supervision") }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("متابعة المحفّظين") }
            }
        }
    }
    alertFor?.let { h ->
        SupAlertDialog(
            recipients = h.teacherIds.zip(h.teacherNames),
            halaqaId = h.id,
            presetTitle = if (h.state == TeacherDayState.NOT_STARTED) ALERT_TEMPLATES[0].first else "",
            presetBody = if (h.state == TeacherDayState.NOT_STARTED) ALERT_TEMPLATES[0].second else "",
            close = { alertFor = null },
            onSent = { toast = "وصل التنبيه إلى المحفّظ" },
        )
    }
}

/* ============================== halaqas (read-only follow-up) ============================== */

@Composable
fun SupervisorHalaqasScreen(profile: Profile, pending: Int, onRefresh: () -> Unit, navigate: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var board by remember { mutableStateOf<SupBoard?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var alertFor by remember { mutableStateOf<SupHalaqa?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }
    suspend fun reload() {
        try { board = withContext(Dispatchers.IO) { loadSupBoard() }; message = null }
        catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) { message = e.message ?: "تعذر التحميل" }
    }
    val syncEpoch by AppGraph.connectivity.syncEpoch.collectAsState()
    LaunchedEffect(syncEpoch) { reload() }
    val b = board
    Column {
        AppTopBar("الحلقات", onRefresh = { scope.launch { reload() }; onRefresh() }, pending = pending)
        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        toast?.let { StateNotice(it, kind = "success", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (b == null) { LoadingSkeleton(rows = 4, modifier = Modifier.padding(12.dp)); return@Column }
        LazyColumn(
            state = androidx.compose.foundation.lazy.rememberLazyListState(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (b.halaqas.isEmpty()) item { EmptyState("لا توجد حلقات مسندة إليك") }
            items(b.halaqas, key = { it.id }) { h ->
                SupHalaqaCard(
                    h, detailed = true,
                    onAlert = { alertFor = h },
                    onVisit = { AddActionBus.request("visit:${h.id}"); navigate("visits") },
                    onOpen = null,
                )
            }
        }
    }
    alertFor?.let { h ->
        SupAlertDialog(
            recipients = h.teacherIds.zip(h.teacherNames),
            halaqaId = h.id, close = { alertFor = null }, onSent = { toast = "وصل التنبيه إلى المحفّظ" },
        )
    }
}

/* ============================== visits (offline-first, edit, delete with typed confirmation) ============================== */

@Composable
fun SupervisorVisitsScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    val scope = rememberCoroutineScope()
    var board by remember { mutableStateOf<SupBoard?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<JSONObject?>(null) }
    var creating by remember { mutableStateOf(false) }
    var presetHalaqa by remember { mutableStateOf("") }
    var deleting by remember { mutableStateOf<JSONObject?>(null) }
    var filter by remember { mutableStateOf("all") }

    suspend fun reload() {
        try { board = withContext(Dispatchers.IO) { loadSupBoard() }; message = null }
        catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) { message = e.message ?: "تعذر تحميل الزيارات" }
    }
    val syncEpoch by AppGraph.connectivity.syncEpoch.collectAsState()
    LaunchedEffect(syncEpoch) { reload() }
    val localEpoch by AppGraph.repo.localMutationEpoch.collectAsState()
    LaunchedEffect(localEpoch) { if (localEpoch > 0L) reload() }

    // The "+" sheet / a halaqa card asks for a new visit ("visit" or "visit:<halaqaId>").
    val request by AddActionBus.requested.collectAsState()
    LaunchedEffect(request) {
        val r = request
        if (r != null && (r == "visit" || r.startsWith("visit:"))) {
            presetHalaqa = r.substringAfter("visit:", "")
            creating = true
            AddActionBus.consume()
        }
    }

    val b = board
    val halaqaNames = b?.halaqas?.associate { it.id to it.name }.orEmpty()
    val shown = b?.visits?.filter { filter == "all" || it.optString("halaqa_id") == filter }.orEmpty()

    Column {
        AppTopBar("زيارات المشرف", onRefresh = { scope.launch { reload() }; onRefresh() }, pending = pending)
        message?.let { StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) }
        if (b == null) { LoadingSkeleton(rows = 3, modifier = Modifier.padding(12.dp)); return@Column }
        LazyColumn(
            state = androidx.compose.foundation.lazy.rememberLazyListState(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Button(onClick = { presetHalaqa = ""; creating = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("تسجيل زيارة جديدة") }
            }
            if (b.halaqas.size > 1) item {
                HalaqatiLazySelectField(
                    label = "الحلقة", selectedKey = filter,
                    options = listOf("all" to "كل الحلقات") + b.halaqas.map { it.id to it.name },
                    onSelected = { filter = it }, modifier = Modifier.fillMaxWidth(),
                )
            }
            if (shown.isEmpty()) item { EmptyState("لا توجد زيارات مسجلة") }
            items(shown, key = { it.optString("id") }) { v ->
                val pend = v.optBoolean("_pending", false)
                val hasActions = v.optString("action_items").isNotBlank()
                val done = v.optBoolean("action_done", false)
                BorderedCard(accent = if (pend) MaterialTheme.colorScheme.tertiary else null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(halaqaNames[v.optString("halaqa_id")] ?: "حلقة", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (pend) StatusPill("بانتظار الرفع", kind = "warning")
                        Spacer(Modifier.width(6.dp))
                        Text(v.optString("visit_date"), style = MaterialTheme.typography.labelMedium)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "التنظيم ${supScore(v, "organization_score")} · التدريس ${supScore(v, "teaching_score")} · المتابعة ${supScore(v, "followup_score")}" +
                            (if (!v.isNull("teacher_attendance") && v.has("teacher_attendance")) (if (v.optBoolean("teacher_attendance")) " · المحفّظ حاضر" else " · المحفّظ غائب") else ""),
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (v.optString("notes").isNotBlank()) Text(v.optString("notes"), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
                    if (hasActions) Text("المطلوب: ${v.optString("action_items")}" + if (done) " ✓ نُفّذ" else "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { editing = v }, modifier = Modifier.weight(1f).heightIn(min = 44.dp)) { Text("تعديل") }
                        if (hasActions && !done) OutlinedButton(onClick = {
                            scope.launch {
                                withContext(Dispatchers.IO) { AppGraph.repo.patch("supervisor_visits", "id=eq.${v.optString("id")}", JSONObject().put("action_done", true), dedupe = "visit:${v.optString("id")}:done") }
                                reload()
                            }
                        }, modifier = Modifier.weight(1f).heightIn(min = 44.dp)) { Text("تم التنفيذ") }
                        OutlinedButton(
                            onClick = { deleting = v }, modifier = Modifier.weight(1f).heightIn(min = 44.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        ) { Text("حذف") }
                    }
                }
            }
        }
    }

    if (creating || editing != null) {
        val initial = editing
        SupVisitDialog(
            halaqas = b?.halaqas.orEmpty().map { it.id to it.name },
            initial = initial,
            presetHalaqa = presetHalaqa,
            close = { creating = false; editing = null },
        ) { halaqaId, org, teach, follow, attended, notes, actions ->
            val editId = initial?.optString("id")
            creating = false; editing = null
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val repo = AppGraph.repo
                        if (editId.isNullOrBlank()) {
                            val uid = repo.store.load()?.userId ?: error("الجلسة غير صالحة")
                            val id = UUID.randomUUID().toString()
                            repo.write(
                                "supervisor_visits",
                                JSONObject()
                                    .put("id", id)
                                    .put("halaqa_id", halaqaId)
                                    .put("supervisor_id", uid)
                                    .put("visit_date", LocalDate.now().toString())
                                    .put("teacher_attendance", attended)
                                    .put("organization_score", org)
                                    .put("teaching_score", teach)
                                    .put("followup_score", follow)
                                    .put("notes", notes.ifBlank { JSONObject.NULL })
                                    .put("action_items", actions.ifBlank { JSONObject.NULL }),
                                dedupe = "visit:$id",
                            )
                        } else {
                            repo.patch(
                                "supervisor_visits", "id=eq.$editId",
                                JSONObject()
                                    .put("halaqa_id", halaqaId)
                                    .put("teacher_attendance", attended)
                                    .put("organization_score", org)
                                    .put("teaching_score", teach)
                                    .put("followup_score", follow)
                                    .put("notes", notes.ifBlank { JSONObject.NULL })
                                    .put("action_items", actions.ifBlank { JSONObject.NULL }),
                                dedupe = "visit:$editId:edit",
                            )
                        }
                    }
                    reload(); onRefresh()
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) { message = e.message ?: "تعذر حفظ الزيارة" }
            }
        }
    }
    deleting?.let { v ->
        var typed by remember(v) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف الزيارة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("سيُحذف سجل زيارة ${halaqaNames[v.optString("halaqa_id")] ?: "الحلقة"} بتاريخ ${v.optString("visit_date")}. للتأكيد اكتب كلمة «حذف».")
                    OutlinedTextField(typed, { typed = it }, singleLine = true, label = { Text("اكتب: حذف") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    enabled = typed.trim() == "حذف",
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.heightIn(min = 48.dp),
                    onClick = {
                        val id = v.optString("id"); deleting = null
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) { AppGraph.repo.delete("supervisor_visits", "id=eq.$id", dedupe = "visit:$id:delete") }
                                reload(); onRefresh()
                            } catch (e: kotlinx.coroutines.CancellationException) {
                                throw e
                            } catch (e: Exception) { message = e.message ?: "تعذر الحذف" }
                        }
                    },
                ) { Text("حذف الزيارة") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }, modifier = Modifier.heightIn(min = 48.dp)) { Text("إلغاء") } },
        )
    }
}

internal fun supScore(v: JSONObject, key: String): String = if (v.isNull(key) || !v.has(key)) "—" else "${v.optInt(key)}/5"

@Composable
private fun SupVisitDialog(
    halaqas: List<Pair<String, String>>,
    initial: JSONObject?,
    presetHalaqa: String,
    close: () -> Unit,
    save: (String, Int, Int, Int, Boolean, String, String) -> Unit,
) {
    var halaqaId by remember { mutableStateOf(initial?.optString("halaqa_id")?.takeIf { it.isNotBlank() } ?: presetHalaqa.ifBlank { halaqas.firstOrNull()?.first.orEmpty() }) }
    var org by remember { mutableIntStateOf(initial?.takeIf { !it.isNull("organization_score") }?.optInt("organization_score", 3) ?: 3) }
    var teach by remember { mutableIntStateOf(initial?.takeIf { !it.isNull("teaching_score") }?.optInt("teaching_score", 3) ?: 3) }
    var follow by remember { mutableIntStateOf(initial?.takeIf { !it.isNull("followup_score") }?.optInt("followup_score", 3) ?: 3) }
    var attended by remember { mutableStateOf(initial?.takeIf { !it.isNull("teacher_attendance") }?.optBoolean("teacher_attendance", true) ?: true) }
    var notes by remember { mutableStateOf(initial?.optString("notes").orEmpty().takeIf { it != "null" }.orEmpty()) }
    var actions by remember { mutableStateOf(initial?.optString("action_items").orEmpty().takeIf { it != "null" }.orEmpty()) }
    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (initial == null) "زيارة إشرافية" else "تعديل الزيارة") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 500.dp).verticalScroll(rememberScrollState()).imePadding(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HalaqatiLazySelectField(label = "الحلقة", selectedKey = halaqaId, options = halaqas, onSelected = { halaqaId = it }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("المحفّظ حاضر", Modifier.weight(1f))
                    Switch(checked = attended, onCheckedChange = { attended = it })
                }
                SupScorePicker("التنظيم", org) { org = it }
                SupScorePicker("التدريس", teach) { teach = it }
                SupScorePicker("المتابعة", follow) { follow = it }
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(actions, { actions = it }, label = { Text("المطلوب من المحفّظ") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                Text("تُحفظ الزيارة على هذا الهاتف فورًا وتُرسل عند توفر الإنترنت.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(enabled = halaqaId.isNotBlank(), modifier = Modifier.heightIn(min = 48.dp), onClick = { save(halaqaId, org, teach, follow, attended, notes.trim(), actions.trim()) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = close, modifier = Modifier.heightIn(min = 48.dp)) { Text("إلغاء") } },
    )
}

@Composable
private fun SupScorePicker(label: String, value: Int, onChange: (Int) -> Unit) {
    Column {
        Text("$label: $value/5", style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            (1..5).forEach { n -> ProFilterChip(value == n, { onChange(n) }, n.toString()) }
        }
    }
}
