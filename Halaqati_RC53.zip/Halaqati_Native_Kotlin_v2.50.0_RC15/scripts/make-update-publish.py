from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.0',
    'versionCode':28900,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "واجهة جديدة للمشرف: رئيسية «غرفة العمليات» ببطاقة لكل حلقة (هل بدأ المحفّظ جلسته، كم سُمّع)، وقوائم خاصة به، وإزالة التحفيظ السريع والخطط الذكية والشهادات من حسابه.",
        "زيارات المشرف تُحفظ بدون إنترنت وتُرفع تلقائيًا، ويمكن تعديلها أو حذفها بكتابة كلمة «حذف»، مع متابعة تنفيذ المطلوب من المحفّظ.",
        "«متابعة المحفظين» (و«المحفظين والمشرفين» لمسؤول النظام): لوحة التزام لكل شخص مع إرسال تنبيه مباشر للمحفّظ، ومتابعة والمقارنة جديدتان حول المحفظين.",
        "الحسابات والصلاحيات: صفوف مصغّرة قابلة للفتح، وتجميد الحساب وفكه، وصورة شخصية للمحفّظ والمشرف.",
        "إشعارات مسؤول النظام تعرض ما أُرسل إليه فقط، وإرسال الإشعارات يشمل الآن المانحين والمشرفين.",
        "بطاقة الرئيسية تعرض آية أو حديثًا أو كلمة طيبة تناسب نوع الحساب وتتغير يوميًا.",
        "شريط عدم الاتصال صار رفيعًا بسطر واحد، وبطاقات التسميع والطلاب بحدود وألوان أوضح مع إزالة تكرار اسم الطالب.",
        "زر «تعديل المرحلة» مباشرة في بطاقة الخطة وتبسيط إدارة المراحل، وبطاقة «ادعم التطبيق» يُدخل المدير بياناتها.",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
