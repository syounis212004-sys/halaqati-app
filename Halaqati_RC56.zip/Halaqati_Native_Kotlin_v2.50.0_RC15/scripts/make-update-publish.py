from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.89.3',
    'versionCode':28903,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "إصلاح خطأ في حساب «المطلوب حتى اليوم» لخطط الحفظ: كان يُحسب أحيانًا على عدد قليل من السطور فيظهر الطالب المتأخر متقدمًا، وصار يُحسب على هدف الخطة الفعلي.",
        "نطاق الحفظ لم يعد يُقصّ عند نهاية نطاق الخطة القديمة، فيحصل الطالب على نطاق يكفي هدفه (مثل 30 صفحة) لا ثلاث صفحات فقط.",
        "إخفاء كلمة null من «ملاحظة الخطة».",
        "يشمل كل ما في الإصدارات السابقة: واجهة المشرف الجديدة، إيقاف اهتزاز القوائم، وإصلاح حذف الزيارات.",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
