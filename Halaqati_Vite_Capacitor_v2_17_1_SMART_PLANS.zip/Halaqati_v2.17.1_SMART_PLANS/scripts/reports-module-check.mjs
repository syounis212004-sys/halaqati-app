import fs from 'node:fs';

const legacy=fs.readFileSync('src/legacy/app.js','utf8');
const runtime=fs.readFileSync('src/features/reports/runtime.js','utf8');
const main=fs.readFileSync('src/main.js','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));

function ok(condition,message){
  if(!condition){ console.error('REPORTS_MODULE_CHECK_FAIL:',message); process.exit(1); }
  console.log('OK:',message);
}

ok(pkg.version==='2.17.1','package version is 2.17.1');
ok(!legacy.includes('Halaqati Web/Reports Hotfix'),'modern reports hotfix no longer lives inside legacy/app.js');
ok(runtime.includes("window.__HALAQATI_REPORTS_RUNTIME__='2.13.7-arabic-hq-safe'"),'reports runtime sentinel exists');
ok(runtime.includes('window.downloadReportPdfFromPreview=async function'),'stable PDF exporter moved to reports runtime');
ok(runtime.includes('window.openReportPreview=function'),'PDF preview remains in reports runtime');
ok(runtime.includes('collectSearchablePdfTextItems'),'searchable Arabic PDF layer remains in reports runtime');
ok(runtime.includes('buildRowSafePdfPages'),'row-safe PDF pagination remains in reports runtime');
ok(runtime.includes('window.loadSelectedReport=async function'),'fresh report-data loader remains in reports runtime');
ok(main.includes("import reportsRuntimeUrl from './features/reports/runtime.js?url'"),'main imports reports runtime URL');
const legacyPos=main.indexOf("loadClassicScript(legacyUrl");
const reportsPos=main.indexOf("loadClassicScript(reportsRuntimeUrl");
const lazyPos=main.indexOf('installReportLazyLoading()');
ok(legacyPos>=0&&reportsPos>legacyPos,'reports runtime loads after legacy runtime');
ok(lazyPos>reportsPos,'lazy wrappers install after reports runtime');
ok(!runtime.includes('function settingsPage('),'settings implementation was not moved into reports module');
ok(!runtime.includes('function studentsPage('),'students implementation was not moved into reports module');
ok(!runtime.includes('function sessionCards('),'sessions implementation was not moved into reports module');
console.log('REPORTS_MODULE_CHECK_PASS');
