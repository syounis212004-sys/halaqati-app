package com.mohammedsamir.halaqati.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.ui.theme.CairoFamily

/**
 * Nour design kit: one calm vocabulary shared by every screen.
 *  - surfaces: white card (20dp corners, 1dp outline), at most ONE strong emerald hero per screen;
 *  - colour = status only (success / warning / danger) and appears as a small pill, a thin marker, or a progress fill;
 *  - numbers in Cairo (tabular look), Amiri stays for large titles;
 *  - icon sizes 20 / 24 / 28, avatar sizes 40 / 48 / 56 / 72.
 */
object NourIcon {
    val Inline: Dp = 20.dp
    val Action: Dp = 24.dp
    val Feature: Dp = 28.dp
}

object NourAvatarSize {
    val Small: Dp = 40.dp
    val Medium: Dp = 48.dp
    val Large: Dp = 56.dp
    val Hero: Dp = 72.dp
}

/** success / warning / danger / neutral -> (accent, soft container, on-container) */
@Composable
fun nourTone(kind: String): Triple<Color, Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (kind) {
        "success" -> Triple(cs.primary, cs.primaryContainer, cs.onPrimaryContainer)
        "warning" -> Triple(cs.tertiary, cs.tertiaryContainer, cs.onTertiaryContainer)
        "danger", "error" -> Triple(cs.error, cs.errorContainer, cs.onErrorContainer)
        else -> Triple(cs.onSurfaceVariant, cs.surfaceVariant, cs.onSurfaceVariant)
    }
}

@Composable
fun NourCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    marker: Color? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(20.dp)
    val base = modifier.fillMaxWidth()
    Surface(
        modifier = if (onClick != null) base.clip(shape).clickable(onClick = onClick) else base,
        shape = shape,
        color = cs.surface,
        shadowElevation = 1.dp,
        border = BorderStroke(1.dp, cs.outlineVariant),
    ) {
        Column(Modifier.then(if (marker != null) Modifier.padding(0.dp) else Modifier)) {
            if (marker != null) Box(Modifier.fillMaxWidth().height(3.dp).background(marker))
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
        }
    }
}

/** Slim progress bar: rounded, no stop-indicator dot, fills from the reading start (right in RTL). */
@Composable
fun NourProgress(fraction: Float, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    Box(modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().clip(CircleShape).background(color))
    }
}

/** A calm number tile: soft container, big Cairo number, small label, optional 20dp icon. */
@Composable
fun NourStatTile(value: String, label: String, modifier: Modifier = Modifier, tone: String = "neutral", icon: ImageVector? = null) {
    val (accent, container, _) = nourTone(tone)
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(if (tone == "neutral") cs.primaryContainer.copy(alpha = .7f) else container)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        if (icon != null) Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(NourIcon.Inline))
        Text(value, style = MaterialTheme.typography.headlineSmall.copy(fontFamily = CairoFamily, fontWeight = FontWeight.ExtraBold), color = if (tone == "neutral") cs.primary else accent)
        Text(label, style = MaterialTheme.typography.labelMedium, color = cs.onSurface, maxLines = 2)
    }
}

/** An icon in a soft round container; the only icon container shape used in lists and headers. */
@Composable
fun NourIconBadge(icon: ImageVector, modifier: Modifier = Modifier, tone: String = "success", size: Dp = 40.dp) {
    val (accent, container, _) = nourTone(tone)
    Box(modifier.size(size).clip(CircleShape).background(container), contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(if (size >= 48.dp) NourIcon.Feature else NourIcon.Action))
    }
}

/** Photo (or the first letter on a soft tint) at one of the four avatar sizes. */
@Composable
fun NourAvatar(photo: String?, name: String, size: Dp = NourAvatarSize.Medium, modifier: Modifier = Modifier) {
    StudentAvatar(photo, name, size, modifier)
}

/** The one strong block of a screen: emerald fill and a faint cached lattice. */
@Composable
fun NourHero(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primary) {
        Column(
            Modifier.fillMaxWidth().nourHeroFill(androidx.compose.material3.MaterialTheme.colorScheme.primary).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp), content = content,
        )
    }
}

/**
 * RC95: the app's one small ornament — an eight-pointed star (two squares, the khatam of Islamic geometry) in gold.
 * Drawn once per size via drawWithCache; decorative only, hidden from accessibility.
 */
@Composable
fun NourStar(modifier: Modifier = Modifier, size: Dp = 14.dp, color: Color = MaterialTheme.colorScheme.tertiary, hole: Color = MaterialTheme.colorScheme.surface) {
    androidx.compose.foundation.layout.Spacer(
        modifier.size(size).drawWithCache {
            val r = this.size.minDimension / 2f
            val c = androidx.compose.ui.geometry.Offset(this.size.width / 2f, this.size.height / 2f)
            fun square(rot: Double) = androidx.compose.ui.graphics.Path().apply {
                for (k in 0 until 4) {
                    val a = rot + k * Math.PI / 2
                    val x = c.x + r * kotlin.math.cos(a).toFloat()
                    val y = c.y + r * kotlin.math.sin(a).toFloat()
                    if (k == 0) moveTo(x, y) else lineTo(x, y)
                }
                close()
            }
            val a = square(0.0)
            val b = square(Math.PI / 4)
            onDrawBehind {
                drawPath(a, color)
                drawPath(b, color)
                drawCircle(hole, radius = r * .28f, center = c)
            }
        },
    )
}

/** RC95: a section title with the gold star before it and a hairline after it. One style for every role. */
@Composable
fun NourSectionTitle(text: String, modifier: Modifier = Modifier, trailing: (@Composable () -> Unit)? = null) {
    androidx.compose.foundation.layout.Row(
        modifier.fillMaxWidth().padding(top = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiaryContainer), contentAlignment = Alignment.Center) { NourStar(size = 16.dp) }
        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface)
        Box(Modifier.weight(1f).height(1.dp).background(MaterialTheme.colorScheme.outlineVariant))
        trailing?.invoke()
    }
}

/** RC95: the single hero fill shared by every role: the theme primary deepening to one corner + one cached girih lattice.
 * Follows the colour the user picked in Settings. */
fun Modifier.nourHeroFill(primary: Color): Modifier = this
    .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(
        androidx.compose.ui.graphics.lerp(primary, Color.Black, .32f), primary, androidx.compose.ui.graphics.lerp(primary, Color.White, .10f),
    )))
    .girih(Color.White, .14f, 44.dp)

/** RC96: the lead element of a list screen: one emerald hero holding its 2-4 key numbers; [warn] marks the one needing attention (gold). */
@Composable
fun NourStatStrip(items: List<Triple<String, String, Boolean>>, modifier: Modifier = Modifier) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primary) {
        androidx.compose.foundation.layout.Row(Modifier.fillMaxWidth().nourHeroFill(MaterialTheme.colorScheme.primary).padding(vertical = 16.dp)) {
            items.forEachIndexed { i, (value, label, warn) ->
                if (i > 0) Box(Modifier.width(1.dp).height(44.dp).align(Alignment.CenterVertically).background(Color.White.copy(alpha = .25f)))
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(value, style = MaterialTheme.typography.headlineMedium.copy(fontFamily = CairoFamily, fontWeight = FontWeight.ExtraBold), color = if (warn) MaterialTheme.colorScheme.tertiaryContainer else Color.White)
                    Text(label, style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = .92f))
                }
            }
        }
    }
}
