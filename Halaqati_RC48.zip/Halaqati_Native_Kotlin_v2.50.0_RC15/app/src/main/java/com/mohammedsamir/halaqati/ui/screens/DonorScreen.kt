@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.ui.components.AppTopBar
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.components.animatedCountText
import com.mohammedsamir.halaqati.ui.components.halaqatiEnter
import com.mohammedsamir.halaqati.ui.components.heroBackground
import com.mohammedsamir.halaqati.ui.components.heroBrush
import com.mohammedsamir.halaqati.ui.theme.cardHairline
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** RC46/RC47: the donor ("المانح") home — a warm welcome, the month's winners on a podium per category, then the statistics view. */
@Composable
fun DonorHomeScreen(profile: Profile, pending: Int, onRefresh: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var refreshTick by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = "المانح", onRefresh = { refreshTick++; onRefresh() }, pending = pending)
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ProFilterChip(tab == 0, { tab = 0 }, "المكرَّمون", showCheckIcon = false, modifier = Modifier.weight(1f))
            ProFilterChip(tab == 1, { tab = 1 }, "الدعم", showCheckIcon = false, modifier = Modifier.weight(1f))
            ProFilterChip(tab == 2, { tab = 2 }, "الإحصاءات", showCheckIcon = false, modifier = Modifier.weight(1f))
        }
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> DonorAwardsTab(refreshTick)
                1 -> DonorSupportTab(refreshTick)
                else -> ObserverScreen(profile, pending, onRefresh, embedded = true)
            }
        }
    }
}

@Composable
private fun DonorAwardsTab(refreshTick: Int) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var months by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var month by remember { mutableStateOf<String?>(null) }
    var scopeKind by remember { mutableStateOf("halaqa") }
    var data by remember { mutableStateOf<JSONObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var picked by remember { mutableStateOf<JSONObject?>(null) }

    fun loadMonths() {
        scope.launch {
            loading = true; error = null
            runCatching { withContext(Dispatchers.IO) { AppGraph.repo.awardMonths() } }
                .onSuccess { list ->
                    months = list
                    month = month?.takeIf { m -> list.any { it.optString("month").take(7) == m } } ?: list.firstOrNull()?.optString("month")?.take(7)
                    if (list.isEmpty()) data = null
                }
                .onFailure { error = it.message ?: "تعذر التحميل" }
            loading = false
        }
    }
    LaunchedEffect(refreshTick) { loadMonths() }
    LaunchedEffect(month, scopeKind) {
        val m = month ?: return@LaunchedEffect
        loading = true
        runCatching { withContext(Dispatchers.IO) { AppGraph.repo.donorAwards("$m-01", scopeKind) } }
            .onSuccess { data = it; error = null }
            .onFailure { error = it.message ?: "تعذر التحميل"; data = null }
        loading = false
    }

    val groups = data?.optJSONArray("groups")?.awardObjects().orEmpty()
    val myHalaqas = groups.map { it.optString("halaqa_name") }.filter { it.isNotBlank() && it != "null" }.distinct()
    val allWinners = groups.flatMap { it.optJSONArray("winners")?.awardObjects().orEmpty() }
    val totalPages = allWinners.sumOf { it.optDouble("pages", 0.0) }
    val avgAttendance = if (allWinners.isEmpty()) 0.0 else allWinners.sumOf { it.optDouble("attendance_pct", 0.0) } / allWinners.size
    fun open(intent: Intent) = runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            state = rememberLazyListState(),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Surface(Modifier.fillMaxWidth().halaqatiEnter(), shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.primary) {
                    Column(
                        Modifier.fillMaxWidth().heroBackground(heroBrush(MaterialTheme.colorScheme.primary)).padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text("السلام عليكم ورحمة الله", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .8f))
                        Text("شكرًا لدعمك 🌿", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimary)
                        if (scopeKind == "halaqa" && myHalaqas.isNotEmpty()) {
                            Text("حلقتك: " + myHalaqas.joinToString("، "), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .9f))
                        }
                        Text(
                            "«خيرُكم من تعلّم القرآنَ وعلّمه» — بفضل الله ثم بدعمك تُثمر الحلقة.",
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .92f),
                        )
                    }
                }
            }
            error?.let { item { StateNotice(it, "warning") } }
            if (allWinners.isNotEmpty()) item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DonorStat("مكرَّمًا", allWinners.size.toString(), Modifier.weight(1f))
                    DonorStat("صفحة", awardNum(totalPages), Modifier.weight(1f))
                    DonorStat("حضور", awardNum(avgAttendance) + "٪", Modifier.weight(1f))
                }
            }
            if (months.isNotEmpty()) item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(months) { row ->
                        val key = row.optString("month").take(7)
                        ProFilterChip(month == key, { month = key }, awardMonthLabel(key), showCheckIcon = false)
                    }
                }
            }
            if (months.isNotEmpty()) item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProFilterChip(scopeKind == "halaqa", { scopeKind = "halaqa" }, "حسب الحلقة", showCheckIcon = false)
                    ProFilterChip(scopeKind == "category", { scopeKind = "category" }, "حسب الفئة", showCheckIcon = false)
                }
            }
            if (loading && data == null) item { LoadingSkeleton(rows = 3) }
            if (!loading && months.isEmpty() && error == null) item { EmptyState("لم يُعتمد تكريم أي شهر بعد. سيصلك إشعار عند اعتماد المدير.") }
            items(groups) { g ->
                val winners = g.optJSONArray("winners")?.awardObjects().orEmpty()
                val title = listOf(g.optString("halaqa_name").takeIf { it.isNotBlank() && it != "null" }, g.optString("category_name")).filterNotNull().joinToString(" · ")
                Surface(
                    Modifier.fillMaxWidth().halaqatiEnter(), shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.5.dp, border = cardHairline(),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("نجوم الشهر", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
                        Text(title, style = MaterialTheme.typography.titleLarge)
                        if (winners.isEmpty()) {
                            Text("لم يستوفِ أحد شروط التكريم في هذه المجموعة هذا الشهر.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            Podium(winners, onPick = { picked = it })
                        }
                    }
                }
            }
        }
    }

    picked?.let { w ->
        ModalBottomSheet(onDismissRequest = { picked = null }, containerColor = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
            val phone = w.optString("phone").takeIf { it.isNotBlank() && it != "null" }
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MedalAvatar(w.optInt("rank"), w.optString("name"), 52)
                    Column(Modifier.weight(1f)) {
                        Text(w.optString("name"), style = MaterialTheme.typography.titleMedium)
                        Text("${w.optString("halaqa_name")} · ${awardNum(w.optDouble("score"))} / 100 · ${awardNum(w.optDouble("pages"))} صفحة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                ScoreBar("الحفظ", w.optDouble("hifz_pct"), 100.0)
                ScoreBar("السرد", w.optDouble("sard_pct"), 100.0)
                ScoreBar("الحضور", w.optDouble("attendance_pct"), 100.0)
                ScoreBar("السلوك", w.optDouble("behavior") * 10, 100.0)
                ScoreBar("جودة التسميع", w.optDouble("quality") * 10, 100.0)
                if (phone != null) Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 4.dp)) {
                    FilledTonalButton(onClick = { open(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) }, modifier = Modifier.weight(1f)) { Text("اتصال بولي الأمر") }
                    FilledTonalButton(onClick = { open(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + phone.filter { it.isDigit() }))) }, modifier = Modifier.weight(1f)) { Text("واتساب") }
                }
            }
        }
    }
}

@Composable
private fun DonorStat(label: String, value: String, modifier: Modifier) {
    Surface(modifier.halaqatiEnter(), shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 1.5.dp, border = cardHairline()) {
        Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(animatedCountText(value), style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun MedalAvatar(rank: Int, name: String, size: Int) {
    val base = medalColor(rank)
    Box(
        Modifier.size(size.dp).background(base, CircleShape),
        contentAlignment = Alignment.Center,
    ) { Text(name.trim().take(1), color = Color.White, style = MaterialTheme.typography.titleLarge) }
}

@Composable
private fun ScoreBar(label: String, value: Double, max: Double) {
    val fraction = (value / max).coerceIn(0.0, 1.0).toFloat()
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
            Text(awardNum(value) + "٪", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LinearProgressIndicator(
            progress = { fraction }, modifier = Modifier.fillMaxWidth().height(6.dp).padding(top = 2.dp),
            trackColor = MaterialTheme.colorScheme.surfaceVariant, color = MaterialTheme.colorScheme.primary,
        )
    }
}

/** First place in the middle and tallest, second on the right, third on the left (RTL reading order). Plinths rise in. */
@Composable
private fun Podium(winners: List<JSONObject>, onPick: (JSONObject) -> Unit) {
    val byRank = winners.associateBy { it.optInt("rank") }
    val order = listOf(2, 1, 3).map { byRank[it] }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
        listOf(2, 1, 3).forEachIndexed { idx, rank ->
            val w = order[idx]
            val target = when (rank) { 1 -> 64.dp; 2 -> 44.dp; else -> 30.dp }
            val h by animateDpAsState(if (shown) target else 0.dp, tween(650), label = "plinth")
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                if (w != null) {
                    Surface(onClick = { onPick(w) }, color = Color.Transparent) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            MedalAvatar(rank, w.optString("name"), if (rank == 1) 68 else 54)
                            Spacer(Modifier.height(6.dp))
                            Text(w.optString("name"), style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center, maxLines = 2)
                            Text("${awardNum(w.optDouble("score"))} / 100", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (w != null) Box(
                    Modifier.fillMaxWidth().height(h).padding(top = 6.dp).background(medalColor(rank), RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)),
                    contentAlignment = Alignment.TopCenter,
                ) { Text(rank.toString(), color = Color.White, style = MaterialTheme.typography.titleLarge) }
            }
        }
    }
}
