from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.84.0',
    'versionCode':28400,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        'بطاقات الدعم: ينشر المدير حاجة (دعم المحفّظين، دعم مسؤول النظام، ضيافة أسبوعية أو شهرية للطلاب، جوائز) ويتكفّل بها المانح بفترات يختارها، والتحويل يتم خارج التطبيق.',
        'يؤكد المدير استلام الدعم ثم يسجّل التسليم بإفادة مكتوبة وصورة اختيارية، فيراها المانح في «كفالاتي» ويصله إشعار شكر. يرى المانح عدد الطلاب المستفيدين دون أسمائهم.',
        'ربط المانح بحلقاته: من صفحة «الدعم والمانحون» يحدّد المدير الحلقات التي يراها كل مانح (التكريم والإحصاءات وبطاقات الدعم)، ومن لم تُحدَّد له يرى كل الحلقات.',
        'تصميم جديد بالكامل بروح iOS الحديثة: صفحات رمادية دافئة وبطاقات بيضاء كبيرة الزوايا بظل ناعم، وشريط علوي وسفلي أخف، وأزرار اختيار على شكل أقراص.',
        'زخرفة نجمة ثمانية إسلامية خافتة (ترسم بلا صور) خلف بطاقات الترحيب، وتدرّج أخضر زمردي، وأيقونات مستديرة ملوّنة في الاختصارات، مع دخول متتابع وضغط ناعم.',
        'صفحة المانح الجديدة: ترحيب دافئ وأرقام الشهر ومنصّة فائزين لكل فئة تنمو بحركة، وضغطة على الطالب تفتح ورقة بدرجاته مفصّلة. أُزيل قسم التثبيت.',
        'التكريم الشهري (للمدير): درجة من ١٠٠ (حفظ ٤٠ · سرد ٣٠ · حضور ١٠ · سلوك ١٠ · جودة ١٠) تُحسب فجر اليوم الأول من الشهر لكل حلقة أو لكل فئة، بشروط (حفظ فوق ٩٠٪، سرد ١٠٠٪، غياب بلا عذر لا يزيد على جلستين). تراجعها وتستبعد من تشاء بسبب، ثم تعتمد الشهر.',
        'واجهة المانح الجديدة: أشهر معتمدة، وأفضل ٣ طلاب في كل فئة بأسمائهم الكاملة، ومجتهدو التثبيت. رقم ولي الأمر لا يظهر إلا بإذن المدير لكل طالب.',
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
