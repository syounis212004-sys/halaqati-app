package com.mohammedsamir.halaqati.pushbridge;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;

@CapacitorPlugin(name = "HalaqatiPushBridge")
public class HalaqatiPushBridgePlugin extends Plugin {

    private static final String PREFS = "halaqati_push";
    private static final String TOKEN_KEY = "fcm_token";

    private FirebaseApp ensureFirebase() {
        try {
            return FirebaseApp.getInstance();
        } catch (IllegalStateException ignored) {
            FirebaseApp initialized = FirebaseApp.initializeApp(getContext());
            if (initialized == null) {
                throw new IllegalStateException("FirebaseApp initialization returned null. Check google-services.json.");
            }
            return initialized;
        }
    }

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private void cacheToken(String token) {
        if (token != null && !token.trim().isEmpty()) {
            prefs().edit().putString(TOKEN_KEY, token.trim()).apply();
        }
    }

    private String cachedToken() {
        return prefs().getString(TOKEN_KEY, "");
    }

    @PluginMethod
    public void diagnostics(PluginCall call) {
        try {
            FirebaseApp app = ensureFirebase();
            FirebaseOptions options = app.getOptions();
            boolean playServicesInstalled = false;
            String playServicesVersion = "";
            try {
                PackageInfo info = getContext().getPackageManager().getPackageInfo("com.google.android.gms", 0);
                playServicesInstalled = info != null;
                if (info != null) playServicesVersion = String.valueOf(info.versionName);
            } catch (Exception ignored) {}
            String cached = cachedToken();
            JSObject out = new JSObject();
            out.put("ok", true);
            out.put("packageName", getContext().getPackageName());
            out.put("projectId", options.getProjectId());
            out.put("applicationId", options.getApplicationId());
            out.put("senderId", options.getGcmSenderId());
            out.put("autoInitEnabled", FirebaseMessaging.getInstance().isAutoInitEnabled());
            out.put("playServicesInstalled", playServicesInstalled);
            out.put("playServicesVersion", playServicesVersion);
            out.put("cachedToken", cached != null && !cached.isEmpty());
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Firebase diagnostics failed: " + String.valueOf(e.getMessage()), e);
        }
    }

    @PluginMethod
    public void getCachedToken(PluginCall call) {
        JSObject out = new JSObject();
        String token = cachedToken();
        out.put("token", token == null ? "" : token);
        out.put("cached", token != null && !token.isEmpty());
        call.resolve(out);
    }

    @PluginMethod
    public void getToken(PluginCall call) {
        try {
            ensureFirebase();
            FirebaseMessaging messaging = FirebaseMessaging.getInstance();
            messaging.setAutoInitEnabled(true);
            messaging.getToken().addOnCompleteListener(task -> {
                if (!task.isSuccessful()) {
                    Exception ex = task.getException();
                    call.reject("FCM token failed: " + (ex != null ? ex.getMessage() : "unknown error"), ex);
                    return;
                }
                String token = task.getResult();
                if (token == null || token.trim().isEmpty()) {
                    call.reject("FCM returned an empty token");
                    return;
                }
                cacheToken(token);
                JSObject out = new JSObject();
                out.put("token", token);
                out.put("last4", token.length() > 4 ? token.substring(token.length() - 4) : token);
                call.resolve(out);
            });
        } catch (Exception e) {
            call.reject("FCM token bridge failed: " + String.valueOf(e.getMessage()), e);
        }
    }
}
