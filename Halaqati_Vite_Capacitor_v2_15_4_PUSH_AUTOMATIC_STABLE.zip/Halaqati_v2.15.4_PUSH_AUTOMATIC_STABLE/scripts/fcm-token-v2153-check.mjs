import fs from 'node:fs';
const r=fs.readFileSync('src/features/notifications/runtime.js','utf8');
const c=JSON.parse(fs.readFileSync('capacitor.config.json','utf8'));
function ok(v,m){if(!v)throw new Error(m)}
ok(r.includes('directNativeFcmToken'),'direct native token recovery missing');
ok(r.includes('registrationError'),'Capacitor registrationError listener missing');
ok(r.includes("let ready=await enablePushNotifications(true)"),'test push must auto-enable first');
ok(r.includes("Promise.resolve().then(()=>p.register())"),'Capacitor register must be non-blocking');
ok(r.includes("window.addEventListener('online'"),'online auto retry missing');
ok(c.plugins?.PushNotifications?.presentationOptions?.includes('alert'),'foreground alert presentation missing');
ok(c.plugins?.PushNotifications?.presentationOptions?.includes('sound'),'foreground sound presentation missing');
console.log('FCM_TOKEN_V2153_CHECK_PASS');
