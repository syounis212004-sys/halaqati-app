alter table public.user_devices
  add column if not exists registration_type text not null default 'token';

alter table public.user_devices
  drop constraint if exists user_devices_registration_type_check;

alter table public.user_devices
  add constraint user_devices_registration_type_check
  check (registration_type in ('token','fid'));

create index if not exists idx_user_devices_active_registration_type
  on public.user_devices(user_id, active, registration_type);
