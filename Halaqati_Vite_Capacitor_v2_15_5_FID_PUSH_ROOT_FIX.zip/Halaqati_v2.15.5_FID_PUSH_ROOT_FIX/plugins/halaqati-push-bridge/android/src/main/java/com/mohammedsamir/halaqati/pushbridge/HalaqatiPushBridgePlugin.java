package com.mohammedsamir.halaqati.pushbridge;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.installations.FirebaseInstallations;
import com.google.firebase.messaging.FirebaseMessaging;

@CapacitorPlugin(name = "HalaqatiPushBridge")
public class HalaqatiPushBridgePlugin extends Plugin {

    private static final String PREFS = "halaqati_push";
    private static final String REGISTRATION_ID_KEY = "fcm_registration_id";
    private static final String REGISTRATION_TYPE_KEY = "fcm_registration_type";

    /**
     * Firebase must be initialized by FirebaseInitProvider from google-services.json.
     * We deliberately avoid manual Firebase initialization here. Firebase Android
     * SDK issue #8016 documented a deterministic heartbeat/DataStore deadlock when
     * Firebase was manually initialized and immediately used by Installations/Messaging.
     */
    private FirebaseApp firebaseApp() {
        return FirebaseApp.getInstance();
    }

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private void cacheRegistration(String id, String type) {
        if (id != null && !id.trim().isEmpty()) {
            prefs().edit()
                .putString(REGISTRATION_ID_KEY, id.trim())
                .putString(REGISTRATION_TYPE_KEY, type == null ? "fid" : type)
                .apply();
        }
    }

    private String cachedRegistrationId() {
        return prefs().getString(REGISTRATION_ID_KEY, "");
    }

    private String cachedRegistrationType() {
        return prefs().getString(REGISTRATION_TYPE_KEY, "fid");
    }

    @PluginMethod
    public void diagnostics(PluginCall call) {
        try {
            FirebaseApp app = firebaseApp();
            FirebaseOptions options = app.getOptions();
            boolean playServicesInstalled = false;
            String playServicesVersion = "";
            try {
                PackageInfo info = getContext().getPackageManager().getPackageInfo("com.google.android.gms", 0);
                playServicesInstalled = info != null;
                if (info != null) playServicesVersion = String.valueOf(info.versionName);
            } catch (Exception ignored) {}
            String cached = cachedRegistrationId();
            JSObject out = new JSObject();
            out.put("ok", true);
            out.put("packageName", getContext().getPackageName());
            out.put("projectId", options.getProjectId());
            out.put("applicationId", options.getApplicationId());
            out.put("senderId", options.getGcmSenderId());
            out.put("autoInitEnabled", FirebaseMessaging.getInstance().isAutoInitEnabled());
            out.put("playServicesInstalled", playServicesInstalled);
            out.put("playServicesVersion", playServicesVersion);
            out.put("cachedRegistration", cached != null && !cached.isEmpty());
            out.put("registrationType", cachedRegistrationType());
            out.put("registrationApi", "fid");
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Firebase diagnostics failed: " + String.valueOf(e.getMessage()), e);
        }
    }

    @PluginMethod
    public void getCachedRegistration(PluginCall call) {
        JSObject out = new JSObject();
        String id = cachedRegistrationId();
        out.put("registrationId", id == null ? "" : id);
        out.put("registrationType", cachedRegistrationType());
        out.put("cached", id != null && !id.isEmpty());
        call.resolve(out);
    }

    /**
     * Firebase Messaging 25.1+ introduced the FID registration API. register()
     * performs the FCM backend registration; only after it succeeds do we read
     * the Firebase Installation ID and return it to JavaScript/server storage.
     * This avoids the deprecated getToken() path entirely.
     */
    @PluginMethod
    public void registerFid(PluginCall call) {
        try {
            firebaseApp(); // fail fast if google-services/FirebaseInitProvider is broken
            FirebaseMessaging messaging = FirebaseMessaging.getInstance();
            messaging.setAutoInitEnabled(true);
            messaging.register().addOnCompleteListener(registerTask -> {
                if (!registerTask.isSuccessful()) {
                    Exception ex = registerTask.getException();
                    call.reject("FCM FID registration failed: " + (ex != null ? ex.getMessage() : "unknown error"), ex);
                    return;
                }
                FirebaseInstallations.getInstance().getId().addOnCompleteListener(fidTask -> {
                    if (!fidTask.isSuccessful()) {
                        Exception ex = fidTask.getException();
                        call.reject("Firebase Installation ID failed: " + (ex != null ? ex.getMessage() : "unknown error"), ex);
                        return;
                    }
                    String fid = fidTask.getResult();
                    if (fid == null || fid.trim().isEmpty()) {
                        call.reject("Firebase returned an empty Installation ID");
                        return;
                    }
                    cacheRegistration(fid, "fid");
                    JSObject out = new JSObject();
                    out.put("registrationId", fid);
                    out.put("registrationType", "fid");
                    out.put("last4", fid.length() > 4 ? fid.substring(fid.length() - 4) : fid);
                    call.resolve(out);
                });
            });
        } catch (Exception e) {
            call.reject("FCM FID bridge failed: " + String.valueOf(e.getMessage()), e);
        }
    }
}
