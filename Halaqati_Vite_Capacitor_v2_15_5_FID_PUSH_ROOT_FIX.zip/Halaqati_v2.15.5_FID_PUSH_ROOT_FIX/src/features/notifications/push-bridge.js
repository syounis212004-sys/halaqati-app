/* Halaqati v2.15.5 — crash-safe Push bridge.
   Push is automatic. The direct native Firebase FID bridge is registered explicitly
   so token retrieval never depends on the legacy Capacitor.Plugins global. */
import { registerPlugin } from '@capacitor/core';

const firebaseConfigured = String(import.meta.env.VITE_HALAQATI_FIREBASE_CONFIGURED || 'false').toLowerCase() === 'true';
let loadPromise = null;

window.HalaqatiPushConfigured = firebaseConfigured;
window.HalaqatiPushNotifications = null;
window.HalaqatiPushLoadError = '';
window.HalaqatiNativePushBridge = firebaseConfigured ? registerPlugin('HalaqatiPushBridge') : null;

window.loadHalaqatiPushPlugin = async function loadHalaqatiPushPlugin(){
  if(!firebaseConfigured) return null;
  if(window.HalaqatiPushNotifications) return window.HalaqatiPushNotifications;
  if(loadPromise) return loadPromise;
  loadPromise = import('@capacitor/push-notifications')
    .then(mod => {
      const plugin = mod?.PushNotifications || null;
      window.HalaqatiPushNotifications = plugin;
      return plugin;
    })
    .catch(err => {
      window.HalaqatiPushLoadError = String(err?.message || err || 'Push plugin load failed');
      console.warn('PushNotifications lazy load failed', err);
      loadPromise = null;
      return null;
    });
  return loadPromise;
};
