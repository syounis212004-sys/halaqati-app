from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.88.0',
    'versionCode':28800,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "مكافأة الطالب صارت تدفقًا كاملًا: تختار نوع المكافأة (مبلغ مالي أو هدية عينية) من خيارات يحددها المدير، ثم موافقة المدير، فبيانات التحويل وإثباته، ثم تأكيد الاستلام وتسليم الطالب مع رسالة شكر، وشريط تتبّع واضح بالتواريخ في كل طلب.",
        "محادثة خاصة لكل طلب مكافأة ولكل كفالة بين المانح والمدير فقط، تتضمن أحداث الحالة تلقائيًا وإشعارات للطرفين، دون أي تواصل بين المانحين أو مع أولياء الأمور والطلاب.",
        "سياسة منع تكرار مكافأة الطالب يحددها المدير (واحدة شهريًا، أو تجميع الطلبات، أو تمويل مشترك) مع رفض الطلب المكرر من المانح نفسه خلال 24 ساعة، وإصلاح سباق السعة في الكفالات.",
        "نوع حساب «مانح» عند إنشاء الحساب وعند إكمال الحساب، مع إشعار المدير وشاشة انتظار مناسبة.",
        "صفحة ولي الأمر: بطاقة «نظرة اليوم» (مقرر اليوم، هل سمّع، الحضور، الأخطاء والتنبيهات والجودة لآخر يوم تسميع)، وإصلاح مقرر اليوم الذي كان يبدأ قبل آخر ما سمّعه الطالب.",
        "شارات أصعب وتنافسية: أوسمة شهرية بثلاث درجات ووسام موسمي لا يُمنح إلا لمن حقق أوسمة ثلاثة أشهر متتالية.",
        "صفحة إنجازات ولي الأمر: بطاقات مرتّبة ومتوسطة، ومنتقي فترة واضح (حسب الشهر أو آخر 7/30/90 يومًا) مع عنوان يبيّن الفترة.",
        "منتقي أشهر حقيقي في «المكرَّمون» وتبويبات مقسّمة بمؤشر منزلق وانتقال سلس للمحتوى.",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
