package com.mohammedsamir.halaqati.ui.components

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.ui.theme.LocalReducedMotion
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/**
 * RC27.15: small shared motion helpers used across the app. All of them respect "الحركة: مخففة"
 * ([LocalReducedMotion]) and never change layout size, so they are safe to add to any card or row.
 */

/**
 * Hands out a growing delay to elements that appear in the same instant, so a screenful of cards rises one after
 * another (a soft cascade) without anyone passing an index. Calls more than 90 ms apart start a new cascade.
 */
internal object HalaqatiEnterClock {
    private var last = 0L
    private var step = 0

    fun nextDelayMillis(): Long {
        val now = SystemClock.uptimeMillis()
        step = if (now - last > 90L) 0 else minOf(step + 1, 8)
        last = now
        return step * 45L
    }
}

/** Fade + short rise on first composition. Elements that appear together cascade (see [HalaqatiEnterClock]). */
@Composable
fun Modifier.halaqatiEnter(): Modifier {
    val reduced = LocalReducedMotion.current
    val progress = remember { Animatable(if (reduced) 1f else 0f) }
    val startDelay = remember { HalaqatiEnterClock.nextDelayMillis() }
    LaunchedEffect(Unit) {
        if (!reduced) {
            delay(startDelay)
            progress.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
        }
    }
    return this.graphicsLayer {
        alpha = progress.value
        translationY = (1f - progress.value) * 18.dp.toPx()
    }
}

/** Counts a whole number up from 0 the first time it is shown, and between values when it changes. Other text is returned as is. */
@Composable
fun animatedCountText(value: String): String {
    val reduced = LocalReducedMotion.current
    val target = value.trim().toIntOrNull()
    val counter = remember { Animatable(0f) }
    LaunchedEffect(target, reduced) {
        if (target != null && !reduced) counter.animateTo(target.toFloat(), tween(850, easing = FastOutSlowInEasing))
    }
    return if (target == null || reduced) value else counter.value.roundToInt().toString()
}
