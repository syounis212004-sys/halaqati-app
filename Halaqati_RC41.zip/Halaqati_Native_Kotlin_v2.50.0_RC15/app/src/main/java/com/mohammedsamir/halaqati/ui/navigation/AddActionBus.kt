package com.mohammedsamir.halaqati.ui.navigation

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** RC40: the bottom bar's "＋" button asks the Sessions page to open its "new session" dialog (survives the page being created late). */
object AddActionBus {
    private val flag = MutableStateFlow(false)
    val requested: StateFlow<Boolean> get() = flag
    fun request() { flag.value = true }
    fun consume() { flag.value = false }
}
