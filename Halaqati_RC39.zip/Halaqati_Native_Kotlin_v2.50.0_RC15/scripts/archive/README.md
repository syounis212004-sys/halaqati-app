# Archived release gates
Historical gates pinned to old version numbers / UI that no longer exist (RC9–RC20).
They are kept for reference only and are NOT part of the active gate suite.
Active gates live in scripts/*check*.py.
