# RC27.48 — إصلاح بناء 2.63.47 (2.63.48 / 26348)

- فشل البناء: `BirthDateField.kt` ينقصه `import androidx.compose.ui.unit.dp`. أُضيف.
- كل ميزات RC27.47 باقية كما هي.
