package com.mohammedsamir.halaqati.ui.guardian

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.material3.CardColors
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.ui.theme.HalaqatiUiTokens

/**
 * RC27.11: ONE card look for the whole app. Card / ElevatedCard / OutlinedCard in this package resolve here
 * (same-package declarations win over the material3 star import), so every card gets the same shape, the same
 * fine hairline border and no shadow. Callers may still pass their own colors (status tints) and an emphasised
 * border (thicker than a hairline); the shape and elevation are fixed on purpose so screens never drift apart.
 */
@Composable
private fun unifiedColors(colors: CardColors?): CardColors =
    colors ?: CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)

@Composable
private fun unifiedBorder(border: BorderStroke?): BorderStroke =
    if (border != null && border.width > 1.dp) border else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)

private val unifiedShape: Shape get() = androidx.compose.foundation.shape.RoundedCornerShape(HalaqatiUiTokens.RadiusMedium)

@Composable
fun Card(
    modifier: Modifier = Modifier,
    @Suppress("UNUSED_PARAMETER") shape: Shape? = null,
    colors: CardColors? = null,
    @Suppress("UNUSED_PARAMETER") elevation: androidx.compose.material3.CardElevation? = null,
    border: BorderStroke? = null,
    content: @Composable ColumnScope.() -> Unit,
) = androidx.compose.material3.Card(
    modifier = modifier, shape = unifiedShape, colors = unifiedColors(colors),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), border = unifiedBorder(border), content = content,
)

@Composable
fun Card(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    @Suppress("UNUSED_PARAMETER") shape: Shape? = null,
    colors: CardColors? = null,
    @Suppress("UNUSED_PARAMETER") elevation: androidx.compose.material3.CardElevation? = null,
    border: BorderStroke? = null,
    content: @Composable ColumnScope.() -> Unit,
) = androidx.compose.material3.Card(
    onClick = onClick, modifier = modifier, enabled = enabled, shape = unifiedShape, colors = unifiedColors(colors),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), border = unifiedBorder(border), content = content,
)

@Composable
fun ElevatedCard(
    modifier: Modifier = Modifier,
    @Suppress("UNUSED_PARAMETER") shape: Shape? = null,
    colors: CardColors? = null,
    @Suppress("UNUSED_PARAMETER") elevation: androidx.compose.material3.CardElevation? = null,
    content: @Composable ColumnScope.() -> Unit,
) = androidx.compose.material3.Card(
    modifier = modifier, shape = unifiedShape, colors = unifiedColors(colors),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), border = unifiedBorder(null), content = content,
)

@Composable
fun ElevatedCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    @Suppress("UNUSED_PARAMETER") shape: Shape? = null,
    colors: CardColors? = null,
    @Suppress("UNUSED_PARAMETER") elevation: androidx.compose.material3.CardElevation? = null,
    content: @Composable ColumnScope.() -> Unit,
) = androidx.compose.material3.Card(
    onClick = onClick, modifier = modifier, enabled = enabled, shape = unifiedShape, colors = unifiedColors(colors),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), border = unifiedBorder(null), content = content,
)

@Composable
fun OutlinedCard(
    modifier: Modifier = Modifier,
    @Suppress("UNUSED_PARAMETER") shape: Shape? = null,
    colors: CardColors? = null,
    @Suppress("UNUSED_PARAMETER") elevation: androidx.compose.material3.CardElevation? = null,
    border: BorderStroke? = null,
    content: @Composable ColumnScope.() -> Unit,
) = androidx.compose.material3.Card(
    modifier = modifier, shape = unifiedShape, colors = unifiedColors(colors),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), border = unifiedBorder(border), content = content,
)

@Composable
fun OutlinedCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    @Suppress("UNUSED_PARAMETER") shape: Shape? = null,
    colors: CardColors? = null,
    @Suppress("UNUSED_PARAMETER") elevation: androidx.compose.material3.CardElevation? = null,
    border: BorderStroke? = null,
    content: @Composable ColumnScope.() -> Unit,
) = androidx.compose.material3.Card(
    onClick = onClick, modifier = modifier, enabled = enabled, shape = unifiedShape, colors = unifiedColors(colors),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), border = unifiedBorder(border), content = content,
)
