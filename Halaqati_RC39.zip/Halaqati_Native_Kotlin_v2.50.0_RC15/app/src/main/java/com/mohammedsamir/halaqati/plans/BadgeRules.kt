package com.mohammedsamir.halaqati.plans

/**
 * RC27.37 daily badges, computed from existing attendance and recitation rows (no new tables).
 * Levels: 1 bronze, 2 silver, 3 gold.
 */
object BadgeRules {
    data class Attendance(val date: String, val status: String, val cancelled: Boolean = false)
    data class Recitation(val date: String, val pages: Double, val evaluation: String, val cancelled: Boolean = false)
    data class Badge(val key: String, val title: String, val detail: String, val level: Int)
    data class Next(val title: String, val remaining: Int, val unit: String)
    data class Result(val earned: List<Badge>, val next: Next?)

    private val POOR = setOf("repeat", "weak", "إعادة", "ضعيف")

    val STREAK_STEPS = listOf(3, 7, 15)
    val QUALITY_STEPS = listOf(3, 5, 10)
    val PAGES_STEPS = listOf(10.0, 30.0, 60.0)

    /** Consecutive present/late sessions from the newest backwards; excused is neutral, absent breaks. */
    fun attendanceStreak(rows: List<Attendance>): Int {
        var n = 0
        for (r in rows.filter { !it.cancelled }.sortedByDescending { it.date }) {
            when (r.status) {
                "present", "late" -> n++
                "excused" -> Unit
                else -> break
            }
        }
        return n
    }

    /** Consecutive recent recitations that were not repeat/weak. */
    fun qualityStreak(rows: List<Recitation>): Int {
        var n = 0
        for (r in rows.filter { !it.cancelled }.sortedByDescending { it.date }) {
            if (r.evaluation.lowercase() in POOR) break else n++
        }
        return n
    }

    private fun level(value: Double, steps: List<Double>): Int = steps.count { value >= it }

    fun compute(attendance: List<Attendance>, recitations: List<Recitation>, today: java.time.LocalDate = java.time.LocalDate.now()): Result {
        val earned = ArrayList<Badge>()
        val streak = attendanceStreak(attendance)
        val sl = level(streak.toDouble(), STREAK_STEPS.map { it.toDouble() })
        if (sl > 0) earned += Badge("streak", "انتظام", "$streak جلسات متتالية", sl)
        val quality = qualityStreak(recitations)
        val ql = level(quality.toDouble(), QUALITY_STEPS.map { it.toDouble() })
        if (ql > 0) earned += Badge("quality", "إتقان", "$quality تسميعات متتالية بجودة", ql)
        val from = today.minusDays(30).toString()
        val pages = recitations.filter { !it.cancelled && it.date >= from }.sumOf { it.pages }
        val pl = level(pages, PAGES_STEPS)
        if (pl > 0) earned += Badge("pages", "اجتهاد", "${Math.round(pages)} صفحة خلال 30 يومًا", pl)

        // Closest next goal: the streak step still ahead (most motivating and easiest to explain).
        val nextStreak = STREAK_STEPS.firstOrNull { it > streak }
        val next = nextStreak?.let { Next("شارة الانتظام", it - streak, "جلسات متتالية") }
        return Result(earned.sortedByDescending { it.level }, next)
    }
}
