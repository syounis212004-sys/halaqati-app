from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.87.0',
    'versionCode':28700,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        'إصلاح المزامنة: كان تجديد جلسة الدخول يُرسَل من عدة عمليات في آن واحد فيرفضه الخادم ثم يحدّ من الطلبات، فتُعلَّم عمليات سليمة «تحتاج مراجعة». صار التجديد مرة واحدة بالدور مع مهلة بعد الفشل، وفشله يُعدّ انتهاء جلسة تُعاد المحاولة بعده لا خطأ في البيانات.',
        'تنبيهات الخطط الذكية تتوقف عند أول فشل مصادقة بدل إرسال مئات الطلبات (واحد لكل طالب).',
        'الرئيسية الجديدة للمانح: ملخص لكل شيء في صفحة واحدة (أرقام حلقته الحقيقية للشهر، نجوم الشهر، الدعم وما ينتظره منك، أثره، آخر الأخبار) وكل قسم يفتح صفحته.',
        'شريط المانح السفلي بأيقونات: الرئيسية، المكرَّمون، الدعم، أثري، المزيد (والإحصاءات في المزيد). أُزيلت التبويبات العلوية.',
        'استُبدلت أرقام صفحة المكرَّمين المضلِّلة (كانت أرقام الفائزين فقط) بأرقام الحلقة كاملة، وخُفّفت أزرار الشهر والنطاق إلى تبويبات مقسّمة وأقراص خفيفة.',
        'التحويل المالي صار موثّقًا: يحدّد المدير حسابًا افتراضيًا (بنك أو محفظة) أو حسابًا لكل بطاقة، والمبلغ رقمي بالشيكل أو الدولار أو الدينار الأردني. يرى المانح بيانات التحويل مع زر نسخ، ثم يرفع رقم الحوالة أو صورة الإشعار ليتحقق المدير.',
        'إصلاح الأرقام في صفحة المانح والتكريم: السلوك والجودة والسرد والحضور لا تتجاوز ١٠٠٪، والحفظ وحده قد يتجاوزها مع وسم «تجاوز الخطة».',
        'صفحات المانح الجديدة: تبويبات مقسّمة بنمط iOS، وصفحة «أثري» (أثر دعمك، شارات، تقرير الشهر مع مشاركة، سجل العطاء، أخبار الحلقة، صندوق اقتراحات)، وزر «كافئ هذا الطالب»، ورسالة شكر من المدير مع إثبات التسليم.',
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
