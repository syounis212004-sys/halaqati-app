package com.mohammedsamir.halaqati.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.ui.theme.CairoFamily

/**
 * Nour design kit: one calm vocabulary shared by every screen.
 *  - surfaces: white card (20dp corners, 1dp outline), at most ONE strong emerald hero per screen;
 *  - colour = status only (success / warning / danger) and appears as a small pill, a thin marker, or a progress fill;
 *  - numbers in Cairo (tabular look), Amiri stays for large titles;
 *  - icon sizes 20 / 24 / 28, avatar sizes 40 / 48 / 56 / 72.
 */
object NourIcon {
    val Inline: Dp = 20.dp
    val Action: Dp = 24.dp
    val Feature: Dp = 28.dp
}

object NourAvatarSize {
    val Small: Dp = 40.dp
    val Medium: Dp = 48.dp
    val Large: Dp = 56.dp
    val Hero: Dp = 72.dp
}

/** success / warning / danger / neutral -> (accent, soft container, on-container) */
@Composable
fun nourTone(kind: String): Triple<Color, Color, Color> {
    val cs = MaterialTheme.colorScheme
    return when (kind) {
        "success" -> Triple(cs.primary, cs.primaryContainer, cs.onPrimaryContainer)
        "warning" -> Triple(cs.tertiary, cs.tertiaryContainer, cs.onTertiaryContainer)
        "danger", "error" -> Triple(cs.error, cs.errorContainer, cs.onErrorContainer)
        else -> Triple(cs.onSurfaceVariant, cs.surfaceVariant, cs.onSurfaceVariant)
    }
}

@Composable
fun NourCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    marker: Color? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(20.dp)
    val base = modifier.fillMaxWidth()
    Surface(
        modifier = if (onClick != null) base.clip(shape).clickable(onClick = onClick) else base,
        shape = shape,
        color = cs.surface,
        border = BorderStroke(1.dp, cs.outlineVariant),
    ) {
        Column(Modifier.then(if (marker != null) Modifier.padding(0.dp) else Modifier)) {
            if (marker != null) Box(Modifier.fillMaxWidth().height(3.dp).background(marker))
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
        }
    }
}

/** Slim progress bar: rounded, no stop-indicator dot, fills from the reading start (right in RTL). */
@Composable
fun NourProgress(fraction: Float, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    Box(modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().clip(CircleShape).background(color))
    }
}

/** A calm number tile: soft container, big Cairo number, small label, optional 20dp icon. */
@Composable
fun NourStatTile(value: String, label: String, modifier: Modifier = Modifier, tone: String = "neutral", icon: ImageVector? = null) {
    val (accent, container, _) = nourTone(tone)
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(if (tone == "neutral") cs.surfaceVariant else container.copy(alpha = .55f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        if (icon != null) Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(NourIcon.Inline))
        Text(value, style = MaterialTheme.typography.titleLarge.copy(fontFamily = CairoFamily, fontWeight = FontWeight.ExtraBold), color = if (tone == "neutral") cs.onSurface else accent)
        Text(label, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, maxLines = 2)
    }
}

/** An icon in a soft round container; the only icon container shape used in lists and headers. */
@Composable
fun NourIconBadge(icon: ImageVector, modifier: Modifier = Modifier, tone: String = "success", size: Dp = 40.dp) {
    val (accent, container, _) = nourTone(tone)
    Box(modifier.size(size).clip(CircleShape).background(container), contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(if (size >= 48.dp) NourIcon.Feature else NourIcon.Action))
    }
}

/** Photo (or the first letter on a soft tint) at one of the four avatar sizes. */
@Composable
fun NourAvatar(photo: String?, name: String, size: Dp = NourAvatarSize.Medium, modifier: Modifier = Modifier) {
    StudentAvatar(photo, name, size, modifier)
}

/** The one strong block of a screen: emerald fill and a faint cached lattice. */
@Composable
fun NourHero(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primary) {
        Column(
            Modifier.fillMaxWidth().latticeOverlay(Color.White, .10f, 36.dp).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp), content = content,
        )
    }
}
