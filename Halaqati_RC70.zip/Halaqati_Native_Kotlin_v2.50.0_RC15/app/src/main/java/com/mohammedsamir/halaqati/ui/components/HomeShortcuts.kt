package com.mohammedsamir.halaqati.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.Assignment
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.model.UserRole
import com.mohammedsamir.halaqati.ui.navigation.AppDestination
import com.mohammedsamir.halaqati.ui.navigation.RoleNavigationPolicy
import com.mohammedsamir.halaqati.ui.theme.cardHairline

private data class Shortcut(val route: String, val label: String, val icon: ImageVector)

/**
 * RC67: one calm colour. Every tile is a solid emerald disc with a white icon (no random pastel hues), the label sits
 * below, and only the pages the signed-in role can really open are shown.
 */
@Composable
fun HomeShortcuts(showPlans: Boolean, navigate: (String) -> Unit, showAwards: Boolean = false, role: UserRole? = null) {
    fun allowed(d: AppDestination) = role == null || RoleNavigationPolicy.canOpen(role, d)
    val items = buildList {
        add(Shortcut("students", "الطلاب", Icons.Rounded.People))
        if (showPlans) add(Shortcut("plans", "الخطط", Icons.Rounded.Assignment))
        add(Shortcut("sessions", "الجلسات", Icons.Rounded.CalendarMonth))
        if (allowed(AppDestination.Exams)) add(Shortcut("exams", "الاختبارات", Icons.Rounded.Quiz))
        if (allowed(AppDestination.Certificates)) add(Shortcut("certificates", "الشهادات", Icons.Rounded.WorkspacePremium))
        add(Shortcut("reports", "التقارير", Icons.Rounded.Assessment))
        if (allowed(AppDestination.Insights)) add(Shortcut("insights", "المتابعة", Icons.Rounded.Insights))
        add(Shortcut("rankings", "الترتيب", Icons.Rounded.EmojiEvents))
        add(Shortcut("quran", "المصحف", Icons.Rounded.MenuBook))
        if (allowed(AppDestination.Team)) add(Shortcut("team", "الفريق", Icons.Rounded.Groups))
        if (showAwards) add(Shortcut("awards", "التكريم", Icons.Rounded.Star))
        if (showAwards) add(Shortcut("support", "الدعم", Icons.Rounded.Favorite))
    }
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("الوصول السريع", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = cs.onSurface)
        items.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { item ->
                    Column(
                        Modifier.weight(1f).halaqatiEnter().halaqatiPressable { navigate(item.route) }.padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Surface(shape = androidx.compose.foundation.shape.CircleShape, color = cs.primary, modifier = Modifier.size(56.dp)) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(item.icon, contentDescription = null, tint = cs.onPrimary, modifier = Modifier.size(28.dp))
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(item.label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 1)
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
