@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.mohammedsamir.halaqati.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.ui.components.AppTopBar
import com.mohammedsamir.halaqati.ui.components.latticeOverlay
import com.mohammedsamir.halaqati.ui.components.HeroTheme
import com.mohammedsamir.halaqati.ui.components.EmptyState
import com.mohammedsamir.halaqati.ui.components.LoadingSkeleton
import com.mohammedsamir.halaqati.ui.components.ProFilterChip
import com.mohammedsamir.halaqati.ui.components.SegmentedTabs
import com.mohammedsamir.halaqati.ui.components.PillChip
import com.mohammedsamir.halaqati.ui.components.StateNotice
import com.mohammedsamir.halaqati.ui.components.animatedCountText
import com.mohammedsamir.halaqati.ui.components.halaqatiEnter
import com.mohammedsamir.halaqati.ui.components.heroBackground
import com.mohammedsamir.halaqati.ui.components.heroBrush
import com.mohammedsamir.halaqati.ui.theme.cardHairline
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** RC50: the donor's home is a summary of everything (halaqa month figures, stars, support, impact, news); each section opens its page. */
@Composable
fun DonorHomeScreen(profile: Profile, pending: Int, onRefresh: () -> Unit, navigate: (String) -> Unit = {}) {
    var tick by remember { mutableIntStateOf(0) }
    var report by remember { mutableStateOf<JSONObject?>(null) }
    var halaqaNames by remember { mutableStateOf<List<String>>(emptyList()) }
    var starWinners by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var awardMonth by remember { mutableStateOf<String?>(null) }
    var openCards by remember { mutableIntStateOf(0) }
    var needProof by remember { mutableIntStateOf(0) }
    var pledgeCount by remember { mutableIntStateOf(0) }
    var deliveredCount by remember { mutableIntStateOf(0) }
    var beneficiaries by remember { mutableIntStateOf(0) }
    var news by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    val reportMonth = remember { java.time.YearMonth.now().minusMonths(1).toString() }

    LaunchedEffect(tick) {
        loading = true
        withContext(Dispatchers.IO) {
            val months = runCatching { AppGraph.repo.awardMonths() }.getOrDefault(emptyList())
            val latest = months.firstOrNull()?.optString("month")?.take(7)
            awardMonth = latest
            val payload = latest?.let { runCatching { AppGraph.repo.donorAwards("$it-01", "halaqa") }.getOrNull() }
            val groups = payload?.optJSONArray("groups")?.awardObjects().orEmpty()
            halaqaNames = groups.map { it.optString("halaqa_name") }.filter { it.isNotBlank() && it != "null" }.distinct()
            starWinners = groups.mapNotNull { g ->
                g.optJSONArray("winners")?.awardObjects()?.firstOrNull { it.optInt("rank") == 1 }
                    ?.let { w -> JSONObject(w.toString()).put("category_name", g.optString("category_name")) }
            }
            report = runCatching { AppGraph.repo.donorReport("$reportMonth-01") }.getOrNull()
            openCards = runCatching { AppGraph.repo.supportCards().size }.getOrDefault(0)
            val mine = runCatching { AppGraph.repo.myPledges() }.getOrDefault(emptyList())
            pledgeCount = mine.size
            deliveredCount = mine.count { it.optString("status") == "delivered" }
            needProof = mine.count { (it.optString("status") == "pledged" || it.optString("status") == "received") && (it.optString("transfer_submitted_at").isBlank() || it.optString("transfer_submitted_at") == "null") }
            beneficiaries = mine.filter { it.optString("status") == "delivered" }.sumOf { it.optInt("beneficiaries", 0) }
            news = runCatching { AppGraph.repo.donorNews().take(2) }.getOrDefault(emptyList())
        }
        loading = false
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = "الرئيسية", kicker = "أهلًا بك، " + profile.fullName.trim().substringBefore(' '), onRefresh = { tick++; onRefresh() }, pending = pending)
        LazyColumn(
            state = rememberLazyListState(), modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                HeroTheme {
Surface(Modifier.fillMaxWidth().halaqatiEnter(), shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.primary) {
                    Column(
                        Modifier.fillMaxWidth().heroBackground(heroBrush(MaterialTheme.colorScheme.primary)).latticeOverlay().padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text("السلام عليكم ورحمة الله", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .8f))
                        Text("شكرًا لدعمك", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimary)
                        if (halaqaNames.isNotEmpty()) {
                            Text("حلقتك: " + halaqaNames.joinToString("، "), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .9f))
                        }
                        val donorPhrase = remember { com.mohammedsamir.halaqati.ui.dashboard.RolePhrases.forRole("observer", java.time.LocalDate.now().toEpochDay()) }
                        Text(
                            donorPhrase.text + " — " + donorPhrase.source,
                            style = MaterialTheme.typography.bodyMedium, fontFamily = androidx.compose.ui.text.font.FontFamily.Serif, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .92f),
                        )
                    }
                }
}
            }
            if (loading && report == null) item { LoadingSkeleton(rows = 3) }
            report?.let { r ->
                item {
                    SummaryCard("ملخص حلقتك · " + awardMonthLabel(reportMonth), "الإحصاءات", { navigate("donor_stats") }) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SummaryTile("طالبًا", r.optInt("students").toString(), Modifier.weight(1f))
                            SummaryTile("جلسة", r.optInt("sessions").toString(), Modifier.weight(1f))
                            SummaryTile("مكرَّمون", r.optInt("winners").toString(), Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SummaryTile("صفحة حفظ", awardNum(r.optDouble("hifz_pages")), Modifier.weight(1f))
                            SummaryTile("صفحة مراجعة", awardNum(r.optDouble("review_pages")), Modifier.weight(1f))
                            SummaryTile("حضور", if (r.isNull("attendance_pct")) "—" else r.optInt("attendance_pct").toString() + "٪", Modifier.weight(1f))
                        }
                    }
                }
            }
            item {
                SummaryCard("نجوم الشهر", "كل المكرَّمين", { navigate("donor_awards") }) {
                    if (starWinners.isEmpty()) {
                        Text("لم يُعتمد تكريم بعد. سيصلك إشعار عند اعتماد المدير.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        awardMonth?.let { Text(awardMonthLabel(it), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary) }
                        starWinners.forEach { w ->
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                MedalAvatar(1, w.optString("name"), 38)
                                Column(Modifier.weight(1f)) {
                                    Text(w.optString("name"), style = MaterialTheme.typography.titleSmall)
                                    Text(w.optString("category_name") + " · " + awardNum(w.optDouble("score")) + " / 100", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
            item {
                SummaryCard("الدعم", "افتح الدعم", { navigate("donor_support") }) {
                    Text(if (openCards > 0) "$openCards بطاقة دعم مفتوحة تنتظر كفلاء." else "لا توجد بطاقات دعم مفتوحة الآن.", style = MaterialTheme.typography.bodyMedium)
                    if (needProof > 0) {
                        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .7f)) {
                            Text("لديك $needProof كفالة تنتظر إرسال إثبات التحويل.", Modifier.fillMaxWidth().padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            item {
                SummaryCard("أثري", "التفاصيل", { navigate("donor_impact") }) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryTile("كفالة", pledgeCount.toString(), Modifier.weight(1f))
                        SummaryTile("وصلت", deliveredCount.toString(), Modifier.weight(1f))
                        SummaryTile("طالب استفاد", beneficiaries.toString(), Modifier.weight(1f))
                    }
                }
            }
            if (news.isNotEmpty()) item {
                SummaryCard("آخر أخبار الحلقة", "أثري", { navigate("donor_impact") }) {
                    news.forEach { n ->
                        Column {
                            Text(n.optString("title"), style = MaterialTheme.typography.titleSmall)
                            n.optString("body").takeIf { it.isNotBlank() && it != "null" }?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(title: String, action: String, onAction: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Surface(Modifier.fillMaxWidth().halaqatiEnter(), shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 1.5.dp, border = cardHairline()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = onAction) { Text(action + " ‹") }
            }
            content()
        }
    }
}

@Composable
private fun SummaryTile(label: String, value: String, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)) {
        Column(Modifier.padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(animatedCountText(value), style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DonorPage(title: String, profile: Profile, pending: Int, onRefresh: () -> Unit, content: @Composable (Int) -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title = title, kicker = "أهلًا بك، " + profile.fullName.trim().substringBefore(' '), onRefresh = { tick++; onRefresh() }, pending = pending)
        Box(Modifier.weight(1f)) { content(tick) }
    }
}

@Composable
fun DonorAwardsPage(profile: Profile, pending: Int, onRefresh: () -> Unit) = DonorPage("المكرَّمون", profile, pending, onRefresh) { DonorAwardsTab(it) }

@Composable
fun DonorSupportPage(profile: Profile, pending: Int, onRefresh: () -> Unit) = DonorPage("الدعم", profile, pending, onRefresh) { tick ->
    var section by rememberSaveable { mutableIntStateOf(0) }
    val chatScope = rememberCoroutineScope()
    var chatId by remember { mutableStateOf<String?>(null) }
    var chatError by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        // RC60: private chat with the administrator (general, not tied to a request)
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.End) {
            androidx.compose.material3.FilledTonalButton(
                onClick = {
                    chatScope.launch {
                        runCatching { kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { com.mohammedsamir.halaqati.data.AppGraph.repo.chatOpenDirect(profile.id) } }
                            .onSuccess { chatId = it; chatError = null }
                            .onFailure { chatError = it.message ?: "تعذر فتح المحادثة" }
                    }
                },
                modifier = Modifier.heightIn(min = 48.dp),
            ) { Text("محادثة مع المدير") }
        }
        chatError?.let { com.mohammedsamir.halaqati.ui.components.StateNotice(it, kind = "error", modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) }
        SegmentedTabs(listOf("الكفالات والدعم", "طلبات المكافآت"), section, { section = it }, Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        com.mohammedsamir.halaqati.ui.components.TabContentTransition(section, { it }, Modifier.weight(1f)) { s ->
            if (s == 0) DonorSupportTab(tick) else DonorRewardsTab(tick)
        }
    }
    chatId?.let { id -> ChatSheet(id, "محادثة مع المدير") { chatId = null } }
}

@Composable
fun DonorImpactPage(profile: Profile, pending: Int, onRefresh: () -> Unit) = DonorPage("أثري", profile, pending, onRefresh) { DonorImpactTab(it) }

@Composable
private fun DonorAwardsTab(refreshTick: Int) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var months by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var month by remember { mutableStateOf<String?>(null) }
    var scopeKind by remember { mutableStateOf("halaqa") }
    var data by remember { mutableStateOf<JSONObject?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var picked by remember { mutableStateOf<JSONObject?>(null) }
    var rewardFor by remember { mutableStateOf<JSONObject?>(null) }
    var rewardNote by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf<String?>(null) }

    fun loadMonths() {
        scope.launch {
            loading = true; error = null
            runCatching { withContext(Dispatchers.IO) { AppGraph.repo.awardMonths() } }
                .onSuccess { list ->
                    months = list
                    month = month?.takeIf { m -> list.any { it.optString("month").take(7) == m } } ?: list.firstOrNull()?.optString("month")?.take(7)
                    if (list.isEmpty()) data = null
                }
                .onFailure { error = it.message ?: "تعذر التحميل" }
            loading = false
        }
    }
    LaunchedEffect(refreshTick) { loadMonths() }
    LaunchedEffect(month, scopeKind) {
        val m = month ?: return@LaunchedEffect
        loading = true
        runCatching { withContext(Dispatchers.IO) { AppGraph.repo.donorAwards("$m-01", scopeKind) } }
            .onSuccess { data = it; error = null }
            .onFailure { error = it.message ?: "تعذر التحميل"; data = null }
        loading = false
    }

    val groups = data?.optJSONArray("groups")?.awardObjects().orEmpty()
    fun open(intent: Intent) = runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            state = rememberLazyListState(),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            notice?.let { n -> item { StateNotice(n, "success") } }
            error?.let { item { StateNotice(it, "warning") } }
            if (months.isNotEmpty()) item {
                com.mohammedsamir.halaqati.ui.components.MonthPicker(months.map { it.optString("month").take(7) }, month, { month = it })
            }
            if (months.isNotEmpty()) item {
                SegmentedTabs(listOf("حسب الحلقة", "حسب الفئة"), if (scopeKind == "halaqa") 0 else 1, { scopeKind = if (it == 0) "halaqa" else "category" })
            }
            if (loading && data == null) item { LoadingSkeleton(rows = 3) }
            if (!loading && months.isEmpty() && error == null) item { EmptyState("لم يُعتمد تكريم أي شهر بعد. سيصلك إشعار عند اعتماد المدير.") }
            item(key = "groups") {
                com.mohammedsamir.halaqati.ui.components.TabContentTransition(scopeKind, { if (it == "halaqa") 0 else 1 }) { _ ->
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        groups.forEach { g ->
                val winners = g.optJSONArray("winners")?.awardObjects().orEmpty()
                val title = listOf(g.optString("halaqa_name").takeIf { it.isNotBlank() && it != "null" }, g.optString("category_name")).filterNotNull().joinToString(" · ")
                Surface(
                    Modifier.fillMaxWidth().halaqatiEnter(), shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.5.dp, border = cardHairline(),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("نجوم الشهر", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
                        Text(title, style = MaterialTheme.typography.titleLarge)
                        if (winners.isEmpty()) {
                            Text("لم يستوفِ أحد شروط التكريم في هذه المجموعة هذا الشهر.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            Podium(winners, onPick = { picked = it })
                        }
                    }
                }
                        }
                    }
                }
            }
        }
    }

    rewardFor?.let { w ->
        RewardRequestDialog(
            winner = w, month = month.orEmpty(),
            onDismiss = { rewardFor = null },
            onFinished = { msg, _ -> rewardFor = null; picked = null; notice = msg },
        )
    }
    notice?.let { n -> LaunchedEffect(n) { kotlinx.coroutines.delay(3500); notice = null } }

    picked?.let { w ->
        ModalBottomSheet(onDismissRequest = { picked = null }, containerColor = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)) {
            val phone = w.optString("phone").takeIf { it.isNotBlank() && it != "null" }
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MedalAvatar(w.optInt("rank"), w.optString("name"), 52)
                    Column(Modifier.weight(1f)) {
                        Text(w.optString("name"), style = MaterialTheme.typography.titleMedium)
                        Text("${w.optString("halaqa_name")} · ${awardNum(w.optDouble("score"))} / 100 · ${awardNum(w.optDouble("pages"))} صفحة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                ScoreBar("الحفظ", w.optDouble("hifz_pct"), allowOver = true)
                ScoreBar("السرد", w.optDouble("sard_pct"))
                ScoreBar("الحضور", w.optDouble("attendance_pct"))
                ScoreBar("السلوك", w.optDouble("behavior"))
                ScoreBar("جودة التسميع", w.optDouble("quality"))
                Text("للدعم أو المكافأة افتح تبويب «الدعم»، أو اطلب مكافأة هذا الطالب عبر المدير.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = { rewardFor = w }, modifier = Modifier.fillMaxWidth()) { Text("كافئ هذا الطالب") }
                if (phone != null) Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 4.dp)) {
                    FilledTonalButton(onClick = { open(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) }, modifier = Modifier.weight(1f)) { Text("اتصال بولي الأمر") }
                    FilledTonalButton(onClick = { open(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + phone.filter { it.isDigit() }))) }, modifier = Modifier.weight(1f)) { Text("واتساب") }
                }
            }
        }
    }
}

@Composable
private fun MedalAvatar(rank: Int, name: String, size: Int) {
    val base = medalColor(rank)
    Box(
        Modifier.size(size.dp).background(base, CircleShape),
        contentAlignment = Alignment.Center,
    ) { Text(name.trim().take(1), color = Color.White, style = MaterialTheme.typography.titleLarge) }
}

@Composable
private fun ScoreBar(label: String, raw: Double, allowOver: Boolean = false) {
    // Only the hifz figure may pass 100% (a student can exceed the plan); every other figure is capped at 100%.
    val value = if (allowOver) raw else raw.coerceAtMost(100.0)
    val fraction = (value / 100.0).coerceIn(0.0, 1.0).toFloat()
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
            Text(awardNum(value) + "٪" + if (allowOver && value > 100.0) " · تجاوز الخطة" else "", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LinearProgressIndicator(
            progress = { fraction }, modifier = Modifier.fillMaxWidth().height(6.dp).padding(top = 2.dp),
            trackColor = MaterialTheme.colorScheme.surfaceVariant, color = MaterialTheme.colorScheme.primary,
        )
    }
}

/** First place in the middle and tallest, second on the right, third on the left (RTL reading order). Plinths rise in. */
@Composable
private fun Podium(winners: List<JSONObject>, onPick: (JSONObject) -> Unit) {
    val byRank = winners.associateBy { it.optInt("rank") }
    val order = listOf(2, 1, 3).map { byRank[it] }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
        listOf(2, 1, 3).forEachIndexed { idx, rank ->
            val w = order[idx]
            val target = when (rank) { 1 -> 64.dp; 2 -> 44.dp; else -> 30.dp }
            val h by animateDpAsState(if (shown) target else 0.dp, tween(650), label = "plinth")
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                if (w != null) {
                    Surface(onClick = { onPick(w) }, color = Color.Transparent) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            MedalAvatar(rank, w.optString("name"), if (rank == 1) 68 else 54)
                            Spacer(Modifier.height(6.dp))
                            Text(w.optString("name"), style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center, maxLines = 2)
                            Text("${awardNum(w.optDouble("score"))} / 100", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (w != null) Box(
                    Modifier.fillMaxWidth().height(h).padding(top = 6.dp).background(medalColor(rank), RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)),
                    contentAlignment = Alignment.TopCenter,
                ) { Text(rank.toString(), color = Color.White, style = MaterialTheme.typography.titleLarge) }
            }
        }
    }
}
