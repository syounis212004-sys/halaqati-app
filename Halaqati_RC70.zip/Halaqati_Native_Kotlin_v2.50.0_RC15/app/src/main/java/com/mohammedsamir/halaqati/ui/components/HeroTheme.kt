package com.mohammedsamir.halaqati.ui.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

/**
 * RC70 look: in light mode a "hero" card is the calm grey card (dark text); in dark mode it is the deep emerald card
 * (white text). Hero code keeps using colorScheme.primary / onPrimary, which this wrapper maps to the right pair, so every hero
 * card follows the same rule without repeating it.
 */
@Composable
fun HeroTheme(content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < .5f
    val bg = if (dark) Color(0xFF0B6E4F) else cs.surface
    val fg = if (dark) Color.White else cs.onSurface
    MaterialTheme(colorScheme = cs.copy(primary = bg, onPrimary = fg), content = content)
}
