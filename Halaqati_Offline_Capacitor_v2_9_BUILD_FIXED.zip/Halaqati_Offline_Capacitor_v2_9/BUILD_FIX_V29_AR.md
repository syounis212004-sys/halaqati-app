# إصلاح بناء APK — v2.9.0

سبب فشل GitHub Actions كان أن الـworkflow يستدعي:
- scripts/configure-android-version.mjs
- scripts/make-update-publish.mjs

بينما حزمة v2.4 لم تكن تحتوي هذين الملفين.

تمت إضافتهما في هذه الحزمة.

تم رفع رقم النسخة إلى 2.9.0 / versionCode 20900
حتى تكون أحدث من سلسلة 2.8.x ولا يرفض Android تثبيتها كتحديث أقدم.
