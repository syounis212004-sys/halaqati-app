from pathlib import Path
import json, os, shutil, hashlib
apk=Path('app/build/outputs/apk/release/app-release.apk')
out=Path('update-publish');out.mkdir(exist_ok=True)
target=out/'Halaqati-latest.apk'
shutil.copy2(apk,target)
sha=hashlib.sha256(apk.read_bytes()).hexdigest()
manifest={
    'versionName':'2.90.0',
    'versionCode':29000,
    'apkUrl':'https://syounis212004-sys.github.io/halaqati-web/Halaqati-latest.apk',
    'sha256':sha,
    'native':True,
    # RC30: a forced update locks EVERY installed copy out until it updates, so it is a per-release choice made in the
    # workflow (input "mandatory"). Default is optional; use mandatory only for releases that fix wrong data or security.
    'mandatory':os.environ.get('HALAQATI_MANDATORY','false').strip().lower()=='true',
    'notes':[
        "«كادر الحلقات»: صفحة واحدة للمشرفين والمحفّظين بدل «فريق الجمعية»، وتظهر فيها حلقات المشرف أيضًا (كانت لا تظهر)",
        "«صورتي» في الإعدادات: كل مستخدم يضيف صورته بنفسه، وتظهر في الرئيسية والقائمة، وإن لم توجد فحرف الاسم في منتصف الدائرة",
        "شريط سفلي عائم بشكل كبسولة مع زر الإضافة في المنتصف",
        "الرئيسية: الصورة على اليمين وأكبر، والآية بخط القاهرة، وحلقة بيانية لنسبة الحضور",
        "جلسات اليوم: بلاطات ملوّنة للملخص بدل السطر الطويل",
        "التقارير: مرشحات بسطر واحد، ومقارنة الشهر بثلاثة أعمدة وأرقام بخانة عشرية وأشرطة",
        "الجمعيات: الحلقات المستقلة تظهر في قسم خاص مع زر «ربط بجمعية»",
        "تحسينات في قواعد البيانات: جمعية الحلقة تتبع مركزها، ونقل المحفّظ آمن عند الضغط المتزامن، والصور تُقبل مضغوطة فقط",
        "عقد تصميم مشترك (design/tokens.json) بين التطبيق والويب",
    ]
}
(out/'version.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Update package prepared:', manifest['versionName'], manifest['versionCode'])
