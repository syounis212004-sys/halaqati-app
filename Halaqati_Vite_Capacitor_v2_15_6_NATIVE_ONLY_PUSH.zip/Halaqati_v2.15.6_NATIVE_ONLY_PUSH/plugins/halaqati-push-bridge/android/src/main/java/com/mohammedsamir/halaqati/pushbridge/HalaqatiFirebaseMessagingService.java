package com.mohammedsamir.halaqati.pushbridge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.NonNull;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class HalaqatiFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onRegistered(@NonNull String installationId) {
        HalaqatiPushBridgePlugin.cacheRegistration(getApplicationContext(), installationId, "fid");
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        super.onMessageReceived(message);
        RemoteMessage.Notification n = message.getNotification();
        String title = n != null && n.getTitle() != null ? n.getTitle() : message.getData().get("title");
        String body = n != null && n.getBody() != null ? n.getBody() : message.getData().get("body");
        if (title == null || title.isEmpty()) title = "حلقتي";
        if (body == null) body = "";
        showNotification(title, body, message.getData().get("deep_link"));
    }

    private void showNotification(String title, String body, String deepLink) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(HalaqatiPushBridgePlugin.CHANNEL_ID) == null) {
            NotificationChannel ch = new NotificationChannel(HalaqatiPushBridgePlugin.CHANNEL_ID, "حلقتي", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("إشعارات الحضور والتسميع والإعلانات");
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
        }
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch == null) launch = new Intent();
        launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (deepLink != null) launch.putExtra("halaqati_deep_link", deepLink);
        PendingIntent pi = PendingIntent.getActivity(this, (int)(System.currentTimeMillis() & 0x7fffffff), launch,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0));

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, HalaqatiPushBridgePlugin.CHANNEL_ID)
            : new Notification.Builder(this);
        b.setSmallIcon(getApplicationInfo().icon)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(new Notification.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setPriority(Notification.PRIORITY_HIGH)
            .setDefaults(Notification.DEFAULT_ALL);
        nm.notify((int)(System.currentTimeMillis() & 0x7fffffff), b.build());
    }
}
