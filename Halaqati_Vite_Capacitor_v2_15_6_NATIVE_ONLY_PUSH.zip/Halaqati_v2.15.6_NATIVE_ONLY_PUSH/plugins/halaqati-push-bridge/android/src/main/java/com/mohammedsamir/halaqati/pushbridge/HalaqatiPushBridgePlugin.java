package com.mohammedsamir.halaqati.pushbridge;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Build;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.installations.FirebaseInstallations;
import com.google.firebase.messaging.FirebaseMessaging;

@CapacitorPlugin(
    name = "HalaqatiPushBridge",
    permissions = {
        @Permission(alias = "notifications", strings = { Manifest.permission.POST_NOTIFICATIONS })
    }
)
public class HalaqatiPushBridgePlugin extends Plugin {

    public static final String PREFS = "halaqati_push";
    public static final String REGISTRATION_ID_KEY = "fcm_registration_id";
    public static final String REGISTRATION_TYPE_KEY = "fcm_registration_type";
    public static final String CHANNEL_ID = "halaqati_general";

    @Override
    public void load() {
        ensureChannel();
        try {
            FirebaseMessaging.getInstance().setAutoInitEnabled(true);
        } catch (Exception ignored) {}
    }

    private FirebaseApp firebaseApp() { return FirebaseApp.getInstance(); }
    private SharedPreferences prefs() { return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    public static void cacheRegistration(Context context, String id, String type) {
        if (id == null || id.trim().isEmpty()) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(REGISTRATION_ID_KEY, id.trim())
            .putString(REGISTRATION_TYPE_KEY, type == null ? "fid" : type)
            .apply();
    }

    private String cachedRegistrationId() { return prefs().getString(REGISTRATION_ID_KEY, ""); }
    private String cachedRegistrationType() { return prefs().getString(REGISTRATION_TYPE_KEY, "fid"); }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "حلقتي", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("إشعارات الحضور والتسميع والإعلانات");
                ch.enableVibration(true);
                nm.createNotificationChannel(ch);
            }
        }
    }

    @PluginMethod
    public void ensureNotificationChannel(PluginCall call) {
        ensureChannel();
        call.resolve();
    }

    @PluginMethod
    public void notificationPermission(PluginCall call) {
        JSObject out = new JSObject();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            out.put("receive", "granted");
        } else {
            int granted = ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS);
            if (granted == android.content.pm.PackageManager.PERMISSION_GRANTED) out.put("receive", "granted");
            else if (getActivity() != null && getActivity().shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) out.put("receive", "prompt-with-rationale");
            else out.put("receive", "prompt");
        }
        call.resolve(out);
    }

    @PluginMethod
    public void requestNotificationPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermission(call);
            return;
        }
        requestPermissionForAlias("notifications", call, "notificationPermissionCallback");
    }

    @PermissionCallback
    private void notificationPermissionCallback(PluginCall call) {
        notificationPermission(call);
    }

    @PluginMethod
    public void diagnostics(PluginCall call) {
        try {
            FirebaseApp app = firebaseApp();
            FirebaseOptions options = app.getOptions();
            boolean playServicesInstalled = false;
            String playServicesVersion = "";
            try {
                PackageInfo info = getContext().getPackageManager().getPackageInfo("com.google.android.gms", 0);
                playServicesInstalled = info != null;
                if (info != null) playServicesVersion = String.valueOf(info.versionName);
            } catch (Exception ignored) {}
            String cached = cachedRegistrationId();
            JSObject out = new JSObject();
            out.put("ok", true);
            out.put("packageName", getContext().getPackageName());
            out.put("projectId", options.getProjectId());
            out.put("applicationId", options.getApplicationId());
            out.put("senderId", options.getGcmSenderId());
            out.put("autoInitEnabled", FirebaseMessaging.getInstance().isAutoInitEnabled());
            out.put("playServicesInstalled", playServicesInstalled);
            out.put("playServicesVersion", playServicesVersion);
            out.put("cachedRegistration", cached != null && !cached.isEmpty());
            out.put("registrationType", cachedRegistrationType());
            out.put("registrationApi", "fid-native-only");
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Firebase diagnostics failed: " + String.valueOf(e.getMessage()), e);
        }
    }

    @PluginMethod
    public void getCachedRegistration(PluginCall call) {
        JSObject out = new JSObject();
        String id = cachedRegistrationId();
        out.put("registrationId", id == null ? "" : id);
        out.put("registrationType", cachedRegistrationType());
        out.put("cached", id != null && !id.isEmpty());
        call.resolve(out);
    }

    @PluginMethod
    public void registerFid(PluginCall call) {
        try {
            firebaseApp();
            ensureChannel();
            FirebaseMessaging messaging = FirebaseMessaging.getInstance();
            messaging.setAutoInitEnabled(true);
            messaging.register().addOnCompleteListener(registerTask -> {
                if (!registerTask.isSuccessful()) {
                    Exception ex = registerTask.getException();
                    call.reject("FCM FID registration failed: " + (ex != null ? ex.getMessage() : "unknown error"), ex);
                    return;
                }
                FirebaseInstallations.getInstance().getId().addOnCompleteListener(fidTask -> {
                    if (!fidTask.isSuccessful()) {
                        Exception ex = fidTask.getException();
                        call.reject("Firebase Installation ID failed: " + (ex != null ? ex.getMessage() : "unknown error"), ex);
                        return;
                    }
                    String fid = fidTask.getResult();
                    if (fid == null || fid.trim().isEmpty()) {
                        call.reject("Firebase returned an empty Installation ID");
                        return;
                    }
                    cacheRegistration(getContext(), fid, "fid");
                    JSObject out = new JSObject();
                    out.put("registrationId", fid);
                    out.put("registrationType", "fid");
                    out.put("last4", fid.length() > 4 ? fid.substring(fid.length() - 4) : fid);
                    call.resolve(out);
                });
            });
        } catch (Exception e) {
            call.reject("FCM FID bridge failed: " + String.valueOf(e.getMessage()), e);
        }
    }
}
