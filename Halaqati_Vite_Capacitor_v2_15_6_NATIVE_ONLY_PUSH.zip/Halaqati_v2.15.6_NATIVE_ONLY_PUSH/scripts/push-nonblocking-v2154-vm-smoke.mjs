import fs from 'node:fs';
import vm from 'node:vm';
const code=fs.readFileSync('src/features/notifications/runtime.js','utf8');
const calls=[];
const never=()=>new Promise(()=>{});
const pushPlugin={
  checkPermissions: async()=>({receive:'granted'}),
  requestPermissions: async()=>({receive:'granted'}),
  // Reproduce the field failure: Capacitor listener registration never resolves.
  addListener: ()=>never(),
  createChannel: async()=>({}),
  register: async()=>({}),
};
const nativeBridge={
  diagnostics: async()=>({ok:true,projectId:'halaqti-test',applicationId:'1:test:android',autoInitEnabled:true,playServicesInstalled:true}),
  getCachedToken: async()=>({token:''}),
  getToken: async()=>({token:'FCM_NATIVE_DIRECT_TOKEN_987654'}),
};
const ctx={
  console,setTimeout,clearTimeout,setInterval,clearInterval,Promise,Date,Math,JSON,String,Number,Array,Set,Map,Object,
  navigator:{onLine:true},document:{visibilityState:'visible'},
  window:{HalaqatiPushConfigured:true,HalaqatiPushNotifications:pushPlugin,HalaqatiPushLoadError:'',HalaqatiNativePushBridge:nativeBridge,Capacitor:{getPlatform:()=> 'android',Plugins:{}},addEventListener(){}},
  state:{user:{id:'user-1'},profile:{role:'admin'},page:'home',pushState:{},notificationPreferences:{push_enabled:true},students:[],notifications:[],notificationUnread:0},
  APP_VERSION_NAME:'2.15.6',isNativeHalaqati:()=>true,ensureServerAuthSession:async()=>true,
  db:{functions:{invoke:async(_n,{body})=>{calls.push(body);return {data:{ok:true,device:{id:'dev-1'}},error:null}}},from:()=>({select(){return this},eq(){return this},neq(){return this},order(){return this},limit:async()=>({data:[],error:null}),maybeSingle:async()=>({data:null,error:null}),upsert:async()=>({error:null}),update(){return this},is:async()=>({error:null})})},
  toast(){},render(){},$:()=>null,esc:s=>String(s??''),fmt:s=>String(s??''),go(){},studentProfile(){},cacheSnapshot(){},attAr:{},behAr:{},
};
ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(code,ctx,{filename:'notifications-runtime.js'});
const started=Date.now();
const ok=await ctx.enablePushNotifications(false);
const elapsed=Date.now()-started;
if(!ok)throw new Error('activation failed despite direct native token');
if(elapsed>4000)throw new Error(`activation was blocked by addListener for ${elapsed}ms`);
if(!ctx.state.pushState?.registered)throw new Error('device not marked registered');
if(!calls.some(x=>x.action==='register_device'&&x.push_token==='FCM_NATIVE_DIRECT_TOKEN_987654'))throw new Error('direct native token was not uploaded');
console.log('PUSH_NONBLOCKING_V2154_VM_PASS',elapsed+'ms');
process.exit(0);
