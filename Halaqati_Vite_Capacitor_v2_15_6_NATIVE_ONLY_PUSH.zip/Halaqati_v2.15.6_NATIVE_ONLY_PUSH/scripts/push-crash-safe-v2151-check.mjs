import fs from 'node:fs';
function need(cond,msg){if(!cond){console.error('PUSH_CRASH_SAFE_CHECK_FAIL:',msg);process.exit(1)}}
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const bridge=fs.readFileSync('src/features/notifications/push-bridge.js','utf8');
const runtime=fs.readFileSync('src/features/notifications/runtime.js','utf8');
const main=fs.readFileSync('src/main.js','utf8');
need(!pkg.dependencies?.['@capacitor/push-notifications'],'external Capacitor push dependency must be absent');
need(!bridge.includes("import('@capacitor/push-notifications')"),'external Push plugin must never be lazy-loaded');
need(bridge.includes("registerPlugin('HalaqatiPushBridge')"),'native bridge registration missing');
need(bridge.includes('VITE_HALAQATI_FIREBASE_CONFIGURED'),'build-time Firebase guard missing');
need(runtime.includes('bridge.notificationPermission'),'native permission path missing');
need(runtime.includes('bridge.requestNotificationPermission'),'native permission request missing');
need(runtime.includes('directNativeFcmRegistration()'),'native FID registration missing');
need(runtime.includes('enablePushNotifications(false).catch'),'background Push initialization must be error-contained');
need(main.includes("version: '2.15.6'"),'main version is not v2.15.6');
console.log('PUSH_CRASH_SAFE_CHECK_PASS');
