import fs from 'node:fs'; import vm from 'node:vm';
const src=fs.readFileSync('src/features/notifications/runtime.js','utf8');
if(src.includes("withPushTimeout(pushPlugin()")) throw new Error('legacy plugin gate remains');
if(!src.includes('bridge.notificationPermission')) throw new Error('native permission path missing');
if(!src.includes('directNativeFcmRegistration()')) throw new Error('native registration path missing');
console.log('NATIVE_ONLY_PUSH_V2156_VM_PASS');
