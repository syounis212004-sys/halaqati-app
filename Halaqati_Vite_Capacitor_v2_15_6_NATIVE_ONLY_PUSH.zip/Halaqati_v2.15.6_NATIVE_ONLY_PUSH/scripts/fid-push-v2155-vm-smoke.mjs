import fs from 'node:fs';
import vm from 'node:vm';
const code=fs.readFileSync('src/features/notifications/runtime.js','utf8');
const calls=[];
const never=()=>new Promise(()=>{});
const pushPlugin={
  checkPermissions: async()=>({receive:'granted'}),
  requestPermissions: async()=>({receive:'granted'}),
  // Even if Capacitor listeners hang forever, FID registration must finish first.
  addListener: ()=>never(),
  createChannel: async()=>({}),
  register: ()=>never(),
};
const nativeBridge={
  diagnostics: async()=>({ok:true,projectId:'halaqti-test',applicationId:'1:test:android',autoInitEnabled:true,playServicesInstalled:true,registrationApi:'fid'}),
  getCachedRegistration: async()=>({registrationId:'',registrationType:'fid'}),
  registerFid: async()=>({registrationId:'cFAKE_INSTALLATION_ID_FID_1234567890',registrationType:'fid'}),
};
const ctx={
  console,setTimeout,clearTimeout,setInterval,clearInterval,Promise,Date,Math,JSON,String,Number,Array,Set,Map,Object,
  navigator:{onLine:true},document:{visibilityState:'visible'},
  window:{HalaqatiPushConfigured:true,HalaqatiPushNotifications:pushPlugin,HalaqatiPushLoadError:'',HalaqatiNativePushBridge:nativeBridge,Capacitor:{getPlatform:()=> 'android',Plugins:{}},addEventListener(){}},
  state:{user:{id:'user-1'},profile:{role:'admin'},page:'home',pushState:{},notificationPreferences:{push_enabled:true},students:[],notifications:[],notificationUnread:0},
  APP_VERSION_NAME:'2.15.6',isNativeHalaqati:()=>true,ensureServerAuthSession:async()=>true,
  db:{functions:{invoke:async(_n,{body})=>{calls.push(body);if(body.action==='test_push')return {data:{ok:true,push_configured:true,push_sent:1},error:null};return {data:{ok:true,device:{id:'dev-1'}},error:null}}},from:()=>({select(){return this},eq(){return this},neq(){return this},order(){return this},limit:async()=>({data:[],error:null}),maybeSingle:async()=>({data:null,error:null}),upsert:async()=>({error:null}),update(){return this},is:async()=>({error:null})})},
  toast(){},render(){},$:()=>null,esc:s=>String(s??''),fmt:s=>String(s??''),go(){},studentProfile(){},cacheSnapshot(){},attAr:{},behAr:{},
};
ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(code,ctx,{filename:'notifications-runtime.js'});
const started=Date.now();
const ok=await ctx.enablePushNotifications(false);
const elapsed=Date.now()-started;
if(!ok)throw new Error('FID activation returned false');
if(elapsed>4000)throw new Error(`FID activation was blocked by Capacitor listeners for ${elapsed}ms`);
if(!ctx.state.pushState?.registered)throw new Error('device not marked registered');
const reg=calls.find(x=>x.action==='register_device');
if(!reg)throw new Error('register_device not called');
if(reg.registration_type!=='fid')throw new Error('registration_type is not fid');
if(reg.push_token!=='cFAKE_INSTALLATION_ID_FID_1234567890')throw new Error('FID not uploaded');
console.log('FID_PUSH_V2155_VM_PASS',elapsed+'ms');
process.exit(0);
