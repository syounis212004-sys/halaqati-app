/* Halaqati v2.15.6 — Native-only Firebase Push bridge.
   No external Capacitor push plugin is loaded. */
import { registerPlugin } from '@capacitor/core';

const firebaseConfigured = String(import.meta.env.VITE_HALAQATI_FIREBASE_CONFIGURED || 'false').toLowerCase() === 'true';
window.HalaqatiPushConfigured = firebaseConfigured;
window.HalaqatiPushLoadError = '';
window.HalaqatiNativePushBridge = firebaseConfigured ? registerPlugin('HalaqatiPushBridge') : null;
