import fs from 'node:fs';
import assert from 'node:assert/strict';

const read=p=>fs.readFileSync(p,'utf8');
const pkg=JSON.parse(read('package.json'));
const core=read('src/core/runtime.js');
const reports=read('src/features/reports/runtime.js');
const legacy=read('src/legacy/app.js');
const vector=read('src/features/reports/vector-pdf-runtime.js');

assert.equal(pkg.version,'2.40.4','package version must be 2.40.4');
assert.ok(core.includes("APP_VERSION_NAME='2.40.4'")&&core.includes('APP_VERSION_CODE=24004'),'runtime version/code mismatch');
assert.ok(vector.includes("const VERSION='2.40.4-vector-pdf'"),'vector PDF layer must remain enabled');
assert.ok(reports.includes("window.__HALAQATI_REPORTS_RUNTIME__='2.40.4-server-first-null-safe-reports'"),'v2.40.4 reports runtime sentinel missing');

// The regression that caused "0 طالب · 0 لقاء": SQL <> drops NULL rows.
assert.ok(!reports.includes(".neq('status','withdrawn')"),'reports must not SQL-neq nullable student status');
assert.ok(!reports.includes(".neq('status','cancelled')"),'reports must not SQL-neq nullable session status');
assert.ok(reports.includes('const students=rawStudents.filter(reportStudentIsActive);'),'students must be filtered client-side with NULL-safe semantics');
assert.ok(reports.includes('const sessions=rawSessions.filter(reportSessionIsActive);'),'sessions must be filtered client-side with NULL-safe semantics');
assert.ok(reports.includes('normalizeReportHalaqaSelection()'),'stale report halaqa selection repair missing');
assert.ok(reports.includes('report integrity mismatch: server returned 0 students'),'false-success zero-student guard missing');
assert.ok(reports.includes('report integrity mismatch: server returned 0 sessions'),'false-success zero-session guard missing');
assert.ok(reports.includes('optionalReportRead'),'optional analytics datasets should not block the core report');
assert.ok(reports.includes("optionalReportRead('student_daily_notes'"),'daily notes must be treated as optional metadata');
assert.ok(!legacy.includes(".neq('status','cancelled')"),'legacy report fallback must also be NULL-safe');
assert.ok(legacy.includes("sessions=(sr.data||[]).filter(x=>x.status!=='cancelled')"),'legacy fallback must filter cancelled sessions in JS');

// Model the exact PostgreSQL/PostgREST three-valued-logic failure.
const sqlNeq=(value,blocked)=>value==null?false:value!==blocked;
const jsActive=(value,blocked)=>String(value||'').toLowerCase()!==blocked;
const studentStatuses=[null,'active','withdrawn'];
const sessionStatuses=[null,'open','closed','cancelled'];
assert.deepEqual(studentStatuses.filter(v=>sqlNeq(v,'withdrawn')),['active']);
assert.deepEqual(studentStatuses.filter(v=>jsActive(v,'withdrawn')),[null,'active']);
assert.deepEqual(sessionStatuses.filter(v=>sqlNeq(v,'cancelled')),['open','closed']);
assert.deepEqual(sessionStatuses.filter(v=>jsActive(v,'cancelled')),[null,'open','closed']);

console.log('HALAQATI_V2404_REPORTS_DATA_FIX_PASS');
console.log('NULL legacy statuses are preserved; withdrawn/cancelled rows are excluded; vector PDF remains active ✅');
