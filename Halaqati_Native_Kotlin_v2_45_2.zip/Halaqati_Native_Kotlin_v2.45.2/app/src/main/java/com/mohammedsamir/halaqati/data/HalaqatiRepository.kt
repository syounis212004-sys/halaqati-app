package com.mohammedsamir.halaqati.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.mohammedsamir.halaqati.BuildConfig
import com.mohammedsamir.halaqati.model.*
import com.mohammedsamir.halaqati.plans.SmartPlanEngine
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.UUID

data class PlanSnapshot(
    val plan: PlanRow,
    val student: Student,
    val progress: SmartPlanEngine.Progress,
)

class HalaqatiRepository(
    private val context: Context,
    val api: SupabaseApi,
    val store: SecureSessionStore,
    val queue: OfflineQueue,
) {
    fun loggedIn() = store.load() != null

    fun signOut() = store.clear()

    fun authCallbackType(url: String): String = api.callbackType(url)

    fun updatePassword(newPassword: String) = api.updatePassword(newPassword)

    fun online(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun login(email: String, password: String) = api.signIn(email, password)

    fun register(email: String, password: String, name: String, phone: String, role: String) =
        api.signUp(email, password, name, phone, role)

    fun googleOAuthUrl(): String = api.googleOAuthUrl()

    fun acceptOAuthCallback(url: String): UserSession? = api.acceptOAuthCallback(url)

    fun requestPasswordReset(email: String) = api.requestPasswordReset(email)

    fun registerPushToken(token: String) {
        if (store.load()?.userId.isNullOrBlank() || token.isBlank()) return
        if (!online()) return
        api.function(
            "halaqati-notify",
            JSONObject()
                .put("action", "register_device")
                .put("push_token", token)
                .put("platform", "android")
                .put("device_name", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
                .put("app_version", BuildConfig.VERSION_NAME),
        )
        store.savePushToken(token)
    }

    /**
     * Disable the current device on the notification service while the old user session is
     * still valid. The local token is cleared even when the network call fails; the ViewModel
     * also asks Firebase to rotate/delete the FCM token so a later account cannot inherit it.
     */
    fun unregisterPushDevice() {
        val token = store.loadPushToken() ?: return
        try {
            if (loggedIn() && online()) {
                api.function(
                    "halaqati-notify",
                    JSONObject()
                        .put("action", "unregister_device")
                        .put("push_token", token),
                )
            }
        } finally {
            store.clearPushToken()
        }
    }

    fun testPush(): JSONObject = JSONObject(
        api.function(
            "halaqati-notify",
            JSONObject().put("action", "test_push"),
        ),
    )

    fun sendStudentEvent(
        studentId: String,
        sourceKey: String,
        title: String,
        body: String,
        data: JSONObject = JSONObject(),
    ): JSONObject = JSONObject(
        api.function(
            "halaqati-notify",
            JSONObject()
                .put("action", "event_student")
                .put("kind", "system")
                .put("student_id", studentId)
                .put("source_key", sourceKey)
                .put("title", title)
                .put("body", body)
                .put("deep_link", "student:$studentId")
                .put("data", data),
        ),
    )

    /**
     * Native equivalent of the legacy checkSmartPlanAlerts() loop.
     * Server source_key de-duplication makes the periodic worker safe to run more than once.
     */
    fun runSmartPlanAlerts(now: ZonedDateTime = ZonedDateTime.now(ZoneId.of("Asia/Gaza"))): Int {
        if (!loggedIn() || !online()) return 0
        val profile = profileWithRefresh()
        if (profile.role !in setOf(UserRole.ADMIN, UserRole.SUPERVISOR, UserRole.TEACHER)) return 0

        val today = now.toLocalDate()
        var delivered = 0
        planSnapshots(today).forEach { snapshot ->
            if (!SmartPlanAlertRules.shouldSendDelay(snapshot.progress.consecutiveMissed, snapshot.plan.delayAlertDays)) {
                return@forEach
            }
            val progress = snapshot.progress
            runCatching {
                sendStudentEvent(
                    studentId = snapshot.student.id,
                    sourceKey = "smart-plan-delay:${snapshot.plan.id}:${snapshot.student.id}:$today",
                    title = "تنبيه الخطة · ${snapshot.student.fullName}",
                    body = "الخطة متأخرة ${progress.consecutiveMissed} أيام دوام. المتبقي ${progress.remaining} صفحة، والحالة ${progress.healthLabel}.",
                    data = JSONObject()
                        .put("smart_plan_id", snapshot.plan.id)
                        .put("health", progress.health)
                        .put("missed_days", progress.consecutiveMissed),
                )
            }.onSuccess { delivered++ }
        }

        if (now.hour >= 17) {
            val tomorrow = today.plusDays(1)
            planSnapshots(tomorrow)
                .groupBy { it.student.id }
                .values
                .forEach { candidates ->
                    val student = candidates.firstOrNull()?.student ?: return@forEach
                    val preferred = SmartPlanAlertRules.preferredPlanType(student.track)
                    val next = candidates.firstOrNull { it.plan.type == preferred } ?: candidates.firstOrNull() ?: return@forEach
                    val assignment = next.progress.assignment
                    if (!SmartPlanAlertRules.shouldSendHomePrep(now.hour, next.plan.homePrepPush, assignment.startPage)) {
                        return@forEach
                    }
                    runCatching {
                        sendStudentEvent(
                            studentId = student.id,
                            sourceKey = "smart-plan-prep:${next.plan.id}:${student.id}:$tomorrow",
                            title = "تحضير الغد · ${student.fullName}",
                            body = "مطلوب غداً ${SmartPlanAlertRules.assignmentLabel(assignment.kind, assignment.startPage, assignment.endPage)}.",
                            data = JSONObject()
                                .put("smart_plan_id", next.plan.id)
                                .put("plan_date", tomorrow.toString())
                                .put("start_page", assignment.startPage)
                                .put("end_page", assignment.endPage),
                        )
                    }.onSuccess { delivered++ }
                }
        }
        return delivered
    }

    fun profile(): Profile {
        val session = store.load() ?: error("not signed in")
        val json = api.select(
            "profiles",
            "select=id,full_name,role,requested_role,approval_status,active,email,rejection_reason" +
                "&id=eq.${session.userId}&limit=1",
        ).optJSONObject(0) ?: JSONObject()
            .put("id", session.userId)
            .put("full_name", session.email)
            .put("role", "guardian")
            .put("requested_role", "guardian")
            .put("approval_status", "pending")
            .put("active", true)

        return Profile(
            id = json.optString("id"),
            fullName = json.optString("full_name").ifBlank { session.email },
            role = UserRole.from(json.optString("role")),
            approvalStatus = json.optString("approval_status", "pending"),
            email = json.optString("email", session.email),
            active = json.optBoolean("active", true),
            requestedRole = UserRole.from(json.optString("requested_role")),
            rejectionReason = json.optString("rejection_reason"),
        )
    }

    fun profileWithRefresh(): Profile = try {
        profile()
    } catch (e: SupabaseException) {
        if (e.status != 401) throw e
        api.refresh() ?: throw e
        profile()
    }

    fun students(): List<Student> {
        val arr = api.select("students", "select=*&status=neq.withdrawn&order=full_name.asc&limit=1000")
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(Student::from) }
    }

    fun sessions(): List<SessionRow> {
        val arr = api.select("sessions", "select=*&status=neq.cancelled&order=session_date.desc&limit=300")
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(SessionRow::from) }
    }

    fun plans(): List<PlanRow> {
        val arr = api.select("smart_plans", "select=*&order=updated_at.desc&limit=500")
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(PlanRow::from) }
    }

    fun attendanceForSession(sessionId: String): Map<String, AttendanceRow> {
        val arr = withAuthRetry {
            api.select(
                "attendance_records",
                "select=id,session_id,student_id,status,excuse_reason,arrival_minutes_late" +
                    "&session_id=eq.$sessionId&limit=2000",
            )
        }
        return (0 until arr.length())
            .mapNotNull { arr.optJSONObject(it)?.let(AttendanceRow::from) }
            .associateBy { it.studentId }
    }

    fun notesForSession(sessionId: String): Map<String, DailyNoteRow> {
        val arr = withAuthRetry {
            api.select(
                "student_daily_notes",
                "select=id,session_id,student_id,behavior,behavior_score,teacher_comment,homework,parent_visible,participation" +
                    "&session_id=eq.$sessionId&limit=2000",
            )
        }
        return (0 until arr.length())
            .mapNotNull { arr.optJSONObject(it)?.let(DailyNoteRow::from) }
            .associateBy { it.studentId }
    }

    fun planSnapshots(today: LocalDate = LocalDate.now()): List<PlanSnapshot> {
        val students = students()
        val planRows = plans()
        if (students.isEmpty() || planRows.isEmpty()) return emptyList()

        val enginePlansById = planRows.mapNotNull { row ->
            row.toEnginePlan()?.let { row.id to it }
        }.toMap()
        if (enginePlansById.isEmpty()) return emptyList()

        val start = enginePlansById.values.minOf { it.startDate }.toString()
        val end = maxOf(today, enginePlansById.values.maxOf { it.endDate }).toString()
        val recitations = planRecitations(start, end)
        val events = planEvents()
        val rowsById = planRows.associateBy { it.id }

        return buildList {
            students.forEach { student ->
                val engineStudent = SmartPlanEngine.Student(
                    id = student.id,
                    halaqaId = student.halaqaId.orEmpty(),
                    categoryId = student.categoryId,
                )
                SmartPlanEngine.effectivePlans(enginePlansById.values.toList(), engineStudent, today)
                    .forEach { enginePlan ->
                        val row = rowsById[enginePlan.id] ?: return@forEach
                        val progress = SmartPlanEngine.calculateProgress(
                            plan = enginePlan,
                            studentId = student.id,
                            recitations = recitations,
                            events = events[enginePlan.id].orEmpty(),
                            today = today,
                        )
                        add(PlanSnapshot(row, student, progress))
                    }
            }
        }.sortedWith(
            compareBy<PlanSnapshot> { healthPriority(it.progress.health) }
                .thenByDescending { it.progress.behindBy }
                .thenBy { it.student.fullName },
        )
    }

    private fun planRecitations(from: String, to: String): List<SmartPlanEngine.Recitation> {
        val query = "select=id,student_id,activity_type,start_page,end_page,pages_count,evaluation,mistakes,prompts," +
            "selection_data,created_at,sessions!inner(session_date)" +
            "&sessions.session_date=gte.$from&sessions.session_date=lte.$to&order=created_at.asc&limit=10000"
        val arr = withAuthRetry { api.select("recitation_entries", query) }
        return (0 until arr.length()).mapNotNull { index ->
            val row = arr.optJSONObject(index) ?: return@mapNotNull null
            val date = row.optJSONObject("sessions")?.optString("session_date")
                ?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
                ?: return@mapNotNull null
            val selection = row.optJSONObject("selection_data") ?: JSONObject()
            val lines = selection.optJSONArray("qcf_line_keys")?.let { a ->
                (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }
            }.orEmpty()
            SmartPlanEngine.Recitation(
                id = row.optString("id"),
                studentId = row.optString("student_id"),
                activityType = row.optString("activity_type"),
                date = date,
                startPage = nullablePage(row, "start_page"),
                endPage = nullablePage(row, "end_page"),
                pagesCount = row.optDouble("pages_count", 0.0),
                evaluation = row.optString("evaluation").ifBlank { null },
                mistakes = row.optInt("mistakes", 0),
                prompts = row.optInt("prompts", 0),
                taggedPlanId = selection.optString("smart_plan_id")
                    .ifBlank { selection.optString("plan_id") }
                    .ifBlank { null },
                qcfLineKeys = lines,
                createdAt = row.optString("created_at"),
            )
        }
    }

    private fun planEvents(): Map<String, List<SmartPlanEngine.Event>> {
        val arr = withAuthRetry {
            api.select(
                "smart_plan_events",
                "select=plan_id,event_type,payload,event_date,created_at&order=created_at.asc&limit=5000",
            )
        }
        val output = linkedMapOf<String, MutableList<SmartPlanEngine.Event>>()
        for (index in 0 until arr.length()) {
            val row = arr.optJSONObject(index) ?: continue
            val planId = row.optString("plan_id")
            if (planId.isBlank()) continue
            val payload = row.optJSONObject("payload") ?: JSONObject()
            val pages = when {
                payload.has("pages") -> payload.optDouble("pages", 0.0)
                payload.has("delta_pages") -> payload.optDouble("delta_pages", 0.0)
                payload.has("value") -> payload.optDouble("value", 0.0)
                else -> 0.0
            }
            val milestone = payload.optString("milestone_key")
                .ifBlank { payload.optString("key") }
                .ifBlank { null }
            output.getOrPut(planId) { mutableListOf() } += SmartPlanEngine.Event(
                type = row.optString("event_type"),
                pages = pages,
                milestoneKey = milestone,
            )
        }
        return output
    }

    private fun PlanRow.toEnginePlan(): SmartPlanEngine.Plan? {
        val start = runCatching { LocalDate.parse(startDate) }.getOrNull() ?: return null
        val end = runCatching { LocalDate.parse(endDate) }.getOrNull() ?: return null
        if (id.isBlank() || halaqaId.isBlank() || target <= 0.0 || end < start) return null
        val pauses = settings.pauseRanges.mapNotNull { (fromRaw, toRaw) ->
            val from = runCatching { LocalDate.parse(fromRaw) }.getOrNull() ?: return@mapNotNull null
            val to = runCatching { LocalDate.parse(toRaw) }.getOrNull() ?: return@mapNotNull null
            if (to < from) null else SmartPlanEngine.PauseRange(from, to)
        }
        val weekdays = scheduleWeekdays.filter { it in 0..6 }.toSet().ifEmpty { setOf(0, 1, 2, 3, 4) }
        return SmartPlanEngine.Plan(
            id = id,
            scopeType = scopeType,
            halaqaId = halaqaId,
            studentId = studentId,
            categoryId = categoryId,
            parentPlanId = parentPlanId,
            planType = type,
            targetPages = target,
            startDate = start,
            endDate = end,
            scheduleWeekdays = weekdays,
            catchUpWeekday = catchUpWeekday,
            maxDailyMultiplier = maxDailyMultiplier.coerceIn(1.0, 3.0),
            autoExtend = autoExtend,
            qualityGateEnabled = qualityGateEnabled,
            minimumEvaluation = minimumEvaluation,
            rangeStartPage = rangeStartPage,
            rangeEndPage = rangeEndPage,
            milestoneMode = milestoneMode,
            milestoneRequiresApproval = milestoneRequiresApproval,
            delayAlertDays = delayAlertDays,
            status = status,
            updatedAt = updatedAt,
            createdAt = createdAt,
            settings = SmartPlanEngine.Settings(
                minimumDailyMode = settings.minimumDailyMode,
                minimumDailyPages = settings.minimumDailyPages,
                pauseRanges = pauses,
                intensiveWeekFrom = settings.intensiveWeekFrom?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                intensiveWeekTo = settings.intensiveWeekTo?.let { runCatching { LocalDate.parse(it) }.getOrNull() },
                intensiveWeekdays = settings.intensiveWeekdays.filter { it in 0..6 }.toSet(),
                memorizationLineKeys = settings.memorizationLineKeys,
            ),
        )
    }

    private fun nullablePage(row: JSONObject, name: String): Int? =
        if (!row.has(name) || row.isNull(name)) null else row.optInt(name).takeIf { it in 1..604 }

    private fun healthPriority(value: String): Int = when (value) {
        "red" -> 0
        "yellow" -> 1
        else -> 2
    }

    fun table(table: String, query: String = "select=*&order=created_at.desc&limit=250") = api.select(table, query)

    fun accountProfiles(): JSONArray = withAuthRetry {
        api.select(
            "profiles",
            "select=id,full_name,email,phone,role,requested_role,approval_status,active,approved_at,rejection_reason,created_at" +
                "&order=created_at.desc&limit=1000",
        )
    }

    private fun requireDirectAccountConnection() {
        require(online()) { "تعديل الحسابات يحتاج اتصالاً مباشراً بالخادم" }
    }

    fun approveAccount(userId: String, role: String) {
        requireDirectAccountConnection()
        require(role in setOf("guardian", "teacher", "supervisor")) { "الصلاحية المطلوبة غير صالحة" }
        val uid = store.load()?.userId ?: error("الجلسة غير صالحة")
        withAuthRetry {
            api.patch(
                "profiles",
                "id=eq.$userId",
                JSONObject()
                    .put("role", role)
                    .put("requested_role", role)
                    .put("approval_status", "approved")
                    .put("active", true)
                    .put("approved_at", java.time.Instant.now().toString())
                    .put("approved_by", uid)
                    .put("rejection_reason", JSONObject.NULL),
            )
        }
    }

    fun rejectAccount(userId: String, reason: String) {
        requireDirectAccountConnection()
        withAuthRetry {
            api.patch(
                "profiles",
                "id=eq.$userId",
                JSONObject()
                    .put("approval_status", "rejected")
                    .put("active", false)
                    .put("rejection_reason", reason.trim().takeIf { it.isNotBlank() } ?: JSONObject.NULL),
            )
        }
    }

    fun setAccountActive(userId: String, active: Boolean) {
        requireDirectAccountConnection()
        withAuthRetry { api.patch("profiles", "id=eq.$userId", JSONObject().put("active", active)) }
    }

    fun changeAccountRole(userId: String, role: String) {
        requireDirectAccountConnection()
        require(role in setOf("guardian", "teacher", "supervisor")) { "الصلاحية المطلوبة غير صالحة" }
        withAuthRetry {
            api.patch(
                "profiles",
                "id=eq.$userId&role=neq.admin",
                JSONObject().put("role", role).put("requested_role", role),
            )
        }
    }

    fun deleteAccountPermanently(userId: String) {
        requireDirectAccountConnection()
        val raw = withAuthRetry { api.rpc("admin_delete_account", JSONObject().put("target_user", userId)) }.trim()
        if (raw.equals("false", true) || raw.isBlank()) error("تعذر حذف الحساب نهائياً")
    }

    fun guardianAccounts(): JSONArray {
        val raw = withAuthRetry { api.rpc("list_guardian_accounts") }
        return runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
    }

    fun linkPrimaryGuardian(studentId: String, guardianId: String?) {
        requireDirectAccountConnection()
        val args = JSONObject().put("p_student_id", studentId)
        if (guardianId.isNullOrBlank()) args.put("p_guardian_id", JSONObject.NULL) else args.put("p_guardian_id", guardianId)
        withAuthRetry { api.rpc("set_student_primary_guardian", args) }
    }


    fun reportRecitations(
        from: String,
        to: String,
        track: String = "all",
        halaqaId: String = "all",
        sessionType: String = "all",
    ): JSONArray {
        require(track in setOf("all", "general_hifz", "tathbit")) { "المسار غير صالح" }
        require(sessionType in setOf("all", "tasmee", "sard", "review", "test", "tajweed", "lesson", "other")) { "نوع اللقاء غير صالح" }
        val trackFilter = if (track == "all") "" else "&${StudentTrackRules.postgrestFilter("students.track_code", track)}"
        val halaqaFilter = if (halaqaId == "all") "" else "&sessions.halaqa_id=eq.$halaqaId"
        val typeFilter = if (sessionType == "all") "" else "&sessions.session_type=eq.$sessionType"
        val query = "select=student_id,activity_type,pages_count,mistakes,prompts,evaluation,safety_percentage,points,created_at," +
            "students!inner(full_name,track_code,halaqa_id),sessions!inner(session_date,halaqa_id,session_type,status)" +
            "&sessions.session_date=gte.$from&sessions.session_date=lte.$to&sessions.status=neq.cancelled" +
            "$trackFilter$halaqaFilter$typeFilter&order=created_at.asc&limit=10000"
        return withAuthRetry { api.select("recitation_entries", query) }
    }

    /** Native parity with the legacy reportStatsRows engine.
     * Keeps all active RLS-visible students in the selected track, including zero-activity rows.
     */
    fun reportSummary(
        from: String,
        to: String,
        track: String = "all",
        halaqaId: String = "all",
        sessionType: String = "all",
    ): JSONArray {
        val start = runCatching { LocalDate.parse(from) }.getOrElse { error("تاريخ البداية غير صالح") }
        val end = runCatching { LocalDate.parse(to) }.getOrElse { error("تاريخ النهاية غير صالح") }
        require(end >= start) { "الفترة غير صالحة" }
        require(track in setOf("all", "general_hifz", "tathbit")) { "المسار غير صالح" }
        require(sessionType in setOf("all", "tasmee", "sard", "review", "test", "tajweed", "lesson", "other")) { "نوع اللقاء غير صالح" }

        val studentTrack = if (track == "all") "" else "&${StudentTrackRules.postgrestFilter("track_code", track)}"
        val studentHalaqa = if (halaqaId == "all") "" else "&halaqa_id=eq.$halaqaId"
        val students = withAuthRetry {
            api.select(
                "students",
                "select=id,full_name,track_code,category_id,halaqa_id,status&status=eq.active$studentTrack$studentHalaqa&order=full_name.asc&limit=2000",
            )
        }
        val categories = withAuthRetry { api.select("student_categories", "select=id,name&limit=1000") }
        val categoryNames = buildMap<String, String> {
            for (i in 0 until categories.length()) {
                categories.optJSONObject(i)?.let { row ->
                    row.optString("id").takeIf { it.isNotBlank() }?.let { put(it, row.optString("name")) }
                }
            }
        }

        val sessionHalaqa = if (halaqaId == "all") "" else "&sessions.halaqa_id=eq.$halaqaId"
        val sessionTypeFilter = if (sessionType == "all") "" else "&sessions.session_type=eq.$sessionType"
        val sessionFilters = "&sessions.session_date=gte.$from&sessions.session_date=lte.$to&sessions.status=neq.cancelled$sessionHalaqa$sessionTypeFilter"
        val recitations = withAuthRetry {
            api.select(
                "recitation_entries",
                "select=student_id,activity_type,pages_count,mistakes,prompts,points," +
                    "sessions!inner(session_date,halaqa_id,session_type,status)$sessionFilters&limit=20000",
            )
        }
        val attendance = withAuthRetry {
            api.select(
                "attendance_records",
                "select=student_id,status,sessions!inner(session_date,halaqa_id,session_type,status)$sessionFilters&limit=20000",
            )
        }
        val extraPoints = runCatching {
            withAuthRetry {
                api.select(
                    "student_points",
                    "select=student_id,points&awarded_at=gte.$from&awarded_at=lte.$to&limit=10000",
                )
            }
        }.getOrElse { JSONArray() }

        data class Aggregate(
            val student: JSONObject,
            var hifz: Double = 0.0,
            var tathbit: Double = 0.0,
            var review: Double = 0.0,
            var sard: Double = 0.0,
            var tilawah: Double = 0.0,
            var mistakes: Int = 0,
            var prompts: Int = 0,
            var recitationPoints: Double = 0.0,
            var bonusPoints: Double = 0.0,
            var present: Int = 0,
            var absent: Int = 0,
            var excused: Int = 0,
            var late: Int = 0,
        )

        val byStudent = linkedMapOf<String, Aggregate>()
        for (i in 0 until students.length()) {
            val student = students.optJSONObject(i) ?: continue
            val id = student.optString("id")
            if (id.isNotBlank()) byStudent[id] = Aggregate(student)
        }
        for (i in 0 until attendance.length()) {
            val row = attendance.optJSONObject(i) ?: continue
            val aggregate = byStudent[row.optString("student_id")] ?: continue
            when (row.optString("status")) {
                "present" -> aggregate.present++
                "absent" -> aggregate.absent++
                "excused" -> aggregate.excused++
                "late" -> aggregate.late++
            }
        }
        for (i in 0 until recitations.length()) {
            val row = recitations.optJSONObject(i) ?: continue
            val aggregate = byStudent[row.optString("student_id")] ?: continue
            val pages = row.optDouble("pages_count", 0.0).coerceAtLeast(0.0)
            when {
                row.optString("activity_type") == "new_hifz" && aggregate.student.optString("track_code") == "tathbit" -> aggregate.tathbit += pages
                row.optString("activity_type") == "new_hifz" -> aggregate.hifz += pages
                row.optString("activity_type").contains("review") -> aggregate.review += pages
                row.optString("activity_type") == "sard" -> aggregate.sard += pages
                else -> aggregate.tilawah += pages
            }
            aggregate.mistakes += row.optInt("mistakes", 0).coerceAtLeast(0)
            aggregate.prompts += row.optInt("prompts", 0).coerceAtLeast(0)
            aggregate.recitationPoints += row.optDouble("points", 0.0)
        }
        for (i in 0 until extraPoints.length()) {
            val row = extraPoints.optJSONObject(i) ?: continue
            byStudent[row.optString("student_id")]?.let { it.bonusPoints += row.optDouble("points", 0.0) }
        }

        val ordered = byStudent.values.sortedWith(
            compareByDescending<Aggregate> { it.recitationPoints + it.bonusPoints }
                .thenByDescending { it.hifz + it.tathbit + it.review + it.sard + it.tilawah }
                .thenBy { it.student.optString("full_name") },
        )
        return JSONArray().apply {
            ordered.forEach { a ->
                val categoryId = a.student.optString("category_id")
                val totalPages = a.hifz + a.tathbit + a.review + a.sard + a.tilawah
                put(
                    JSONObject()
                        .put("student_id", a.student.optString("id"))
                        .put("student_name", a.student.optString("full_name", "طالب"))
                        .put("track_code", StudentTrackRules.canonicalStored(a.student.optString("track_code", "general_hifz")))
                        .put("category_name", categoryNames[categoryId].orEmpty())
                        .put("hifz_pages", kotlin.math.round(a.hifz * 100.0) / 100.0)
                        .put("tathbit_pages", kotlin.math.round(a.tathbit * 100.0) / 100.0)
                        .put("review_pages", kotlin.math.round(a.review * 100.0) / 100.0)
                        .put("sard_pages", kotlin.math.round(a.sard * 100.0) / 100.0)
                        .put("tilawah_pages", kotlin.math.round(a.tilawah * 100.0) / 100.0)
                        .put("total_pages", kotlin.math.round(totalPages * 100.0) / 100.0)
                        .put("mistakes", a.mistakes)
                        .put("prompts", a.prompts)
                        .put("present", a.present)
                        .put("absent", a.absent)
                        .put("excused", a.excused)
                        .put("late", a.late)
                        .put("sessions", a.present + a.absent + a.excused + a.late)
                        .put("recitation_points", kotlin.math.round(a.recitationPoints * 100.0) / 100.0)
                        .put("bonus_points", kotlin.math.round(a.bonusPoints * 100.0) / 100.0)
                        .put("points", kotlin.math.round((a.recitationPoints + a.bonusPoints) * 100.0) / 100.0),
                )
            }
        }
    }

    fun rankingRange(from: String, to: String): JSONArray {
        val query = "select=student_id,pages_count,mistakes,prompts,points,activity_type," +
            "students!inner(full_name,category_id,track_code),sessions!inner(session_date)" +
            "&sessions.session_date=gte.$from&sessions.session_date=lte.$to&limit=10000"
        val source = withAuthRetry { api.select("recitation_entries", query) }
        data class Aggregate(
            val student: JSONObject,
            var points: Double = 0.0,
            var pages: Double = 0.0,
            var mistakes: Int = 0,
            var prompts: Int = 0,
        )
        val byStudent = linkedMapOf<String, Aggregate>()
        for (index in 0 until source.length()) {
            val row = source.optJSONObject(index) ?: continue
            val id = row.optString("student_id")
            if (id.isBlank()) continue
            val aggregate = byStudent.getOrPut(id) {
                Aggregate(row.optJSONObject("students") ?: JSONObject().put("full_name", "طالب"))
            }
            aggregate.points += row.optDouble("points", 0.0)
            aggregate.pages += row.optDouble("pages_count", 0.0)
            aggregate.mistakes += row.optInt("mistakes", 0)
            aggregate.prompts += row.optInt("prompts", 0)
        }
        val ordered = byStudent.entries.sortedWith(
            compareByDescending<Map.Entry<String, Aggregate>> { it.value.points }
                .thenByDescending { it.value.pages }
                .thenBy {
                    val pages = it.value.pages.coerceAtLeast(0.0001)
                    (it.value.mistakes + it.value.prompts * 0.5) / pages
                },
        )
        return JSONArray().apply {
            ordered.forEach { (id, aggregate) ->
                put(
                    JSONObject()
                        .put("student_id", id)
                        .put("students", aggregate.student)
                        .put("student_name", aggregate.student.optString("full_name", "طالب"))
                        .put("points", kotlin.math.round(aggregate.points * 100.0) / 100.0)
                        .put("pages", kotlin.math.round(aggregate.pages * 100.0) / 100.0)
                        .put("mistakes", aggregate.mistakes)
                        .put("prompts", aggregate.prompts),
                )
            }
        }
    }

    fun firstHalaqaId(): String? = api.select(
        "halaqas",
        "select=id&active=eq.true&order=created_at.asc&limit=1",
    ).optJSONObject(0)?.optString("id")?.takeIf { it.isNotBlank() }

    private fun queueOwnerId(): String = store.load()?.userId?.takeIf { it.isNotBlank() }
        ?: error("لا يمكن حفظ عملية محلية دون جلسة مستخدم صالحة")

    private fun queued(method: String, path: String, obj: JSONObject?, dedupe: String) {
        queue.add(queueOwnerId(), method, path, obj?.toString(), dedupe)
        scheduleSync()
    }

    private fun shouldQueue(error: Exception): Boolean = when (error) {
        is IOException -> true
        is SupabaseException -> error.status == 0 || error.status == 408 || error.status == 429 || error.status >= 500
        else -> false
    }

    private inline fun <T> withAuthRetry(block: () -> T): T = try {
        block()
    } catch (e: SupabaseException) {
        if (e.status != 401) throw e
        api.refresh() ?: throw e
        block()
    }

    fun write(
        table: String,
        obj: JSONObject,
        onConflict: String? = null,
        dedupe: String = "${table}:${obj.optString("id", UUID.randomUUID().toString())}",
    ): JSONArray {
        if (!online()) {
            val path = "/rest/v1/$table${onConflict?.let { "?on_conflict=$it" }.orEmpty()}"
            queued("POST", path, obj, dedupe)
            return JSONArray().put(obj)
        }
        return try {
            withAuthRetry {
                if (onConflict != null) api.upsert(table, obj, onConflict) else api.insert(table, obj)
            }
        } catch (e: Exception) {
            if (!shouldQueue(e)) throw e
            val path = "/rest/v1/$table${onConflict?.let { "?on_conflict=$it" }.orEmpty()}"
            queued("POST", path, obj, dedupe)
            JSONArray().put(obj)
        }
    }

    fun patch(
        table: String,
        filter: String,
        obj: JSONObject,
        dedupe: String = "$table:$filter",
    ): JSONArray {
        if (!online()) {
            queued("PATCH", "/rest/v1/$table?$filter", obj, dedupe)
            return JSONArray().put(obj)
        }
        return try {
            withAuthRetry { api.patch(table, filter, obj) }
        } catch (e: Exception) {
            if (!shouldQueue(e)) throw e
            queued("PATCH", "/rest/v1/$table?$filter", obj, dedupe)
            JSONArray().put(obj)
        }
    }

    fun delete(
        table: String,
        filter: String,
        dedupe: String = "$table:$filter:delete",
    ): JSONArray {
        if (!online()) {
            queued("DELETE", "/rest/v1/$table?$filter", null, dedupe)
            return JSONArray()
        }
        return try {
            withAuthRetry { api.delete(table, filter) }
        } catch (e: Exception) {
            if (!shouldQueue(e)) throw e
            queued("DELETE", "/rest/v1/$table?$filter", null, dedupe)
            JSONArray()
        }
    }

    /** Queue-safe mutation RPC. RPC calls that represent state changes use the same
     * durable offline queue as REST writes instead of failing when connectivity drops. */
    fun rpcWrite(
        name: String,
        args: JSONObject = JSONObject(),
        dedupe: String = "rpc:$name:${UUID.randomUUID()}",
    ): String {
        val path = "/rest/v1/rpc/$name"
        if (!online()) {
            queued("POST", path, args, dedupe)
            return ""
        }
        return try {
            withAuthRetry { api.rpc(name, args) }
        } catch (e: Exception) {
            if (!shouldQueue(e)) throw e
            queued("POST", path, args, dedupe)
            ""
        }
    }

    fun recordPlanEvent(
        planId: String,
        studentId: String,
        eventType: String,
        payload: JSONObject = JSONObject(),
    ) {
        require(eventType in setOf(
            "milestone_approved", "auto_extension", "manual_credit", "manual_debit",
            "pause", "resume", "notification_sent", "retry_required", "catch_up",
        )) { "نوع حدث الخطة غير صالح" }
        val clientEventId = UUID.randomUUID().toString()
        val obj = JSONObject()
            .put("client_event_id", clientEventId)
            .put("plan_id", planId)
            .put("student_id", studentId)
            .put("event_type", eventType)
            .put("event_date", LocalDate.now().toString())
            .put("payload", payload)
        store.load()?.userId?.let { obj.put("created_by", it) }
        write(
            "smart_plan_events",
            obj,
            onConflict = "client_event_id",
            dedupe = "plan-event:$clientEventId",
        )
    }

    fun setPlanStatus(planId: String, status: String) {
        require(status in setOf("draft", "active", "paused", "completed", "archived")) { "حالة الخطة غير صالحة" }
        patch(
            "smart_plans",
            "id=eq.$planId",
            JSONObject()
                .put("status", status)
                .put("updated_at", java.time.Instant.now().toString()),
            dedupe = "plan-status:$planId",
        )
    }

    fun saveSmartPlan(draft: SmartPlanDraft): String {
        require(draft.scopeType in setOf("student", "category", "halaqa")) { "نطاق الخطة غير صالح" }
        require(draft.type in setOf("hifz", "review", "sard", "tathbit")) { "نوع الخطة غير صالح" }
        require(draft.reviewTier in setOf("none", "near", "far", "both")) { "مسار المراجعة غير صالح" }
        require(draft.minimumEvaluation in setOf("excellent", "very_good", "good", "repeat")) { "أقل تقييم غير صالح" }
        require(draft.milestoneMode in setOf("none", "hizb", "juz")) { "نوع الاختبار المرحلي غير صالح" }
        require(draft.status in setOf("draft", "active", "paused", "completed", "archived")) { "حالة الخطة غير صالحة" }
        require(draft.halaqaId.isNotBlank()) { "اختر الحلقة" }
        when (draft.scopeType) {
            "student" -> require(!draft.studentId.isNullOrBlank()) { "اختر الطالب" }
            "category" -> require(!draft.categoryId.isNullOrBlank()) { "اختر الفئة" }
        }
        val start = runCatching { LocalDate.parse(draft.startDate) }.getOrElse { error("تاريخ البداية غير صالح") }
        val end = runCatching { LocalDate.parse(draft.endDate) }.getOrElse { error("تاريخ النهاية غير صالح") }
        require(end >= start) { "تاريخ النهاية يجب ألا يسبق البداية" }
        require(draft.targetPages > 0.0 && draft.targetPages <= 604.0) { "هدف الخطة يجب أن يكون بين 0 و604 صفحة" }
        val weekdays = draft.scheduleWeekdays.distinct().filter { it in 0..6 }
        require(weekdays.isNotEmpty()) { "اختر يوم دوام واحداً على الأقل" }
        require(draft.catchUpWeekday == null || draft.catchUpWeekday in 0..6) { "يوم الاستدراك غير صالح" }
        require(draft.maxDailyMultiplier in 1.0..3.0) { "أقصى زيادة يومية غير صالحة" }
        require(draft.delayAlertDays in 1..30) { "عدد أيام تنبيه التأخر غير صالح" }
        require(draft.nearRevisionPages in 0.0..30.0) { "المراجعة القريبة غير صالحة" }
        require(draft.farRevisionPages in 0.0..604.0) { "المراجعة البعيدة غير صالحة" }
        require(draft.rangeStartPage == null || draft.rangeStartPage in 1..604)
        require(draft.rangeEndPage == null || draft.rangeEndPage in 1..604)

        val now = java.time.Instant.now().toString()
        val planId = draft.id?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
        val settings = JSONObject()
            .put("minimum_daily_mode", draft.minimumDailyMode.ifBlank { "dynamic" })
            .put("minimum_daily_pages", draft.minimumDailyPages.coerceAtLeast(0.0))
            .put("intensive_weekdays", JSONArray(draft.intensiveWeekdays.distinct().filter { it in 0..6 }))
            .put("memorization_line_keys", JSONArray(draft.memorizationLineKeys.filter { it.isNotBlank() }))
        draft.intensiveWeekFrom?.takeIf { it.isNotBlank() }?.let { settings.put("intensive_week_from", it) }
        draft.intensiveWeekTo?.takeIf { it.isNotBlank() }?.let { settings.put("intensive_week_to", it) }
        draft.routeDirection?.takeIf { it.isNotBlank() }?.let { settings.put("route_direction", it) }

        val obj = JSONObject()
            .put("id", planId)
            .put("scope_type", draft.scopeType)
            .put("halaqa_id", draft.halaqaId)
            .put("student_id", draft.studentId?.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
            .put("category_id", draft.categoryId?.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
            .put("parent_plan_id", draft.parentPlanId?.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
            .put("plan_type", draft.type)
            .put("review_tier", if (draft.type == "review") draft.reviewTier else "none")
            .put("title", draft.title.trim().ifBlank { "${draft.type.uppercase()} ${draft.startDate}" })
            .put("goal_unit", "pages")
            .put("target_units", draft.targetPages)
            .put("target_pages", draft.targetPages)
            .put("start_date", draft.startDate)
            .put("end_date", draft.endDate)
            .put("schedule_weekdays", JSONArray(weekdays))
            .put("catch_up_weekday", draft.catchUpWeekday ?: JSONObject.NULL)
            .put("max_daily_multiplier", draft.maxDailyMultiplier)
            .put("auto_extend", draft.autoExtend)
            .put("quality_gate_enabled", draft.qualityGateEnabled)
            .put("minimum_evaluation", draft.minimumEvaluation)
            .put("range_start_page", draft.rangeStartPage ?: JSONObject.NULL)
            .put("range_end_page", draft.rangeEndPage ?: JSONObject.NULL)
            .put("range_start_surah", draft.rangeStartSurah ?: JSONObject.NULL)
            .put("range_start_ayah", draft.rangeStartAyah ?: JSONObject.NULL)
            .put("range_end_surah", draft.rangeEndSurah ?: JSONObject.NULL)
            .put("range_end_ayah", draft.rangeEndAyah ?: JSONObject.NULL)
            .put("near_revision_pages", draft.nearRevisionPages)
            .put("far_revision_pages", draft.farRevisionPages)
            .put("milestone_mode", draft.milestoneMode)
            .put("milestone_requires_approval", draft.milestoneRequiresApproval)
            .put("delay_alert_days", draft.delayAlertDays)
            .put("home_prep_push", draft.homePrepPush)
            .put("status", draft.status)
            .put("note", draft.note.trim().takeIf { it.isNotBlank() } ?: JSONObject.NULL)
            .put("settings", settings)
            .put("updated_at", now)
        store.load()?.userId?.let { obj.put("created_by", it) }

        if (draft.id.isNullOrBlank()) {
            write("smart_plans", obj, onConflict = "id", dedupe = "smart-plan:$planId")
        } else {
            obj.remove("created_by")
            obj.remove("id")
            patch("smart_plans", "id=eq.$planId", obj, dedupe = "smart-plan-update:$planId")
        }
        return planId
    }

    fun guardianDashboard(studentId: String, from: String, to: String): JSONObject {
        require(studentId.isNotBlank()) { "معرّف الطالب غير صالح" }
        val start = runCatching { LocalDate.parse(from) }.getOrElse { error("تاريخ البداية غير صالح") }
        val end = runCatching { LocalDate.parse(to) }.getOrElse { error("تاريخ النهاية غير صالح") }
        require(end >= start) { "الفترة غير صالحة" }
        val raw = withAuthRetry {
            api.rpc(
                "guardian_student_dashboard_range",
                JSONObject()
                    .put("p_student_id", studentId)
                    .put("p_from", start.toString())
                    .put("p_to", end.toString()),
            )
        }
        return runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    }

    fun guardianCompetition(
        studentId: String,
        track: String,
        scope: String,
        from: String,
        to: String,
    ): JSONArray {
        require(studentId.isNotBlank()) { "معرّف الطالب غير صالح" }
        require(track in setOf("hifz", "review", "sard")) { "نوع الترتيب غير صالح" }
        require(scope in setOf("center", "category", "halaqa")) { "نطاق الترتيب غير صالح" }
        val start = runCatching { LocalDate.parse(from) }.getOrElse { error("تاريخ البداية غير صالح") }
        val end = runCatching { LocalDate.parse(to) }.getOrElse { error("تاريخ النهاية غير صالح") }
        require(end >= start) { "الفترة غير صالحة" }
        val raw = withAuthRetry {
            api.rpc(
                "guardian_competition_board_range",
                JSONObject()
                    .put("p_student_id", studentId)
                    .put("p_track", track)
                    .put("p_scope", scope)
                    .put("p_from", start.toString())
                    .put("p_to", end.toString()),
            )
        }
        return runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
    }

    fun ensureTodaySession(halaqaId: String, date: String, assignmentKind: String): SessionRow {
        require(halaqaId.isNotBlank()) { "معرّف الحلقة غير صالح" }
        val sessionType = when (assignmentKind) {
            "sard" -> "sard"
            "review", "tathbit" -> "review"
            "test" -> "test"
            else -> "tasmee"
        }
        val existing = withAuthRetry {
            api.select(
                "sessions",
                "select=*&halaqa_id=eq.$halaqaId&session_date=eq.$date&session_type=eq.$sessionType" +
                    "&status=in.(open,planned)&order=created_at.asc&limit=1",
            )
        }.optJSONObject(0)
        if (existing != null) return SessionRow.from(existing)

        val title = when (sessionType) {
            "sard" -> "جلسة السرد"
            "review" -> "جلسة المراجعة والتثبيت"
            "test" -> "جلسة اختبار الخطة"
            else -> "جلسة تسميع اليوم"
        }
        val id = createSession(halaqaId, date, sessionType, title)
        return SessionRow(id, halaqaId, date, sessionType, title, "open")
    }

    fun createSession(halaqaId: String, date: String, type: String, title: String): String {
        val id = UUID.randomUUID().toString()
        val createdBy = store.load()?.userId
        val obj = JSONObject()
            .put("id", id)
            .put("halaqa_id", halaqaId)
            .put("session_date", date)
            .put("session_type", type)
            .put("title", title.takeIf { it.isNotBlank() })
            .put("status", "open")
        createdBy?.let { obj.put("created_by", it) }
        write("sessions", obj, onConflict = "id")
        return id
    }

    fun saveAttendance(
        sessionId: String,
        studentId: String,
        status: String,
        excuseReason: String = "",
        arrivalMinutesLate: Int = 0,
    ) {
        require(status in setOf("present", "absent", "excused", "late")) { "حالة حضور غير صالحة" }
        require(arrivalMinutesLate >= 0) { "دقائق التأخر غير صالحة" }
        val id = UUID.nameUUIDFromBytes("$sessionId:$studentId".toByteArray()).toString()
        val obj = JSONObject()
            .put("id", id)
            .put("session_id", sessionId)
            .put("student_id", studentId)
            .put("status", status)
            .put("arrival_minutes_late", if (status == "late") arrivalMinutesLate else 0)
        if (status == "excused" && excuseReason.isNotBlank()) obj.put("excuse_reason", excuseReason.trim())
        store.load()?.userId?.let { obj.put("recorded_by", it) }
        write(
            "attendance_records",
            obj,
            onConflict = "session_id,student_id",
            dedupe = "attendance:$sessionId:$studentId",
        )
    }

    fun saveDailyNote(
        sessionId: String,
        studentId: String,
        behavior: String = "normal",
        behaviorScore: Int? = null,
        teacherComment: String = "",
        homework: String = "",
        parentVisible: Boolean = true,
        participation: String = "",
    ) {
        require(behavior in setOf("excellent", "good", "normal", "needs_attention", "warning")) { "تقييم السلوك غير صالح" }
        require(behaviorScore == null || behaviorScore in 1..5) { "درجة السلوك يجب أن تكون من 1 إلى 5" }
        val id = UUID.nameUUIDFromBytes("note:$sessionId:$studentId".toByteArray()).toString()
        val obj = JSONObject()
            .put("id", id)
            .put("session_id", sessionId)
            .put("student_id", studentId)
            .put("behavior", behavior)
            .put("teacher_comment", teacherComment.trim().takeIf { it.isNotBlank() })
            .put("homework", homework.trim().takeIf { it.isNotBlank() })
            .put("parent_visible", parentVisible)
        behaviorScore?.let { obj.put("behavior_score", it) }
        participation.trim().takeIf { it.isNotBlank() }?.let { obj.put("participation", it) }
        store.load()?.userId?.let { obj.put("created_by", it) }
        write(
            "student_daily_notes",
            obj,
            onConflict = "session_id,student_id",
            dedupe = "note:$sessionId:$studentId",
        )
    }

    fun saveRecitation(draft: RecitationDraft) {
        require(draft.activityType in setOf("new_hifz", "review_near", "review_far", "sard", "tilawah", "test")) {
            "نوع التسميع غير صالح"
        }
        require(draft.pages >= 0) { "عدد الصفحات غير صالح" }
        require(draft.mistakes >= 0 && draft.prompts >= 0) { "عدد الأخطاء أو التلقين غير صالح" }
        require(draft.evaluation in setOf("not_rated", "excellent", "very_good", "good", "repeat")) {
            "التقييم غير صالح"
        }
        require(draft.inputMethod in setOf("pages", "ayahs", "surahs", "juz", "import")) { "طريقة الإدخال غير صالحة" }

        val id = draft.clientId?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
        val safety = SafetyScoring.calculate(draft.pages, draft.mistakes, draft.prompts)
        // V6 evaluation is derived from the actual safety result; this keeps Native and Web parity.
        val evaluation = SafetyScoring.inferredEvaluation(safety, draft.pages > 0.0)
        val points = SafetyScoring.points(draft.pages, draft.mistakes, draft.prompts)
        val penaltyUnits = SafetyScoring.penaltyUnits(draft.mistakes, draft.prompts)
        val penaltyPerPage = if (draft.pages > 0.0) penaltyUnits / draft.pages else 0.0
        val selectionData = JSONObject().put("native", true)
        if (draft.inputMethod == "import") selectionData.put("imported", true)
        draft.smartPlanId?.takeIf { it.isNotBlank() }?.let { selectionData.put("smart_plan_id", it) }
        draft.smartPlanType?.takeIf { it.isNotBlank() }?.let { selectionData.put("smart_plan_type", it) }
        draft.smartPlanDate?.takeIf { it.isNotBlank() }?.let { selectionData.put("smart_plan_date", it) }
        if (draft.qcfLineKeys.isNotEmpty()) {
            selectionData.put("qcf_line_keys", JSONArray(draft.qcfLineKeys))
        }

        val obj = JSONObject()
            .put("id", id)
            .put("student_id", draft.studentId)
            .put("session_id", draft.sessionId)
            .put("activity_type", draft.activityType)
            .put("input_method", draft.inputMethod)
            .put("pages_count", draft.pages)
            .put("mistakes", draft.mistakes)
            .put("prompts", draft.prompts)
            .put("evaluation", evaluation)
            .put("safety_percentage", safety)
            .put("penalty_units", penaltyUnits)
            .put("penalty_per_page", penaltyPerPage)
            .put("points", points)
            .put("scoring_version", "V6")
            .put("selection_data", selectionData)
        if (draft.notes.isNotBlank()) obj.put("teacher_note", draft.notes)
        draft.startPage?.let { obj.put("start_page", it) }
        draft.endPage?.let { obj.put("end_page", it) }
        store.load()?.userId?.let { obj.put("created_by", it) }

        write("recitation_entries", obj, onConflict = "id", dedupe = "recitation:${draft.sessionId}:${draft.studentId}:$id")
    }

    fun currentUserId(): String? = store.load()?.userId?.takeIf { it.isNotBlank() }

    fun pendingQueueSize(): Int = currentUserId()?.let { queue.size(it) } ?: 0

    fun blockedQueueSize(): Int = currentUserId()?.let { queue.blockedSize(it) } ?: 0

    fun queueSnapshot(limit: Int = 200): List<OfflineQueue.SnapshotItem> =
        currentUserId()?.let { queue.snapshot(it, limit) } ?: emptyList()

    fun retryBlockedQueueItem(id: Long) {
        currentUserId()?.let { queue.retryBlocked(id, it) }
    }

    fun discardQueueItem(id: Long) {
        currentUserId()?.let { queue.discard(id, it) }
    }

    fun retryAllBlockedQueueItems() {
        val owner = currentUserId() ?: return
        queue.snapshot(owner, 1000).filter { it.blocked }.forEach { queue.retryBlocked(it.id, owner) }
        scheduleSync()
    }

    fun flushQueue() {
        if (!online()) return
        val owner = currentUserId() ?: return
        for (item in queue.all(owner)) {
            try {
                withAuthRetry { api.raw(item.method, item.path, item.body) }
                queue.done(item.id, owner)
            } catch (e: Exception) {
                queue.fail(item.id, owner)
                // Permanent 4xx data/RLS errors must not spin forever as if they were transient.
                if (e is SupabaseException && e.status in 400..499 && e.status != 408 && e.status != 429) {
                    queue.markBlocked(item.id, owner, e.message ?: "HTTP ${e.status}")
                    continue
                }
                throw e
            }
        }
    }

    fun scheduleSync() {
        WorkManager.getInstance(context).enqueueUniqueWork(
            "halaqati-sync-now",
            ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<SyncWorker>()
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build(),
                )
                .build(),
        )
    }
}
