# Feature parity matrix

Source audited: Halaqati v2.44.0 SYNC_REFRESH_FIX.

| Feature | Native 2.45 implementation |
|---|---|
| Authentication & approval | Native auth + profile approval gate; same profiles/roles. |
| Role navigation | Admin/Supervisor/Teacher/Guardian routes ported. |
| Halaqas/categories | Native lists; same halaqas/student_categories. |
| Students | Native directory/create/track status. |
| Sessions | Native create/open roster, attendance, recitation, offline queue. |
| Smart plans | Native list + same smart_plans/events contract; scoring reference preserved. |
| Reports | Native PDF export + recitation data. |
| Certificates | Native PDF certificates + original logos. |
| Notifications | FCM service + user_devices and notifications. |
| Rankings | student_points or guardian RPC. |
| Guardian | role-restricted nav + children-oriented pages/RPC data. |
| Import/export | XLSX/CSV/DOCX parser + JSON backup; unsafe PDF/image OCR refuses auto-commit. |
| Community | announcements/forum_posts same tables. |
| Supervision | supervisor_visits same table. |
| Accounts | profiles view; destructive admin ops remain server-side RPC/edge functions. |
| Quran calculator | Native page system 1-604. |
| Offline sync | SQLite write queue + WorkManager + visible pending state. |
| Pull refresh | Every data screen exposes explicit refresh; no WebView refresh dependency. |
| Updater compatibility | same package id; workflow emits version.json + Halaqati-latest.apk. |

## Important
Full behavioral equivalence still requires CI/device regression against production RLS and real role accounts. The ZIP intentionally does not claim that a static migration can prove zero defects.
