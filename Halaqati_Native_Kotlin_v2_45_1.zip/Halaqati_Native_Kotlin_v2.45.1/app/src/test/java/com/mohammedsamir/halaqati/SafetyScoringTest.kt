package com.mohammedsamir.halaqati
import com.mohammedsamir.halaqati.data.SafetyScoring
import org.junit.Assert.*
import org.junit.Test
class SafetyScoringTest{@Test fun perfect(){assertEquals(100.0,SafetyScoring.calculate(2.0,0,0),0.001)}@Test fun repeatBelow70(){assertEquals("repeat",SafetyScoring.inferredEvaluation(69.9))}@Test fun goodAt70(){assertEquals("good",SafetyScoring.inferredEvaluation(70.0))}}
