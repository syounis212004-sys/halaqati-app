package com.mohammedsamir.halaqati.ui
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.mohammedsamir.halaqati.model.*
import com.mohammedsamir.halaqati.ui.components.*
import com.mohammedsamir.halaqati.ui.screens.*

@Composable fun HalaqatiApp(initialDeepLink:String?=null,vm:AppViewModel=viewModel()){val auth by vm.auth.collectAsState();val sync by vm.sync.collectAsState();when(val a=auth){AuthState.Loading->Box(Modifier.fillMaxSize(),Alignment.Center){CircularProgressIndicator()};AuthState.SignedOut->AuthScreen(onLogin=vm::login,onRegister=vm::register);is AuthState.Error->AuthScreen(error=a.message,onLogin=vm::login,onRegister=vm::register);is AuthState.Pending->PendingApprovalScreen(a.profile,vm::bootstrap,vm::logout);is AuthState.Ready->MainShell(a.profile,sync,vm::sync,vm::logout)}}

@Composable private fun MainShell(profile:Profile,sync:SyncState,onSync:()->Unit,onLogout:()->Unit){
    val nav=rememberNavController()
    val items=RoleNavigation.items(profile.role)
    var more by remember{mutableStateOf(false)}
    Scaffold(bottomBar={
        NavigationBar{
            val current=nav.currentBackStackEntryAsState().value?.destination?.route?:"home"
            RoleNavigation.bottom(profile.role).forEach{r->
                val target=if(r=="more")null else r
                NavigationBarItem(
                    selected=if(target!=null) current==target else more,
                    onClick={if(target==null) more=true else nav.navigate(target){launchSingleTop=true}},
                    icon={Icon(iconFor(r),null)},label={Text(labelFor(r))}
                )
            }
        }
    }){pad->
        Column(Modifier.padding(pad).fillMaxSize()){
            SyncBanner(sync.online,sync.pending,sync.error,onSync)
            NavHost(nav,"home",Modifier.weight(1f),enterTransition={fadeIn()+slideInHorizontally{it/10}},exitTransition={fadeOut()}){
                items.forEach{item->composable(item.route){FeatureRouter(item.route,profile,sync,onSync,{nav.navigate(it)},onLogout)}}
            }
        }
        if(more) ModalBottomSheet(onDismissRequest={more=false}){
            items.filter{it.route !in RoleNavigation.bottom(profile.role)}.forEach{i->
                ListItem(headlineContent={Text(i.title)},leadingContent={Icon(iconFor(i.iconKey),null)},modifier=Modifier.fillMaxWidth(),trailingContent={Icon(Icons.Default.ChevronLeft,null)})
                HorizontalDivider()
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
@Composable private fun FeatureRouter(route:String,p:Profile,s:SyncState,onSync:()->Unit,navigate:(String)->Unit,onLogout:()->Unit){when(route){"home"->DashboardScreen(p,navigate,onSync);"students"->StudentsScreen(s.pending,onSync);"sessions"->SessionsScreen(s.pending,onSync);"plans"->PlansScreen(p,s.pending,onSync);"reports"->ReportsScreen(p,s.pending,onSync);"certificates"->CertificatesScreen(s.pending,onSync);"notifications"->GenericDataScreen("الإشعارات","notifications",s.pending,onSync);"halaqas"->HalaqasScreen(s.pending,onSync);"community"->CommunityScreen(s.pending,onSync);"rankings"->RankingsScreen(p,s.pending,onSync);"importexport"->ImportExportScreen(s.pending,onSync);"supervision"->GenericDataScreen("متابعة المحفظين","supervisor_visits",s.pending,onSync);"users"->UsersScreen(s.pending,onSync);"quran"->QuranCalculatorScreen();"profile"->GuardianProfileScreen(p,s.pending,onSync);"settings"->SettingsScreen(p,onLogout);else->GenericDataScreen(route,route,s.pending,onSync)}}
fun iconFor(k:String)=when(k){"home"->Icons.Default.Home;"notifications"->Icons.Default.Notifications;"group"->Icons.Default.Groups;"forum"->Icons.Default.Forum;"event"->Icons.Default.Event;"person"->Icons.Default.Person;"timeline"->Icons.Default.Timeline;"award"->Icons.Default.EmojiEvents;"report"->Icons.Default.Assessment;"book"->Icons.Default.MenuBook;"leaderboard"->Icons.Default.Leaderboard;"sync"->Icons.Default.Sync;"supervisor"->Icons.Default.SupervisorAccount;"users"->Icons.Default.ManageAccounts;"profile"->Icons.Default.AccountCircle;"settings"->Icons.Default.Settings;"sessions"->Icons.Default.Event;"students"->Icons.Default.Groups;"plans"->Icons.Default.Timeline;"reports"->Icons.Default.Assessment;"more"->Icons.Default.MoreHoriz;else->Icons.Default.Apps}
fun labelFor(r:String)=when(r){"home"->"الرئيسية";"sessions"->"الجلسات";"students"->"الطلاب";"plans"->"الخطط";"reports"->"التقارير";"profile"->"الملف";else->"المزيد"}
