package com.mohammedsamir.halaqati.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val Light=lightColorScheme(primary=Color(0xFF0D3B2F),onPrimary=Color.White,secondary=Color(0xFF2F8B69),tertiary=Color(0xFFB58B32),background=Color(0xFFF7FAF8),surface=Color(0xFFFFFFFF),surfaceVariant=Color(0xFFE6F0EC),error=Color(0xFFB3261E))
@Composable fun HalaqatiTheme(content: @Composable () -> Unit){MaterialTheme(colorScheme=Light,typography=Typography(),content=content)}
