package com.mohammedsamir.halaqati.data
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject
class OfflineQueue(ctx:Context):SQLiteOpenHelper(ctx,"halaqati-offline.db",null,2){
 override fun onCreate(db:SQLiteDatabase){db.execSQL("CREATE TABLE q(id INTEGER PRIMARY KEY AUTOINCREMENT, method TEXT NOT NULL, path TEXT NOT NULL, body TEXT, headers TEXT, created INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, dedupe TEXT)"); db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS q_dedupe ON q(dedupe) WHERE dedupe IS NOT NULL")}
 override fun onUpgrade(db:SQLiteDatabase,old:Int,new:Int){if(old<2) db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS q_dedupe ON q(dedupe) WHERE dedupe IS NOT NULL")}
 fun add(method:String,path:String,body:String?,dedupe:String?=null){writableDatabase.beginTransaction();try{if(dedupe!=null) writableDatabase.delete("q","dedupe=?",arrayOf(dedupe)); val s=writableDatabase.compileStatement("INSERT INTO q(method,path,body,created,dedupe) VALUES(?,?,?,?,?)");s.bindString(1,method);s.bindString(2,path);if(body==null)s.bindNull(3) else s.bindString(3,body);s.bindLong(4,System.currentTimeMillis());if(dedupe==null)s.bindNull(5) else s.bindString(5,dedupe);s.executeInsert();writableDatabase.setTransactionSuccessful()}finally{writableDatabase.endTransaction()}}
 fun size():Int=readableDatabase.rawQuery("SELECT COUNT(*) FROM q",null).use{it.moveToFirst();it.getInt(0)}
 data class Item(val id:Long,val method:String,val path:String,val body:String?)
 fun all(limit:Int=100)=mutableListOf<Item>().also{out-> readableDatabase.rawQuery("SELECT id,method,path,body FROM q ORDER BY id LIMIT ?",arrayOf(limit.toString())).use{c->while(c.moveToNext())out+=Item(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3))}}
 fun done(id:Long){writableDatabase.delete("q","id=?",arrayOf(id.toString()))}
 fun fail(id:Long){writableDatabase.execSQL("UPDATE q SET attempts=attempts+1 WHERE id=?",arrayOf(id))}
}
