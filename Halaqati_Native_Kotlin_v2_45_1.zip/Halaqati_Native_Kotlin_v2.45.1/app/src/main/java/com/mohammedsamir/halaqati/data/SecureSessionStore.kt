package com.mohammedsamir.halaqati.data
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.mohammedsamir.halaqati.model.UserSession
class SecureSessionStore(ctx:Context){
 private val prefs=EncryptedSharedPreferences.create(ctx,"halaqati_secure",MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
 fun save(s:UserSession)=prefs.edit().putString("a",s.accessToken).putString("r",s.refreshToken).putString("u",s.userId).putString("e",s.email).apply()
 fun load():UserSession?{ val a=prefs.getString("a",null)?:return null; return UserSession(a,prefs.getString("r","")?:"",prefs.getString("u","")?:"",prefs.getString("e","")?:"") }
 fun clear()=prefs.edit().clear().apply()
}
