package com.mohammedsamir.halaqati.data
import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit
object AppGraph { lateinit var store:SecureSessionStore; lateinit var api:SupabaseApi; lateinit var queue:OfflineQueue; lateinit var repo:HalaqatiRepository; private set
 fun init(ctx:Context){store=SecureSessionStore(ctx);queue=OfflineQueue(ctx);api=SupabaseApi(store);repo=HalaqatiRepository(ctx,api,store,queue);WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("halaqati-sync",ExistingPeriodicWorkPolicy.KEEP,PeriodicWorkRequestBuilder<SyncWorker>(15,TimeUnit.MINUTES).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())}
}
class SyncWorker(ctx:Context,p:WorkerParameters):CoroutineWorker(ctx,p){override suspend fun doWork()=try{AppGraph.repo.flushQueue();Result.success()}catch(e:Exception){Result.retry()}}
