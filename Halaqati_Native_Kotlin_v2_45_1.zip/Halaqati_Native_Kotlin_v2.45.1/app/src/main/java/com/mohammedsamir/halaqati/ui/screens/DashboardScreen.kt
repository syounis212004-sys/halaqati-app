package com.mohammedsamir.halaqati.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.Profile
import com.mohammedsamir.halaqati.ui.components.*
import kotlinx.coroutines.*
import org.json.JSONArray
import java.time.LocalDate
@Composable fun DashboardScreen(p:Profile,navigate:(String)->Unit,onSync:()->Unit){var stats by remember{mutableStateOf(listOf("…","…","…","…"))};var focus by remember{mutableStateOf<List<Pair<String,String>>>(emptyList())};LaunchedEffect(Unit){withContext(Dispatchers.IO){try{val repo=AppGraph.repo;val sts=repo.students();val sessions=repo.sessions();val rec=repo.table("recitation_entries","select=student_id,pages_count,mistakes,prompts,safety_percentage,created_at&order=created_at.desc&limit=500");val today=LocalDate.now().toString();val todayS=sessions.count{it.date==today};val pages=(0 until rec.length()).sumOf{rec.optJSONObject(it)?.optDouble("pages_count",0.0)?:0.0};stats=listOf(sts.count{it.status=="active"}.toString(),todayS.toString(),"%.1f".format(pages),repo.queue.size().toString());val recentIds=mutableSetOf<String>();for(i in 0 until rec.length())if(rec.optJSONObject(i)?.optString("created_at")?.startsWith(today)==true)recentIds+=rec.optJSONObject(i).optString("student_id");focus=sts.filter{it.id !in recentIds}.take(12).map{it.fullName to "لم يسمّع اليوم"}}catch(_:Exception){}}};LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("مرحبًا، ${p.fullName}",style=MaterialTheme.typography.headlineSmall);Text("لوحة المتابعة اليومية",color=MaterialTheme.colorScheme.onSurfaceVariant)};item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Box(Modifier.weight(1f)){MetricCard("الطلاب",stats[0],onClick={navigate("students")})};Box(Modifier.weight(1f)){MetricCard("جلسات اليوم",stats[1],onClick={navigate("sessions")})}}};item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Box(Modifier.weight(1f)){MetricCard("صفحات مسجلة",stats[2],onClick={navigate("reports")})};Box(Modifier.weight(1f)){MetricCard("معلّق للمزامنة",stats[3],onClick=onSync)}}};item{Text("يحتاج متابعة",style=MaterialTheme.typography.titleLarge)};if(focus.isEmpty())item{EmptyState("لا توجد تنبيهات متابعة الآن")};items(focus){(name,reason)->ElevatedCard(onClick={navigate("students")},modifier=Modifier.fillMaxWidth()){ListItem(headlineContent={Text(name)},supportingContent={Text(reason)},trailingContent={Icon(Icons.Default.ChevronLeft,null)})}};item{TextButton({navigate("rankings")},Modifier.fillMaxWidth()){Text("عرض جميع مؤشرات الأداء والترتيب")}}}}
