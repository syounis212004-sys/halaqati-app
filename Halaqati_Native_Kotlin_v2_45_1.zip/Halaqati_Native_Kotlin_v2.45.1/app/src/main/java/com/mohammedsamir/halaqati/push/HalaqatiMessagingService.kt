package com.mohammedsamir.halaqati.push
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.mohammedsamir.halaqati.data.AppGraph
import org.json.JSONObject
import java.util.UUID
class HalaqatiMessagingService:FirebaseMessagingService(){override fun onNewToken(token:String){super.onNewToken(token);runCatching{val uid=AppGraph.store.load()?.userId?:return;AppGraph.repo.write("user_devices",JSONObject().put("user_id",uid).put("device_token",token).put("registration_type","token").put("platform","android").put("is_active",true),dedupe="device:$uid")}};override fun onMessageReceived(msg:RemoteMessage){super.onMessageReceived(msg);NotificationHelper.show(this,msg.notification?.title?:msg.data["title"]?:"حلقتي",msg.notification?.body?:msg.data["body"]?:"لديك إشعار جديد",msg.data["deep_link"])}}
