package com.mohammedsamir.halaqati.ui
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface AuthState{data object Loading:AuthState;data object SignedOut:AuthState;data class Pending(val profile:Profile):AuthState;data class Ready(val profile:Profile):AuthState;data class Error(val message:String):AuthState}
class AppViewModel:ViewModel(){private val repo=AppGraph.repo;private val _auth=MutableStateFlow<AuthState>(AuthState.Loading);val auth=_auth.asStateFlow();private val _sync=MutableStateFlow(SyncState());val sync=_sync.asStateFlow()
 init{bootstrap()}
 fun bootstrap(){viewModelScope.launch(Dispatchers.IO){try{if(!repo.loggedIn()){_auth.value=AuthState.SignedOut;return@launch};val p=repo.profile();_auth.value=if(p.approvalStatus=="approved")AuthState.Ready(p) else AuthState.Pending(p)}catch(e:Exception){_auth.value=AuthState.Error(e.message?:"تعذر بدء التطبيق")};refreshSync()}}
 fun login(email:String,pw:String){_auth.value=AuthState.Loading;viewModelScope.launch(Dispatchers.IO){try{repo.login(email,pw);bootstrap()}catch(e:Exception){_auth.value=AuthState.Error("فشل تسجيل الدخول: ${e.message}")}}}
 fun register(email:String,pw:String,name:String,role:String){_auth.value=AuthState.Loading;viewModelScope.launch(Dispatchers.IO){try{repo.register(email,pw,name,role);bootstrap()}catch(e:Exception){_auth.value=AuthState.Error("فشل إنشاء الحساب: ${e.message}")}}}
 fun logout(){repo.signOut();_auth.value=AuthState.SignedOut}
 fun sync(){viewModelScope.launch(Dispatchers.IO){_sync.value=_sync.value.copy(syncing=true);try{repo.flushQueue()}catch(_:Exception){};refreshSync()}}
 fun refreshSync(){_sync.value=SyncState(online=repo.online(),pending=repo.queue.size(),syncing=false)}
}
