package com.mohammedsamir.halaqati.data
import com.mohammedsamir.halaqati.BuildConfig
import com.mohammedsamir.halaqati.model.UserSession
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

class SupabaseException(message:String,val status:Int=0):Exception(message)
class SupabaseApi(private val sessionStore:SecureSessionStore){
 private fun connection(url:String,method:String,auth:Boolean=true,prefer:String?=null):HttpURLConnection=(URL(url).openConnection() as HttpURLConnection).apply{
  requestMethod=method; connectTimeout=12000; readTimeout=20000; setRequestProperty("apikey",BuildConfig.SUPABASE_PUBLISHABLE_KEY); setRequestProperty("Accept","application/json");setRequestProperty("Content-Type","application/json");
  if(auth) sessionStore.load()?.accessToken?.takeIf{it.isNotBlank()}?.let{setRequestProperty("Authorization","Bearer $it")}; prefer?.let{setRequestProperty("Prefer",it)}
 }
 private fun call(url:String,method:String="GET",body:String?=null,auth:Boolean=true,prefer:String?=null):String{val c=connection(url,method,auth,prefer);if(body!=null){c.doOutput=true;c.outputStream.use{it.write(body.toByteArray())}};val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;val text=stream?.bufferedReader()?.use{it.readText()}.orEmpty();if(code !in 200..299)throw SupabaseException(text.ifBlank{"HTTP $code"},code);return text}
 fun signIn(email:String,password:String):UserSession{val j=JSONObject(call("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=password","POST",JSONObject().put("email",email).put("password",password).toString(),false));return UserSession(j.getString("access_token"),j.optString("refresh_token"),j.getJSONObject("user").getString("id"),email).also(sessionStore::save)}
 fun signUp(email:String,password:String,fullName:String,role:String):UserSession?{val req=JSONObject().put("email",email).put("password",password).put("data",JSONObject().put("full_name",fullName).put("role",role));val j=JSONObject(call("${BuildConfig.SUPABASE_URL}/auth/v1/signup","POST",req.toString(),false));val a=j.optString("access_token");return if(a.isBlank())null else UserSession(a,j.optString("refresh_token"),j.getJSONObject("user").getString("id"),email).also(sessionStore::save)}
 fun refresh():UserSession?{val old=sessionStore.load()?:return null;if(old.refreshToken.isBlank())return null;val j=JSONObject(call("${BuildConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token","POST",JSONObject().put("refresh_token",old.refreshToken).toString(),false));return UserSession(j.getString("access_token"),j.optString("refresh_token"),j.getJSONObject("user").getString("id"),old.email).also(sessionStore::save)}
 fun select(table:String,query:String="select=*&limit=500",auth:Boolean=true):JSONArray{val t=call("${BuildConfig.SUPABASE_URL}/rest/v1/$table?$query",auth=auth);return if(t.isBlank())JSONArray() else JSONArray(t)}
 fun insert(table:String,obj:JSONObject):JSONArray=JSONArray(call("${BuildConfig.SUPABASE_URL}/rest/v1/$table","POST",obj.toString(),prefer="return=representation"))
 fun upsert(table:String,obj:JSONObject,onConflict:String?=null):JSONArray{val q=onConflict?.let{"?on_conflict=$it"}.orEmpty();return JSONArray(call("${BuildConfig.SUPABASE_URL}/rest/v1/$table$q","POST",obj.toString(),prefer="resolution=merge-duplicates,return=representation"))}
 fun patch(table:String,filter:String,obj:JSONObject):JSONArray=JSONArray(call("${BuildConfig.SUPABASE_URL}/rest/v1/$table?$filter","PATCH",obj.toString(),prefer="return=representation"))
 fun delete(table:String,filter:String):JSONArray=JSONArray(call("${BuildConfig.SUPABASE_URL}/rest/v1/$table?$filter","DELETE",prefer="return=representation"))
 fun rpc(name:String,args:JSONObject=JSONObject()):String=call("${BuildConfig.SUPABASE_URL}/rest/v1/rpc/$name","POST",args.toString())
 fun function(name:String,args:JSONObject=JSONObject(),auth:Boolean=true)=call("${BuildConfig.SUPABASE_URL}/functions/v1/$name","POST",args.toString(),auth)
 fun raw(method:String,path:String,body:String?):String=call("${BuildConfig.SUPABASE_URL}$path",method,body)
}
