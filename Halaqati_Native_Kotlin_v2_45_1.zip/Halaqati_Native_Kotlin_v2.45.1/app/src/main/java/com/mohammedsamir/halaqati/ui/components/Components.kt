package com.mohammedsamir.halaqati.ui.components
import androidx.compose.animation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable fun AppTopBar(title:String,onBack:(()->Unit)?=null,onRefresh:(()->Unit)?=null,pending:Int=0){CenterAlignedTopAppBar(title={Text(title,fontWeight=FontWeight.Bold)},navigationIcon={if(onBack!=null)IconButton(onClick=onBack){Icon(Icons.AutoMirrored.Filled.ArrowBack,"رجوع")}},actions={if(pending>0)BadgedBox(badge={Badge{Text("$pending")}}){Icon(Icons.Default.CloudUpload,"عمليات معلقة")};if(onRefresh!=null)IconButton(onClick=onRefresh){Icon(Icons.Default.Refresh,"تحديث")}})}
@Composable fun MetricCard(title:String,value:String,subtitle:String="",onClick:(()->Unit)?=null){ElevatedCard(Modifier.fillMaxWidth().then(if(onClick!=null)Modifier.clickable{onClick()} else Modifier),shape=RoundedCornerShape(22.dp)){Column(Modifier.padding(18.dp)){Text(title,style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.primary);Spacer(Modifier.height(6.dp));Text(value,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);if(subtitle.isNotBlank())Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
@Composable fun SyncBanner(online:Boolean,pending:Int,error:String?=null,onSync:()->Unit){AnimatedVisibility(visible=!online||pending>0||error!=null,enter=fadeIn()+expandVertically(),exit=fadeOut()+shrinkVertically()){Surface(color=if(!online)Color(0xFFFFF3CD) else MaterialTheme.colorScheme.secondaryContainer){Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){Icon(if(online)Icons.Default.Sync else Icons.Default.CloudOff,null);Spacer(Modifier.width(8.dp));Text(if(!online)"وضع عدم الاتصال — سيتم الحفظ والمزامنة تلقائيًا" else "لديك $pending تغييرات بانتظار المزامنة",Modifier.weight(1f));if(online)TextButton(onClick=onSync){Text("مزامنة")}}}}}
@Composable fun EmptyState(text:String){Box(Modifier.fillMaxWidth().padding(40.dp),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Inbox,null,Modifier.size(46.dp),tint=MaterialTheme.colorScheme.outline);Text(text,Modifier.padding(top=12.dp),color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
