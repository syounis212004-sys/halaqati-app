package com.mohammedsamir.halaqati
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.mohammedsamir.halaqati.ui.HalaqatiApp
import com.mohammedsamir.halaqati.ui.theme.HalaqatiTheme
class MainActivity: ComponentActivity(){ override fun onCreate(savedInstanceState: Bundle?){ super.onCreate(savedInstanceState); enableEdgeToEdge(); setContent { HalaqatiTheme { HalaqatiApp(initialDeepLink=intent?.data?.toString()) } } } }
