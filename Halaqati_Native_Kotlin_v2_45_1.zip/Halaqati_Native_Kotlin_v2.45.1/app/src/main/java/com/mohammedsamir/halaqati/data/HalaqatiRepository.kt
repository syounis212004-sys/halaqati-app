package com.mohammedsamir.halaqati.data
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.work.*
import com.mohammedsamir.halaqati.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.UUID

class HalaqatiRepository(private val context:Context,val api:SupabaseApi,val store:SecureSessionStore,val queue:OfflineQueue){
 fun loggedIn()=store.load()!=null
 fun signOut()=store.clear()
 fun online():Boolean{val cm=context.getSystemService(ConnectivityManager::class.java);val n=cm.activeNetwork?:return false;return cm.getNetworkCapabilities(n)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)==true}
 fun login(email:String,pw:String)=api.signIn(email,pw)
 fun register(email:String,pw:String,name:String,role:String)=api.signUp(email,pw,name,role)
 fun profile():Profile{val s=store.load()?:error("not signed in");val j=api.select("profiles","select=id,full_name,role,approval_status,email&id=eq.${s.userId}&limit=1").optJSONObject(0)?:JSONObject().put("id",s.userId).put("full_name",s.email).put("role","teacher").put("approval_status","pending");return Profile(j.optString("id"),j.optString("full_name"),UserRole.from(j.optString("role")),j.optString("approval_status"),j.optString("email",s.email))}
 fun students():List<Student>{val arr=api.select("students","select=*&status=neq.deleted&order=full_name.asc&limit=1000");return (0 until arr.length()).mapNotNull{arr.optJSONObject(it)?.let(Student::from)}}
 fun sessions():List<SessionRow>{val arr=api.select("sessions","select=*&order=session_date.desc&limit=300");return (0 until arr.length()).mapNotNull{arr.optJSONObject(it)?.let(SessionRow::from)}}
 fun plans():List<PlanRow>{val arr=api.select("smart_plans","select=*&order=updated_at.desc&limit=500");return (0 until arr.length()).mapNotNull{arr.optJSONObject(it)?.let(PlanRow::from)}}
 fun table(table:String,query:String="select=*&order=created_at.desc&limit=250")=api.select(table,query)
 private fun queued(method:String,path:String,obj:JSONObject?,dedupe:String){queue.add(method,path,obj?.toString(),dedupe);scheduleSync()}
 fun write(table:String,obj:JSONObject,onConflict:String?=null,dedupe:String="${table}:${obj.optString("id",UUID.randomUUID().toString())}"):JSONArray=try{if(!online())throw java.io.IOException("offline");if(onConflict!=null)api.upsert(table,obj,onConflict)else api.insert(table,obj)}catch(e:Exception){queued("POST","/rest/v1/$table${onConflict?.let{"?on_conflict=$it"}.orEmpty()}",obj,dedupe);JSONArray().put(obj)}
 fun patch(table:String,filter:String,obj:JSONObject,dedupe:String="$table:$filter")=try{if(!online())throw java.io.IOException("offline");api.patch(table,filter,obj)}catch(e:Exception){queued("PATCH","/rest/v1/$table?$filter",obj,dedupe);JSONArray().put(obj)}
 fun delete(table:String,filter:String,dedupe:String="$table:$filter:delete")=try{if(!online())throw java.io.IOException("offline");api.delete(table,filter)}catch(e:Exception){queued("DELETE","/rest/v1/$table?$filter",null,dedupe);JSONArray()}
 fun createSession(halaqaId:String,date:String,type:String,title:String):String{val id=UUID.randomUUID().toString();write("sessions",JSONObject().put("id",id).put("halaqa_id",halaqaId).put("session_date",date).put("session_type",type).put("title",title).put("status","open"),"id");return id}
 fun saveAttendance(sessionId:String,studentId:String,status:String){val id=UUID.nameUUIDFromBytes("$sessionId:$studentId".toByteArray()).toString();write("attendance_records",JSONObject().put("id",id).put("session_id",sessionId).put("student_id",studentId).put("status",status),"session_id,student_id","attendance:$sessionId:$studentId")}
 fun saveRecitation(d:RecitationDraft){val id=UUID.randomUUID().toString();val safety=SafetyScoring.calculate(d.pages,d.mistakes,d.prompts);val o=JSONObject().put("id",id).put("student_id",d.studentId).put("session_id",d.sessionId).put("activity_type",d.activityType).put("pages_count",d.pages).put("mistakes",d.mistakes).put("prompts",d.prompts).put("evaluation",d.evaluation).put("safety_percentage",safety).put("notes",d.notes);d.startPage?.let{o.put("start_page",it)};d.endPage?.let{o.put("end_page",it)};write("recitation_entries",o,"id","recitation:$id")}
 fun flushQueue(){if(!online())return;for(i in queue.all()){try{api.raw(i.method,i.path,i.body);queue.done(i.id)}catch(e:Exception){queue.fail(i.id);throw e}}}
 fun scheduleSync(){WorkManager.getInstance(context).enqueueUniqueWork("halaqati-sync-now",ExistingWorkPolicy.REPLACE,OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())}
}
object SafetyScoring{fun calculate(pages:Double,mistakes:Int,prompts:Int):Double{val effective=kotlin.math.max(1.0,pages);val density=(mistakes+prompts*.25)/effective;return (100-density*15).coerceIn(0.0,100.0)};fun inferredEvaluation(safety:Double)=when{ safety>85->"excellent"; safety>=75->"very_good"; safety>=70->"good";else->"repeat"}}
