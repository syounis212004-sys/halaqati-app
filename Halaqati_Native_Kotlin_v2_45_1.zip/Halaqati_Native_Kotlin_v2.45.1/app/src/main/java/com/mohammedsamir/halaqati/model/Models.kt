package com.mohammedsamir.halaqati.model
import org.json.JSONObject

enum class UserRole { ADMIN, SUPERVISOR, TEACHER, GUARDIAN, STUDENT, UNKNOWN;
    companion object { fun from(v:String?)=entries.firstOrNull{it.name.equals(v,true)}?:UNKNOWN }
}
data class UserSession(val accessToken:String,val refreshToken:String,val userId:String,val email:String="")
data class Profile(val id:String,val fullName:String,val role:UserRole,val approvalStatus:String,val email:String="")
data class NavItem(val route:String,val title:String,val iconKey:String)
data class SyncState(val online:Boolean=true,val syncing:Boolean=false,val pending:Int=0,val lastSync:String?=null,val error:String?=null)
data class Metric(val title:String,val value:String,val subtitle:String="")
data class Student(val id:String,val fullName:String,val status:String="active",val track:String="general_hifz",val categoryId:String?=null,val halaqaId:String?=null,val guardianName:String?=null){ companion object{ fun from(j:JSONObject)=Student(j.optString("id"),j.optString("full_name"),j.optString("status","active"),j.optString("track_code","general_hifz"),j.optString("category_id").ifBlank{null},j.optString("halaqa_id").ifBlank{null},j.optString("guardian_name").ifBlank{null}) } }
data class SessionRow(val id:String,val halaqaId:String,val date:String,val type:String,val title:String,val status:String){ companion object{ fun from(j:JSONObject)=SessionRow(j.optString("id"),j.optString("halaqa_id"),j.optString("session_date"),j.optString("session_type"),j.optString("title"),j.optString("status")) } }
data class RecitationDraft(val studentId:String,val sessionId:String,val activityType:String,val startPage:Int?,val endPage:Int?,val pages:Double,val mistakes:Int,val prompts:Int,val evaluation:String,val notes:String="")
data class PlanRow(val id:String,val studentId:String?,val type:String,val target:Double,val status:String,val startDate:String,val endDate:String,val title:String){ companion object{fun from(j:JSONObject)=PlanRow(j.optString("id"),j.optString("student_id").ifBlank{null},j.optString("plan_type"),j.optDouble("target_pages",0.0),j.optString("status"),j.optString("start_date"),j.optString("end_date"),j.optString("title"))}}
