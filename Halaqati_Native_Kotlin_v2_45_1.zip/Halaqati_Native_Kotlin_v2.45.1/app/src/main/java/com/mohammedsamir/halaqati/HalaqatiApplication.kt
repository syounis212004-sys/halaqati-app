package com.mohammedsamir.halaqati
import android.app.Application
import com.mohammedsamir.halaqati.data.AppGraph
class HalaqatiApplication: Application(){ override fun onCreate(){ super.onCreate(); AppGraph.init(this) } }
