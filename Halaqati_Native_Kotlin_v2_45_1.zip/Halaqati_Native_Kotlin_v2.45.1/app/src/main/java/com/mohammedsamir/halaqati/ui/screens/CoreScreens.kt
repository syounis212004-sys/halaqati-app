package com.mohammedsamir.halaqati.ui.screens
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mohammedsamir.halaqati.data.AppGraph
import com.mohammedsamir.halaqati.model.*
import com.mohammedsamir.halaqati.ui.components.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.time.LocalDate

@Composable fun StudentsScreen(pending:Int,onRefresh:()->Unit){
    var rows by remember{mutableStateOf<List<Student>>(emptyList())}
    var loading by remember{mutableStateOf(true)}
    var q by remember{mutableStateOf("")}
    var add by remember{mutableStateOf(false)}
    fun load(){
        loading=true
        CoroutineScope(Dispatchers.IO).launch{
            try{rows=AppGraph.repo.students()}catch(_:Exception){}
            loading=false
        }
    }
    LaunchedEffect(Unit){load()}
    Column{
        AppTopBar("الطلاب",onRefresh={load();onRefresh()},pending=pending)
        Row(Modifier.padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){
            OutlinedTextField(q,{q=it},label={Text("بحث")},leadingIcon={Icon(Icons.Default.Search,null)},modifier=Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            FilledIconButton({add=true}){Icon(Icons.Default.Add,"إضافة")}
        }
        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(rows.filter{q.isBlank()||it.fullName.contains(q,true)},key={it.id}){student->
                ElevatedCard(Modifier.fillMaxWidth()){
                    ListItem(headlineContent={Text(student.fullName)},supportingContent={Text((if(student.track=="tathbit")"مسار التثبيت" else "الحفظ العام")+" · "+student.status)},leadingContent={Icon(Icons.Default.Person,null)})
                }
            }
        }
    }
    if(add) StudentDialog({add=false}){name,track->
        CoroutineScope(Dispatchers.IO).launch{
            AppGraph.repo.write("students",JSONObject().put("full_name",name).put("track_code",track).put("status","active"))
            load()
        }
        add=false
    }
}
@Composable private fun StudentDialog(close:()->Unit,save:(String,String)->Unit){var name by remember{mutableStateOf("")};var track by remember{mutableStateOf("general_hifz")};AlertDialog(onDismissRequest=close,title={Text("طالب جديد")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){OutlinedTextField(name,{name=it},label={Text("اسم الطالب")});Row{FilterChip(track=="general_hifz",{track="general_hifz"},{Text("الحفظ العام")});Spacer(Modifier.width(8.dp));FilterChip(track=="tathbit",{track="tathbit"},{Text("التثبيت")})}}},confirmButton={Button({save(name.trim(),track)},enabled=name.isNotBlank()){Text("حفظ")}},dismissButton={TextButton(close){Text("إلغاء")}})}

@Composable fun SessionsScreen(pending:Int,onRefresh:()->Unit){var rows by remember{mutableStateOf<List<SessionRow>>(emptyList())};var students by remember{mutableStateOf<List<Student>>(emptyList())};var loading by remember{mutableStateOf(true)};var add by remember{mutableStateOf(false)};var active by remember{mutableStateOf<SessionRow?>(null)};fun load(){CoroutineScope(Dispatchers.IO).launch{loading=true;try{rows=AppGraph.repo.sessions();students=AppGraph.repo.students()}catch(_:Exception){};loading=false}};LaunchedEffect(Unit){load()};Column{AppTopBar("الجلسات اليومية",onRefresh={load();onRefresh()},pending=pending);Row(Modifier.padding(12.dp)){Button({add=true}){Icon(Icons.Default.Add,null);Text(" جلسة")};Spacer(Modifier.width(8.dp));AssistChip({},{label={Text("تسميع · سرد · مراجعة · اختبار · نشاط")}})};if(loading)LinearProgressIndicator(Modifier.fillMaxWidth());LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(rows,key={it.id}){s->ElevatedCard(onClick={active=s},modifier=Modifier.fillMaxWidth()){ListItem(headlineContent={Text(s.title.ifBlank{sessionTypeAr(s.type)})},supportingContent={Text("${s.date} · ${sessionTypeAr(s.type)} · ${if(s.status=="open")"مفتوحة" else "مرفوعة"}")},leadingContent={Icon(Icons.Default.Event,null)},trailingContent={Icon(Icons.Default.ChevronLeft,null)})}}}};if(add)NewSessionDialog({add=false}){date,type,title->CoroutineScope(Dispatchers.IO).launch{val halaqa=try{AppGraph.repo.table("halaqas","select=id&limit=1").optJSONObject(0)?.optString("id").orEmpty()}catch(_:Exception){""};if(halaqa.isNotBlank())AppGraph.repo.createSession(halaqa,date,type,title);load()};add=false};active?.let{SessionRosterDialog(it,students,{active=null},load)}}
fun sessionTypeAr(t:String)=when(t){"tasmee"->"تسميع";"sard"->"سرد";"review"->"مراجعة";"test"->"اختبار";"lesson"->"نشاط تربوي";else->t}
@Composable private fun NewSessionDialog(close:()->Unit,save:(String,String,String)->Unit){var date by remember{mutableStateOf(LocalDate.now().toString())};var type by remember{mutableStateOf("tasmee")};var title by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("جلسة جديدة")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(date,{date=it},label={Text("التاريخ YYYY-MM-DD")});OutlinedTextField(title,{title=it},label={Text("العنوان (اختياري)")});SingleChoiceSegmentedButtonRow{listOf("tasmee","sard","review","test","lesson").forEachIndexed{i,v->SegmentedButton(type==v,{type=v},SegmentedButtonDefaults.itemShape(i,5)){Text(sessionTypeAr(v))}}}}},confirmButton={Button({save(date,type,title)}){Text("حفظ وفتح")}},dismissButton={TextButton(close){Text("إلغاء")}})}
@Composable private fun SessionRosterDialog(s:SessionRow,students:List<Student>,close:()->Unit,reload:()->Unit){var selected by remember{mutableStateOf<Student?>(null)};AlertDialog(onDismissRequest=close,title={Text(s.title.ifBlank{sessionTypeAr(s.type)})},text={LazyColumn(Modifier.heightIn(max=520.dp)){items(students,key={it.id}){st->ListItem(headlineContent={Text(st.fullName)},supportingContent={Row{TextButton({CoroutineScope(Dispatchers.IO).launch{AppGraph.repo.saveAttendance(s.id,st.id,"present")}}){Text("حاضر")};TextButton({CoroutineScope(Dispatchers.IO).launch{AppGraph.repo.saveAttendance(s.id,st.id,"absent")}}){Text("غائب")};TextButton({selected=st}){Text("تسميع")}}})}}},confirmButton={Button(close){Text("إغلاق")}});selected?.let{RecitationDialog(it,s,{selected=null})}}
@Composable private fun RecitationDialog(st:Student,s:SessionRow,close:()->Unit){var start by remember{mutableStateOf("")};var end by remember{mutableStateOf("")};var pages by remember{mutableStateOf("1")};var mistakes by remember{mutableStateOf("0")};var prompts by remember{mutableStateOf("0")};var eval by remember{mutableStateOf("good")};AlertDialog(onDismissRequest=close,title={Text("تسميع ${st.fullName}")},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){Row{OutlinedTextField(start,{start=it},label={Text("من صفحة")},Modifier.weight(1f));Spacer(Modifier.width(6.dp));OutlinedTextField(end,{end=it},label={Text("إلى صفحة")},Modifier.weight(1f))};OutlinedTextField(pages,{pages=it},label={Text("عدد الصفحات")});Row{OutlinedTextField(mistakes,{mistakes=it},label={Text("أخطاء")},Modifier.weight(1f));Spacer(Modifier.width(6.dp));OutlinedTextField(prompts,{prompts=it},label={Text("تلقين")},Modifier.weight(1f))};Row{listOf("excellent" to "ممتاز","very_good" to "جيد جدًا","good" to "جيد","repeat" to "إعادة").forEach{(v,l)->FilterChip(eval==v,{eval=v},{Text(l)},Modifier.padding(end=3.dp))}}}},confirmButton={Button({CoroutineScope(Dispatchers.IO).launch{AppGraph.repo.saveRecitation(RecitationDraft(st.id,s.id,when(s.type){"sard"->"sard";"review"->"review_near";else->"new_hifz"},start.toIntOrNull(),end.toIntOrNull(),pages.toDoubleOrNull()?:0.0,mistakes.toIntOrNull()?:0,prompts.toIntOrNull()?:0,eval))};close()}){Text("حفظ")}},dismissButton={TextButton(close){Text("إلغاء")}})}

@Composable fun PlansScreen(p:Profile,pending:Int,onRefresh:()->Unit){var rows by remember{mutableStateOf<List<PlanRow>>(emptyList())};var loading by remember{mutableStateOf(true)};fun load(){CoroutineScope(Dispatchers.IO).launch{loading=true;try{rows=AppGraph.repo.plans()}catch(_:Exception){};loading=false}};LaunchedEffect(Unit){load()};Column{AppTopBar(if(p.role==UserRole.GUARDIAN)"خطط الأبناء" else "الخطط الذكية",onRefresh={load();onRefresh()},pending=pending);if(loading)LinearProgressIndicator(Modifier.fillMaxWidth());LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(rows,key={it.id}){pl->ElevatedCard(Modifier.fillMaxWidth()){ListItem(headlineContent={Text(pl.title.ifBlank{planTypeAr(pl.type)})},supportingContent={Text("${planTypeAr(pl.type)} · ${pl.target} صفحة · ${pl.startDate} ← ${pl.endDate}\n${pl.status}")},leadingContent={Icon(Icons.Default.Timeline,null)})}};item{Text("يدعم المحرك Native نفس أنواع الخطة: حفظ، مراجعة، سرد، تثبيت، ونطاقات الصفحات والأحداث اليدوية.",Modifier.padding(8.dp),style=MaterialTheme.typography.bodySmall)}}}}
fun planTypeAr(v:String)=when(v){"hifz"->"حفظ";"review"->"مراجعة";"sard"->"سرد";"tathbit"->"تثبيت";else->v}

@Composable fun HalaqasScreen(pending:Int,onRefresh:()->Unit)=GenericDataScreen("الحلقات والفئات","halaqas",pending,onRefresh,secondary="student_categories")
@Composable fun CommunityScreen(pending:Int,onRefresh:()->Unit)=GenericDataScreen("الإعلانات والمجتمع","announcements",pending,onRefresh,secondary="forum_posts")
@Composable fun UsersScreen(pending:Int,onRefresh:()->Unit)=GenericDataScreen("الحسابات والصلاحيات","profiles",pending,onRefresh)
@Composable fun GuardianProfileScreen(p:Profile,pending:Int,onRefresh:()->Unit)=GenericDataScreen("ملف الطالب","students",pending,onRefresh)

@Composable fun GenericDataScreen(title:String,table:String,pending:Int,onRefresh:()->Unit,secondary:String?=null){
    var rows by remember{mutableStateOf<List<JSONObject>>(emptyList())}
    var loading by remember{mutableStateOf(true)}
    fun load(){
        CoroutineScope(Dispatchers.IO).launch{
            loading=true
            try{val a=AppGraph.repo.table(table);rows=(0 until a.length()).mapNotNull{a.optJSONObject(it)}}catch(_:Exception){}
            loading=false
        }
    }
    LaunchedEffect(table){load()}
    Column{
        AppTopBar(title,onRefresh={load();onRefresh()},pending=pending)
        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if(rows.isEmpty()&&!loading) EmptyState("لا توجد بيانات")
        LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(rows.size){i->
                val j=rows[i]
                ElevatedCard(Modifier.fillMaxWidth()){
                    ListItem(
                        headlineContent={Text(j.optString("full_name",j.optString("title",j.optString("name","سجل"))))},
                        supportingContent={Text(listOf(j.optString("session_date"),j.optString("status"),j.optString("body")).filter{it.isNotBlank()}.take(2).joinToString(" · "))}
                    )
                }
            }
            secondary?.let{item{Text("يشمل أيضًا: $it",style=MaterialTheme.typography.labelMedium,modifier=Modifier.padding(8.dp))}}
        }
    }
}
