package com.mohammedsamir.halaqati.push
import android.app.*
import android.content.*
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import com.mohammedsamir.halaqati.MainActivity
object NotificationHelper{private const val C="halaqati";fun show(ctx:Context,title:String,body:String,deep:String?){val nm=ctx.getSystemService(NotificationManager::class.java);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(C,"إشعارات حلقتي",NotificationManager.IMPORTANCE_DEFAULT));val i=Intent(ctx,MainActivity::class.java).apply{flags=Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP;deep?.let{data=Uri.parse(it)}};val pi=PendingIntent.getActivity(ctx,1,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);nm.notify((System.currentTimeMillis()%Int.MAX_VALUE).toInt(),NotificationCompat.Builder(ctx,C).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(pi).build())}}
