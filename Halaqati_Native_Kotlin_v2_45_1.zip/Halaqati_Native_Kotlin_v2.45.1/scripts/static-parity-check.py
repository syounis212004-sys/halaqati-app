from pathlib import Path
required=['app/src/main/java/com/mohammedsamir/halaqati/MainActivity.kt','app/src/main/java/com/mohammedsamir/halaqati/data/SupabaseApi.kt','app/src/main/java/com/mohammedsamir/halaqati/data/OfflineQueue.kt','app/src/main/java/com/mohammedsamir/halaqati/ui/screens/CoreScreens.kt','app/src/main/java/com/mohammedsamir/halaqati/ui/screens/ReportsAndTools.kt','migration/source-contract.json','migration/parity-matrix.md']
missing=[x for x in required if not Path(x).exists()]
assert not missing,missing
alltext='\n'.join(Path(x).read_text(errors='ignore') for x in required if x.endswith('.kt'))
assert 'WebView' not in alltext
assert 'com.mohammedsamir.halaqati' in Path('app/build.gradle.kts').read_text()
assert 'versionCode = 24501' in Path('app/build.gradle.kts').read_text()
print('Native structure/parity smoke check passed')
